// LEVIATHAN · PROCUREMENT — THE ASK, recounted from raw
//
// Not derived from the wiki's prose this time. Built by merging every
// Annie-thread export in wiki-brain's raw/self/message-csv/, converting the
// one UTC-stamped export to local time (it was producing phantom duplicates
// four hours off), deduplicating on text within a 120-second window, and
// keeping her side only: 18,946 messages from her, 2025-02-01 → 2026-06-05,
// with every month covered.
//
// Classification is frame-and-object, not keyword: a request has to be a
// speech act aimed at somebody AND name what it is for. Every hit was then
// read by hand and false positives struck — the per-category precision that
// survived that audit ships in `meta.precision` and is displayed on the
// instrument, because a number nobody can check is not evidence.
//
// wiki-brain is a public repository, which is why these lines can sit on an
// unencrypted page: they were already published.
(function () {
  window.ProcurementAsks = {
 "meta": {
  "herMessages": 18946,
  "from": "2025-02-01",
  "to": "2026-06-05",
  "files": [
   "imessage_2124702449_both_all_now.csv",
   "imessage_7244346811+2124702449_both_all_now.csv",
   "imessage_2124702449_both_2025-05-14_now.csv",
   "imessage_2124702449_received_2025-06-01_now.csv",
   "imessage_2124702449_received_2026-01-01_2026-06-05.csv",
   "imessages_2124702449_last6months.csv",
   "annie_all_time_logs.csv",
   "imessage_ALL_both_all_now.csv",
   "MASTER_MESSAGES_DB_DUMP.csv"
  ],
  "precision": {
   "fund": 96,
   "order": 94,
   "chase": 80,
   "askSupply": 100,
   "askMoney": 75,
   "askOther": 57,
   "ask3p": 100,
   "denom": 97,
   "want": 88,
   "see": 100,
   "code": 100
  },
  "dollarsStated": 2629,
  "dollarMentions": 68,
  "atmRuns": 32,
  "denomOrders": 42,
  "total": 357
 },
 "records": [
  {
   "d": "2025-02-28",
   "t": "19:01",
   "k": "askOther",
   "x": "Could you maybe come get me here"
  },
  {
   "d": "2025-03-01",
   "t": "16:00",
   "k": "askSupply",
   "x": "Then just ask her to get me a whole"
  },
  {
   "d": "2025-03-01",
   "t": "16:03",
   "k": "fund",
   "x": "I’ll send the money if you can go to atm"
  },
  {
   "d": "2025-03-05",
   "t": "16:43",
   "k": "denom",
   "x": "I said 50"
  },
  {
   "d": "2025-03-07",
   "t": "11:41",
   "k": "want",
   "x": "Like I will definitely want to get something after this nonsense.. waiting for lunch to get here"
  },
  {
   "d": "2025-03-07",
   "t": "17:51",
   "k": "want",
   "x": "Or I am going to just say I am going to get it myself"
  },
  {
   "d": "2025-03-11",
   "t": "17:13",
   "k": "chase",
   "x": "Should I assume there is no way of any one getting any drugs"
  },
  {
   "d": "2025-03-13",
   "t": "18:26",
   "k": "askOther",
   "x": "Back home gonna have dinner soon maybe you should come get me after bc I am gonna make a wittle martini"
  },
  {
   "d": "2025-03-13",
   "t": "18:39",
   "k": "order",
   "x": "I want drugs"
  },
  {
   "d": "2025-03-13",
   "t": "18:51",
   "k": "ask3p",
   "x": "Unless.. I can put in 50 and ask my Mom to send me fifty tomorrow for the phone bill"
  },
  {
   "d": "2025-03-16",
   "t": "13:35",
   "k": "want",
   "x": "Sooooo are you going to get something to today you gonna share with Eggie"
  },
  {
   "d": "2025-03-16",
   "t": "14:21",
   "k": "want",
   "x": "Have you told her “I want to get something for myself”"
  },
  {
   "d": "2025-03-18",
   "t": "12:52",
   "k": "fund",
   "x": "I have $20 cash from Geeg"
  },
  {
   "d": "2025-03-18",
   "t": "12:53",
   "k": "fund",
   "x": "So I have $20 cash. I hope to goddddd I get paid SOMETHING"
  },
  {
   "d": "2025-03-18",
   "t": "17:36",
   "k": "order",
   "x": "I figure if we getting a whole one he would probably come sooner than later as opposed to getting some small"
  },
  {
   "d": "2025-03-18",
   "t": "18:44",
   "k": "askOther",
   "x": "And you can bring me my shit and I’ll leave you the fuck alone"
  },
  {
   "d": "2025-03-25",
   "t": "22:25",
   "k": "want",
   "x": "Get it."
  },
  {
   "d": "2025-03-26",
   "t": "17:08",
   "k": "order",
   "x": "I want drugs"
  },
  {
   "d": "2025-03-29",
   "t": "18:51",
   "k": "want",
   "x": "Did she get anything today."
  },
  {
   "d": "2025-03-30",
   "t": "13:20",
   "k": "want",
   "x": "Well Claire is on her way home. So hopefully she will be paying me today. Not exactly sure how much. But I do have $25 cash. So I’ll let you know so we can get something"
  },
  {
   "d": "2025-04-02",
   "t": "18:12",
   "k": "want",
   "x": "Trying to get a little money together so maybe we can get something small"
  },
  {
   "d": "2025-04-03",
   "t": "15:14",
   "k": "denom",
   "x": "Maybe 20"
  },
  {
   "d": "2025-04-03",
   "t": "20:05",
   "k": "askSupply",
   "x": "ca. you please bring me a one hitter"
  },
  {
   "d": "2025-04-05",
   "t": "07:32",
   "k": "see",
   "x": "So wait did you ever end up seeing him"
  },
  {
   "d": "2025-04-08",
   "t": "15:21",
   "k": "askOther",
   "x": "Then come get me."
  },
  {
   "d": "2025-04-10",
   "t": "17:37",
   "k": "ask3p",
   "x": "I need to ask my mom to send me money for cleaning yesterday"
  },
  {
   "d": "2025-04-10",
   "t": "18:58",
   "k": "fund",
   "x": "can you tell her 40 I have $15 cash and will go to atm now"
  },
  {
   "d": "2025-04-10",
   "t": "18:59",
   "k": "denom",
   "x": "40"
  },
  {
   "d": "2025-04-11",
   "t": "16:48",
   "k": "want",
   "x": "Either I want to send your mom money to get something… and you send money back for the bill or get something in exchange for me covering the bill"
  },
  {
   "d": "2025-04-11",
   "t": "17:03",
   "k": "denom",
   "x": "It was not"
  },
  {
   "d": "2025-04-11",
   "t": "17:27",
   "k": "ask3p",
   "x": "If I can get my mom to send me a little Money to make sure my account doesn’t get overdrawn then I will pay for $40."
  },
  {
   "d": "2025-04-12",
   "t": "14:31",
   "k": "order",
   "x": "I want the drugs now"
  },
  {
   "d": "2025-04-14",
   "t": "12:32",
   "k": "denom",
   "x": "$70?"
  },
  {
   "d": "2025-04-14",
   "t": "13:00",
   "k": "fund",
   "x": "I have $20 cash"
  },
  {
   "d": "2025-04-15",
   "t": "14:01",
   "k": "want",
   "x": "I am going back to sugies at 3:00. Staying until 5:00. My mom is supposed to meet me there and get me a check. I was planning to come over after I leave there. If you want me to of course. If you want to try to get one whole one today we can"
  },
  {
   "d": "2025-04-17",
   "t": "09:47",
   "k": "want",
   "x": "Did you get a whole piece of toast"
  },
  {
   "d": "2025-04-17",
   "t": "09:53",
   "k": "order",
   "x": "If we could get a whole one"
  },
  {
   "d": "2025-04-17",
   "t": "09:54",
   "k": "order",
   "x": "so yeah get a whole one and we ain’t sharing"
  },
  {
   "d": "2025-04-19",
   "t": "09:48",
   "k": "order",
   "x": "I can’t get a full one"
  },
  {
   "d": "2025-04-19",
   "t": "12:20",
   "k": "order",
   "x": "You told me that there’s no fucking way that I can get anything unless I’m getting a full one"
  },
  {
   "d": "2025-04-19",
   "t": "12:21",
   "k": "fund",
   "x": "I’ll fucking go to the atm"
  },
  {
   "d": "2025-04-22",
   "t": "07:25",
   "k": "askOther",
   "x": "Can I come get Betty after I leave here so I can feed her and I can shower and sleep just a little bit then come back over"
  },
  {
   "d": "2025-04-23",
   "t": "13:09",
   "k": "want",
   "x": "If you want to get something today we can.. maybe not share as much this time with your mom. I dont know. But if you want to I have my card, but I don’t have a car today"
  },
  {
   "d": "2025-04-25",
   "t": "12:25",
   "k": "want",
   "x": "Ok… well let me know if you want to get anything today. We just finished lunch here."
  },
  {
   "d": "2025-04-25",
   "t": "14:11",
   "k": "fund",
   "x": "Should I go to the atm now and come there before I go back to get sugie up"
  },
  {
   "d": "2025-04-25",
   "t": "21:58",
   "k": "want",
   "x": "Did your mom also get something"
  },
  {
   "d": "2025-04-27",
   "t": "16:36",
   "k": "askSupply",
   "x": "Bring me a one hitter please"
  },
  {
   "d": "2025-04-29",
   "t": "07:59",
   "k": "order",
   "x": "When I leave here, I’ll go get her money from the atm. I dont know if its still possible to get something less than a full one from him.. but since i wont have enough to get a full one could we get something else like 60"
  },
  {
   "d": "2025-05-03",
   "t": "20:36",
   "k": "want",
   "x": "I was just questioning bc I didn’t ask her in the first place to bring me any if she did get something"
  },
  {
   "d": "2025-05-03",
   "t": "22:21",
   "k": "want",
   "x": "If you want to come get it yeah"
  },
  {
   "d": "2025-05-05",
   "t": "08:56",
   "k": "askSupply",
   "x": "If I bring the money after the bank can you please bring me a one hitter out side"
  },
  {
   "d": "2025-05-05",
   "t": "14:31",
   "k": "see",
   "x": "So when are you coming back"
  },
  {
   "d": "2025-05-05",
   "t": "15:19",
   "k": "see",
   "x": "You were all “he knows you want to see him in the morning” blah blah blah"
  },
  {
   "d": "2025-05-07",
   "t": "17:12",
   "k": "fund",
   "x": "I dont know if she has enough or would want to but I have $30. Just throwing it out there. It won’t be a big deal"
  },
  {
   "d": "2025-05-07",
   "t": "17:25",
   "k": "fund",
   "x": "Do you have enough cash there to cover my $30 if I am not there in time? I have the cash already"
  },
  {
   "d": "2025-05-10",
   "t": "17:39",
   "k": "want",
   "x": "You’ll probably say no and hate me for even asking but your mom mentioned she may be texting him. I dont know if it would be possible to owe her anything to get something. I’ll cash check Monday morning"
  },
  {
   "d": "2025-05-13",
   "t": "17:50",
   "k": "fund",
   "x": "I have $20."
  },
  {
   "d": "2025-05-13",
   "t": "17:51",
   "k": "order",
   "x": "see if he will do a half. $60. I’ll owe $40 until tomorrow morning"
  },
  {
   "d": "2025-05-16",
   "t": "12:55",
   "k": "fund",
   "x": "But I dont know if I will have enough for one full one. I dont know yet"
  },
  {
   "d": "2025-05-18",
   "t": "14:56",
   "k": "order",
   "x": "I want other drugs"
  },
  {
   "d": "2025-05-19",
   "t": "15:19",
   "k": "order",
   "x": "I guess get a full one??"
  },
  {
   "d": "2025-05-19",
   "t": "16:46",
   "k": "askOther",
   "x": "Ok can I come get it"
  },
  {
   "d": "2025-05-20",
   "t": "16:15",
   "k": "denom",
   "x": "45"
  },
  {
   "d": "2025-05-20",
   "t": "16:44",
   "k": "want",
   "x": "I gotta go upstairs and get it"
  },
  {
   "d": "2025-05-22",
   "t": "14:17",
   "k": "want",
   "x": "I mean i obviously have some left but might as well get it today since ill be at both sugies and my uncles house back and forth tomorrow"
  },
  {
   "d": "2025-05-23",
   "t": "23:13",
   "k": "see",
   "x": "So is he coming tonight or not"
  },
  {
   "d": "2025-05-31",
   "t": "23:24",
   "k": "askSupply",
   "x": "Can you get me a little bit of weed to bring back with me"
  },
  {
   "d": "2025-06-03",
   "t": "09:02",
   "k": "askMoney",
   "x": "Unless she can spot me until I get check tomorrow"
  },
  {
   "d": "2025-06-03",
   "t": "20:23",
   "k": "order",
   "x": "Didn’t even ask her for a line 🤥"
  },
  {
   "d": "2025-06-05",
   "t": "10:52",
   "k": "fund",
   "x": "They are filling my prescription now.. so I will come give you the money in a little bit.."
  },
  {
   "d": "2025-06-07",
   "t": "11:30",
   "k": "fund",
   "x": "I have $20 right now."
  },
  {
   "d": "2025-06-07",
   "t": "12:24",
   "k": "fund",
   "x": "I have fifty."
  },
  {
   "d": "2025-06-08",
   "t": "12:01",
   "k": "fund",
   "x": "I have fifty."
  },
  {
   "d": "2025-06-11",
   "t": "12:26",
   "k": "order",
   "x": "I told her a full one"
  },
  {
   "d": "2025-06-11",
   "t": "12:26",
   "k": "fund",
   "x": "But I have the cash they let me cash it"
  },
  {
   "d": "2025-06-12",
   "t": "10:48",
   "k": "fund",
   "x": "I’ll bring you cash I guess. Not a full one. $I may have sixty. I dont know yet. I’m in serious pain right now"
  },
  {
   "d": "2025-06-13",
   "t": "11:13",
   "k": "want",
   "x": "I will try to get a little money today to at least be able to get something"
  },
  {
   "d": "2025-06-14",
   "t": "10:17",
   "k": "fund",
   "x": "I will come over in a little while.. I am going to try to do a payment plan for the phone bill since I doubt it’ll get paid by tomorrow. So I guess if you want to tell your mom to text him I have sixty."
  },
  {
   "d": "2025-06-15",
   "t": "13:43",
   "k": "fund",
   "x": "Well I am trying to get some money together for today.. I’ll probably have fifty."
  },
  {
   "d": "2025-06-15",
   "t": "14:04",
   "k": "fund",
   "x": "I have thirty cash right now.. if I have to take my last twenty out the atm I will."
  },
  {
   "d": "2025-06-15",
   "t": "15:00",
   "k": "fund",
   "x": "I’m trying to get money"
  },
  {
   "d": "2025-06-17",
   "t": "11:11",
   "k": "denom",
   "x": "I have 75 total."
  },
  {
   "d": "2025-06-17",
   "t": "23:03",
   "k": "want",
   "x": "I wouldn’t ever get anything and not make sure you have something too"
  },
  {
   "d": "2025-06-18",
   "t": "17:34",
   "k": "fund",
   "x": "Sent a text at the same time as you saying do you need money for a sub"
  },
  {
   "d": "2025-06-19",
   "t": "11:52",
   "k": "want",
   "x": "And asked me if I was going to get anything"
  },
  {
   "d": "2025-06-19",
   "t": "11:55",
   "k": "want",
   "x": "To be able to get something"
  },
  {
   "d": "2025-06-20",
   "t": "22:24",
   "k": "want",
   "x": "Seriously.. I’m not going anywhere ever. I can come over and get it Dan."
  },
  {
   "d": "2025-06-24",
   "t": "09:13",
   "k": "order",
   "x": "Got check. Need to shower first. Then I’ll cash it and I’ll be over. Tell your mom I want a full one"
  },
  {
   "d": "2025-06-26",
   "t": "09:19",
   "k": "see",
   "x": "Let me see him please"
  },
  {
   "d": "2025-06-28",
   "t": "11:47",
   "k": "fund",
   "x": "I texted your mom. I have the money."
  },
  {
   "d": "2025-07-01",
   "t": "07:58",
   "k": "want",
   "x": "And i dont know how you expect me to be able to get anything today when I do t have money. And he absolutely ripped us off yesterday unless your mom took a bunch of it out for herself."
  },
  {
   "d": "2025-07-01",
   "t": "12:36",
   "k": "fund",
   "x": "I’ll bring $60 over."
  },
  {
   "d": "2025-07-03",
   "t": "20:30",
   "k": "want",
   "x": "I will fucking get it to you"
  },
  {
   "d": "2025-07-05",
   "t": "11:58",
   "k": "fund",
   "x": "I have sixty."
  },
  {
   "d": "2025-07-05",
   "t": "20:31",
   "k": "chase",
   "x": "Alright.. I’m assuming still nothing from bop"
  },
  {
   "d": "2025-07-07",
   "t": "09:01",
   "k": "order",
   "x": "So I guess tell him a full one"
  },
  {
   "d": "2025-07-08",
   "t": "20:46",
   "k": "order",
   "x": "Before I left your mom said she was goi g to see what bop was up to and maybe see if she can get something.. I am goi g to do my best to try to come up with money to get a half one so I’ll let you know if I have any success"
  },
  {
   "d": "2025-07-09",
   "t": "08:29",
   "k": "order",
   "x": "My dad and I are going to take the Lexus to get oil changed soon. I got a check. Still need to get cashed when bank opens. Tell him I want a full one."
  },
  {
   "d": "2025-07-09",
   "t": "09:38",
   "k": "fund",
   "x": "I have the cash. I’ll be over when my dad comes back with his car since mine isn’t here."
  },
  {
   "d": "2025-07-09",
   "t": "12:21",
   "k": "see",
   "x": "Excuse me when is he coming"
  },
  {
   "d": "2025-07-09",
   "t": "14:20",
   "k": "want",
   "x": "I will get it"
  },
  {
   "d": "2025-07-10",
   "t": "15:13",
   "k": "see",
   "x": "When is he coming"
  },
  {
   "d": "2025-07-11",
   "t": "11:25",
   "k": "order",
   "x": "And I plan on asking her to write me a check today after her nap. Need to pay the second payment plan for phone bill tomorrow. I may have enough left to get half a one later. I dont know yet."
  },
  {
   "d": "2025-07-12",
   "t": "21:29",
   "k": "see",
   "x": "Is he coming."
  },
  {
   "d": "2025-07-16",
   "t": "14:56",
   "k": "denom",
   "x": "Fifty."
  },
  {
   "d": "2025-07-26",
   "t": "15:36",
   "k": "fund",
   "x": "I have twenty. Gotta get my last ten out of the atm. But then I won’t have money for gas."
  },
  {
   "d": "2025-07-26",
   "t": "15:39",
   "k": "denom",
   "x": "I just didn’t think he would come for 30"
  },
  {
   "d": "2025-07-28",
   "t": "10:31",
   "k": "fund",
   "x": "I get you money for your subs."
  },
  {
   "d": "2025-07-29",
   "t": "14:52",
   "k": "fund",
   "x": "I have sixty"
  },
  {
   "d": "2025-07-31",
   "t": "14:08",
   "k": "fund",
   "x": "Going to the atm in a couple minutes"
  },
  {
   "d": "2025-08-01",
   "t": "10:26",
   "k": "order",
   "x": "Good morning. I will have enough to get a full one this afternoon"
  },
  {
   "d": "2025-08-03",
   "t": "15:05",
   "k": "fund",
   "x": "Well I know you probably hate me and want nothing to do with me. But I have sixty if you wanted to tell him. If not I understand"
  },
  {
   "d": "2025-08-05",
   "t": "11:44",
   "k": "fund",
   "x": "Good morning I’m about to get a shower and I’ll be over after. I am trying to get some money together to get sixty.. I have twenty so far. But i also gotta get money for gas."
  },
  {
   "d": "2025-08-05",
   "t": "15:24",
   "k": "fund",
   "x": "I have fifty dollars. I dont know if that means anything"
  },
  {
   "d": "2025-08-05",
   "t": "15:31",
   "k": "fund",
   "x": "I will bring the money in a few minutes then go pick up dinner"
  },
  {
   "d": "2025-08-06",
   "t": "11:51",
   "k": "want",
   "x": "I’ll get it over as soon as I can"
  },
  {
   "d": "2025-08-07",
   "t": "12:08",
   "k": "denom",
   "x": "Yeah. 60"
  },
  {
   "d": "2025-08-07",
   "t": "12:30",
   "k": "fund",
   "x": "Claire is coming back to get the kids then I’ll go to the atm"
  },
  {
   "d": "2025-08-13",
   "t": "18:07",
   "k": "fund",
   "x": "I have forty."
  },
  {
   "d": "2025-08-13",
   "t": "18:10",
   "k": "fund",
   "x": "I have to go to the atm"
  },
  {
   "d": "2025-08-14",
   "t": "15:50",
   "k": "want",
   "x": "I’m going g to be responsible and say just have him pick up James money and not get anything else if I do get my money"
  },
  {
   "d": "2025-08-14",
   "t": "17:45",
   "k": "fund",
   "x": "Can I just send it to your mom and you can go to the ATM"
  },
  {
   "d": "2025-08-15",
   "t": "10:39",
   "k": "order",
   "x": "I should have enough to get a whole one sometime this afternoon"
  },
  {
   "d": "2025-08-15",
   "t": "12:30",
   "k": "order",
   "x": "Tell bop I want a full one"
  },
  {
   "d": "2025-08-19",
   "t": "08:04",
   "k": "want",
   "x": "But there really isn’t any left for real. I will try to get some extra money if possible t o get something today"
  },
  {
   "d": "2025-08-19",
   "t": "19:05",
   "k": "want",
   "x": "Get it"
  },
  {
   "d": "2025-08-21",
   "t": "09:07",
   "k": "fund",
   "x": "Yes. I’ll bring money over in a little bit. I have sixty"
  },
  {
   "d": "2025-08-21",
   "t": "14:07",
   "k": "want",
   "x": "I can come get it instead of you dropping off"
  },
  {
   "d": "2025-08-23",
   "t": "09:03",
   "k": "see",
   "x": "I will try to get you some money to see tom okay?"
  },
  {
   "d": "2025-08-23",
   "t": "13:13",
   "k": "want",
   "x": "Alright I think I may have fifty to get something. And fifteen for you to see tom. I’ll let you know for sure"
  },
  {
   "d": "2025-08-25",
   "t": "11:38",
   "k": "order",
   "x": "I’ll get a whole one okay"
  },
  {
   "d": "2025-08-25",
   "t": "15:31",
   "k": "fund",
   "x": "I’ll let you know when I have money."
  },
  {
   "d": "2025-08-25",
   "t": "17:57",
   "k": "denom",
   "x": "I have $120"
  },
  {
   "d": "2025-08-28",
   "t": "11:50",
   "k": "askMoney",
   "x": "Unless your mom has anything she can spot me until tomorrow"
  },
  {
   "d": "2025-08-29",
   "t": "14:55",
   "k": "denom",
   "x": "60"
  },
  {
   "d": "2025-08-30",
   "t": "10:05",
   "k": "fund",
   "x": "Im not cheating on you. I haven’t seen anyone. Yes I take full accountability for how I have treated you Dan. I am fucked up. I am a horrible person. I seriously am. And I regret all of the shit I have put you through. I have to go to fucking Marika’s now for a stupid tye dye party for the kids. I have fifty cash. Thats it. I dont know if you want me to drop it off on my way over to her house or what. I guess let me know."
  },
  {
   "d": "2025-09-01",
   "t": "10:51",
   "k": "fund",
   "x": "I have sixty dollars"
  },
  {
   "d": "2025-09-07",
   "t": "14:38",
   "k": "want",
   "x": "I wouldn’t even know who to get anything from Dan,"
  },
  {
   "d": "2025-09-07",
   "t": "14:39",
   "k": "want",
   "x": "I said I will be getting a check tomorrow and we will get one like we always do on Monday"
  },
  {
   "d": "2025-09-16",
   "t": "10:37",
   "k": "ask3p",
   "x": "I’m trying to get my mom to send me some money. She’s mad because I keep asking for her and it’s always “this is is the last time I’m done sending you money”"
  },
  {
   "d": "2025-09-16",
   "t": "10:47",
   "k": "see",
   "x": "How much do you need to see tom. I’m just confused"
  },
  {
   "d": "2025-09-16",
   "t": "13:10",
   "k": "see",
   "x": "I made that happen bc you needed to see tom"
  },
  {
   "d": "2025-09-16",
   "t": "17:39",
   "k": "see",
   "x": "Did you end up seeing tom?"
  },
  {
   "d": "2025-09-17",
   "t": "17:04",
   "k": "fund",
   "x": "Ok thank you I’ll leave and go to the atm now"
  },
  {
   "d": "2025-09-17",
   "t": "21:51",
   "k": "want",
   "x": "Hope you got back from seeing tom okay. I believe i will have some money at some point tomorrow hopefully and we will get something. Miss you. Goodnight Dan"
  },
  {
   "d": "2025-09-18",
   "t": "12:06",
   "k": "fund",
   "x": "I have the money"
  },
  {
   "d": "2025-09-19",
   "t": "11:37",
   "k": "want",
   "x": "I should have a check sometime this afternoon to hopefully get something"
  },
  {
   "d": "2025-09-20",
   "t": "09:56",
   "k": "want",
   "x": "I’m sorry Dan. I know that’s probably annoying.. but I dont have any money at all left to get anything.. if by some miracle I can get some money today we will get something"
  },
  {
   "d": "2025-09-20",
   "t": "11:37",
   "k": "fund",
   "x": "Well I have twenty dollars if that means anything"
  },
  {
   "d": "2025-09-23",
   "t": "10:58",
   "k": "ask3p",
   "x": "I asked my mom if she could send me some money. I’ll let you know if she can"
  },
  {
   "d": "2025-09-23",
   "t": "12:26",
   "k": "denom",
   "x": "60"
  },
  {
   "d": "2025-09-25",
   "t": "10:37",
   "k": "fund",
   "x": "I mean I have the money. But it’s supposed to be for phone payment tomorrow"
  },
  {
   "d": "2025-09-25",
   "t": "10:39",
   "k": "fund",
   "x": "But I don’t want to go out in the rain right now to go to the atm"
  },
  {
   "d": "2025-09-28",
   "t": "12:02",
   "k": "denom",
   "x": "60"
  },
  {
   "d": "2025-09-28",
   "t": "12:05",
   "k": "fund",
   "x": "Yes going to go to the atm"
  },
  {
   "d": "2025-09-30",
   "t": "09:18",
   "k": "fund",
   "x": "I have the money already out. I am going to sleep for a little while longer then I’ll bring it over"
  },
  {
   "d": "2025-09-30",
   "t": "12:28",
   "k": "see",
   "x": "Did you hear from him yet"
  },
  {
   "d": "2025-10-03",
   "t": "17:35",
   "k": "fund",
   "x": "I’ll hit the atm"
  },
  {
   "d": "2025-10-04",
   "t": "17:16",
   "k": "fund",
   "x": "I have thirty."
  },
  {
   "d": "2025-10-08",
   "t": "12:20",
   "k": "fund",
   "x": "Trying to get money together"
  },
  {
   "d": "2025-10-08",
   "t": "12:43",
   "k": "denom",
   "x": "Fifty"
  },
  {
   "d": "2025-10-09",
   "t": "19:04",
   "k": "fund",
   "x": "Did you need money for a sub"
  },
  {
   "d": "2025-10-09",
   "t": "19:08",
   "k": "want",
   "x": "I can send you that if you need it. I have enough to get something tomorrow"
  },
  {
   "d": "2025-10-10",
   "t": "09:30",
   "k": "order",
   "x": "How is Mimi doing? I will go to the bank in a little bit we can get a full one"
  },
  {
   "d": "2025-10-13",
   "t": "08:44",
   "k": "ask3p",
   "x": "Plus. It’s fucking Columbus Day. Banks are closed even if I were able to get a check. I asked Claire to send me money that she owed me. That’ll get me close to 90."
  },
  {
   "d": "2025-10-14",
   "t": "09:18",
   "k": "fund",
   "x": "I have fifty"
  },
  {
   "d": "2025-10-14",
   "t": "09:18",
   "k": "fund",
   "x": "I’ll bring the money over before my appointment"
  },
  {
   "d": "2025-10-14",
   "t": "10:38",
   "k": "fund",
   "x": "I have $60 going to atm"
  },
  {
   "d": "2025-10-15",
   "t": "12:21",
   "k": "want",
   "x": "I feel like I should probably just wait until tomorrow to get anything"
  },
  {
   "d": "2025-10-15",
   "t": "13:10",
   "k": "denom",
   "x": "60"
  },
  {
   "d": "2025-10-16",
   "t": "13:39",
   "k": "fund",
   "x": "I am trying to get money I will let you know asap"
  },
  {
   "d": "2025-10-16",
   "t": "14:27",
   "k": "fund",
   "x": "I have $30.."
  },
  {
   "d": "2025-10-17",
   "t": "08:16",
   "k": "fund",
   "x": "I highly doubt I can get enough money together for a full one"
  },
  {
   "d": "2025-10-17",
   "t": "12:45",
   "k": "fund",
   "x": "Going to go to the atm now"
  },
  {
   "d": "2025-10-18",
   "t": "13:31",
   "k": "fund",
   "x": "I have twenty right now.."
  },
  {
   "d": "2025-10-20",
   "t": "09:51",
   "k": "want",
   "x": "I will get one later today"
  },
  {
   "d": "2025-10-22",
   "t": "11:17",
   "k": "fund",
   "x": "I have $60"
  },
  {
   "d": "2025-10-23",
   "t": "11:50",
   "k": "fund",
   "x": "I have $20 right now. That’s it. I dont know if I can get more"
  },
  {
   "d": "2025-10-23",
   "t": "13:17",
   "k": "fund",
   "x": "To go to the atm"
  },
  {
   "d": "2025-10-24",
   "t": "11:14",
   "k": "fund",
   "x": "I have $30. That’s it."
  },
  {
   "d": "2025-10-24",
   "t": "11:45",
   "k": "fund",
   "x": "I have $40. Going to atm now"
  },
  {
   "d": "2025-10-26",
   "t": "15:13",
   "k": "fund",
   "x": "I have $30. But I don’t have my car keys.. so i dont know"
  },
  {
   "d": "2025-10-26",
   "t": "15:48",
   "k": "want",
   "x": "I dont know I dont have to get anything"
  },
  {
   "d": "2025-10-28",
   "t": "18:19",
   "k": "want",
   "x": "Did you or your mom get anything today"
  },
  {
   "d": "2025-10-28",
   "t": "18:20",
   "k": "fund",
   "x": "I’m trying to get some money. I dont know if I can. Or if I could buy a damn gift card or something"
  },
  {
   "d": "2025-10-28",
   "t": "18:37",
   "k": "fund",
   "x": "I have $30"
  },
  {
   "d": "2025-10-28",
   "t": "18:40",
   "k": "fund",
   "x": "I’ll bring the cash."
  },
  {
   "d": "2025-10-29",
   "t": "14:54",
   "k": "fund",
   "x": "I have fifty"
  },
  {
   "d": "2025-10-29",
   "t": "15:01",
   "k": "fund",
   "x": "I’m going to the ATM now"
  },
  {
   "d": "2025-11-01",
   "t": "14:58",
   "k": "denom",
   "x": "Um I do have $60."
  },
  {
   "d": "2025-11-06",
   "t": "11:11",
   "k": "denom",
   "x": "Good morning. Can I bring forty over before I go to sugies"
  },
  {
   "d": "2025-11-08",
   "t": "12:42",
   "k": "fund",
   "x": "I have fifty cash I’ll bring with me"
  },
  {
   "d": "2025-11-09",
   "t": "11:19",
   "k": "fund",
   "x": "Good morning. Going down to sugies. Trying to get some money still."
  },
  {
   "d": "2025-11-10",
   "t": "10:40",
   "k": "order",
   "x": "Good morning I’m going g to try to get a check in a little bit so we can get a whole one today"
  },
  {
   "d": "2025-11-11",
   "t": "15:04",
   "k": "denom",
   "x": "60"
  },
  {
   "d": "2025-11-11",
   "t": "15:25",
   "k": "want",
   "x": "Yes I’ll get something"
  },
  {
   "d": "2025-11-12",
   "t": "12:13",
   "k": "fund",
   "x": "That’s why I’m trying to get money"
  },
  {
   "d": "2025-11-13",
   "t": "12:34",
   "k": "fund",
   "x": "Trying to get some money"
  },
  {
   "d": "2025-11-14",
   "t": "08:04",
   "k": "fund",
   "x": "I have money for a whole one today"
  },
  {
   "d": "2025-11-15",
   "t": "12:24",
   "k": "fund",
   "x": "Is there any way I can please send the money"
  },
  {
   "d": "2025-11-15",
   "t": "13:58",
   "k": "fund",
   "x": "In line to check out at Walmart., I will go to the atm after I get home"
  },
  {
   "d": "2025-11-16",
   "t": "10:31",
   "k": "fund",
   "x": "And I have sixty, I know there is a Steelers game at 1:00. And he goes to church so i dont know if you can just tell your mom I want to get sixty"
  },
  {
   "d": "2025-11-25",
   "t": "10:13",
   "k": "fund",
   "x": "Leaving her house now going to to the atm then I’ll be there"
  },
  {
   "d": "2025-11-28",
   "t": "12:50",
   "k": "fund",
   "x": "I have twenty I can send"
  },
  {
   "d": "2025-12-02",
   "t": "13:34",
   "k": "denom",
   "x": "Probably McDonald’s. And I have 100"
  },
  {
   "d": "2025-12-03",
   "t": "17:03",
   "k": "fund",
   "x": "I have twenty.. i dont know if your mom would be able to sell me any of whatever she has?"
  },
  {
   "d": "2025-12-04",
   "t": "13:52",
   "k": "want",
   "x": "You said you had z there already"
  },
  {
   "d": "2025-12-04",
   "t": "15:29",
   "k": "want",
   "x": "I’m moving this fucking chair then I’ll come get it."
  },
  {
   "d": "2025-12-05",
   "t": "13:09",
   "k": "fund",
   "x": "I am laying in bed feeling like death. I’m trying to get some money together"
  },
  {
   "d": "2025-12-05",
   "t": "14:34",
   "k": "fund",
   "x": "I have fifty."
  },
  {
   "d": "2025-12-06",
   "t": "23:18",
   "k": "want",
   "x": "Why can’t I just get it tonight"
  },
  {
   "d": "2025-12-07",
   "t": "12:46",
   "k": "denom",
   "x": "100"
  },
  {
   "d": "2025-12-08",
   "t": "11:47",
   "k": "fund",
   "x": "I will figure out a way to get money together to see him before the kid comes"
  },
  {
   "d": "2025-12-08",
   "t": "11:59",
   "k": "want",
   "x": "And use the money my mom send me to get something"
  },
  {
   "d": "2025-12-08",
   "t": "12:08",
   "k": "denom",
   "x": "100"
  },
  {
   "d": "2025-12-08",
   "t": "12:33",
   "k": "fund",
   "x": "So I’ll leave here once the car comes out. I’ll hit the atm"
  },
  {
   "d": "2025-12-09",
   "t": "10:16",
   "k": "denom",
   "x": "I need to pay the phone bill on the 10th"
  },
  {
   "d": "2025-12-10",
   "t": "14:08",
   "k": "want",
   "x": "Loved “well come feel like crap with me and i will at least get you some z”"
  },
  {
   "d": "2025-12-10",
   "t": "16:45",
   "k": "ask3p",
   "x": "Trying to get my mom to write me a check from Sugie"
  },
  {
   "d": "2025-12-11",
   "t": "14:49",
   "k": "want",
   "x": "More z"
  },
  {
   "d": "2025-12-12",
   "t": "20:06",
   "k": "fund",
   "x": "I have $20"
  },
  {
   "d": "2025-12-13",
   "t": "14:33",
   "k": "want",
   "x": "So wait are there z or no lol"
  },
  {
   "d": "2025-12-13",
   "t": "21:48",
   "k": "want",
   "x": "Argh. I wouldn’t mind more z…. But i refuse to have you walk here"
  },
  {
   "d": "2025-12-15",
   "t": "22:12",
   "k": "ask3p",
   "x": "Listen I had to bc I asked my mom for that money earlier"
  },
  {
   "d": "2025-12-17",
   "t": "10:34",
   "k": "fund",
   "x": "I have $10"
  },
  {
   "d": "2025-12-17",
   "t": "10:45",
   "k": "fund",
   "x": "I gotta get changed and hit the atm"
  },
  {
   "d": "2025-12-17",
   "t": "22:32",
   "k": "want",
   "x": "I was just thinking of it and I wanted to text “I wish I had some z’s” but only if you had seen the tiktok to understand lol"
  },
  {
   "d": "2025-12-19",
   "t": "11:18",
   "k": "askMoney",
   "x": "Is she able to like spot me until I have the money,"
  },
  {
   "d": "2025-12-19",
   "t": "11:40",
   "k": "want",
   "x": "I doubt I’ll get anything before 12:30"
  },
  {
   "d": "2025-12-20",
   "t": "11:09",
   "k": "want",
   "x": "Your mom can’t get anything until I pay her back"
  },
  {
   "d": "2025-12-21",
   "t": "15:01",
   "k": "fund",
   "x": "I have $20"
  },
  {
   "d": "2025-12-22",
   "t": "15:39",
   "k": "denom",
   "x": "Michelle leaving in a min"
  },
  {
   "d": "2025-12-23",
   "t": "11:18",
   "k": "fund",
   "x": "Okay I have thirty dollars right now."
  },
  {
   "d": "2025-12-23",
   "t": "12:44",
   "k": "fund",
   "x": "Let me dry my hair real quick I have fifty"
  },
  {
   "d": "2025-12-23",
   "t": "17:41",
   "k": "want",
   "x": "So how am I gonna get it"
  },
  {
   "d": "2025-12-27",
   "t": "12:45",
   "k": "fund",
   "x": "I have twenty"
  },
  {
   "d": "2025-12-27",
   "t": "12:45",
   "k": "want",
   "x": "I really want to get something today., i dont know if she is able to help or not."
  },
  {
   "d": "2025-12-27",
   "t": "14:00",
   "k": "denom",
   "x": "How do you expect me to get more than the twenty I have Dan"
  },
  {
   "d": "2025-12-27",
   "t": "14:02",
   "k": "fund",
   "x": "I’m trying to get money Dan."
  },
  {
   "d": "2025-12-28",
   "t": "16:51",
   "k": "fund",
   "x": "I have twenty cash.. ten in the bank"
  },
  {
   "d": "2025-12-29",
   "t": "10:59",
   "k": "order",
   "x": "I am going to do my best to get a check today for us to get a full one"
  },
  {
   "d": "2026-01-02",
   "t": "14:26",
   "k": "fund",
   "x": "I have twenty in coins right now I need to cash in"
  },
  {
   "d": "2026-01-02",
   "t": "14:26",
   "k": "ask3p",
   "x": "I asked my mom to send me a little money but she hasn’t yet"
  },
  {
   "d": "2026-01-04",
   "t": "14:10",
   "k": "want",
   "x": "But she was going to get it I said I wouldn’t"
  },
  {
   "d": "2026-01-06",
   "t": "15:37",
   "k": "fund",
   "x": "I’m trying to get some money together okay"
  },
  {
   "d": "2026-01-08",
   "t": "13:35",
   "k": "code",
   "x": "I don’t even have to send it to your mom. You can use the card less access and I can send the code"
  },
  {
   "d": "2026-01-08",
   "t": "13:45",
   "k": "fund",
   "x": "I have sixty"
  },
  {
   "d": "2026-01-08",
   "t": "13:46",
   "k": "code",
   "x": "Tell me when you are going to atm and I’ll send you the code"
  },
  {
   "d": "2026-01-08",
   "t": "13:51",
   "k": "want",
   "x": "Code is good for an hour I’ll get it now"
  },
  {
   "d": "2026-01-09",
   "t": "16:16",
   "k": "want",
   "x": "Whatever. Save my twenty. I’ll come get it later."
  },
  {
   "d": "2026-01-10",
   "t": "12:46",
   "k": "fund",
   "x": "Let me know when I can bring the money"
  },
  {
   "d": "2026-01-14",
   "t": "19:05",
   "k": "want",
   "x": "I wish I had more z"
  },
  {
   "d": "2026-01-14",
   "t": "19:08",
   "k": "code",
   "x": "I dont know if you need to go to the bank for just a small amount I can give you a card less code"
  },
  {
   "d": "2026-01-15",
   "t": "10:33",
   "k": "code",
   "x": "May need for you to go to atm for me i dont know yet I’ll let you know for sure"
  },
  {
   "d": "2026-01-15",
   "t": "12:37",
   "k": "code",
   "x": "Can you please go to atm for me. Get out $80. I will send you the card less code"
  },
  {
   "d": "2026-01-15",
   "t": "19:12",
   "k": "fund",
   "x": "I have the cash that I won"
  },
  {
   "d": "2026-01-15",
   "t": "19:22",
   "k": "fund",
   "x": "I have fifty cash."
  },
  {
   "d": "2026-01-16",
   "t": "13:30",
   "k": "denom",
   "x": "The fifty I gave you yesterday"
  },
  {
   "d": "2026-01-16",
   "t": "13:30",
   "k": "denom",
   "x": "Plus 50 more"
  },
  {
   "d": "2026-01-16",
   "t": "13:30",
   "k": "code",
   "x": "If you need to get fifty out of atm do it I’ll send you code"
  },
  {
   "d": "2026-01-16",
   "t": "13:33",
   "k": "code",
   "x": "I’ll send you code"
  },
  {
   "d": "2026-01-17",
   "t": "13:56",
   "k": "code",
   "x": "Do you want me to send you the code"
  },
  {
   "d": "2026-01-18",
   "t": "14:02",
   "k": "fund",
   "x": "I have forty dollars leaving now"
  },
  {
   "d": "2026-01-19",
   "t": "07:48",
   "k": "want",
   "x": "Good morning And okay I will do my best to get it around lunch"
  },
  {
   "d": "2026-01-19",
   "t": "10:27",
   "k": "order",
   "x": "I want a line"
  },
  {
   "d": "2026-01-20",
   "t": "19:48",
   "k": "ask3p",
   "x": "I asked my mom for money. We willl see if she sends it."
  },
  {
   "d": "2026-01-22",
   "t": "10:42",
   "k": "fund",
   "x": "I have $20"
  },
  {
   "d": "2026-01-22",
   "t": "13:21",
   "k": "code",
   "x": "But if you want to get the twenty out let me know and I’ll send you a code"
  },
  {
   "d": "2026-01-23",
   "t": "11:44",
   "k": "fund",
   "x": "I have sixty"
  },
  {
   "d": "2026-01-24",
   "t": "10:21",
   "k": "fund",
   "x": "I have $59"
  },
  {
   "d": "2026-01-24",
   "t": "13:01",
   "k": "code",
   "x": "Tell me when to get a code"
  },
  {
   "d": "2026-01-25",
   "t": "18:29",
   "k": "askOther",
   "x": "The yes you can come get me after dinner"
  },
  {
   "d": "2026-01-26",
   "t": "14:46",
   "k": "want",
   "x": "Well the kids have been here all afternoon… I am trying to get money together to hopefully get something today"
  },
  {
   "d": "2026-01-26",
   "t": "18:35",
   "k": "fund",
   "x": "I’m trying to get money for drugs Dan"
  },
  {
   "d": "2026-01-27",
   "t": "14:15",
   "k": "order",
   "x": "I am getting some money. Hopefully enough to get a full one"
  },
  {
   "d": "2026-01-27",
   "t": "14:41",
   "k": "fund",
   "x": "If you can run to the atm for me while I try to get my car out I’d appreciate it"
  },
  {
   "d": "2026-01-27",
   "t": "14:45",
   "k": "code",
   "x": "Just tell me when to send the atm code"
  },
  {
   "d": "2026-01-27",
   "t": "15:18",
   "k": "fund",
   "x": "I’ll go to the ATM"
  },
  {
   "d": "2026-02-01",
   "t": "14:22",
   "k": "see",
   "x": "She fucking asked me to stop and get it. I said is he coming soon? If so I will go get the wine now. She said yes"
  },
  {
   "d": "2026-02-05",
   "t": "16:29",
   "k": "denom",
   "x": "I only have fifty."
  },
  {
   "d": "2026-02-05",
   "t": "16:32",
   "k": "code",
   "x": "I have to go get my car. If you want to go to atm for me I’ll send code."
  },
  {
   "d": "2026-02-05",
   "t": "16:47",
   "k": "code",
   "x": "You can’t go to ATM for me?"
  },
  {
   "d": "2026-02-11",
   "t": "11:08",
   "k": "want",
   "x": "Well how would I get anything without money 😂"
  },
  {
   "d": "2026-02-11",
   "t": "11:10",
   "k": "want",
   "x": "Well I want something obviously. But I can’t get anything"
  },
  {
   "d": "2026-02-11",
   "t": "12:11",
   "k": "fund",
   "x": "Alright I have fifty. I am at sugies now. Trying to get in and out. Gotta stop at pnc and deposit some cash bc my account got overdrawn from a freaking monthly service charge and iCloud 🙄😑"
  },
  {
   "d": "2026-02-16",
   "t": "13:35",
   "k": "fund",
   "x": "I said I have $30."
  },
  {
   "d": "2026-02-17",
   "t": "18:07",
   "k": "chase",
   "x": "Did you get your subs yet"
  },
  {
   "d": "2026-02-18",
   "t": "16:13",
   "k": "want",
   "x": "I know it’s probably annoying to ask this. But what are the chances you could see him again? I wanted to get something to save for tomorrow bc I am pretty sure I have to take Sugie to an appointment in the afternoon"
  },
  {
   "d": "2026-02-22",
   "t": "14:09",
   "k": "denom",
   "x": "60"
  },
  {
   "d": "2026-02-23",
   "t": "12:19",
   "k": "denom",
   "x": "On my way with $80"
  },
  {
   "d": "2026-02-28",
   "t": "12:47",
   "k": "fund",
   "x": "I am fixing trying to get some money"
  },
  {
   "d": "2026-02-28",
   "t": "12:47",
   "k": "fund",
   "x": "Edited to “I am trying to get some money ”"
  },
  {
   "d": "2026-03-02",
   "t": "11:33",
   "k": "denom",
   "x": "100"
  },
  {
   "d": "2026-03-06",
   "t": "12:44",
   "k": "fund",
   "x": "But I’ll bring the money to you first"
  },
  {
   "d": "2026-03-06",
   "t": "18:19",
   "k": "want",
   "x": "I’ll find someone else to get it from and you’ll never have to deal with this again"
  },
  {
   "d": "2026-03-07",
   "t": "20:10",
   "k": "fund",
   "x": "And I don’t want you to think this is the only reason why I would want to come over… but I have sixty cash if it is possible"
  },
  {
   "d": "2026-03-09",
   "t": "13:11",
   "k": "denom",
   "x": "She’s writing me a check. I’ll get 80"
  },
  {
   "d": "2026-03-16",
   "t": "11:20",
   "k": "fund",
   "x": "I’ll just bring the money to your mom if you are gone"
  },
  {
   "d": "2026-03-16",
   "t": "12:13",
   "k": "denom",
   "x": "100"
  },
  {
   "d": "2026-03-17",
   "t": "10:17",
   "k": "denom",
   "x": "I only have like 30"
  },
  {
   "d": "2026-03-17",
   "t": "10:18",
   "k": "want",
   "x": "Let me see if I can get anything more. What time are you going to paint today"
  },
  {
   "d": "2026-03-19",
   "t": "21:19",
   "k": "fund",
   "x": "I will bring the money. I will get the black"
  },
  {
   "d": "2026-03-23",
   "t": "12:59",
   "k": "fund",
   "x": "Well I have twenty for you Dan sorry I will get the other forty"
  },
  {
   "d": "2026-03-23",
   "t": "17:52",
   "k": "want",
   "x": "Well i technically have some money if you want to get something"
  },
  {
   "d": "2026-03-23",
   "t": "17:57",
   "k": "denom",
   "x": "100?"
  },
  {
   "d": "2026-03-23",
   "t": "18:26",
   "k": "code",
   "x": "When should I get a code for the atm"
  },
  {
   "d": "2026-03-23",
   "t": "18:36",
   "k": "want",
   "x": "god if I make you this miserable I will leave you alone we don’t need to get anything"
  },
  {
   "d": "2026-03-23",
   "t": "18:59",
   "k": "fund",
   "x": "On the way to the ATM now"
  },
  {
   "d": "2026-03-27",
   "t": "16:13",
   "k": "chase",
   "x": "Did you get your subs"
  },
  {
   "d": "2026-03-28",
   "t": "18:17",
   "k": "see",
   "x": "Did you ever end up seeing bop"
  },
  {
   "d": "2026-03-28",
   "t": "18:51",
   "k": "want",
   "x": "I want some 😕"
  },
  {
   "d": "2026-03-28",
   "t": "19:58",
   "k": "askOther",
   "x": "Bring me some 🥺"
  },
  {
   "d": "2026-04-05",
   "t": "21:21",
   "k": "want",
   "x": "I will get something yes"
  },
  {
   "d": "2026-04-05",
   "t": "21:22",
   "k": "want",
   "x": "I’ll get something tomorrow"
  },
  {
   "d": "2026-04-07",
   "t": "11:18",
   "k": "code",
   "x": "Are you able to go to an atm"
  },
  {
   "d": "2026-04-07",
   "t": "11:42",
   "k": "code",
   "x": "I’ll get you a code"
  },
  {
   "d": "2026-04-07",
   "t": "22:49",
   "k": "want",
   "x": "I will get it"
  },
  {
   "d": "2026-04-08",
   "t": "13:07",
   "k": "code",
   "x": "I’ll send you an access code. Take fifty out."
  },
  {
   "d": "2026-04-09",
   "t": "14:39",
   "k": "code",
   "x": "That code will expire"
  },
  {
   "d": "2026-04-14",
   "t": "13:12",
   "k": "fund",
   "x": "I have $60 dollars. That’s it. That’s all I can fucking do"
  },
  {
   "d": "2026-04-20",
   "t": "11:19",
   "k": "denom",
   "x": "100"
  },
  {
   "d": "2026-04-21",
   "t": "10:06",
   "k": "fund",
   "x": "Like I have twenty but it’s my last twenty I have to my name right now"
  },
  {
   "d": "2026-04-22",
   "t": "17:12",
   "k": "see",
   "x": "Did you ever see him"
  },
  {
   "d": "2026-04-27",
   "t": "09:12",
   "k": "want",
   "x": "Yes. It might not be a lot but I will get something"
  },
  {
   "d": "2026-05-04",
   "t": "11:24",
   "k": "fund",
   "x": "I will give you money"
  },
  {
   "d": "2026-05-04",
   "t": "11:26",
   "k": "code",
   "x": "If you can go to the atm I guess I’ll give you a code. Take out like $30"
  },
  {
   "d": "2026-05-05",
   "t": "12:23",
   "k": "see",
   "x": "Is there any possibility of seeing bop"
  },
  {
   "d": "2026-05-05",
   "t": "12:25",
   "k": "code",
   "x": "Are you able to go to the atm for me"
  },
  {
   "d": "2026-05-05",
   "t": "12:26",
   "k": "denom",
   "x": "100 I’ll get the code"
  },
  {
   "d": "2026-05-05",
   "t": "14:21",
   "k": "want",
   "x": "Just let me know when he comes Dan. If you want me to come get it I will. I just have to start getting ready"
  },
  {
   "d": "2026-05-05",
   "t": "14:53",
   "k": "want",
   "x": "I want to get it first. I am dying here"
  },
  {
   "d": "2026-05-09",
   "t": "12:32",
   "k": "code",
   "x": "Can you go to atm"
  },
  {
   "d": "2026-05-10",
   "t": "12:20",
   "k": "see",
   "x": "I dont know if you want to try to see him, or when you start work today. But if you want to.. I’ll have to send you a code soon bc I will have shitty cell service"
  },
  {
   "d": "2026-05-10",
   "t": "15:41",
   "k": "see",
   "x": "Did you see him?"
  },
  {
   "d": "2026-05-11",
   "t": "12:17",
   "k": "see",
   "x": "Is he coming now?"
  },
  {
   "d": "2026-05-14",
   "t": "15:50",
   "k": "want",
   "x": "Well if you find a way to get anything… bring it."
  },
  {
   "d": "2026-05-14",
   "t": "17:27",
   "k": "denom",
   "x": "Well I have $25 in bank. And $20 cash…"
  },
  {
   "d": "2026-05-14",
   "t": "17:54",
   "k": "fund",
   "x": "I have $40 cash"
  },
  {
   "d": "2026-05-14",
   "t": "17:56",
   "k": "fund",
   "x": "I’ll leave the forty cash. And take twenty out of ATM."
  },
  {
   "d": "2026-05-14",
   "t": "21:39",
   "k": "want",
   "x": "And the z"
  },
  {
   "d": "2026-05-15",
   "t": "13:51",
   "k": "want",
   "x": "I know this is not what you want to hear from me right now; but if you have anything left or are getting anything.. I only have a little money and would be grateful to get something before work if possible."
  },
  {
   "d": "2026-05-15",
   "t": "14:15",
   "k": "fund",
   "x": "I am going to give you the cash I have. Idc."
  },
  {
   "d": "2026-05-16",
   "t": "14:09",
   "k": "want",
   "x": "If I can get it still you won’t be out your sixty Dan."
  },
  {
   "d": "2026-05-17",
   "t": "12:24",
   "k": "see",
   "x": "If you are seeing him before work today let me know.."
  },
  {
   "d": "2026-05-18",
   "t": "12:16",
   "k": "see",
   "x": "Well if you are seeing him let me know"
  },
  {
   "d": "2026-05-18",
   "t": "12:58",
   "k": "denom",
   "x": "I guess do 100"
  },
  {
   "d": "2026-05-18",
   "t": "12:59",
   "k": "code",
   "x": "Are you going to the atm"
  },
  {
   "d": "2026-05-19",
   "t": "10:51",
   "k": "code",
   "x": "Are you about to go to atm"
  },
  {
   "d": "2026-05-19",
   "t": "11:16",
   "k": "fund",
   "x": "I’ll get ready quick and hit the atm before I go grocery shopping for Sugie"
  },
  {
   "d": "2026-05-19",
   "t": "11:16",
   "k": "denom",
   "x": "60"
  },
  {
   "d": "2026-05-21",
   "t": "10:39",
   "k": "want",
   "x": "And you were right, if it’s POSSIBLE, to get something small today before I go into work… I would really appreciate it"
  },
  {
   "d": "2026-05-25",
   "t": "12:19",
   "k": "denom",
   "x": "60"
  },
  {
   "d": "2026-05-31",
   "t": "17:50",
   "k": "code",
   "x": "Can you go to atm"
  },
  {
   "d": "2026-05-31",
   "t": "17:51",
   "k": "denom",
   "x": "100?"
  },
  {
   "d": "2026-05-31",
   "t": "17:54",
   "k": "fund",
   "x": "I can send money on cashapp now"
  },
  {
   "d": "2026-05-31",
   "t": "18:37",
   "k": "code",
   "x": "Send you a code??"
  },
  {
   "d": "2026-05-31",
   "t": "19:32",
   "k": "want",
   "x": "Am I coming to get it"
  }
 ]
};
})();
