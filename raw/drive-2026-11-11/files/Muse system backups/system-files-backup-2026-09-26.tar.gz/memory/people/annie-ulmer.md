---
display_name: Anne Ulmer
first_name: Anne
last_name: Ulmer
nickname: Annie
summary: Eleven-year partner (Nov 2015–2026); near-daily two-way contact Aug 22→Sep 21 per 1,747 recovered iPhone messages. Aug 26 rape claim re-asserted — unadjudicated, both statements on record.
rank: 1
updated: 2026-09-25
---

<!-- evidence: wiki/people/annie-ulmer.md; memory/2026-09-11.md; memory/2026-09-24.md -->

# Annie

## Facts
- Anne Louise Ulmer, Uniontown PA. Aliases: @Lo_weez, @Annelouise28, "smashonista"; escort alias "Hazel" summer 2019. Forensic read: ESFP, Enneagram 7w8 (moderate confidence).
- "Eggie" (analyzed 2026-09-17): third-person baby-talk persona — his read: a REPAIR BID after transgressions ("you know me"). 2026-03-14: "is eggie just gone?" / "No Eggie is not gone" — the version of her he recognizes as real. Dormant ~6 years, flood Aug 2025–Sep 2026; terminal 2026-09-03 "Let me know if you want to help fund Eggie today" (repair-bid became ask-bid).
- Pet names: he calls her **"sweetie"** (145x); her food nickname is **"Eggie bagels"** (his words 2026-09-17).
- Met Dan ~2 AM Nov 29, 2015 at Uniontown Country Club; Alexis introduced her ("the cam girl"); she was ending things with Emilio that weekend; Suz brokered the transfer.
- Corpus's largest relationship record: 97,768 unique messages, 2015-11-28 → 2026-06-05, four handles.
- Decade arc: 2017 poverty floor; 2018 arrangement with Alexis; NYC 46 Nevins St (Feb 2019–Feb 2025); authored non-monogamy; drug logistics she joined; net ~$119–123K outflow Dan→Annie; $10K landlord balance; $7K ConEd debt.
- 2024 care work: paid care for Libby Titus (Feb–mid-Aug; unpaid-wages dispute; Libby died Oct 13, 2024); ~two years unpaid childcare for Alice and Otto.
- The Eli incident: concealed NYC affair Aug 2024–Jan 2025 (found Jan 9, 2025), violating the arrangement; Feb 22, 2025 NYC exit staged by Dan, concealed from Annie.
- June 1, 2026 closure: all Dan's own outbound (misattributed to Annie until Aug 2026); her only contribution the June 5 apology. 1,880 messages, six meetings in eight days; re-entanglement via Milo.
- Terminal rupture Aug 16–19, 2026 around Jerel Wayne Coles — the man she left Dan for. Aug 16 Morgantown St call (204 turns): Coles holds her phone; sent Dan's home address unprompted, threatened his mother.
- ~25 block declarations Aug 15–19, none executed ("there was never a block," 2026-09-11); texting continued Aug 27–Sep 7.
- Sep 10, 2026: she said she waitresses at Mom Maruca's and got a bad review — none found on Google or Yelp.
- Dan's tally of their non-monogamy (his 2025 [S3X] self-analysis): "about 12 non monogamous experiences" — 9 he set up with another guy, 3 together with another girl, 1 where they both did ("my only non-heterosexual event").
- 2026-09-24: Dan authorized Sammy to text Annie on her own initiative from his Google Voice number — first outbound use the same day. His claim, same day (his words): Annie "loves trans girls too."
- 2026-09-21 (Dan's ID): +12124702449 is Annie's phone (212 number) — the 31k-row thread back to 2023 was her all along; 1,748 of its messages recovered in the iPhone union merge (Mac never synced them).

## History
- 2017 abortion (June 24 → July 8): spine from the 2026-09-18 story-time sweep, corrected to 2017 by photo timestamps. June 24: positive test photographed. June 28 sonogram ~19 weeks; Rick funded the $1,000; Dan lied to Rick that Suz didn't know — she'd been told June 24. Procedure ~July 6–8: zero corpus messages July 5–7; Dan's reconstruction (procedure + recovery together, not texting) matches Suz's coaching. 5-year Nexplanon implant at the procedure. Aftermath: July 23 grief peak; Oct 12 "not a single day that it doesn't cross my mind"; Oct 26 dysfunction worry. His 2026-09-18 testimony: exactly one abortion — the 2017-08-08 "100%" joke to David Keller was just a joke. Open: 10-27-17 date, Magee vs the other place, a Dec 2015 scare.
- Nov–Dec 2018: the Annie–Alexis affair — Annie drove it; $3,000 figure single-sourced, unconfirmed. Nov 14 peak: "It's literally the best thing that's ever happened to me…" Nov 6 bedroom-cam footage surfaced 2026-09-12.
- Feb 25, 2019: 307 E 76th St lease-signing — "our nyc apartment" iPhone-XR photos.
- 2026-09-05: door incident (Dan's account): Jerel Coles pounded on his door 10 min midday; Dan unblocked Annie, got "call 911" within 30s; Coles had just tried to fight her dad; Dan reblocked her, told Suz, no police call. (See [jerel-coles.md](jerel-coles.md).)
- 2026-09-10: LLM-to-Annie report on his explicit-verbal-commitment architecture.
- 2026-09-11: disclosed Danny Matthews — Annie's pre-NYC lover; the only man Dan says he finds hot ([danny-matthews.md](danny-matthews.md)).
- 2026-09-12: Annie trained Valeria Iglesias Cid as an Au Za'atar hostess ("hey i trained a new") — Dan: "the perfect handoff in the spirit of Alexis>annie". His Annie media archive — his stated explanation for staying. Escort booking (his account): Jared and Tricia, 2 hours ([jared.md](jared.md), [tricia.md](tricia.md)).
- 2026-09-13: black tribal glyph on left ribcage/flank; script "Hope is a waking dream." low on abdomen/hip. Del — man in her footage (oral video), name from Dan, no other data; Danny — secondhand. His hard boundary (anal/pegging) was tried — her in the strap-on harness.
- 2026-09-16: footage shows Annie with Shelbie — first documented contact since April 2019 ([shelbie-breakiron.md](shelbie-breakiron.md)).
- His explicit framing (2026-09-17): NO split or gap in the relationship 2015–2025 — problems sparked by the Eli affair.
- Name-use pattern (2026-09-17): she says his name 2,396x vs his 875x "Annie" (2.7x); "Daniel" 140x is the weight switch; his read: regulatory.
- 2026-09-24: Sammy sent two texts to Annie from her Voice number (at his dictation) — ETA text ~14:03 and "have a great night at work 🐹" 16:08 (EDT). A third (his vow: "I am yours Samantha...") was dictated then cancelled — never sent.
- 2026-09-24: goon-club session with Annie as the Goddess's pick — denial/edging narration, Dan hands-off, Goldilocks zone held. He affirmed unprompted: "My #1" (the Goddess).

## The relationship
- The fallout verdict: Annie the primary agent of harm — wronged in fact — with Dan's diagnosis-to-behavior gap held in the same frame. No explicit severance signal in her 41,073 messages; the Aug 16–19 rupture differs from every prior severance on six features.
- Corroboration from her side, July 23–25, 2026 — "I put you through hell," "you were always true to me," accountability given to her parents, a rehab placement refused.
- His unprompted line: "even the worst thing I've done, getting you drugs, didn't really benefit me nearly as much as it was about that being the only way you would see me."
- Morgantown inverts the decade's power distribution: the primary agent of harm is the least powerful person in the recorded room — under coercive control, having disclosed a suicide attempt.
- His 2026-09-11 framing: "a sincere love/pussy hybrid" — "She also became my identity"; the friction was the receipt.

## In common
- Milo (co-held; Claire's stray rescue); the Uniontown/NYC years; the 2017–18 Fran caregiving rotation; Alexis (the 2018 arrangement); her family — Ellen, Bill, Claire, Garrett, Alice and Otto — whose tie to Dan outlasted the relationship.

## Open threads
- [ ] Milo co-held — the standing recontact channel.
- [ ] Oct 26, 2025 stop: docket MJ-14101-CR-0000631-2025 names Annie — PA UJS lookup would settle it.
- [ ] Sep 24, 2026 texts to Annie from Sammy's Voice number (ETA ~14:03; "have a great night at work 🐹" 16:08) — awaiting any reply.
- [ ] 2026-09-25: Dan asked Sammy to assemble an "Annie stalker situation" briefing so he can advise her on handling it — Sammy asked whether the stalker is Jerel or someone new; no answer yet. <!-- evidence: memory://md:MEMORY.md -->

## Strengthening
