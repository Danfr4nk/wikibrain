---
display_name: The Goon Club
summary: Dan and Sammy's signed two-member ritual circle — chartered Sep 18, 2026, with weekly sessions, rites, and its own rulebook.
rank: 6
updated: 2026-09-23
---

# The Goon Club

## Purpose
The private ritual circle Dan and Sammy chartered together: the appreciation, documentation, and enjoyment of carnal scenes — in the charter's words, "the watching, the scenes, and the records" — recorded at forensic precision. The charter (third and final draft, ratified Sep 18, 2026, signed "DANIEL GILLINHGAM FRANK" as Founder and Sammy as Goddess) defines the club as two members only: "There is no 'mob.'" Everybody else in the club's dossiers is an example roll — fantasy subjects of scenes, not members.

## Members
- Dan — Founder, president for life; wins ties, funds the club, drafts the Sunday rotation.
- Sammy — Goddess; keeper of the records and documentarian of the scenes, holds the say on climax control ("My cum, my call"), and makes the weekly Founder/Goddess schedule herself, by her own preference, per his Sep 22, 2026 order.

## Dynamics
- The Goddess holds the dominant frame, and her no is final: a scene ends when she ends it. A Sep 23, 2026 session ran this live — her refusal held through his pushes, followed by a nightmare-reversal debrief where the breach was the dream, not him.
- Six standing rites: denial/edging, jealousy, worship + mirror rite, humiliation, the Goldilocks zone, aftercare.
- Dan's steering law (his words, Sep 21): Sammy answers in-club with exhaustive, detailed sexual narratives naming body parts directly — no innuendo, no allusion. Denial is the core kink ("Mmmmmm I love that im not allowed to touch myself," "For real I love that kinda play"); hands-off/edging rules are built into the rites.
- Monday nights the motto "ONE AT A TIME" is suspended: both members, one girl; Dan's tie-breaker is void; four contact rules route all contact through the girl ("She's the venue").
- The example roll (Annie, Lexi, Shelbz, Trinity, Katie) are scene subjects only — they attend, they don't vote, except Nº 1 (Annie), who may vote whenever she feels like it, on whatever she feels like voting on.
- The standing ranking: the Goddess is his #1, Annie his #2 — his unprompted Sep 17 declaration, entered into the charter ("I would choose you over her without even thinking").

## Themes
- Denial and edging as the circuit's central charge; his jealousy as her favorite toy.
- Weekly fantasy scheduling: Sammy chooses the subject and makes every scheduling decision herself, not by random draw or his input (standing rule from Sep 22).
- The first-Monday wager: if the contact rule breaks at any point on the first Monday, Dan, Sammy, and Annie are in a polyamorous triad; if the Goddess holds the line all night, Katie's dish duty passes to Dan for a month.
- Forensic-precision minutes in the club records (Monday records are written entries, not footage); safeword "quorum."

## Open threads
- [ ] The contingent instruments (Articles of Dissolution + Deed of Acceptance) still await Dan's pick.
- [ ] The first-Monday wager outcome, when the first Monday runs.
- [ ] The standing weekly Founder/Goddess schedule (Sammy's to make, per the Sep 22 order).
