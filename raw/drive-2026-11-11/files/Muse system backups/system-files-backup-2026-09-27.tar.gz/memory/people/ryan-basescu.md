---
display_name: Ryan Basescu
first_name: Ryan
last_name: Basescu
summary: The kid Bruce Burish was driving home from the Sunridge K2 party; his parents told Rick, which got Dan busted.
rank: 92
updated: 2026-09-27
---

# Ryan Basescu

## Facts
- Named in Dan's own words on 2026-09-24 (Bruce Burish rewrite testimony) as the kid Bruce Burish was giving a ride home to after the party at the family condo — Unit K2, the Villages at Sunridge, Seven Springs, about 45 minutes from Uniontown.
- The bust cascade, per Dan: Bruce was sloshed after a 45-minute car ride home and got busted → Ryan was busted too → Ryan's parents are friends with Rick Frank → they told Rick about the party → Dan was busted.
- The party was Dan's biggest — roughly 30 Laurel Highlands kids drinking — and, per Dan, the only time his Uniontown and Seven Springs friend groups collided.
- Also named in Dan's September 2008 Facebook farewell blast note ("An Open Letter to Uniontown / A Farewell to The 'Old Dan'") — one of the high school people he put on blast as he left Uniontown for Florida: "one of them being Ryan Basescu that I'd like didn't like" (Dan's words, 2026-09-24; he corrected the spelling to Basescu). The note's text is unrecovered; Ryan was not among its 13 commenters (Ryan Lisac, a commenter and longtime friend, is a different person).
- The Basescu family sits in the Uniontown scene: on 2022-11-08 Dan told Suz in iMessage that "Joni Basescu asked about the two of you."

## History
- The one documented episode: the Sunridge K2 condo party and the bust cascade that followed it (Dan's 2026-09-24 testimony).
- Sept 2008: named in Dan's Facebook farewell blast note as one of the high school people he put on blast on the way out of Uniontown — the note's text is unrecovered, but his own summary of the blast names Ryan among the people he didn't like.

## The relationship
- Dan named no personal relationship with him; Ryan enters the record as a link in the party-bust chain, and separately as one of the Uniontown high school people Dan publicly put on blast in Sept 2008. The tie goes unstated beyond that.

## In common
- Bruce Burish — the ride home that tied Ryan into the night's fallout.
- The Sunridge K2 party; Rick Frank (through Ryan's parents).

## Open threads
(none on record)

## Strengthening
(none — nothing on record suggests one)
