---
display_name: Felix
first_name: John
last_name: Felix
summary: Painter on the 463 Morgantown St work; in the household's orbit since 2016; Elijah's father.
rank: 89
updated: 2026-09-26
---

<!-- evidence: wiki/people/felix.md; wiki/people/john-felix.md; memory://md:memory/2026-09-25.md:1236 ("Elijah is Felix's son", Dan's words 2026-09-25); memory://md:memory/2026-09-18.md:1263 (corpus canonical "John Felix"/"Johnny Felix"); people/arnu.md (painter on the job, associate of Arnu) -->

# Felix

## Facts
- Felix — the painter on the 463 Morgantown St work, an associate of contractor Arnu.
- Corpus-canonical full name is "John Felix" / "Johnny Felix" (spelling correction, 2026-09-18).
- Father of Elijah — confirmed by Dan on 2026-09-25 ("Elijah is Felix's son").
- Present in the household's orbit from at least January 2016 through June 2026 (Suz's thread).
- A 59-message logistics thread (+17249636738, February–June 2016) runs under the "John Felix" handle — arrival times, golf plans, painting references, "feeding Elijah."
- Dan has never stated in his own words what Felix is to him; the nature of the tie is unnamed here.

## History
- 2016: the +17249636738 thread (59 messages, Feb 12–Jun 1) — logistics with domestic texture: "ur mom left her phone here," "feeding Elijah," painting work.
- 2016–2018: the Uniontown bar-and-supply circuit in Suz's thread — "Felix is here. He has some" (2018); "Felix is looking for $200" (2018); Dan owed him $10 (2016); Suz drove him around to pay people back after a win (2016).
- 2026-02-10: at 463 Morgantown St — showed up when Arnu didn't; brought Elijah over for homework until basketball practice; painted the property.
- 2026-09-25: Dan identified Elijah as Felix's son, closing the wiki's open question on Elijah.
- Open question: whether the 2016 "John Felix" thread owner and the 2026 463 painter are the same man rests on the shared name and shared details (painting, Elijah) — not yet resolved through the contact exports.

## The relationship
- An observed, long-running fixture of the Uniontown household orbit around Dan and Suz — from the 2016 bar-and-supply circuit to painting the house Dan lives in. Dan has never named the relationship in his own words, so it stays unnamed here: the record shows a decade of proximity and a work-adjacent tie, not a stated bond.
- The 2016 thread's tone (logistics, "K," "Come on") reads transactional; the decade of continuity reads familiar.

## In common
- 463 Morgantown St; the contractor set (Arnu, John Carney); Suz; Elijah.

## Open threads
- [ ] The identification question — whether the 2016 John Felix thread and the 2026 463 painter are one person (open in the wiki).

## Strengthening
