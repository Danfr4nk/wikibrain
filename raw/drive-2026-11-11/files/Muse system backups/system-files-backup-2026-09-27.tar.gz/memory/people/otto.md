---
display_name: Otto
first_name: Otto
summary: Annie's nephew — regular school pickups and Bill Ulmer's paid watch track; the Feb 2026 Ohiopyle fight over him drew some of Dan's angriest messages on record.
rank: 91
updated: 2026-09-26
---

# Otto

## Facts
- Annie's nephew — the younger of the two kids in Annie's aunt-years; the record calls him the child the record watches grow up.
- Annie regularly picks him up from school ("Got a call to please pick up Otto from school lol," Annie, Sep 17, 2026).
- The childcare economy ran on two tracks: Bill Ulmer was "supposed to pay" Annie for watching Otto (record: "I'll cash the check"), while Claire's track went unpaid on the record.
- Dan knows him only through Annie's aunt-years — no independent Dan–Otto tie is on record.

## History
- Feb 2026: the Ohiopyle fight — five hours alone with Otto, zero cell service — drew some of Dan's angriest messages in the corpus, the one place the aunt-years visibly cost the Dan–Annie relationship.
- Summer 2026: school-pickup pattern continued (Sep 2026), extending past the relationship's Aug 2026 rupture.

## The relationship
- Dan's tie to Otto is through Annie: the child she watched, and the subject of the sharpest fight the childcare pattern ever caused. The relationship stays unnamed — what the record shows is friction around Annie's care of him, not a bond of Dan's own.

## In common
- The Ulmer family orbit: Annie, Claire, Ellen, Bill.
- Annie's aunt-years — the childcare pattern that outlived the relationship.

## Open threads

## Strengthening
