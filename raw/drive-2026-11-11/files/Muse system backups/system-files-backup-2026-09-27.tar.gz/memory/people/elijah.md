---
display_name: Elijah
first_name: Elijah
summary: Felix's son — in the household's orbit since 2016; does homework at the house before basketball practice.
rank: 93
updated: 2026-09-27
---

# Elijah

## Facts
- Felix's son — Dan identified him as such on 2026-09-25, closing the wiki's documented open question (memory/2026-09-25.md#L1240).
- Comes to the household with Felix: a Suz iMessage from 2026-02-10 has Felix bringing Elijah over "to do his homework until basketball practice" while Felix painted at 463 Morgantown St (memory/2026-09-25.md#L1243).
- In the orbit since 2016: a 2016 John Felix thread mentions "feeding Elijah"; memory treats it as the same child as the 2026 homework-before-basketball-practice kid (memory/2026-09-25.md#L1240).
- Plays basketball (practice schedule, per the Feb 2026 message).

## History
- 2016: mentioned in a John Felix thread ("feeding Elijah") — the earliest trace.
- Feb 10, 2026: Suz iMessage — Felix brought Elijah to the house to do homework until basketball practice while Felix did more painting at 463 Morgantown St.
- Sep 25, 2026: Dan stated outright that Elijah is Felix's son; the wiki recorded it as a gap-fill because it resolved a documented open question (memory/2026-09-25.md#L1236).

## The relationship
- Dan knows Elijah through Felix, who has been in the household's orbit since 2016. The tie is observed — a kid who comes to the house with his father — and no stated relationship exists on record, so it stays unnamed.
- No direct Dan↔Elijah contact is on record; everything about him arrives via Felix or Suz's messages.

## In common
- Felix, and through him the household and the 463 Morgantown St work crew.
- Basketball — his practice schedule is the reason the Feb 2026 homework visit was timed as it was.

## Open threads
- None on record.

## Strengthening
