---
display_name: Alice
first_name: Alice
summary: Annie's niece — one of the two kids at the center of Annie's aunt-years; the childcare pattern around her outlived the relationship.
rank: 90
updated: 2026-09-26
---

# Alice

## Facts
- Annie's niece (Claire's daughter) — a child Annie has regularly watched for years; the record calls her the child Annie helped raise.
- Started school in fall 2026 ("to hear about Alice's first day," Annie's messages, Aug 2026).
- Dan knows her only through Annie's aunt-years — she is part of the Ulmer-family orbit (Ellen, Bill, Claire), not someone Dan has an independent tie with.
- Annie's childcare pattern for Alice and Otto outlived the relationship: Annie was still watching and cutting Alice's hair in Aug 2026.

## History
- 2019–2020: born (birth-year inference from the school-start record; not a confirmed date).
- 2025–2026: Annie's messages from her number regularly name Alice — picking her up from school for Claire, sitting with her, the Aug 2026 "I gotta watch Alice / I gotta cut Alice's hair now" run.

## The relationship
- Dan's tie to Alice is entirely through Annie: she is the child Annie helped raise, and her care was a standing feature of the Annie years. The record shows no direct Dan–Alice tie, so the relationship stays unnamed.

## In common
- The Ulmer family orbit: Annie, Claire, Ellen, Bill.
- Annie's aunt-years — the years of regular childcare alongside the Dan–Annie relationship.

## Open threads

## Strengthening
