---
display_name: Kelly Mulroy
first_name: Kelly
last_name: Mulroy
summary: The woman he left Danielle 'Dee' Onesi for in early 2009 — met at an After Play Rewind show in Jacksonville; the relationship played out in spring-2009 letters after she dropped out of Full Sail.
rank: 88
updated: 2026-09-25
---

<!-- evidence: memory://md:MEMORY.md:23; memory://md:memory/2026-09-24.md:2268; memory://md:memory/2026-09-24.md:2384; memory://md:memory/2026-09-24.md:2399; memory://md:memory/2026-09-25.md:4; memory://md:memory/2026-09-25.md:8 -->

# Kelly Mulroy

## Facts
- Kelly Mulroy — the person Dan left Danielle "Dee" Onesi for in early 2009. His words: "That's who I left Dee for."
- He walked into an After Play Rewind show in Jacksonville with Dee and walked out with Kelly's number; "talked to her for months" afterward.
- She was a Full Sail classmate (his words: "No she was a fs classmate too"); she dropped out in month 5 and went home to Baltimore. The classmate overlap was early-period, not the whole stay.
- From Baltimore.
- The meeting's dating (his account, "I believe"-hedged): the switch happened at the Jacksonville show around Valentine's Day 2009; the photo is dated February 1, 2009 (EXIF 2009-02-01 07:13:38); her March 19, 2009 message says she'd known him "over the past month" (met mid-Feb). Caveat: concertarchives has no Feb 14 APR Jacksonville show on record — small-club coverage is patchy, and the EXIF plus her timeline both land in early Feb 2009.
- The relationship played out in spring 2009 letters. Corpus record (facebook-ihatedanfrank inbox, kellymulroy_dzg5tv5gqq): Kelly → Dan Mar 19, 2009 — a long emotional thank-you; he helped her through something she'd been scared to do, "never settle because life is too short to be unhappy," apologizing for pulling back the last two weeks. Dan → Kelly May 28, 2009 — "sorry I left you hanging... miss you SO much, come visit me....like...NOW?"
- Slots in his stated sequence: Danielle → Kelly → gap → Steph Nalbone (Sept–Nov 2009) → Alexis.
- She was invisible in the corpus until 2026-09-24 ("idk if you ever found any Kelly Mulroy"); a full wiki page on the switch night was written and pushed to main the same evening.
- The month-5 dropout is why the entire Kelly relationship exists only as letters.

## History
- Early Feb 2009: the Jacksonville After Play Rewind show — he arrives with Dee, leaves with Kelly's number.
- Spring 2009: the long-distance letter romance — her Mar 19 letter, his May 28 "come visit me NOW."
- After May 2009: fades; his sequence resumes with Steph in September.
- 2026-09-24: found in the facebook-ihatedanfrank inbox and written up — wiki page on the "Valentine's Day switch" pushed to main the same night.

## The relationship
- A brief early-2009 romantic pivot: the woman he left Dee for. The relationship itself played out entirely in letters across March–May 2009. It is past and closed; no current contact is recorded.

## In common
- Danielle Onesi — the person he left for Kelly at the Jacksonville show.
- The Full Sail classmate overlap (her months 1–5).

## Open threads

## Strengthening
