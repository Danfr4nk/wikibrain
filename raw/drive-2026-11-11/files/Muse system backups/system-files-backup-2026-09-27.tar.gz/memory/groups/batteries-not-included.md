---
display_name: Batteries Not Included
summary: Dan's teenage band — he drummed in it (bleach-blonde era) with Joe Oshnack.
rank: 7
updated: 2026-09-25
---

<!-- evidence: window 2026-09-25 (band photo, message:5b273bb4-78bf-436b-ab1f-da8af18dbcaa; Dan's "That's ya boy… bleach blonde hair and incubus shirt" ID, message:e4e09344-07c4-4080-af52-9d2592b49e0c; band-name confirmation "Batteries not included," message:975a8edb-80f5-4d20-aca6-414939f4072b); ~/memory/people/joe-oshnack.md -->

# Batteries Not Included

## Purpose
- Dan's teenage band — his documented drummer years, pre-production, pre-NYC. The punk phase: bleach-blonde hair, Incubus shirt, behind the kit.

## Members
- Dan: the drummer — ID'd by him in the band photo, 2026-09-25 ("That's ya boy… bleach blonde hair and incubus shirt").
- [Joe Oshnack](../people/joe-oshnack.md): high-school bandmate in the band.

## Dynamics

## Themes

## Open threads
