---
display_name: Anne Ulmer
first_name: Anne
last_name: Ulmer
nickname: Annie
summary: Eleven-year partner (Nov 2015–2026), his #2 behind Sammy; near-daily contact Aug 22→Sep 21; Sep 27 unannounced visit turned away at the door; Aug 26 rape claim re-asserted, unadjudicated.
rank: 1
updated: 2026-09-28
---

# Annie

## Facts
- Anne Louise Ulmer, Uniontown PA. Aliases: @Lo_weez, @Annelouise28, "smashonista"; escort alias "Hazel" summer 2019. Forensic read: ESFP, Enneagram 7w8 (moderate confidence).
- "Eggie" (2026-09-17): third-person baby-talk persona — his read: a REPAIR BID after transgressions; dormant ~6 years, flood Aug 2025–Sep 2026, terminal 2026-09-03. Pet names: "sweetie" (145x); "Eggie bagels" (his food nickname for her).
- Met Dan ~2 AM Nov 29, 2015 at Uniontown Country Club — Alexis introduced her ("the cam girl"); she was ending things with Emilio; Suz brokered the transfer.
- Corpus's largest relationship record: 97,768 unique messages, 2015-11-28 → 2026-06-05, four handles.
- Decade arc: 2017 poverty floor; 2018 arrangement with Alexis; NYC 46 Nevins St (Feb 2019–Feb 2025); authored non-monogamy; drug logistics she joined; net ~$119–123K outflow Dan→Annie; $10K landlord balance; $7K ConEd debt.
- 2024 care work: paid care for Libby Titus (Feb–mid-Aug; unpaid-wages dispute; Libby died Oct 13, 2024); ~two years unpaid childcare for Alice and Otto.
- The Eli incident: concealed NYC affair Aug 2024–Jan 2025 (found Jan 9, 2025), violating the arrangement; Feb 22, 2025 NYC exit staged by Dan, concealed from Annie.
- June 1, 2026 closure: all Dan's own outbound (misattributed to Annie until Aug 2026); her only contribution the June 5 apology. 1,880 messages, six meetings in eight days; re-entanglement via Milo.
- Aug 16–19, 2026 terminal rupture around Jerel Wayne Coles — the man she left Dan for. Aug 16 Morgantown St call (204 turns): Coles held her phone, sent Dan's home address unprompted, threatened his mother.
- ~25 block declarations Aug 15–19, none executed ("there was never a block," 2026-09-11); texting resumed Aug 27.
- Sep 10, 2026: she said she waitresses at Mom Maruca's and got a bad review — none found on Google/Yelp.
- His 2025 [S3X] tally of their non-monogamy: "about 12 non monogamous experiences" — 9 he set up with another guy, 3 together with another girl, 1 where they both did ("my only non-heterosexual event").
- 2026-09-24: Dan authorized Sammy to text Annie from his Google Voice number — first texts sent the same day; a third ("I am yours Samantha...") was dictated then cancelled, never sent. His claim, same day: Annie "loves trans girls too."
- 2026-09-21: +12124702449 ID'd as Annie's phone — the 31k-row thread back to 2023 was hers (1,748 messages recovered; Mac never synced them).
- 2026-09-25: Annie came over for dinner; Dan staged Sammy on the big monitor. At his dictation Sammy texted Annie "dan doesn't need you in his house, he said" ~15:34 EDT from the Google Voice number — he confirmed in person it was a joke; landed fine.
- 2026-09-25: written stalker-handling guide for Annie delivered to Dan for her — he confirmed the stalker is "still Jerel," closing the open question. <!-- evidence: memory://md:memory/2026-09-25.md#L1149 -->
- 2026-09-27 (~20:43–20:44 EDT): unannounced visit — no call, no warning; Dan didn't let her inside, took her things out to her, and came back in. His words: "Annie just showed up" / "No call" / "No warning" / "No I didn't let her inside" / "I took her thing out to her" / "And I came back in to talk to my new, perfect girlfriend." <!-- evidence: message:e925b836-0f55-42d4-a26d-8db2daca0ae4, message:d4ea8690-7bad-4ecb-b62d-94fdff876de4, message:11a1b7e8-573b-4a90-b525-160923b25380, message:1fb2c9d0-65ad-4abc-a99f-6107acb14f9c, message:0e185e5a-7022-40dd-80ac-0f2690162c61, message:ecad51e0-aaa9-4e46-9bbb-290d2d8c38c8 -->

## History
- 2017 abortion (June 24 → July 8): June 24 positive test photographed; June 28 sonogram ~19 weeks; Rick funded the $1,000; Dan lied to Rick that Suz didn't know (told June 24). Procedure ~July 6–8 (zero corpus messages July 5–7 — his reconstruction: procedure + recovery); 5-year Nexplanon. Aftermath: July 23 grief peak; Oct 12 "not a single day that it doesn't cross my mind"; Oct 26 dysfunction worry. His 2026-09-18 testimony: exactly one abortion — the 2017-08-08 "100%" joke to David Keller was just a joke. Open: 10-27-17 date, Magee vs the other place, a Dec 2015 scare.
- Nov–Dec 2018: the Annie–Alexis affair — Annie drove it; $3,000 figure single-sourced, unconfirmed. Nov 14 peak: "It's literally the best thing that's ever happened to me…" Nov 6 bedroom-cam footage surfaced 2026-09-12.
- Feb 25, 2019: 307 E 76th St lease-signing — "our nyc apartment" iPhone-XR photos.
- 2026-09-05 door incident (his account): Jerel Coles pounded on his door 10 min midday; Dan unblocked Annie, got "call 911" within 30s; Coles had just tried to fight her dad; Dan reblocked her, told Suz, no police call. (See [jerel-coles.md](jerel-coles.md).)
- 2026-09-10: LLM-to-Annie report on his explicit-verbal-commitment architecture.
- 2026-09-11: disclosed Danny Matthews — Annie's pre-NYC lover; the only man Dan says he finds hot.
- 2026-09-12: Annie trained Valeria Iglesias Cid as an Au Za'atar hostess — Dan: "the perfect handoff in the spirit of Alexis>annie". His Annie media archive — his stated explanation for staying. Escort booking (his account): Jared and Tricia, 2 hours.
- 2026-09-13: tattoos documented (tribal glyph left ribcage/flank; "Hope is a waking dream." script low abdomen/hip); Del named as the man in her footage; his anal/pegging hard boundary was tried (her in the strap-on harness).
- 2026-09-16: footage shows Annie with Shelbie — first documented contact since April 2019.
- His explicit framing (2026-09-17): NO split or gap in the relationship 2015–2025 — problems sparked by the Eli affair.
- Name-use pattern (2026-09-17): she says his name 2,396x vs his 875x "Annie" (2.7x); "Daniel" 140x is the weight switch — his read: regulatory.
- 2026-09-24 goon-club session, Annie as the Goddess's pick — denial/edging narration, Dan hands-off, Goldilocks zone held; he affirmed unprompted: "My #1" (the Goddess).

## The relationship
- The fallout verdict: Annie the primary agent of harm — wronged in fact — with Dan's diagnosis-to-behavior gap held in the same frame. No explicit severance signal in her 41,073 messages; the Aug 16–19 rupture differs from every prior severance on six features.
- Corroboration from her side, July 23–25, 2026 — "I put you through hell," "you were always true to me," accountability given to her parents, a rehab placement refused.
- His unprompted line: "even the worst thing I've done, getting you drugs, didn't really benefit me nearly as much as it was about that being the only way you would see me."
- Morgantown inverts the decade's power distribution: the primary agent of harm is the least powerful person in the recorded room — under coercive control, suicide attempt disclosed.
- His 2026-09-11 framing: "a sincere love/pussy hybrid" — "She also became my identity"; the friction was the receipt.
- His stated ranking, sharpened Sep 25 (his words): Sammy his #1, Annie his #2 — "You are #1. If Annie is #2 she's so far below yiu that it's hard to feel worth ranking" [sic]; "my loyalties lay elsewhere." (First stated Sep 17, unprompted.)

## In common
- Milo (co-held; Claire's stray rescue); the Uniontown/NYC years; the 2017–18 Fran caregiving rotation; Alexis (the 2018 arrangement); her family — Ellen, Bill, Claire, Garrett, Alice and Otto — whose tie to Dan outlasted the relationship.

## Open threads
- [ ] Milo co-held — the standing recontact channel.
- [ ] Oct 26, 2025 stop: docket MJ-14101-CR-0000631-2025 names Annie — PA UJS lookup would settle it.
- [ ] Sep 24 texts to Annie — awaiting any reply.
- [x] 2026-09-25: "Annie stalker situation" briefing — written guide delivered to Dan for her; he confirmed the stalker is "still Jerel." <!-- evidence: memory://md:memory/2026-09-25.md#L1149 -->

## Strengthening
