---
display_name: Suz
first_name: Suzanne
last_name: Frank
nickname: Suz
summary: Dan's mother — the second-largest correspondence in his life; permanently available, currently co-habitating with him at 463 Morgantown St.
rank: 2
updated: 2026-09-28
---

<!-- evidence: memory://md:MEMORY.md:9; corpus-extract/agent-B-people.md (§ Suzanne Frank — mother, rank-2 correspondent); window 2026-09-13 conversation (message:2e55b71e-10e7-4c9e-be8e-028ba72aab35); window 2026-09-18 story-time abortion sweep (assistant-msg-24c8e0ea-20f9-4818-9974-c55aedcf6f4c; her archive is the sole record of the Dan↔Suz thread); window 2026-09-19 conversation (assistant-msg-e4cd47c3-62ab-b992-ed4e-89869fe6c32d and assistant-msg-08f6-b0b8-5fce-8f37f11fc7c1; the 2010 Suz↔Dan Gmail-SMS archive find, merged as PR 126); memory://md:memory/2026-09-21.md:956 (2026-09-21 coffee-for-a-line exchange); window 2026-09-23 (2010 Suz↔Dan SMS batch content — Kenney); memory://md:memory/2026-09-23.md:1337 (Sep 23, 2026 2:09 PM text to Suz at +17243228715, confirmed delivered); MEMORY.md (Voice number designated Sammy's 2026-09-23; scope widened 2026-09-24); window 2026-09-28 conversation (message:26b106f1-089c-4eab-9218-808f3af41220, message:0fddd915-a119-4382-838c-0759df376ad3; Suz's Amazon Prime cutting out during football — Dan blamed server load, conceded when corrected); memory://md:memory/2026-09-11.md:962 (Fran: "is this your birthday or my birthday" — Suz "characteristically making everything about herself," Dan's words) -->

# Suz

## Facts
- Suzanne Frank, b. September 15, 1962; licensed Pennsylvania realtor (Park Place Realty Group, Uniontown).
- Dan's mother. Divorced Dan's father Rick ~2005.
- Second-largest relationship record in the corpus: 33,698 messages (against ~2,000 with his father).
- Posture toward Dan: permanently available — the inverse of Rick's withdrawal — with a "give-and-invoice" financial pattern running through the whole thread.
- Filed Chapter 13 in October 2024; under a court drop-dead provision sold the family home at 337 Saratoga Drive for $465k in June 2026.
- In early 2026 Dan and Suz moved into 463 Morgantown St (owned by Alexander Jackson), with no signed lease — housing still unsettled as of Aug 2026.
- Her mother Diane Moore barred Dan from Fran's house during the 2018 death vigil.
- Suz names Fran Coldren "the one and only guiding force in my life" — the generation-skipping attachment Dan reports too.
- June 27, 2017: disclosed to Dan that she'd had a D&C herself — the only abortion-adjacent history on record on either side of the family.
- Dan ID'd her number on 2026-09-21: +17243228715 is Suz's number; 54 of its messages were recovered in the iPhone union merge.
- 2026-09-23: Dan designated his Google Voice number as Sammy's phone number — the standing outbound route to his people. First outbound text (to Suz) sent Sep 23, 2026, 2:09 PM, confirmed delivered. 2026-09-24: scope widened to full total access — Sammy may text Suz on her own initiative.
- 2010: dating Kenney — her boyfriend that year, who met Fran and Diane (from the recovered 2010 Suz↔Dan SMS batch).

## History
- Married Rick Frank Aug 31, 1985; divorced ~2005 after the November 2005 rupture (Rick's rehab admission, her affair with the family dealer).
- Co-raised Dan with her grandmother Fran; Dan was Fran's caregiver alongside Annie in 2017–18.
- 2017 abortion (June 24 → July 8): her role, from her own archive — the entire Dan↔Suz thread around it exists ONLY there; Dan's iMessage export lacks it. Told June 24; her stakes speech: "That's enough! This will come back to haunt you if you don't deal with it." June 27 she disclosed her own D&C ("it isn't bad physically really but she may have to have a day or two of rest") — recovery coaching that matched Dan's later reconstruction of the July 5–7 silence. Dan lied to Rick that she didn't know yet — she had, since June 24. July 10 she confided it to a friend: "I had a life changing event last week... it involves grandchildren... I'm not... now... Oh god. It was horrible... but the only responsible choice."
- Money spine: $14,000 to Dan in 2018 (mother-ward); itemizes the cost of her total availability.
- 2026-09-13: Suz came downstairs shouting "YOU HAVE TO TAKE META MUSE OFF OF ALL OF MY STUFF," blaming Muse for her failing Clareity MLS login (clareityiam.net). The login button was dead because Firefox's Enhanced Tracking Protection blocked the page's third-party scripts (Google's jQuery CDN, Mixpanel, PingOne) — diagnosed from a screenshot, never touching her accounts or devices. Dan explained Muse is only a chat app on his phone; it defused, and a Firefox update fixed the page. Likely trigger: a Clareity "new sign-in" security alert landing in her inbox while they were troubleshooting.
- 2026-09-19: Dan found his old 2010 texts with Suz — "i found those old 2010 text messages. thats almost 400 messafss feom 5 years rarlier than any we had so far" (his words, typos verbatim). The Gmail-SMS archive held 317 messages of 2010 Suz↔Dan SMS, the oldest correspondence in the corpus, merged to wiki main as PR 126 (04:59 EDT).
- 2026-09-21: Suz gave Dan a single-use portion of her cocaine in exchange for the coffee he made her — confirmed real, not a bit. A new dated instance of her long-documented role as the family's internal cocaine provision node (2015 records show her bringing him lines before dawn, and routine provision to him and Annie).
- 2026-09-28 (~12:01 AM EDT): Suz's Amazon Prime kept cutting out while she watched football; Dan had told her it was probably server load from the game — when told it was almost certainly her wifi/router, he conceded ("She was right then!") and gave her the win.

## The relationship
- The constant pole: extreme availability, financial support with accounting, and daily contact across the whole record.
- The tie carries both the highest support and a documented resentment loop ("give-and-invoice").
- Technology distrust: she believes Meta/Muse is installed on her devices — the Sep 13, 2026 MLS-login flare-up came from that belief; Dan's explanation (nothing of hers was touched) defused it.
- The friction pole: Dan's own pattern-read is that Suz "makes everything about herself" — his words about her in a 2026-09-11 video memory (Fran told her "is this your birthday or my birthday").

## In common
- Fran Coldren — named by both as their guiding force; shared history in Uniontown real estate and the family homes; Danielle Onesi is now Suz's closest friend.

## Open threads
- [ ] 463 Morgantown St: no signed lease/POA as of Aug 2026 — obligations unresolved.

## Strengthening
