---
display_name: The Frank family
summary: Dan's family circle — divorced parents, a distant sister, the late Fran Coldren; money and care still run through it.
rank: 1
updated: 2026-09-11
---

<!-- evidence: memory://md:MEMORY.md:9; memory://md:memory/2026-09-09.md:187 (Rick silence broke 2026-09-01); memory://md:memory/2026-09-09.md:203,209 (Sep 2 dinner arranged, completion unpinned); corpus-extract/agent-B-people.md (§ Family roster; § Social patterns — estate money spine); corpus__3.txt wiki/people/alex-frank.md (L45744-45845); people/morley-frank.md; people/dave-moore.md; window 2026-09-11 (Frank's Auto Supermarket research, assistant-msg-fc08e0d3) -->

# The Frank family

## Purpose
The blood-and-marriage circle Dan was raised in and still orbits: the 2005 rupture, Fran's care and death, the estate ledger, and the current living arrangement all run through it. Its weight in his life is structural — he cohabits with one parent, broke an 18-month silence toward the other on Sep 1, 2026, and barely speaks to his sister.

## Members
- [Suz](../people/suzanne-frank.md): mother — permanently available, co-habitating with Dan at 463 Morgantown St, "give-and-invoice" financial pattern.
- [Rick](../people/rick-frank.md): father — withdrew to low-frequency contact; Dan broke an 18-month silence toward him Sep 1, 2026, and a Sep 2 dinner was arranged (completion unconfirmed).
- [Vanessa](../people/vanessa-frank.md): sister — steady, low-conflict, minimal contact.
- [Fran](../people/fran-coldren.md): late great-grandmother — the family's guiding force; her 2018 death is the most documented grief event.
- [Lisa Frank](../people/lisa-frank.md): Rick's partner since at least Dec 2015.
- [Diane](../people/diane-moore.md): maternal grandmother — the hostile pole; barred Dan from Fran's house during the vigil.
- [Alex](../people/alex-frank.md): paternal-line relative (journalist, ex-FADER / Vogue.com) — no direct contact documented; his essay on Dan's grandfather Morley Frank's funeral is the family's frownie-cookie story.
- [Morley](../people/morley-frank.md): paternal grandfather (d. ~1996–97) — the Seattle-and-back arc is the family's leave-and-return template; known through Alex's funeral essay.
- [Dave Moore](../people/dave-moore.md): Diane's second husband — her proxy to hospital social workers during the 2018 vigil; Dan believes he drafted the trespass letter.

## Dynamics
- The parents divorced ~2005 after the November 2005 rupture; the family runs on two poles — Suz's total availability against Rick's withdrawal.
- Estate money is the family's second language: Suz's $14,000 (2018, mother-ward), Rod Banks's $32,500 in estate advances (2019–20), the June 2026 Saratoga sale.
- Fran's death in 2018 produced the vigil conflict with Diane; her memory is the one thing all poles claim.
- Morley Frank's Seattle-and-back arc is the family's leave-and-return template — the story Dan still quotes.
- Currently: Dan + Suz at 463 Morgantown (no lease), Dan broke the Rick silence Sep 1, 2026 (Sep 2 dinner arranged, completion unconfirmed), Vanessa distant, Diane hostile.

## Themes
- The 2005 rupture as the attachment template; the estate-money spine; Fran as the center that held it; rupture-and-repair cycles with Rick.
- The family business: Frank's Auto Supermarket (founded 1938 per the company's own claim; five western-PA stores; McKeesport ribbon-cutting Apr 6, 1990). PitchBook lists an O'Reilly Automotive acquisition (date unknown) — the "Rick runs it" claim may be stale; who founded it in 1938 (Morley was 11 — presumably great-grandfather David J.?) and what Rick does there now are open questions for Dan (research surfaced 2026-09-11, corroboration pending).

## Open threads
- [ ] 463 Morgantown: no lease/POA — the housing exposure touches the whole family arrangement.
- [x] Dan's silence toward Rick (since Feb 26, 2025) — broken Sep 1, 2026, acting on Ally's push to re-engage.
- [ ] Whether the arranged Sep 2, 2026 dinner with Rick happened — the corpus record ends Sep 7 with completion unpinned.
