---
display_name: The Nemacolin crew
summary: Dan's 2016–19 golf-caddy crew at Nemacolin Woodlands — the three-year work circle with its own manager, friction episodes, and one genuine friendship.
rank: 4
updated: 2026-09-18
---

<!-- evidence: corpus-extract/agent-B-people.md (§ Brad Hubeaut; § Davey Fitzpatrick; § Christian Hanson; § Christo Coan; § Vaughn); ~/memory/people/jack-rusko.md; window 2026-09-18 story-time (Brad's June 2017 abortion-provider remark, assistant-msg-d672db3d-66c7-47bd-b47d-f7c9435fc40c) -->

# The Nemacolin crew

## Purpose
The caddy-yard circle of Dan's 2016–19 Nemacolin Woodlands years — the longest blue-collar stretch before Au Za'atar, and the work crew that sat between the NYC exit and the restaurant era. One genuine friendship came out of it; the rest is the texture of a working yard.

## Members
- [Brad Hubeaut](../people/brad-hubeaut.md): caddy manager 2017–18 — the friction pole; documented an April 2018 episode over uncleaned carts and turned-down shifts. June 2017: told Dan (via Annie) he'd been at the same abortion provider recently with someone else — "we could write off the procedure as an occupational expense."
- Davey Fitzpatrick: assistant caddie master — the job's operational log.
- Christo Coan: golf-course coworker — co-organized Dan's October 31, 2017 Halloween/birthday party; his thread carries the passing reference to Dan's otherwise undocumented DUI.
- [Jack Rusko](../people/jack-rusko.md): fellow caddy and genuine friend 2017–18 — the two-month laptop-loan saga; sent unprompted condolences after Fran's death.
- Vaughn: caddie and small-time weed middleman.

## Dynamics
- A working yard with a manager (Brad), an operations layer (Davey), a social organizer (Christo), and one real friend (Jack).
- Documented friction with management in April 2018 — uncleaned carts, turned-down shifts.
- Dan's place: rank-and-file caddy, 2016–19; the social fringe more than the yard's center, except with Jack.

## Themes
- Caddy-yard logistics and loop assignments; the friction with Brad; golf itself (Dan caddied and played with marquee regulars, including retired NHL forward Christian Hanson); the Halloween 2017 party; the Fran-death condolences that marked Jack out.

## Open threads
