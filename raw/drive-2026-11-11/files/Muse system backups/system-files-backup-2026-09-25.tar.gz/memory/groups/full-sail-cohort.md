---
display_name: The Full Sail cohort
summary: Dan's 2008-era Full Sail friend circle — the $5 birthday Venmo bit still runs 15+ years on.
rank: 3
updated: 2026-09-09
---

<!-- evidence: corpus-extract/agent-B-people.md (§ Eric Jester; § Jamie Mohler; § Matt Dunn; § Jason Bermejo) -->

# The Full Sail cohort

## Purpose
Dan's 2008-era circle from Full Sail (Recording Arts, graduated Sep 2009) — the peer group of his production years. Dormant more than active, but the threads never died: it's the era's durable friendship set.

## Members
- [Eric Jester](../people/eric-jester.md): film-school friend; the one whose music taste Dan defers to.
- [Jason Bermejo](../people/jason-bermejo.md): the era's most durable friendship; introduced Dan to Kid Cudi and DIY production.
- Jamie Mohler: Full Sail friend, NYC-1 household regular in 2011; the annual $5 birthday Venmo bit runs through Eric.
- Matt Dunn: fourth member of the cohort; the same $5 birthday bit, 15+ years on.

## Dynamics
Low-frequency, long-dormancy — dense 2009–13 banter decaying to decade-spanning check-ins. Eric is the hub: the birthday bit runs through him. Jason is the one whose friendship stayed at volume.

## Themes
Music and production; era nostalgia; the running $5 birthday bit.

## Open threads
