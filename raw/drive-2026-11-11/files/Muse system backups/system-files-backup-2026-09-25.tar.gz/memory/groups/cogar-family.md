---
display_name: The Cogar family
summary: Fran Coldren's extended family — her sisters, kids, and grandkids; Eddie & Brenda Cogar's surprise 50th anniversary party is Nov 7, 2026, and Dan's invited.
rank: 5
updated: 2026-09-16
---

<!-- evidence: memory://md:MEMORY.md (Cogar family bullet, 2026-09-16, Dan's words) -->

# The Cogar family

## Purpose
Fran Coldren's extended family — her sisters, their kids, and the grandkids; the family thread on Fran's side of the line. Dan knows them as "grams, so they're Franz family" (his words), and the connection runs through Fran, the person he names as his biggest life influence. They are a real family circle in his orbit: invites flow, milestones get celebrated, and Dan received one to Eddie & Brenda's 50th.

## Members
- Eddie Cogar: married to Brenda since 11/22/76; their surprise 50th anniversary party is Sat Nov 7, 2026, 3–6pm at The Silo, 1135 Main Street, Granville, WV 26534.
- Brenda Cogar: Eddie's wife; same party.
- Erica: the RSVP contact for the party (304-282-6579, RSVP by Oct 31).

## Dynamics
- Fran is the anchor — the Cogar family is Fran Coldren's line, and Dan's tie to them runs through her.
- Milestone gatherings are the contact surface: the Nov 7 surprise 50th is the dated event on the record.

## Themes
- Family milestones and gatherings on Fran's side.
- Eddie & Brenda's 50th anniversary (married 11/22/76).

## Open threads
- [ ] Eddie & Brenda Cogar's surprise 50th anniversary party — Sat Nov 7, 2026, 3–6pm, The Silo, Granville WV; RSVP by Oct 31 to Erica 304-282-6579.
