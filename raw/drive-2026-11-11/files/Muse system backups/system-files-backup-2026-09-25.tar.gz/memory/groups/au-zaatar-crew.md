---
display_name: The Au Za'atar crew
summary: Dan's 41-month restaurant crew (Mar 2021–Aug 2024) — his longest job, and the one boss he ever loved.
rank: 2
updated: 2026-09-12
---

<!-- evidence: memory://md:MEMORY.md (Work: Au Za'atar Mar 2021–Aug 2024, 41 months, longest job); corpus-extract/agent-B-people.md (§ Dimitri; § Ismaila Barry; § Manuel; § Felipe; § Tarik Fallous); window 2026-09-12T05:24–07:34 (message:assistant-msg-989805ba-9eef-31f4-efbe-7c0e1a1e01fa): Lou Bahet — Au Za'atar hostess, 1,602 Instagram messages Aug 31–Sep 20, 2023, then nothing. -->

# The Au Za'atar crew

## Purpose
Dan's NYC restaurant years — March 2021 to August 2024, 41 months, his longest job. One of the few warm workplaces on record: the tenure was viable because of the equal tip split, and the people outlasted the job unevenly.

## Members
- Dimitri: Greek manager of the Midtown spot — "the only boss or manager or supervisor who i have ever actually really loved"; promoted Dan busser→server.
- Tarik Fallous: owner-operator (with brother Ghassan); hired Dan on the spot with zero food-service experience; genuine post-termination warmth to Apr 2026.
- Ismaila Barry ("DJ"): Senegalese busser-turned-server; counts among Dan's best friends; same busser-to-server climb.
- Manuel: coworker turned genuine friend (2023–2026, mostly in Spanish); the friendship outlasted the job.
- Felipe: Dan's "unbelievably gay Colombian bff" from the job; the friendship did not survive the job's end.
- [Lou Bahet](../people/lou-bahet.md): Au Za'atar hostess; 1,602 Instagram messages over 21 days (Aug 31–Sep 20, 2023), then nothing — a burst of contact with a coworker, not a lasting friendship.

## Dynamics
- Dimitri promoted from within; Tarik ran an equal front-of-house tip split that made the 41-month tenure viable.
- Dan and DJ both climbed busser→server; Manuel's friendship outlasted the job; Felipe's didn't.

## Themes
- The job as the anchor of the NYC-2 era; the Valeria affair (winter 2021–22) ran through the workplace; post-termination warmth from Tarik.

## Open threads
