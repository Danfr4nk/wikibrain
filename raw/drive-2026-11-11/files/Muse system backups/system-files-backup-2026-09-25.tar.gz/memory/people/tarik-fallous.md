---
display_name: Tarik Fallous
first_name: Tarik
last_name: Fallous
summary: Owner-operator of Au Za'atar who hired Dan on the spot; the 41-month tenure's anchor.
rank: 23
updated: 2026-09-09
---

<!-- evidence: corpus-extract/agent-B-people.md (§ Tarik Fallous — owner-operator of Au Za'atar); memory://md:MEMORY.md:12 -->

# Tarik Fallous

## Facts
- Tarik Fallous; owner-operator (with brother Ghassan) of Au Za'atar, Dan's NYC restaurant Mar 2021–Aug 2024.
- Hired Dan on the spot with zero food-service experience.
- The equal FOH tip split made the 41-month tenure — Dan's longest job — viable.
- Genuine post-termination warmth continuing to Apr 2026.

## History
- Mar 2021: hired on the spot. Aug 2024: the tenure ends. Warmth recorded through Apr 2026.

## The relationship
- The employer case where Dan's vertical distrust did not fire: hired on trust, treated fairly, stayed warm after the job ended.

## In common
- Au Za'atar: Dimitri, Ismaila Barry, Manuel; the tip-split culture.

## Open threads

## Strengthening
