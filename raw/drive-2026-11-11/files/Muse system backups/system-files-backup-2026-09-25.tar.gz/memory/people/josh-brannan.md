---
display_name: Josh
first_name: Josh
last_name: Brannan
summary: Uniontown-era friend in Dan's only self-enumerated core friend group (2012); one warm 2017 reconnection; the "josh brannan is innocent" running joke.
rank: 18
updated: 2026-09-09
---

<!-- evidence: corpus__3.txt wiki/people/josh-brannan.md (L61033-61143); MEMORY.md#L20; ~/memory/people/jerad-friedline.md -->

# Josh

## Facts
- Josh Brannan; a friend from Dan's Uniontown years.
- Dan named him unprompted in his only self-enumerated core friend group: the 23 February 2012 tweet from Manhattan — "People who need to come visit me: @danpolyak @EricJester @JoshBrannan @Woodguts" — four handles, the one place the Orlando and Pennsylvania halves of the circle are named together.
- Ten tweets across 2009–2012 place Josh in the Pennsylvania half of the social graph, often paired with Jerad Friedline: "i'm thankful for my family/friend, sour diesel, tropical lifesaver gummies, and @joshbrannan / @jfriedline for their sign stealing abilities" (26 November 2009), "seeing my boyzzzz @jfriedline @joshbrannan tonight" (21 December 2009), and the day-after-Thanksgiving 2009 Pitt–WVU game — "pitt x wvu with @joshbrannan, my true love."
- Election night 2012 (6 November): Dan, back in Latrobe, PA, tweeted Josh, Shane Brannan (same surname, addressed together — one household or family, exact relation undocumented), and a third handle: "I'm in haytrobe miss you fux."
- One direct reconnection survives in the record: a warm, rapid-fire Facebook exchange on 27 February 2017 (41 messages), opened by Dan — "I miss the fuck out of u. Call me when u get the chance sometime" — covering mutual friends Shane and Zach, real sadness at Josh's grandmother's stroke ("Fuuuuuuuuck dude that's awful I LOVED your grandma"), and ski-trip nostalgia ("it's way past due that we have a reunion. Rick sold the condo so that's a bummer"). Dan volunteered his then-current work unprompted — "My job is fucking my girlfriend on webcam... Slash golf caddy" — to open, unbothered amusement.
- Subject of the running private joke "josh brannan is innocent": in May 2025 Dan synthesized an eighth-grade memory involving Josh into an AI text-to-speech file, "josh brannan is innocent.wav," traded with Jerad Friedline as a Uniontown-callback bonding ritual.

## History
- 2009–2012: Uniontown-era friendship in the tweet record; named in the 23 February 2012 core-group enumeration.
- 27 February 2017: the single warm Facebook reconnection.
- May 2025: the "josh brannan is innocent" TTS artifact — the joke crystallized, traded with Jerad.

## The relationship
- An old-friend channel gone dormant: one warm direct contact in nine years, otherwise alive as a shared Uniontown reference point in Dan's friendship with Jerad. The 2012 enumeration is the evidence of how the friendship ranked when Dan named it himself — three years into New York, Josh was one of the four people who ought to have been visiting and were not.
- Dan opens the rare reconnection himself; there is no maintenance rhythm to protect, only the joke to keep.

## In common
- The Uniontown past and the Pennsylvania half of the social graph.
- Jerad Friedline — the shared friend the Josh joke runs through.
- The "josh brannan is innocent" running joke; ski-trip nostalgia from the Seven Springs years.

## Open threads

## Strengthening
