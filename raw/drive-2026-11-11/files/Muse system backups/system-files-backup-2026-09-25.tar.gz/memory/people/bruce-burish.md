---
display_name: Bruce Burish
first_name: Bruce
last_name: Burish
summary: Laurel Highlands high-school friend; the one who got Dan busted for the Sunridge K2 condo party; warm contact through Sep 2024.
rank: 81
updated: 2026-09-24
---

# Bruce Burish

## Facts
- Dan's own words, 2026-09-24: "a friend from high school" — Laurel Highlands; not involved in caddying (a wiki inference tying him to the Nemacolin caddy era was struck as wrong the same day).
- The "Bruce" all over Dan's 2015–16 Alexis texts is her bar manager, not Burish — disambiguated in the 2026-09-24 cross-check.
- In Sag Harbor/Hamptons by 2018 (there again 2021); snap handle bburish9; birthdays days apart from Dan's (Nov 1).
- Contact runs through Facebook (Oct 2018 → Sep 2022, including "Hey kid", "Miss you brother") and Instagram (→ Sep 2024).
- Aug 2022, to Dan: "Secret is safe with me bro."
- Last exchange: Sep 14, 2024, on Instagram — Dan: "The 7springs party lol"; Bruce: "Jesus / When I got picked up / I remember it well / I got in so much trouble."

## History
- The Sunridge K2 party (the only party Dan ever threw at the family condo in the villages at Seven Springs — Sunridge K2): ~30 people from Laurel Highlands, and the one time his Uniontown friends and his Seven Springs friends collided. Dan's account, 2026-09-24: Bruce had his mom arranged to pick him up and was giving Ryan Basescu a ride home; Bruce showed up sloshed, got himself busted → Ryan got busted → Ryan's parents (friends with Rick) told Rick → Dan got busted. Bruce confirmed the bust himself in the Sep 14, 2024 exchange above.
- Oct 2018 (corpus): Dan to Bruce — "fuck everyone we graduated with" — corroborates the Laurel Highlands cohort.
- Nov 8, 2022 (Suz's iMessage archive): "Joni Basescu asked about the two of you" — the Basescus still in orbit with Suz.
- Correction note: an earlier version of his wiki article claimed no contact after Oct 2018; the 2026-09-24 cross-check found the unread Facebook thread and Instagram through Sep 2024, and the false claim was struck with a dated note.

## The relationship
- Warm, low-frequency, long-lived. Built on the high-school and Seven Springs condo years, not the later eras — Dan corrected the record on this himself.
- Dan is the one who reaches out (the Sep 2024 party message), and Bruce answers warmly and in kind — the tone is easy, bro-affectionate, with trust on the table ("Secret is safe with me bro").
- Bruce carries a shared piece of Dan's mythology — the bust cascade — and plays it back with his own memory intact.

## In common
- Laurel Highlands graduation cohort ("fuck everyone we graduated with", Oct 2018).
- Seven Springs — the condo years, the ski weekends.
- Same age cohort; birthdays days apart.

## Open threads

## Strengthening
- The thread's been quiet since the Sep 2024 party exchange; a casual check-in fits — Dan's the one who usually re-opens it, and Bruce has always answered warm.
