---
display_name: John Paci
first_name: John
last_name: Paci
summary: NYC landlord (307 E 76th St), full name John Paci Jr per public records; performed the eviction Dan asked him to fake in Jan 2025 — Ally Lubin confirmed it Aug 2026.
rank: 34
updated: 2026-09-24
---

<!-- evidence: corpus-extract/agent-B-people.md (§ John Paci — landlord/owner of 307 E 76th St); window 2026-09-11 (lease-signing photos, assistant-msg-e89f45bd); window 2026-09-24 (message:assistant-msg-1333d465-8636-43c5-9af4-7b30cba71d7d — "John Paci Jr" confirmed from public records; 2020 voicemails + roof-lockout night; Ally Lubin 2026-08-25 confirms the staged eviction; Jan–Feb 2025 Annie-window quotes rest on the lost dump alone); memory://md:memory/2026-09-24.md:833; wiki/people/john-paci.md (refreshed 2026-09-24) -->

# John Paci

## Facts
- John Paci Jr — full name confirmed by the Augrented public-records building report (crawled 2026-06-21); landlord and owner of 307 E 76th St (a 5-story, 20-unit Old Law Tenement, built 1910, Upper East Side) for the full six-year tenancy, Feb 2019 – Feb 2025.
- Ran the building himself: leasing, exterminator scheduling, rent and debt collection all directly, no management company; building-wide notices signed "John PACI" (e.g. Dec 8, 2024).
- Feb 25, 2019: the 307 E 76th St lease-signing — iPhone-XR photos 8:19–8:20 PM, GPS-fixed to the block; the unit unfurnished, in move-in condition.
- Sep 1, 2020: the roof lockout — Dan texted Paci from a temporary Google number: "we got locked on the roof, is anyone in the building who can open the door for us?"; follow-up call logs Sep 2/7, and three voicemails Sep 11/16/18 about the exterminator/roach bombing, with callback 631-455-8185.
- Contact-card correction (2026-09-24): +16313513671 was Dan's own temporary Google number (Sep 2020), not Paci's — struck. The dyadic thread runs on +16314558185: 26 rows (13 sent / 13 received), Mar 2024 – Jul 2025.
- Jan 2025: Dan telephoned Paci and asked him to perform an eviction he would fake if Annie called; Paci agreed. Annie called; her parents called separately; he told both it was done. The vacancy itself was real and scheduled (contractors booked for Feb 9 against a Feb 8 move-out); the eviction threat was the performed part. Dan banked the final two months' rent as moving capital on purpose; Paci's Mar 5, 2025 accounting closed the balance at $10,000 after cleanup and the security-deposit deduction.
- Aug 25, 2026: Ally Lubin became the first third party to confirm the staged eviction — "After you faked the eviction?" → Dan: "Yes correctamundo"; then "Does she know you lied about the eviction?" Financial detail from Dan the same night: ~$10,000 owed, rent about to rise another $500, had been paying $750/week toward the balance, and had "been holding our landlord off for a full year."
- Corpus gap: the Jan–Feb 2025 Annie eviction-window correspondence — and Annie rows for Nov 2024 and Jul 2025 — exist in none of the current exports. Every quote from that window rests solely on the lost dox-scan dump.
- Jim Blanchard was Paci's on-the-ground man at the building (unofficial super and rental broker) and called him "one of the most outstanding people/landlords I have come across" in 28 years.

## History
- Feb 25, 2019: the 307 E 76th St lease-signing.
- Sep 2020: the roof lockout, the voicemails, the roach bombing — the building's org chart in miniature: tenant → Jim → John calls the exterminator → Jim cleans up after.
- Mar 2024 – Jul 2025: the dyadic Paci thread — ordinary rent-check mechanics (checks held, deposit timing), the baseline the February 2025 performance deviated from.
- Jan–Feb 2025: the staged-eviction arrangement — Dan's telephone ask, Paci's performance against calls from Annie and her parents, the real Feb 8 vacancy underneath, the two months banked. One tension on the record: the decode says Annie's parents called Paci; Dan's Feb 6 text says "I had to call her parents" — both can be true in sequence; the record doesn't settle the agency.
- Mar 5, 2025: Paci's $10,000 accounting.
- Aug 25, 2026: Ally Lubin's confirmation — the first outside voice on the staged eviction. Her "Does she know you lied about the eviction?" puts honest tension on the account's "she never found out" — unresolved.

## The relationship
- A landlord who played along with a deception at Dan's request — cooperative, and entangled in the Annie-era cover stories. Six years of warm, functional correspondence; agreeing to play the villain for a tenant who owed him five figures is a larger favor than simply holding an apartment, and the warmth of the record makes the Jan 2025 performance more remarkable, not less.
- One of the landlord cases Dan files under the same authority-skepticism lens as his bosses.

## In common
- 307 E 76th St; the Jan–Feb 2025 eviction episode.
- Jim Blanchard — Paci's on-the-ground man at the building.

## Open threads

## Strengthening
