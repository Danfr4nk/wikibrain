---
display_name: Jacob Bacharach
first_name: Jacob
last_name: Bacharach
summary: Novelist from Dan's childhood Saratoga Drive neighborhood; Rick hired teenage Jacob for a TV commercial; Dan deliberately follows his work and the 'Uniontown Glitch' coincidence chain around him.
rank: 63
updated: 2026-09-15
---

<!-- evidence: memory/2026-09-12.md#L207; memory/2026-09-13.md#L52; memory/2026-09-15.md#L225-240; wiki/people/jacob-bacharach.md (Danfr4nk/wikibrain) -->

# Jacob Bacharach

## Facts
- Jacob Bacharach — novelist; author of *The Doorposts of Your House and on Your Gates* (2017) and *The Bend of the World*.
- The Bacharach family lived halfway down Saratoga Drive from the Frank family in Uniontown — Dan's childhood neighborhood.
- Dan's father Rick hired teenage Jacob to play a teenager in a TV commercial.
- Dan deliberately follows his work: the record holds a search chain — a 2011 obituary (a Bacharach), Feb 7, 2021 "jacob bacharach twitter," and Nov 2021 searches of the novels. Dan's held Goodreads export contains exactly one Bacharach title: *Doorposts*, rated 5.
- *Doorposts* is the Uniontown/Fayette County novel — Bacharach's own Feb 2021 message (held in the record) names it as the Uniontown book.
- Dan frames 155 Virginia Avenue as the address with "a bunch of really weird and odd coincidences" — his words — specifically "the series of Jacob Bacharach coincidences that center around the house" (2026-09-13).

## History
- The Bacharach family lived halfway down Saratoga Drive from the Franks during Dan's Uniontown childhood; Rick (Frank's Auto Supermarket) cast teenage Jacob as a teenager in a TV commercial.
- 2011: Dan searched a Bacharach obituary.
- Feb 7, 2021: Dan searched "jacob bacharach twitter"; Nov 2021: searches of the novels.
- Feb 2021: Bacharach's own message names *Doorposts* as the Uniontown book — held in the record.
- 2026-09-13: Dan described the Bacharach coincidence chain around 155 Virginia Avenue in chat.
- 2026-09-15: the wikibrain article `wiki/people/jacob-bacharach.md` was created, and the engine's contradiction audit (work-0030) resolved that the Virginia Avenue passage is from *Doorposts* (2017), not *The Bend of the World* — Dan's retelling had drifted for five years on a wrong label inherited from a held Gemini session.

## The relationship
- No personal friendship on record; the tie is childhood-neighborhood proximity plus years of deliberate, curious attention from Dan. Bacharach is one of the few creators Dan both grew up around and keeps actively returning to — the neighbor-family figure who became the center of the "Uniontown Glitch" coincidence chain.
- The relationship on Dan's side is researcher-to-subject: he holds Bacharach's message about the Uniontown book, tracks the work (a Goodreads 5 for *Doorposts*), and treats the coincidence chain as standing lore.

## In common
- Saratoga Drive, Uniontown — the childhood neighborhood both come from.
- Uniontown/Fayette County as subject matter — *Doorposts* is the novel Dan reads as the Uniontown book.

## Open threads
- [ ] The Uniontown Glitch: Dan's standing fascination with the Bacharach coincidences around 155 Virginia Avenue — no action pending, but the record keeps growing.

## Strengthening
