---
display_name: James Blanchard
first_name: James
last_name: Blanchard
nickname: Jim
summary: Unofficial super and rental broker of 307 E 76th St (his own words, 2025) — the building's day-to-day man across Dan's whole NYC tenancy; six years of warm correspondence, mostly with Suz.
rank: 87
updated: 2026-09-24
---

<!-- evidence: window 2026-09-24 (user message:616f1cdd-8f6e-434e-9b4a-b37a0a514c91 commissioned the cross-corpus rewrite; message:assistant-msg-1333d465-8636-43c5-9af4-7b30cba71d7d — role confirmed in his own words to Suz 2025-02-08; Nov 2019 "i'm in jim blanchards apartment" went to Annie; Maertens number struck); memory://md:memory/2026-09-24.md:833; wiki/people/jim-blanchard.md (rewritten 2026-09-24) -->

# James Blanchard

## Facts
- James "Jim" Blanchard — the unofficial super and rental broker of 307 E 76th St. His own description, given to Suz on 2025-02-08: "I was the quiet 'unofficial super' at my building and still help tenants whenever I can. I was the rental broker for many years."
- Email jtblanchard66@gmail.com; phone +19173631636. The +18082854597 that sat on his contact card was struck 2026-09-24: it belongs to Matt Maertens, an adjacent Facebook address-book row — zero rows in either corpus.
- Feb 25, 2019, lease-signing day: Dan texted Annie "No jim is the landlord"; Annie's gloss the same minute — "James 'Jim' is the guy we have been talking to." He was never the landlord. John Paci was the owner, and Jim referred to Paci as "your landlord" in the third person.
- He met Dan and Annie on move-in day and was the building's day-to-day man for the full six-year tenancy: move-in logistics, building-wide tenant notices under his own name, coordinating the landlord's access, water shutoffs, leak checks, exterminator scheduling, basement access.
- Dan ↔ Jim correspondence: 54 rows, Mar 1, 2019 – Dec 28, 2023.
- Suz ↔ Jim correspondence: 205 rows, Sep 7, 2020 – Mar 30, 2025 — the bigger channel, and the warmest third-party relationship in the 76th Street record. Sep 17, 2020, Jim to Suz, on Paci: "John is one of the most outstanding people/landlords I have come across" in 28 years in the business.
- Nov 15, 2019: Dan texted Annie "i'm in jim blanchards apartment."
- Sep 2020: Jim's crisis correspondence ran through Suz with Annie as the subject; his Sep 7 text to Suz ("He texted me with it last week when he was stuck on the roof") cross-corroborates the Sep 1 roof-lockout night.

## History
- Feb 2019: lease-signing day; Dan briefly believed Jim was the landlord.
- Mar 2019 – Dec 2023: the direct Dan↔Jim thread — warm throughout, one friction point (a rent-pressure exchange, 2021-06-10, ended warmly).
- Sep 2020 – Mar 2025: the Suz↔Jim thread — 205 rows; the building's daily life mostly ran through this channel.
- Feb 2025: Jim writes to Suz in the past tense ("was") and mentions landlord/tenant court — unexplained; no falling-out on record.
- After Mar 30, 2025: silence in both threads.

## The relationship
- Dan never names what Jim was to him, so the page doesn't either. The record shows the person you talked to about the building for six years — warm, cooperative, and closer to Suz than to Dan (205 rows to 54).
- Dan's own retrospective tag for Jim, "worlds worst" (operator capture, Aug 10, 2026), is uncorroborated-to-contradicted by the contemporaneous record: 259 dated messages, warm throughout, one friction point that ended warmly.

## In common
- 307 E 76th St — Jim's building, Dan's home for six years.
- John Paci — the owner Jim worked under, scheduled access for, and praised.
- Suz — Jim's larger correspondence; the crisis channel (Sep 2020, landlord/tenant court 2025).

## Open threads

## Strengthening
