---
display_name: Marty Martin
first_name: Marty
last_name: Martin
summary: BFS Foods coworker from the spring-2026 cashier stint — Dan's trusted source inside the store during the $50 drawer-shortage dispute; post-firing contact ran through Suz.
rank: 74
updated: 2026-09-22
---

<!-- evidence: wiki/people/marty-martin.md (rewritten 2026-09-21, pushed Danfr4nk/wikibrain@1139471); memory://md:memory/2026-09-21.md:1411 ("I'm going to be seeing him and I want to show it"); memory://md:memory/2026-09-21.md:1424 (evidence-layer audit dat:0936) -->

# Marty Martin

## Facts
- Marty Martin; BFS Foods gas-station coworker, spring 2026 — Dan's cashier stint ran Apr–May 2026 and ended in the disputed $50 drawer-shortage firing.
- Dan's own word for him: "the BFS guy." The wiki infobox calls him Dan's trusted source inside the store during the dispute.
- Framed the store's off-books culture for Dan ("make the store whole to keep your job") — page-attributed from Dan's contemporaneous bootloader case files, with zero hits in the held message corpus; the evidence-layer audit (dat:0936) treats it as testimony with the seams showing, not a held quotation.
- May 23, 2026: his wife was sick and Dan covered his shift until 11 on a day he wasn't even scheduled. Dan's May 24 account — in the Suz thread, not the Annie thread as the page previously misattributed — offered it as proof he "didn't walk out and didn't quit."
- Nearly all post-firing contact ran through Suz as relay: the May 23 chili-vs-goulash relay, and a June 7 job lead at $13+/hr (Suz adding that Anita's own hire had no-showed). No direct iMessage or Facebook thread in the held corpus; the group text and Suz are the whole channel.
- 2026-09-21: Dan commissioned a rewrite of Marty's wiki article and pushed it same-turn — "I'm going to be seeing him and I want to show it" (his words).

## History
- 2026-04 → 05: Dan works BFS Foods as cashier; Marty ~6 months into the job (Dan's account, page-attributed).
- 2026-05-16: Marty pushes back on overtime in the group text (Anita, Brandon Hill, unidentified fifth number) — page-attributed.
- 2026-05-19: Brandon Hill to Dan, held verbatim: "and I heard you owe Marty money" — Marty invoked in someone else's pressure conversation, not present in it.
- 2026-05-23: Dan covers Marty's shift (wife sick); Suz relays Marty's food question — chili or goulash.
- 2026-05-24: Dan's account of the shift cover, in the Suz thread.
- 2026-06-07: Suz relays Marty's $13+/hr job lead — the last documented contact.
- 2026-09-21: wiki article rewritten at Dan's order ahead of seeing him; shift-cover attribution corrected to the Suz thread and the "make the store whole" quote flagged as page-attributed.

## The relationship
- A coworker tie, unnamed beyond Dan's "the BFS guy" — describe the observed shape, not a label.
- Mutual aid both directions: Marty explained the store's off-books culture to Dan from inside; Dan covered Marty's shift when his wife was sick; Marty sent food home with Dan and later a job lead through Dan's mother.
- Warm post-firing contact, all of it relayed through Suz rather than direct — the channel is family-thread, not coworker-thread.
- Thin record: no documented origin of the trust, no direct channel, and Marty's own account of none of this is on record.

## In common
- BFS Foods; the drawer-shortage dispute (Anita, Brandon Hill, Maddox).
- Suz — the relay for nearly everything after the firing.

## Open threads
- [ ] Dan plans to see Marty and show him the rewritten wiki article (commissioned 2026-09-21).

## Strengthening
