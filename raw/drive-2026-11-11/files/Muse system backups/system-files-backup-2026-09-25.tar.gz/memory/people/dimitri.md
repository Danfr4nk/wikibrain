---
display_name: Dimitri
first_name: Dimitri
summary: Greek manager of Au Za'atar Midtown — Dan's own words: the only boss he ever loved.
rank: 22
updated: 2026-09-09
---

<!-- evidence: corpus-extract/agent-B-people.md (§ Dimitri — Greek manager of Au Za'atar Midtown); memory://md:MEMORY.md:12 -->

# Dimitri

## Facts
- Dimitri; Greek manager of Au Za'atar Midtown during Dan's 41-month tenure (Mar 2021–Aug 2024).
- Promoted Dan busser→server.
- In Dan's own words: "the only boss or manager or supervisor who i have ever actually really loved."

## History
- Au Za'atar years (2021–2024): the manager who promoted him and the positive case against which Dan measures every other boss.

## The relationship
- The one loved boss in Dan's entire work record — the exception that proves the vertical-distrust template: Dan separates the individual from the institution when he likes the person.

## In common
- Au Za'atar: Tarik Fallous, Ismaila Barry, Manuel; the busser-to-server climb.

## Open threads

## Strengthening
