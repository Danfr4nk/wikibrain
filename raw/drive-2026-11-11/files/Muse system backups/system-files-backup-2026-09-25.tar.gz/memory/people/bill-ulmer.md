---
display_name: Bill
first_name: Bill
last_name: Ulmer
summary: Annie's father — 58 warm messages 2017–2020, treated Dan as family, annual birthday texts.
rank: 20
updated: 2026-09-09
---

<!-- evidence: corpus-extract/agent-B-people.md (§ Bill Ulmer — Annie's father) -->

# Bill

## Facts
- Bill Ulmer; Annie's father.
- 58 warm messages, 2017–2020; treated Dan as family — signed off "Miss and love you both. Dad/Bill" in the record.
- Annual birthday texts, continuing the thread past its message-volume years.

## History
- 2017–2020: the warm thread runs through the Annie decade; a de facto father-in-law tie that stands on its own.

## The relationship
- De facto in-law who treated Dan as family in his own words; the paternal warmth pole of Annie's family graph.

## In common
- Annie's family: Ellen, Claire, Garrett, Alice, Otto.

## Open threads

## Strengthening
