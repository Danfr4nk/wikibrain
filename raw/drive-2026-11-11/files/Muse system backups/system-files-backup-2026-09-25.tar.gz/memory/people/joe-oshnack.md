---
display_name: Joe Oshnack
first_name: Joe
last_name: Oshnack
summary: High-school bandmate (Batteries Not Included); recipient of Dan's fullest account of his pre-2020 conservative identity and its reversal.
rank: 48
updated: 2026-09-10
---

<!-- evidence: corpus-extract/agent-B-people.md (§ Joe Oshnack); corpus-extract/corpus_index.txt (wiki/people/joe-oshnack.md) -->

# Joe Oshnack

## Facts
- Joe Oshnack — high-school bandmate; their band was Batteries Not Included (Park City UT).
- Recipient of Dan's fullest account of his pre-2020 conservative identity and its reversal.

## History
- High-school years: bandmates.
- Later: the recipient of Dan's most complete telling of the political reversal.

## The relationship
- An old bandmate who became the audience for Dan's hardest self-accounting — trusted with the identity story, not just the music.

## In common
- The high-school band years; Uniontown.

## Open threads

## Strengthening
