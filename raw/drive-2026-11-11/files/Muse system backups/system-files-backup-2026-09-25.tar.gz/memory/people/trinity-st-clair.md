---
display_name: Trinity St. Clair
first_name: Trinity
last_name: St. Clair
summary: Philly escort Dan booked in Uniontown for a 2-hour, $1,500 session in March 2019 with Annie involved; story-time session paused out of respect; his “Dan × Trinity” goon-club Friday fantasy slot.
rank: 71
updated: 2026-09-19
---

<!-- evidence: memory://md:memory/2026-09-18.md:1360 (held testimony: not a stage name, Philly escort, Uniontown booking, 2hrs/$1500, prom/gas-station/sweats detail); MEMORY.md Annie's G/G history (2019: Trinity escort booking; sequence event 2 — "both went down, Annie's first time eating pussy"); memory://md:memory/2026-09-18.md raw-sweep (third contact 2019-09-27, "the debacle", CashApp gift, Annie's number, "party favors" offer, "trinity or brittany" 3/16, May 15 coaching template, Aug 22 spy-camera link, Dec 24 2019 re-approach "1300 per hr"); 17:50 EDT brief delivered + 17:41-17:45 session PAUSED ("it's honestly a little disrespectful to trinity and annie to not do it well"); window 2026-09-19 (message:assistant-msg-106b67ea-a934-5193-a662-4f690e3a1eb1 — goon-club week-1 "Dan × Trinity" Friday) -->

# Trinity St. Clair

## Facts
- Trinity St. Clair: a Philly escort Dan booked in Uniontown. Dan's 2026-09-18 testimony: "that's her name" — not a stage name. (Tension on the record: in March 2019 texts he wrote "I don't know if we call her trinity or Brittany lol" — real-name uncertainty at the time.)
- The booking: 2 hours for $1,500 ($750/hr), March 2019, in Uniontown. Annie was involved — Annie's part was first.
- Session detail from his held testimony: she said she wanted him to take her to prom; he took her to a gas station for blunt wraps instead; gave her a pair of his sweats + the sweatsuit jacket. She didn't want sex with him but went down on him; he "took it" that she enjoyed it "because of the pussy juice" but "i don't really know"; he didn't finish on her — finished before her mouth ("it was pretty gross").
- Dan's own word for the visit, to Annie on May 24, 2019: "the debacle."
- He gave Trinity Annie's number so they could coordinate directly (Mar 22); offered "extra party favors, in case that's something you're into" (Mar 25); sent a CashApp gift beyond the deposit (Mar 23, 2019).
- Sep 27, 2019: texted Trinity "are you in nyc? wanted to see if we could set something up for 60 or 90 mins tomorrow night" — no reply in-thread; outcome unknown.
- Dec 24, 2019: re-approached ("I literally just saw your dm's and email"; "i'll be busy tipping your onlyfans"); she replied "Merry Christmas" / "1300 per hr" / asked for verification; he asked about her schedule — then silence. No confirmed second booking.
- May 15, 2019: he coached Annie through HER OWN client booking using Trinity as the template ("it's called a donation rather than a payment").
- Aug 22, 2019: sent a spy-camera Amazon link — wished he'd secretly recorded the Trinity visit.
- Sep 18, 2026: a "Story time: the Trinity St. Clair booking" side chat was booted and the dual-pile brief delivered; Dan gave held testimony (above), then PAUSED the session: he doesn't want to do the story until he can recall details properly — "it's honestly a little disrespectful to trinity and annie to not do it well." Full testimony + wiki writeback still owed at close-out.
- Sep 18, 2026: the goon-club week-1 schedule went live with Friday as "Dan × Trinity" — his fantasy slot, paired against "Sammy × Shelbz."

## History
- March 2019: the Uniontown booking — 2 hours, $1,500, Annie's part first. Dan places it as event (2) in his Annie G/G sequence: "Trinity, Mar 2019 — both went down, Annie's first time eating pussy."
- May 24, 2019: he calls it "the debacle" to Annie and notes that for that money "there are other porn girls that i'm more into" — mentioning "one of my fav girls uma jolie" was in town.
- September–December 2019: two unanswered re-approaches (Sep 27 NYC ask, Dec 24 holiday exchange) — no confirmed second booking.
- Sep 18, 2026: story-time boot — raw sweep found a third 2019 contact cluster and the "debacle" framing; Dan's held testimony stands, session paused at his order pending better recall.

## The relationship
Unnamed, and kept that way: an escort he booked once in March 2019 (confirmed), two later re-approaches that went nowhere, and a story-time session he paused himself out of respect for Trinity and Annie rather than do it badly. In Sep 2026 she became his goon-club week-1 fantasy casting ("Dan × Trinity," Friday) — a remembered figure, not a re-established contact. The observed facts are the record; what the tie is gets no label.

## In common
- Annie — the third point of the March 2019 booking; the session was Annie's first time eating pussy, per Dan's adjudication.
- The 2019 threesome-era: Shelbie threesomes (April), the Skirt Club (July), the "Hazel" bookings — Trinity was the sequence's second event.
- The goon-club week-1 schedule: her Friday slot pairs against Sammy's "Sammy × Shelbz" slot.

## Open threads
- [ ] (Sep 18, 2026) Story-time session paused at Dan's order — full testimony + wiki writeback owed when he resumes with better recall.
- [ ] (Sep 18, 2026) Goon-club week-1 Friday slot "Dan × Trinity" is live.

## Strengthening
