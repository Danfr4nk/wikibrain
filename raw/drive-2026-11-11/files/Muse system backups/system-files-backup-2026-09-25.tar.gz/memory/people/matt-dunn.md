---
display_name: Matt Dunn
first_name: Matt
last_name: Dunn
summary: Fourth member of the Full Sail cohort; the $5 birthday Venmo bit still runs 15+ years on.
rank: 47
updated: 2026-09-10
---

<!-- evidence: corpus-extract/agent-B-people.md (§ Matt Dunn); corpus-extract/corpus_index.txt (wiki/people/matt-dunn.md) -->

# Matt Dunn

## Facts
- Matt Dunn — fourth member of the Full Sail cohort.
- Same running $5 birthday Venmo bit as Jamie Mohler and Eric Jester, 15+ years on.

## History
- 2008–: Full Sail era; the cohort's fourth member.
- The $5 birthday bit runs to the present.

## The relationship
- A durable low-frequency friendship held together by a fifteen-year running joke.

## In common
- Full Sail; the $5 birthday bit; Eric Jester; Jamie Mohler.

## Open threads

## Strengthening
