---
display_name: Emilio
first_name: Emilio
summary: Annie's partner at the moment of the November 2015 switch; displaced by Dan — his retaliation text to Claire triggered the December 2, 2015 family confrontation.
rank: 42
updated: 2026-09-10
---

<!-- evidence: corpus-extract/agent-B-people.md (§ Emilio); corpus-extract/corpus_index.txt (wiki/people/emilio.md); memory://md:memory/2026-09-10.md:146 -->

# Emilio

## Facts
- Emilio — Annie's partner at the moment of the November 2015 switch.
- Dan displaced him; Annie entered Dan's life the day after he evicted Alexis.
- His retaliation text to Claire (Annie's sister) triggered the December 2, 2015 family confrontation.

## History
- November 2015: Annie's partner when Dan and Annie began; displaced within days.
- December 2, 2015: his retaliation text to Claire set off the family confrontation.

## The relationship
- Dan never had a relationship with him — Emilio is the man on the other side of the bond switch, the displacement the wiki treats as its central thesis.

## In common
- Annie Ulmer; the November–December 2015 switch; Claire Ulmer.

## Open threads

## Strengthening
