---
display_name: Matt Kraus
first_name: Matt
last_name: Kraus
summary: Closest documented childhood friend — Seven Springs condo neighbor, four Camp Woodward summers.
rank: 27
updated: 2026-09-09
---

<!-- evidence: corpus-extract/agent-B-people.md (§ Matt Kraus — closest documented childhood friend) -->

# Matt Kraus

## Facts
- Matt Kraus; the closest documented childhood friend in the record.
- Seven Springs condo neighbor; Vans Skatepark birthday trips (2001–03); four Camp Woodward summers.

## History
- Childhood: the Seven Springs and skate-park years; the friendship is the record's anchor for that era.

## The relationship
- The childhood friendship the record leans on — documented depth, long dormancy.

## In common
- Seven Springs; the childhood ski identity.

## Open threads

## Strengthening
