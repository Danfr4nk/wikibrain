---
display_name: Katherine Palakovich
first_name: Katherine
last_name: Palakovich
summary: Creative License Director of Business Affairs and notary; notarized the false statements used against Dan in the whistleblower dispute.
rank: 51
updated: 2026-09-10
---

<!-- evidence: corpus-extract/agent-B-people.md (§ Katherine Palakovich); corpus-extract/corpus_index.txt (wiki/people/katherine-palakovich.md) -->

# Katherine Palakovich

## Facts
- Katherine Palakovich — Director of Business Affairs at Creative License, and a notary.
- Notarized the false statements used against Dan in the whistleblower dispute with Kevin McKiernan.

## History
- 2011–12: Dan's Creative License tenure; the whistleblower dispute and the notarized statements followed.

## The relationship
- An adversarial professional contact — her notarization is what gave the retaliation its paperwork.

## In common
- Creative License; Kevin McKiernan; the whistleblower dispute.

## Open threads

## Strengthening
