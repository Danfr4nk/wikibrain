---
display_name: Bop
summary: Supply contact Dan goes through for Suboxone logistics; warned Dan on Sep 12, 2026 that Annie had been seen at DiMarco's.
rank: 76
updated: 2026-09-22
---

# Bop

## Facts
- Known to Dan as "Bop" (his texts render it "bop"); the name/handle of the person Dan middlemans for Suboxone supply logistics in Aug–Sep 2026.
- A "Felix" appears in the same Aug 23 logistics context; whether Felix is Bop or a second dealer is unverified (annie-thread-findings-20260921.md §3, §4).
- Part of the near-daily $30–$100 Suboxone exchanges running through Sep 21, 2026: $60–$80 amounts, mailbox drops, ATM runs; "Bop coming at noon" (annie-thread-findings-20260921.md §1 Aug 24, §2 claim 7).
- Sep 12, 2026: sat Dan down and warned him he had seen Annie at DiMarco's "and who you were with"; Annie denied being there (annie-thread-findings-20260921.md §1 Sep 12; MEMORY.md).
- Sep 12, 2026: Dan took Bop's daughter to work (annie-thread-findings-20260921.md §3).

## History
- Aug 24, 2026: Dan middlemans Bop/Felix for supply logistics ($60–$80, mailbox drops, ATM runs) while sorting synthetic urine for Annie's drug test.
- Sep 12, 2026: the DiMarco's warning ("He sat me down again / And he saw you at dimarco's and who you were with"); the same day, Dan drives Bop's daughter to work.

## The relationship
- A recurring, transactional contact: Dan moves Suboxone through him, and Bop feeds Dan information about Annie's movements. Nothing on the record suggests friendship; the tie is supply and information as observed, not a relationship Dan has named.

## In common
- The Suboxone logistics that serve both Dan and Annie.
- Annie — the subject of Bop's Sep 12 warning to Dan.

## Open threads

## Strengthening
