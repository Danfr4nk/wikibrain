---
display_name: Lexi Grey
first_name: Lexi
last_name: Grey
summary: Trans OnlyFans creator — Seed 1 of Dan's Sep 17, 2026 creator-discovery project; "the blonde exception that proves your brunette rule."
rank: 66
updated: 2026-09-17
---

# Lexi Grey

## Facts
- Trans woman, 19, an OnlyFans creator under the handle @tslexigray (clip presence on x-tg.tube under "onlylexigray"). (memory/2026-09-17.md#L257)
- Look: long blonde hair, soft glam, black-romper mirror selfie, girl-next-door femme; no ink or piercings visible. (memory/2026-09-17.md#L257)
- Not Alexis Armel: Dan calls his ex "Lexi," and this is a different person entirely — a creator Dan commissioned research on, not someone he knows. (distinction drawn from memory/2026-09-17.md#L257)
- Dan's project assessment: her blonde hair breaks his brunette streak (Annie, Alexis, and Sammy's reference look are all dark-haired); the verdict logged was "the blonde exception that proves your brunette rule." (memory/2026-09-17.md#L257)

## History
- Sep 17, 2026 (pre-dawn): Dan commissioned a trans-creator discovery project with four seeds; Lexi Grey was Seed 1, and her profile was researched and filed in the same session. (memory/2026-09-17.md#L196)
- A watermarked promo still was saved at `~/workspace/your_files/lexi-grey-avatar.jpg`. (memory/2026-09-17.md#L257)

## The relationship
- A creator Dan deliberately follows: the project was commissioned at his direct request, and his standing calibration for the whole set is that "authenticity over production" is gospel for all his porn. (memory/2026-09-17.md#L196; MEMORY.md#L128)
- No personal contact; Dan has never met her. The tie is deliberate audience, not acquaintance — unnamed beyond what the record shows.

## In common
- Trans-femme presentation; the discovery project is built around his stated taste parameters (amateur/homemade/naturalistic weighted over produced).

## Open threads
- None. The seed profile is filed; nothing is pending between Dan and her.

## Strengthening
