---
display_name: Jamie Mohler
first_name: Jamie
last_name: Mohler
summary: Full Sail friend and NYC-1 household regular (2011); the annual $5 birthday Venmo bit still runs through him 15+ years on.
rank: 46
updated: 2026-09-10
---

<!-- evidence: corpus-extract/agent-B-people.md (§ Jamie Mohler); corpus-extract/corpus_index.txt (wiki/people/jamie-mohler.md) -->

# Jamie Mohler

## Facts
- Jamie Mohler — Full Sail-era friend.
- NYC-1 household regular in 2011.
- The annual $5 birthday Venmo bit runs through Eric Jester and him, 15+ years on; transitioned ~2023.

## History
- 2008–: Full Sail era friendship.
- 2011: NYC-1 household regular.
- 2023: transitioned; the $5 birthday bit continues.

## The relationship
- One of the era's durable friendships — the kind that survives on a running joke and annual contact rather than volume.

## In common
- Full Sail; the NYC-1 years; the $5 birthday bit; Eric Jester; Matt Dunn.

## Open threads

## Strengthening
