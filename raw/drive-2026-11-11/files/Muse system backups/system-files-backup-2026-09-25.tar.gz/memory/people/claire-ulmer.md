---
display_name: Claire
first_name: Claire
last_name: Ulmer
summary: Annie's sister; found Milo as a starving stray and routed him to Dan and Annie.
rank: 21
updated: 2026-09-09
---

<!-- evidence: corpus-extract/agent-B-people.md (§ Claire Ulmer — Annie's sister) -->

# Claire

## Facts
- Claire Ulmer; Annie's sister, married to Garrett.
- The reason Milo exists: she found him as a starving stray and routed him to Dan and Annie for a one-night foster that became permanent.
- Mother of Alice (b. ~2019–20) and Otto; Annie's unpaid childcare for them is her largest sustained commitment in the record.

## History
- The Milo handoff: a one-night foster that never ended — the dog that became the channel of every later Annie recontact.

## The relationship
- De facto family through Annie; the record's trace of Dan's contact with her runs through Milo and the family thread rather than a direct line.

## In common
- Annie's family: Ellen, Bill, Garrett, Alice, Otto; Milo's origin story.

## Open threads

## Strengthening
