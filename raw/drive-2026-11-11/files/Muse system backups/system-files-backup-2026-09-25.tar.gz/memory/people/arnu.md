---
display_name: Arnu
first_name: Arnu
summary: Contractor on 463 Morgantown St; his mechanics lien (deadline ~July 27, 2026) attaches to the property's title.
rank: 41
updated: 2026-09-10
---

<!-- evidence: corpus-extract/agent-B-people.md (§ Arnu — 463 contractor exposure set); memory://md:MEMORY.md:36 -->

# Arnu

## Facts
- Arnu — contractor on the 463 Morgantown St work.
- His mechanics lien (deadline ~July 27, 2026) attaches to the property's title.
- Felix, the painter on the job, is his associate.

## History
- 2026: contracted for work on 463 Morgantown St; the lien exposure followed.

## The relationship
- A work relationship that became a legal exposure — the lien runs against Alexander Jackson's title, the house Dan and Suz live in.

## In common
- 463 Morgantown St; the contractor exposure set (John Carney, Felix); Alexander Jackson as the property owner.

## Open threads
- [ ] The mechanics lien on 463 Morgantown St — the exposure is unresolved.

## Strengthening
