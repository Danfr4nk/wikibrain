---
display_name: Jerad
first_name: Jerad
last_name: Friedline
summary: Dan's oldest friend — a high-signal, low-frequency channel; political and financial tips in crises.
rank: 15
updated: 2026-09-09
---

<!-- evidence: corpus-extract/agent-B-people.md (§ Jerad Friedline — oldest friend) -->

# Jerad

## Facts
- Jerad Friedline; Dan's oldest friend.
- The sole high-signal, low-frequency channel: 857 messages, mostly received — political and financial tips in crises.
- The September 2020 FSLY tip that launched Dan's market era came from him.

## History
- Decades-long friendship; contact concentrates in crisis-adjacent tips rather than chatter.

## The relationship
- Peer, not project: one of the few ties Dan doesn't metabolize into drama — the tips come in, the friendship persists.

## In common
- The Uniontown past; the "josh brannan is innocent" running joke with Josh Brannan.

## Open threads

## Strengthening
