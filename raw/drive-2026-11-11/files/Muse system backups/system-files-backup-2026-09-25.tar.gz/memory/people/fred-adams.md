---
display_name: Fred Adams
first_name: Fred
last_name: Adams
summary: Uniontown attorney, later judge; trustee/executor of the Coldren estate who controlled the money valve until his death ~May 2020.
rank: 50
updated: 2026-09-11
---

<!-- evidence: corpus-extract/agent-B-people.md (§ Fred Adams); corpus-extract/corpus_index.txt (wiki/people/fred-adams.md); window 2026-09-11 (2017 Palm City letters, assistant-msg-99ba0352) -->

# Fred Adams

## Facts
- Fred Adams — Uniontown attorney, later judge; partner at Coldren Adams.
- Trustee/executor of the Coldren estate; set the 24-hour vigil mandate for Fran's death.
- Controlled the estate's money valve until his death ~May 2020.
- Rod Banks was the estate's disbursing hand under him ($32,500 in advance checks to Dan, 2019–20).
- 2017: visible in the Palm City correspondence — "already nodding along" on Diane's August 2017 pressure for Fran to sell the Palm City house, and formally cc'd on the November 2017 $20,000 loan against Fran's inheritance (letters surfaced 2026-09-11).

## History
- 2017: the Palm City letters — nodding along on the August sale pressure, formally cc'd on the November loan.
- 2018: set the 24-hour vigil mandate during Fran's final decline.
- 2019–20: controlled the estate money valve; died ~May 2020.

## The relationship
- Not a personal relationship — a fiduciary one. Adams held the estate's money and the vigil's rules; Dan's contact with him ran through the ledger, not the living room.

## In common
- The Coldren estate; Fran Coldren; the 2018 vigil.

## Open threads

## Strengthening
