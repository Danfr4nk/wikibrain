---
display_name: wax motif
summary: Music creator in Dan's obsessions tier — named alongside LYNY, nimino, and BSEARL; no further detail on record yet.
rank: 79
updated: 2026-09-22
---

# wax motif

## Facts
- Music creator named by Dan in his obsessions list: "Taste: obsessions — MUSIC- LYNY, wax motif, nimino, BSEARL" (memory://md:MEMORY.md:31).
- No tracks, dates, or further detail on record beyond the listing.

## History

## The relationship
- One of the creators in Dan's obsessions tier — by the roster's own bar, someone he deliberately returns to; the record holds nothing more specific yet.

## In common
- Dan's other music obsessions: [BSEARL](../people/bsearl.md), [nimino](../people/nimino.md), [LYNY](../people/lyny.md).

## Open threads

## Strengthening
