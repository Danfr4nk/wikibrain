---
display_name: Rain
first_name: Rain
nickname: Rainbolt
summary: GeoGuessr video creator — the one Dan watches; he is not part of the GeoGuessr fandom, only the videos.
rank: 61
updated: 2026-09-14
---

# Rain

## Facts
- GeoGuessr content creator whose videos Dan watches ("we watch RAiN geoguessr videos and Thats it" — his words, 2026-09-14).
- Dan says he "knows who Rain is" and follows GeoGuessr content more than ~99% of the population; at one point he thought GeoGuessr was literally just Rain (his words, 2026-09-14).
- He is deliberately NOT part of the GeoGuessr competitive fandom — he watches the videos, not the spectator scene (2026-09-14; same day he watched the Berlin arena event and found the fandom "striking" after never hearing of it).
- Dan's correction on the record: not "GeoGuessr fandom," just Rain's videos — the correct framing going forward.

## History
- 2026-09-14 (~00:45 EDT): Dan watched a GeoGuessr spectator event at a packed Berlin arena and was struck by how large the competitive fandom was, having never heard of it; stated the same night that he thought GeoGuessr was "literally just rain."
- 2026-09-14 (afternoon): corrected the record in chat — he is not a fandom citizen, he watches RAiN's GeoGuessr videos, and that is it.

## The relationship
- One-way audience relationship: Dan consumes the videos; there is no contact, collaboration, or two-way tie.
- The nature of the relationship is not named by Dan beyond being a viewer of the videos — so it stays unstated here.

## In common
- GeoGuessr videos as background/entertainment viewing; Dan's interest is in the creator's play, not the competitive scene.

## Open threads

## Strengthening
