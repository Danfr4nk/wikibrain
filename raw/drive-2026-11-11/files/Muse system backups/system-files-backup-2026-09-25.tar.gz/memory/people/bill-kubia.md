---
display_name: Bill Kubia
first_name: Bill
last_name: Kubia
summary: Died of an OD on Aug 14, 2010 — Dan's reaction marks him as a drug-era acquaintance; surfaced in the recovered 2010 Suz↔Dan SMS.
rank: 83
updated: 2026-09-23
---

<!-- evidence: memory://md:memory/2026-09-23.md (2010 Suz↔Dan SMS batch content flags); window 2026-09-23 conversation (assistant-msg-0f1029f6-9502-d35b-b3d3-44e8d9de6074 — "Bill Kubia (OD death, Aug 14 — your reaction: 'so glad I'm not there')") -->

# Bill Kubia

## Facts
- Died of an overdose on Aug 14, 2010.
- Dan's reaction in the 2010 texts with Suz: "so glad I'm not there."

## History
- Aug 14, 2010: his OD death — Dan heard about it in real time and reacted with relief at not being there.

## The relationship
- A drug-era acquaintance — close enough that Dan registered his death personally, distant enough that nothing else about him is on record. The nature of the tie is unstated; the record holds the reaction and nothing more.

## In common
- The 2010 drug scene Dan was exiting (six months pill-free as of Aug 14, 2010, per the same batch).

## Open threads

## Strengthening
