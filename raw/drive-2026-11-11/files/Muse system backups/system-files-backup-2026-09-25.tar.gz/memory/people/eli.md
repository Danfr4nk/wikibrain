---
display_name: Eli
first_name: Eli
summary: The man Annie had the concealed NYC affair with; the 'Eli incident' is the record's clearest exhibit of the bond's weaponized ambiguity.
rank: 44
updated: 2026-09-10
---

<!-- evidence: corpus-extract/agent-B-people.md (§ Eli); corpus-extract/corpus_index.txt (wiki/timeline/events/eli-incident.md) -->

# Eli

## Facts
- Eli — the man Annie had the concealed NYC affair with.
- The "Eli incident" is the wiki's clearest exhibit of the bond's weaponized ambiguity.

## History
- NYC era: the concealed affair with Annie, documented as the Eli incident.

## The relationship
- Dan never met him — Eli exists in Dan's record as the concealed third party, the affair whose ambiguity became the weapon.

## In common
- Annie Ulmer; the NYC years.

## Open threads

## Strengthening
