---
display_name: BSEARL
summary: Electronic producer Dan deliberately follows — "SOLD MY SOUL" sits in his ALL TIME TOP 100, and the Flume "You & Me" BSEARL EDIT is his stress-test track for the MELODY and CHORDS tools.
rank: 73
updated: 2026-09-19
---

# BSEARL

## Facts
- Electronic music producer; releases on Bandcamp (bsearl.bandcamp.com) as name-your-price downloads.
- Dan names BSEARL as one of his current music obsessions, alongside LYNY, wax motif, and nimino.
- `SOLD MY SOUL` (original) holds a slot in Dan's "DAN FRANK ALL TIME TOP 100 VIP CRATE".
- `FLUME - YOU & ME (BSEARL EDIT)` (posted June 2025) is the BSEARL track Dan keeps returning to; it is Bandcamp-only, not on Spotify.
- `Places` is a candidate second BSEARL entry in the Top 100, which would make him a repeat entry.
- Dan engages with BSEARL's work forensically: lead-sound analysis and transcription, not just listening.
- No real name is on record; relationship is follower-to-creator, one-directional.

## History
- 2026-09-10: at Dan's request, an automated first-pass MIDI transcription of the BSEARL lead (~63.0–67.2s of the track): 22 note-on events, nominal 140 BPM, delivered explicitly as unquantized and pending correction by ear.
- 2026-09-12: Dan wished the Flume remix were on Spotify; confirmed it is Bandcamp-only. [fact|high] `SOLD MY SOUL` confirmed as already in the All Time Top 100; `Places` floated as a possible second entry.
- 2026-09-15: sound-design analysis of BSEARL's added synth entering ~1:04 in the Flume edit — a fast, jumping monophonic pluck/lead with large interval changes; saw-wave characterization held at medium confidence with no stems available.
- 2026-09-19: Dan ran the full 237.3s BSEARL edit through his MELODY tool (287 notes in 0.8s; the tool tracked the F3 bass pulse for ~70% of the track, clean lead capture only 2:00–2:30) and his CHORDS tool (119.8 BPM; the song reads as an F → F# → A#m loop, with a suspected F#maj7 split on the F/F# flip). Dan's ear is the ground truth on both verdicts.

## The relationship
- One of the few creators Dan deliberately returns to rather than knowing — BSEARL is in the obsession tier of his taste forensics, not the casual-listening tier.
- The tie is analytical as much as musical: Dan uses BSEARL tracks as test material for his own music-analysis tools and as a sound-design reference for GRIPNOTIC production.
- No contact, no two-way channel; the relationship exists entirely in Dan's listening, transcription, and tool work.
- What Dan would say of him: his track holds a Top-100 slot; that is the endorsement.

## In common
- Dan's other music obsessions: LYNY, wax motif, nimino.
- The 2025 dance-music re-entry; the GRIPNOTIC project; the music-analysis tools (MELODY, CHORDS) Dan built and tested against BSEARL tracks.

## Open threads

## Strengthening
