---
display_name: Dave Moore
first_name: Dave
last_name: Moore
summary: Diane Moore's second husband — Dan's maternal grandmother's husband; her proxy to hospital social workers during the 2018 vigil, believed by Dan to have drafted the trespass letter.
rank: 39
updated: 2026-09-10
---

<!-- evidence: corpus-extract/agent-B-people.md (§ Dave Moore); memory://md:MEMORY.md:9 -->

# Dave Moore

## Facts
- Dave Moore — Diane Moore's second husband, Dan's maternal grandmother's husband.
- During the 2018 death vigil he acted as Diane's proxy to the hospital social workers.
- Dan believes he drafted the trespass letter that barred Dan from Fran's house while Fran was dying.

## History
- 2018: the Fran death vigil — Dave served as Diane's proxy; the trespass letter against Dan followed.

## The relationship
- Not a relationship of warmth or contact — he enters Dan's record as Diane's instrument in the 2018 vigil conflict, the hostile pole of the maternal line made bureaucratic.

## In common
- Diane Moore; the 2018 Fran vigil.

## Open threads

## Strengthening
