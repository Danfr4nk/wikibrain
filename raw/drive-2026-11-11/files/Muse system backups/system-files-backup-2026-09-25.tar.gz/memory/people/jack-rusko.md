---
display_name: Jack Rusko
first_name: Jack
last_name: Rusko
summary: Fellow Nemacolin caddy and genuine friend 2017–18; sent unprompted condolences after Fran's death.
rank: 29
updated: 2026-09-09
---

<!-- evidence: corpus-extract/agent-B-people.md (§ Jack Rusko — fellow Nemacolin caddy); memory://md:MEMORY.md:12 -->

# Jack Rusko

## Facts
- Jack Rusko; fellow Nemacolin Woodlands caddy and genuine friend, 2017–18 (202 messages).
- The two-month laptop-loan saga.
- Sent unprompted condolences after Fran's death in 2018.

## History
- 2017–2018: the caddy years; the friendship's signal moment came after Fran's death.

## The relationship
- A work friendship that showed genuine care — the unprompted condolence is what the record kept.

## In common
- Nemacolin Woodlands; the caddy years.

## Open threads

## Strengthening
