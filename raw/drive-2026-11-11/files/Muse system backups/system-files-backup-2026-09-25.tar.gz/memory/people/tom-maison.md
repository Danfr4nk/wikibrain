---
display_name: Tom Maison
first_name: Tom
last_name: Maison
nickname: Tom
summary: Dan's primary male friend — the safe lateral anchor from the Seven Springs years on; crisis support and steady peer contact.
rank: 6
updated: 2026-09-13
---

<!-- evidence: memory://md:MEMORY.md:10; memory://md:MEMORY.md:16; memory/2026-09-09.md#L16; corpus-extract/agent-B-people.md (§ Tom Maison — primary male ally); window 2026-09-12T22:59–2026-09-13T00:24 (message:assistant-msg-bf2a7711-08c1-4da0-9e01-f6667f6370d6): wall lore from Aug 2025 texts with Tom; message:assistant-msg-dd5ba498-8729-4b5c-b493-6890a12b999a (wall description from Dan's photo) -->

# Tom Maison

## Facts
- Tom Maison; Dan's primary male ally — "the clearest safe lateral (peer, non-paternal) attachment in the corpus."
- Friendship from the adolescent Seven Springs scene onward.
- Crisis anchor and (2025–26) supply line; recurring participant in the arrangement; introduced Dan to Kristin in Aug 2025.
- ~5,763 iMessage corpus messages, rank #5 — the corrected figure after Kristin's handle was found mislabeled under his (her messages had overstated his weight ~2.9x).
- Sep 2026 Messenger pull: 5,734 Messenger messages, 2008–2022 — the biggest single thread in that export (a separate channel from the iMessage corpus count above).
- Aug 2025 "wall" thread: Dan built a wall of dozens of B&W women's portraits, floor to ceiling — "my wall of despair," "THE WALL," "the big beautiful wall of pain" — interrupted by shitpost decor (TRUMP sticker, pentagram, "I'M OK," "BORN TO RAID," a big "GPT" masthead). The project played out live in his texts with Tom: "wall is life tom, wall is life" / "when the wall grows, we grow" / "the wall has been here since time immemorial."
- Contents per his Aug 2025 texts: a roast joke picture bottom-left ("boom fuckin roasted dude"), "a fucking brand new deja reference," and the tarot/occult poster — the same night he told Tom he'd started learning tarot.
- The wall's stated purpose was getting Kristin's take: "SHE NEEDS TO SEE THE WALL TOM" / "THE WALL IS ALL I HAVE NOW" / "well milo, and the wall." Tom's counsel: "You should put a picture of Kristin on your wall" — at a point Dan hadn't yet learned her last name ("YOU WON'T EVEN TELL ME HER LAST NAME").

## History
- Adolescent Seven Springs scene: the friendship's start.
- 2008–2022: 5,734 Messenger messages — the export's biggest thread.
- Through the Annie decade: crisis support, supply, arrangement participation.
- Aug 2025: introduced Dan to Kristin Prentiss.
- Aug 1–2, 2025: Dan built the wall; Aug 3, 12:39 AM, he announced it to Tom ("tell me you appreciate the last 24 hours of my life"). Tom was the live audience for the build, the naming, and the Kristin purpose.
- Aug 26, 2025: Dan sent Kristin a photo of the wall himself (wearing a shirt reading CUMSLUT), and asked Tom whether that was good or bad news.
- 2025–26: supply line; steady peer contact through Dan's Uniontown return.

## The relationship
- The one peer bond the wiki measures everything else against: crisis support without the paternal charge — the "safe lateral."
- No romance, no arrangement hierarchy, no authority template — the plainest friendship in the record.
- Tom is also Dan's sounding board for projects he cares about: the wall era shows Dan workshopping the thing that mattered to him that week (the wall, Kristin's reaction) on Tom in real time.

## In common
- Seven Springs, the Uniontown cohort, the Kristin introduction, the Aug 2025 wall project, the shared years.

## Open threads

## Strengthening
