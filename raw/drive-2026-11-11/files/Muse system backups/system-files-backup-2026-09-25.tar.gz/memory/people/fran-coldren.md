---
display_name: Fran
first_name: Frances
last_name: Coldren
nickname: Fran
summary: Dan's great-grandmother (1920–2018) — named by him as his biggest life influence; he was her caregiver in 2017–18.
rank: 5
updated: 2026-09-23
---

<!-- evidence: memory://md:MEMORY.md:9; corpus-extract/agent-B-people.md (§ Frances "Fran" Whyel Coldren — maternal great-grandmother); window 2026-09-11 (Fran photo/letter batch, assistant-msg-99ba0352; vape album assistant-msg-a3f1f158; Nov 2017 frames assistant-msg-b79ed7ad; death-vigil story/retraction assistant-msg-254fd743); window 2026-09-22 (Dan's correction that he documented the decline extensively; assistant-msg-56708420); window 2026-09-23 (2010 Suz↔Dan SMS batch — Fran ER visit Jul 15, 2010) -->

# Fran

## Facts
- Frances "Fran" Whyel Coldren, 1920-08-15 – 2018-04-04; Dan's maternal great-grandmother.
- Raised Dan alongside Suz; named by both Dan and Suz as the guiding force of their lives — the biggest life influence in his record.
- Dan and Annie were her paid caregivers in 2017–18.
- Her death is the most documented grief event in the corpus. He documented the decline extensively too — 34 Fran media items in the wiki registry, 19 of them videos (home footage, nursing home, wheelchair, hospital bed with oxygen mask, the night vigil with his hand entering frame); on 2026-09-22 he corrected the idea that the family didn't keep the record — he filmed the whole decline.
- During the 2018 death vigil, her daughter Diane Moore barred Dan from Fran's house (trespass letter).
- The Numark NS7 she gifted him is one of his life anchors.
- December 2015: photographed being offered a bong in her own house — three frames in four seconds, Dan's bracelet'd hand taking it in the middle one (surfaced 2026-09-11).
- 2017 Palm City pressure: an August 2017 letter shows Diane pressing Fran to sell the Palm City, Florida house (realtor lined up, Fred Adams already nodding along); a November 2017 letter — ten weeks later — records Fran's shoulder surgery, the Palm City trip called off, and a $20,000 loan against her inheritance, Fred Adams formally cc'd. Palm City's first appearance in the record; possibly the old wiki's undocumented Florida condo sale.
- Nov 6, 2017: photographed holding a PlayStation DualShock 4 (light bar glowing), in teal polka-dot pajamas and a purple chenille jacket; five days later a blurry frame in a purple zip jacket over a pink top, gold oval locket at her throat.
- Feb 20, 2018: photographed in a white turtleneck and dark purple fleece, tissue in hand, being offered a hit off a lime-green box mod (Dan's hand, presumably) — ~2.5 weeks before the March 7–8 fall, and the scene behind the MJ-14101-NT-0000082-2018 summons for smoking in the hospital during the death watch. Distinct from "the keno morning," where she is on the floor in the teal robe.

## History
- Raised Dan alongside Suz. 2017–18: Dan and Annie as paid caregivers on Fran's rotation.
- Jul 15, 2010: ER visit — fluid around the heart/lungs, home the same day (from the recovered 2010 Suz↔Dan SMS batch).
- Dec 2015: the bong photos — Fran in her own house, three frames in four seconds.
- Aug–Nov 2017: the Palm City letters — Diane's sale pressure in August, the $20,000 inheritance-loan posture by November.
- Nov 6, 2017: the DualShock 4 photo. Feb 20, 2018: the vape-album photo. April 2018: the vigil, the trespass letter, her death on the 4th.
- April 5, 2018, ~8:10pm: Dan's same-night account to her Florida friend Lucie Dobbin described asking her for a sign — she blinked (first time in a week), was "there again," smiled, then passed away. ~11:26pm: he retracted the supernatural frame to his sister after reviewing the video — a monitor alarm, not a miracle ("def isn't as 'supernatural' knowing that fact. but doesn't take away from the cool moment we had with gram"). The 39-second vigil video (Stryker bed, oxygen mask, his hand entering frame near the end) was uploaded 2026-09-11, almost certainly the video the retraction cites.

## The relationship
- The generation-skipping attachment: the person Dan was raised by alongside his mother, whose loss is the most documented in the record.
- The tie is closed by death; its weight runs through everything — including Suz, who names her the same way.

## In common
- Uniontown roots, the family homes, the Numark NS7; Lucie Dobbin, her Florida friend, received Dan's fullest same-night account of her death.

## Open threads
- [ ] Exploring the Fran dementia-videos era as a wiki project — proposed 2026-09-22 (assistant-msg-56708420); the documentation exists (19 videos) but the wiki hasn't explored it yet; transcription of the videos is the pending work.

## Strengthening
