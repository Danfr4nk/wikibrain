---
display_name: Kristin
first_name: Kristin
last_name: Prentiss
nickname: Kristin
summary: Dan's girlfriend Aug–Nov 2025 ('the only other relationship of the Annie decade'), ended over $40; the block broke Sep 12, 2026 via reactive reinitiation — a pull surfaced her Aug 26 attempts.
rank: 11
updated: 2026-09-20
---

<!-- evidence: MEMORY.md#L20 (reliability note); memory://md:memory/2026-09-12.md (Messenger pull + block broken 2026-09-12 ~02:51–03:00 EDT); corpus-extract/agent-B-people.md (§ Kristin Prentiss); window 2026-09-12T22:59–2026-09-13T00:24 (wall's purpose was her); window 2026-09-13T05:23–06:23 (reactive-only reinitiation, Kirkaversary); window 2026-09-13T12:23–13:58 (message:24255132: love by day 3 — real at the time, known-overblown); window 2026-09-20T03:24–04:23 (!BRIEF sexuality sweep) -->

# Kristin

## Facts
- Kristin Prentiss; Dan's girlfriend August–November 2025, Akron/Barberton OH.
- "Dan's only other relationship of the Annie decade": ten weeks, 22,000 messages, ended over $40.
- The Dec 9, 2025 block held until Sep 12, 2026, when Dan reinitiated contact via iMessage (screenshot shared in chat). CORRECTION 2026-09-13: reactive, not spontaneous — he messaged her only because the Sep 12 pull surfaced her Aug 26 attempts. His messages: "It's weird I thought about you you yesterday on the kirkaversary" (edited), "I moved. Come see me tomorrow", a photo of dispensary products (Maitri, INSA Kush MNZ, Flower Foundry), "I give you dispo trees" (delivered). Texts read as invitation + weed offer, not apology; the grievance ledger ($40, the ex, backing out after one day) and the Suboxone disclosure are his testimony, uncorroborated in the message record. "kirkaversary" = the Twitter term for the one-year anniversary of Charlie Kirk being shot (AI rap-video feed).
- Aug 26, 2026: Kristin sent five Messenger messages plus a missed call from a pending message request (display name Kristin Shaelene; included unprompted third-party autism framing, "my fellow neuro fuck"); Dan never replied — surfaced by the Sep 12, 2026 Messenger pull.
- Entered Dan's life through Tom's social circle.
- Her handle's messages were at one point mislabeled under Tom's in the corpus counts — overstating Tom's weight ~2.9x before the correction.
- The Aug 2025 wall (his floor-to-ceiling wall of B&W women's portraits — "my wall of despair," "THE WALL") was built in part for her eyes: "SHE NEEDS TO SEE THE WALL TOM" / "THE WALL IS ALL I HAVE NOW." Tom's suggestion — "You should put a picture of Kristin on your wall" — shows she was already the frame of the project before Dan knew her last name ("YOU WON'T EVEN TELL ME HER LAST NAME").
- Aug 26, 2025: Dan sent Kristin a photo of the wall itself (wearing a shirt reading CUMSLUT), and asked Tom whether that was good or bad news.
- The 2025 relationship's terms (his words, from the message record): her rule from day one was "only cum to me"; she ran what he called "YOUR EXTREME EDGING EXPERIMENT THAT YOU DECIDED TO CONDUCT ON ME LOL." His intensity ran both ways: "i have given you both full ownership rights to my cock and my imessage password in one 12 hour span." 2026 (to Kristin): "She is skilled. I HATE blowjobs but hers was righteous."

## History
- Aug 2025: met via Tom's circle. Built the wall of women's portraits with getting her take as its stated purpose; sent her the photo Aug 26.
- Nov 2025: ended over $40. Dec 9, 2025: block.
- Aug 26, 2026: five unanswered Messenger messages + missed call from a pending request.
- Sep 12, 2026: Dan reinitiated — iMessage outreach with a visit invitation ("Come see me tomorrow") and a dispensary photo; reply/outcome not yet evidenced.
- Sep 12→13, 2026 (late-night long chat, transcribed by Dan): intellectual sparring → sexual escalation (asphyxiation-play "joke" — "make sure I don't die while I cum as you choke me", "KIND OF kidding"; photo exchange) → terms negotiation. Her terms: mutual obsession, possessive, "loathes lying and confusion more than anything on earth"; her read of him: doesn't know what he wants or hides it, his kinks are Annie-decade artifacts. His stated needs: clear, secure, appreciates his intensity, "gets" that he doesn't see the world like others; wants to be the obsessed one, doubts anyone could be obsessed with him ("too annoying"). Warmest passage in the log ("you do have sauce... you're caring... stop acting like you need wiki and chatGPT and 20 programs to tell you who you are") braided with hard boundaries — accused him of reordering her words ("manipulation tactics... I'm evolved my guy"), probed whether visiting requires being his gf, said she's done thriving on pain/chaos. Her outsider read of Annie: "you're her supplier. She takes advantage of your neurodivergence." He caught her contradiction (keeps receipts = "pinpointing" she disavowed). CORRECTION 2026-09-13 (primary source — Dan's screen recording of the iMessage thread): the "You switched the order of those to make it seem like I walked back what I was saying" line is DAN's (blue bubble), not Kristin's — his transcription had flipped the speaker. What the video establishes: her "Okay. If you just stated: [bullets]... then you followed with 'now that I think about it'" reverses his actual message order (the obsession line came first); Dan called it out in real time; she never addressed the order claim and pivoted to "No. I'm not here for manipulation tactics." Her deepest cut, delivered as care: "one day the one person you're dependent on won't be here right?... Then who are you without Suz?" Final line: "Nothing 'happened' Dan. Lol. You've been you, I've been me." Also in the chat: he told her he fixed his "fucked up Fred flinstone feet" and that a new Facebook AI model is "literally the craziest thing I've ever seen" — "I've done $5000 worth of work for free lol."

## The relationship
- The decade's one other relationship: brief, intense by volume. The block that had held since Dec 2025 was broken by Dan himself on Sep 12, 2026 — the contact is now open at his initiation, but reactive (the pull surfaced her Aug 26 attempts), not spontaneous.
- The Aug 2025 material shows the early infatuation's shape: he built the wall as a shrine-to-be-judged and measured her reaction to it.
- Sep 13, 2026 (his own framing, from the themes chat): he describes his early intensity toward her as love-bombing — love notes, soliloquies, performative declarations — "real to him at the time, even if the scope of the claims are known to be overblown." By his own concession, he did not actually love Kristin on day 3; the declaration ran ahead of what he felt.

## In common
- Tom's circle; the fall 2025 window; the Aug 2025 wall project.

## Open threads
- [x] Dan's Sep 12, 2026 outreach ("Come see me tomorrow", dispensary photo) — she replied; the full-day Sep 12→13 thread is in the wiki (narrative rewrite 2026-09-13, 13 chapters, merged to main): Wiki Brain unveiled to her, 13 voice memos + her refusal of wiki ingestion, Tom phishing scare, $40 alchemized into a joke, Tom severed from both ends, his confession (back to Annie, cheated on AGAIN), the order-switch callout (screen-recording verified), "Then who are you without Suz?", close: "Nothing 'happened' Dan. Lol. You've been you, I've been me."
- [ ] Whether she visits / what the relationship becomes post-re-initiation.

## Strengthening
- **Editorial stance (2026-09-13, Dan's directive):** in wiki/ human articles, contradiction/gap forensics are not the priority — the human story leads. The order-switch and pinpointing sections moved from featured sections to compact forensic footnotes; evidence-grade detail stays in kb/.
- **Narrative rewrite (2026-09-13, Dan's directive):** the redux entry was fully rewritten as a human article — linear story in 13 chapters (silence breaks → 4:30 AM → machine in the room → visit → phishing scare → severances/confessions → past midnight → close → what the day was). Forensics demoted to footnotes per his standing rule.

## Handles
- 2026-09-21 (Dan's ID): +13307038747 is Kristin's number. The 303-message thread is the Sep 12–13, 2026 re-engagement — the whole thing happened in ~15 hours right after the block broke.
