---
display_name: nimino
summary: Electronic producer in Dan's obsessions tier — the nimino lead is the sound he's currently trying to replicate on his phone for GRIPNOTIC.
rank: 77
updated: 2026-09-22
---

# nimino

## Facts
- Dance-music producer in Dan's obsessions tier (Dan's own "Taste: obsessions — MUSIC- LYNY, wax motif, nimino, BSEARL" list, memory://md:MEMORY.md:31).
- Two nimino tracks sat in Dan's 2026-09-11 vibe list: "Eat Me Better" and "Orla" (memory://md:memory/2026-09-11.md:498); both carried into the 2026-09-12 dance-music vibe cluster (memory://md:memory/2026-09-12.md:38).
- In the 2026-09-12 cluster he wrote the title as "eat you better" (the 2026-09-11 log has "Eat Me Better") — his documented name-mishearing pattern, phonetic approximation rather than a title.
- On 2026-09-22 Dan asked which iPhone GarageBand synth sounds most like the nimino lead — he is trying to replicate the lead sound on his phone for his own production work (message:9157b484-adc7-46c5-9889-b404c5b505bb; memory://md:memory/2026-09-22.md:452).
- No two-way contact on record; the tie is listener-to-creator, analytical as much as musical.

## History
- 2026-09-11: Dan's current vibe list held eight tracks including two nimino cuts ("Eat Me Better", "Orla"); he invited a deliberately adversarial genre read and expected to reject the blanket label "stutter house" (memory://md:memory/2026-09-11.md:498).
- 2026-09-12: both tracks reappeared in the dance-music vibe cluster he shared (memory://md:memory/2026-09-12.md:38).
- 2026-09-22: asked which synth in iPhone GarageBand most replicates the nimino lead, for use in his own GRIPNOTIC production work (message:9157b484-adc7-46c5-9889-b404c5b505bb).

## The relationship
- Deliberately-followed creator in the obsession tier — the same class of tie as BSEARL in Dan's record.
- The tie is forensic, not fannish: the nimino lead is a sound-design reference for GRIPNOTIC, something to pull apart and rebuild on his phone, not just a track to hear.
- The endorsement is behavioral: two tracks in his vibe clusters a day apart, and he wants the lead sound in his own production kit.

## In common
- Dan's other music obsessions: [BSEARL](../people/bsearl.md), [LYNY](../people/lyny.md), [wax motif](../people/wax-motif.md).
- The 2025 dance-music re-entry and the GRIPNOTIC project.

## Open threads

## Strengthening
