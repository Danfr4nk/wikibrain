---
display_name: Jared
first_name: Jared
summary: Half of the couple with Tricia that booked Annie for a 2-hour session; kissing Annie was forbidden him, and afterward Annie made him cum a second time during the walkout.
rank: 59
updated: 2026-09-13
---

<!-- evidence: memory://md:MEMORY.md:93 (new names, red-walls photo, Dan presumably photographer); memory://md:MEMORY.md:95 (kissing restriction, walkout coda, per Annie via Dan); memory://md:memory/2026-09-12.md:767 (dark-haired woman in the photo identified as Annie); memory://md:memory/2026-09-12.md:772 (2-hour couple booking, extra woman from their building) -->

# Jared

## Facts
- Jared (last name unknown) — surfaced as a new name in the 2026-09-12 Annie thread.
- Half of the couple with Tricia that booked Annie for two hours, per Dan's account of the appointment.
- Appears with Tricia (blonde) and Annie (dark-haired, identified by Dan via the flank-tattoo match) in nude/sexual photos on a hotel-style bed with red walls from Dan's intimate archive; Dan presumably the photographer.
- Booking restriction, per Annie via Dan: Jared was not allowed to kiss Annie.
- After the session, with Tricia absent, Annie made Jared cum a second time while he walked her out.
- An additional woman from Jared and Tricia's building was also present when Annie arrived for the appointment.
- Backstory beyond this episode is unknown; no other contact with Dan is documented.

## History
- 2026-09-12: Jared and Tricia surfaced as new names in the Annie thread — the couple that booked Annie for 2 hours. Dan identified the photo's dark-haired woman as Annie and relayed the booking restrictions and the walkout coda.

## The relationship
- Dan has not named this relationship in his own words; the observed tie runs entirely through the Annie episode — Jared is a man from the intimate-archive world whom Dan photographed and whose couple's booking of Annie Dan documented secondhand. Recorded as observed contact, the nature left unstated.

## In common
- Annie Ulmer — the 2-hour booking, the red-walls photo, the walkout coda.
- Tricia — the other half of the couple; the red-walls photo.

## Open threads
- [ ] Jared and Tricia's backstory — who they are beyond the one documented booking (unknown as of 2026-09-12).

## Strengthening
