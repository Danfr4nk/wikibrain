---
display_name: Anita
first_name: Anita
summary: BFS Foods gas-station GM — originated the disputed $50 drawer-shortage claim against Dan.
rank: 32
updated: 2026-09-09
---

<!-- evidence: corpus-extract/agent-B-people.md (§ Anita — BFS Foods gas-station GM); memory://md:MEMORY.md:12; memory://md:MEMORY.md:36 -->

# Anita

## Facts
- Anita (surname unrecorded); GM of the BFS Foods gas station where Dan worked Apr–May 2026.
- Originated the $50 drawer-shortage claim that got Dan terminated — a disputed figure he refused to pay off the books.
- The record's textbook "vertical-suspect" authority figure.
- BFS offered Dan a rehire on Aug 11, 2026 — status unconfirmed.

## History
- Apr–May 2026: the drawer-shortage episode and Dan's termination. Aug 2026: the rehire offer, still open.

## The relationship
- Adversarial manager — the dispute is the whole tie, and the rehire offer leaves it live.

## In common
- BFS Foods: Brandon Hill, Kim, Marty Martin; the $50 dispute.

## Open threads
- [ ] BFS rehire offered Aug 11, 2026 — status unconfirmed.

## Strengthening
