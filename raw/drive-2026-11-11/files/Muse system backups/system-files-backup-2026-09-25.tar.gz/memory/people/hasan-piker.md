---
display_name: Hasan Piker
first_name: Hasan
last_name: Piker
summary: Leftist Twitch streamer Dan has watched since the 2020 radicalization pipeline — sustained, critical fandom; watches, quotes, and pushes back.
rank: 64
updated: 2026-09-16
---

<!-- evidence: memory/2026-09-16.md#L471 (discovery pass: 30 corpus__3.txt mentions, clusters); memory/2026-09-16.md#L1030 (work-0091: wiki article existed, entity node + 2 tweet datums); memory/2026-09-16.md#L542 (28-30 corpus__3.txt mentions: 2020 radicalization channel, 2021 J6 tweets, Feb-2022 Russia criticism, Oct-2023 global-conflict criticism, 2025-26 watch history, 2019 Twitch 2FA); memory/2026-09-12.md#L184 (writing pass 755 -> 4,002 words, merged main 5ae9208); memory/2026-09-14.md#L14 (2020-left-turn pipeline corrected to Hasan Piker / Chapo Trap House / Thoughtslime) -->

# Hasan Piker

## Facts
- Hasan Piker — Twitch streamer and leftist political commentator; Dan has never met him and holds no personal relationship — the tie is viewer-to-creator, sustained from 2019 through 2026.
- One of Dan's three named 2020 lockdown radicalization channels: the pipeline corrected (2026-09-14) to Hasan Piker / Chapo Trap House / Thoughtslime — ContraPoints demoted to adjacent-viewing with a dated correction note.
- 30 Hasan/HasanAbi/hasanthehun mentions in the held corpus (`corpus__3.txt`) versus zero in the index: 2020 radicalization channel, 2021 J6 tweets, Feb-2022 Russia criticism, Oct-2023 global-conflict criticism, 2025-26 watch history, a 2019 Twitch 2FA SMS.
- Watch record: HasanAbi — 16 real watches Aug 2025–Jul 2026 (the 2026 watch tables).
- Dan's wiki holds a 4,002-word article on him (`wiki/interests/hasan-piker.md`), expanded Sep 12, 2026 (755 → 4,002 words, merged main → 5ae9208); the engine's work-0091 (Sep 16, 2026) filled the missing entity node and two tweet datums on top of it.

## History
- 2019: Twitch 2FA SMS on record — Dan's Twitch account already in use before the 2020 turn.
- Aug 2020: the lockdown radicalization pipeline — Chapo/Hasan/ContraPoints becomes the media through which Dan's hard-left turn consolidates.
- Jan 6, 2021: Dan quotes @hasanthehun's "Derrick Evans is in the Capitol Building!!!" in his own J6 tweets — following the same feed in real time.
- 2021-01-09: a tweet in which Dan directly addresses Hasan (datum added Sep 16, 2026, work-0091).
- Feb 2022: the Russia-take criticism — "I love Hasan but his take on Russia is either purposefully antagonistic... or astonishingly naive." His words.
- 2022-02-22: a correction sequence — Dan correcting Hasan (datum added Sep 16, 2026, work-0091).
- Oct 2023: global-conflict criticism — the pushing-back pattern continues.
- Aug 2025–Jul 2026: 16 real watches — the watching never stopped.

## The relationship
- Critical fan: the closeness is parasocial and the engagement is argumentative. Dan has watched Hasan across the whole 2020–2026 arc and credits him as part of the radicalization pipeline, but treats him as someone to be disagreed with in public — the Russia criticism and the 2022 correction sequence are Dan talking back to the same figure he watches for hours.
- This is the pattern of Dan's left-media diet generally: he sits inside the feed (watches, 2FA'd Twitch account) and stands outside the consensus (corrects the takes).

## In common
- The hard-left media diet — Chapo Trap House, Thoughtslime, the 2020 pipeline cohort.
- The shared left-turn narrative: Hasan is one of the few named channels of Dan's 2020 radicalization, the other two being Chapo and Thoughtslime.

## Open threads

## Strengthening
