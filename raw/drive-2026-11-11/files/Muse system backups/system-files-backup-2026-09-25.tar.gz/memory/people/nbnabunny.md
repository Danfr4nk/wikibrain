---
display_name: nbnabunny
summary: London-based trans creator (nbnabunny.com) — Seed 2 of Dan's Sep 17, 2026 creator-discovery project; faceless-era promo, "the dark-haired bookend to Lexi's blonde."
rank: 67
updated: 2026-09-17
---

# nbnabunny

## Facts
- London-based trans creator; site nbnabunny.com; self-brands as "the sluttiest trans girl." (memory/2026-09-17.md#L258)
- Faceless era: her face is concealed in promo, and her about page frames that as questions of intimacy and authorship. (memory/2026-09-17.md#L258)
- Look: long dark hair, hyper-femme lingerie (lace-topped thigh-highs, heels, soft white top); the brutal black-metal wordmark against the delicate girl is the brand contrast. (memory/2026-09-17.md#L258)
- Dan's project assessment: the dark hair puts her back on his brunette streak; the facelessness carries a worship-from-afar charge; logged verdict "the dark-haired bookend to Lexi's blonde." (memory/2026-09-17.md#L258)

## History
- Sep 17, 2026 (pre-dawn): Seed 2 of Dan's commissioned trans-creator discovery project; researched and filed in the same session. (memory/2026-09-17.md#L196)
- A watermarked promo still was saved at `~/workspace/your_files/nbnabunny-photo.jpg` (her homepage yielded only the logo). (memory/2026-09-17.md#L258)

## The relationship
- A creator Dan deliberately follows under the commissioned project; no personal contact, never met. His "authenticity over production" law calibrates the whole seed set. (memory/2026-09-17.md#L196; MEMORY.md#L128)

## In common
- Dark-haired trans-femme presentation; the project's homemade/amateur weighting.

## Open threads
- None. The seed profile is filed; nothing is pending.

## Strengthening
