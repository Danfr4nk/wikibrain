---
display_name: Alexander Jackson
first_name: Alexander
last_name: Jackson
summary: Owner of 463 Morgantown St — Dan and Suz moved in with no signed lease or POA; the Arnu lien attaches to his title.
rank: 31
updated: 2026-09-09
---

<!-- evidence: corpus-extract/agent-B-people.md (§ Alexander Jackson — owner of 463 Morgantown St); memory://md:MEMORY.md:8; memory://md:MEMORY.md:35 -->

# Alexander Jackson

## Facts
- Alexander Jackson; owner of 463 Morgantown St, where Dan currently lives with Suz.
- Dan and Suz moved in early 2026 with no signed lease and no POA — the housing is unsettled as of Aug 2026.
- The Arnu contractor lien attaches to his title.

## History
- Early 2026: the move-in without paperwork. The title and lien exposure are the live facts.

## The relationship
- Landlord by ownership, not by contact — a paper relationship carrying live housing stakes.

## In common
- 463 Morgantown St; the contractor exposure (Arnu, Felix, John Carney).

## Open threads
- [ ] No signed lease or POA — the housing obligation is unresolved.
- [ ] The Arnu lien against his title.

## Strengthening
