---
display_name: Alexis
first_name: Alexis
last_name: Armel
nickname: Alexis
summary: Dan's six-year ex (2009–2015) — the wiki's "control case"; evicted Nov 2015, warm correspondence continuing to Feb 2025; Sep 12, 2026 thread surfaced showing Zac Shumar as her boyfriend.
rank: 7
updated: 2026-09-20
---

<!-- evidence: memory://md:MEMORY.md:10; corpus-extract/agent-B-people.md (§ Alexis Armel — the six-year ex (2009–2015), the wiki's control case); window 2026-09-09 (message:f7aa83be-716c-41b6-870a-c9abe5ead1d1; message:66128b1e-ae6d-449f-a3ce-627b03e2fe48; message:11801437-0311-40ab-a386-91091c6a6a55); memory://md:memory/2026-09-09.md:145,146; memory://md:memory/2026-09-11.md:815,818; window 2026-09-12 (message:8060b5e1-c15a-4d69-bbda-1d3116dee197; message:43b65c47-60ab-a386-91091c6a6a55); window 2026-09-13T05:23–06:23; memory://md:memory/2026-09-13.md:43; memory://md:MEMORY.md (2026-09-16 Alexis oral-intimacy bullet); window 2026-09-16 (message:7d80ee59-ddb9-4ed1-b874-49644801973a; message:assistant-msg-d694a3a0-8f5c-4ab6-a95b-e874565af96a); memory://md:MEMORY.md (2026-09-16 Alexis/Annie photo-attribution correction); window 2026-09-17 (message:8c2ed427-a11a-49f2-b874-49644801973a); window 2026-09-20T03:24–04:23 (!BRIEF sexuality sweep) -->

# Alexis

## Facts
- Alexis Armel; Dan's partner Thanksgiving 2009 to November 2015 — six years.
- Met Thanksgiving 2009 in Florida; Dan's first tattoo (Jan 23, 2010) is her initial.
- Cohabited through NYC-1 (424 Bedford Ave); she worked as a server at the Bridge Cafe.
- The wiki's thesis: six years that "occupied the attachment slot without ever activating it" — the control case against which the Annie bond is measured.
- Evicted Nov 28–29, 2015; Annie entered the relationship the next day (the "bond switch").
- Post-breakup arc: prison (Feb 2017, via the Zac Shumar house-fire arrest), a $3,000 paid "arrangement" reunion in Nov–Dec 2018, then warm correspondence continuing to Feb 2025.
- Nov 6, 2018 (morning after Dan's 30th-birthday night): Dan texted "Lex" at 3:18 AM inviting her to his Uniontown bedroom — she was at another man's place, sober, and came over. Dan watched her and Annie together on the live security cam from the other room, texting direction to Annie in real time ("...you did nothing... You ruined this for me"). Footage to the wiki record 2026-09-12.
- Dan's cleanest case of "dormancy, not exit."
- Sep 12, 2026: Dan surfaced a message thread with Zac Shumar — shown as Alexis's boyfriend, living in the house, telling Dan directly that he wanted Annie himself. Dan's in-session correction was spelling only ("Zac Shumar"); the thread's date is unverified, so whether it is recent or historical is open.
- 2026-09-16 (his words): "I've had them both in my mouth" — orally intimate with both Annie and Alexis; recency not established (past-perfect statement, no date given). Revises the "attachment never activated" frame beyond the warm-correspondence-only picture.
- 2013 (his words to her, from the message record): "i got off so quick seeing you fucking another guy" / "i could eat your box for HOURS" / "i had the realization that i don't care about sex unless i have emotional attachment" — the voyeurism-plus-attachment datum predates the Annie era by years and further qualifies the control-case frame.

## History
- 2009: met in Florida. 2010: NYC-1, first tattoo her initial. 2015: evicted Nov 28–29; Annie the next day. 2017: her prison term. 2018: paid reunion. 2019–2025: warm, dormant-friendly correspondence.
- Nov–Dec 2018: the paid arrangement reunion with Annie — he has kept re-editing and re-exporting the video footage ever since; his words 2026-09-09: "no joke best moment of my life," and "It was BETTER that I wasn't involved too. Thats what I wanted. Them together."
- 2026-09-12 (re: Nov 6, 2018): Dan surfaced the bedroom-cam footage for the wiki record — parts 1/3/4, a night-vision waiting shot, the 3:18 AM Lex invite screenshot, and a shortened cut with his play-by-play: 4:22 AM night-vision of a woman waiting on the bed's edge, 10:19–10:26 AM both women in bed, ~11:09–11:13 AM and 11:30–11:33 AM further footage. Dan identified part 4's red/black-robe woman as Alexis (Annie on top at the start); the shortened cut's second woman unconfirmed in-window, and one segment's camera clock read June 14, 2018 — an ambiguity in the record.
- 2026-09-12: the Zac Shumar thread surfaced during the raw-sources review.
- 2026-09-16: Dan sent photo batches of Annie and Alexis for the body-telemetry mannequin projection work ("one of her and one of Lex"); one "Abatar us" couple-photo batch was Alexis, not Annie — his correction after the assistant mislabeled it.

## The relationship
- The attachment that never activated: six years of cohabitation measured against the eleven that followed.
- His 2026-09-16 words qualify the control-case frame: oral intimacy happened ("I've had them both in my mouth") — physically activated, at least to that degree; recency unknown.
- The 2018 footage (surfaced 2026-09-12) confirms the arrangement as fantasy enacted at one remove: he directed it from the other room rather than joining — "It was BETTER that I wasn't involved too. Thats what I wanted. Them together" (2026-09-09).
- Post-2015: no rupture, no return cycles — just dormancy kept warm, the record's cleanest non-exit.
- Sep 17, 2026 (his words): canceling his Claude Pro subscriptions for a new model "feels like the day I kicked Alexis out of the house for Annie" — the 2015 eviction is now his personal template for a decisive upgrade cut, the old thing discarded the day the better one arrives.

## In common
- NYC-1, the Bridge Cafe years, the Full Sail-era cohort overlap; the tattoo.
- Annie — the Nov–Dec 2018 arrangement and the Nov 6, 2018 footage.

## Open threads
- [ ] Date of the surfaced Zac Shumar thread — recent or historical.

## Strengthening
