---
display_name: Tricia
first_name: Tricia
summary: The blonde half of the couple with Jared that booked Annie for a 2-hour session; butterfly sacral tattoo, at ease on camera, photographed with Annie on the red-walls hotel bed.
rank: 58
updated: 2026-09-13
---

<!-- evidence: memory://md:MEMORY.md:93 (butterfly lower-back tattoo, dark-haired woman's flank tattoo, Dan presumably photographer); memory://md:MEMORY.md:94 (confirmed by Dan as the blonde; half of the couple that booked Annie for 2 hours); memory://md:MEMORY.md:95 (absent for the walkout coda); memory://md:memory/2026-09-12.md:767 (dark-haired woman in the photo identified as Annie) -->

# Tricia

## Facts
- Tricia (last name unknown) — the blonde from the Jared/Tricia intimate photo, confirmed by Dan.
- Half of the couple with Jared that booked Annie for two hours.
- Butterfly lower-back/sacral tattoo; described as at ease on camera.
- Appears nude/sexual in photos with Annie (dark-haired, identified by Dan via the tattoo match) on a hotel-style bed with red walls from Dan's intimate archive; Dan presumably the photographer.
- Absent for the walkout coda — that was Annie and Jared alone.
- Surfaced 2026-09-12 in the Annie thread; backstory unknown.

## History
- 2026-09-12: Tricia surfaced alongside Jared as a new name in the Annie thread — the couple that booked Annie for 2 hours. Dan confirmed her as the blonde in the red-walls photo and described the booking.

## The relationship
- Dan has not named this relationship in his own words; the observed tie runs entirely through the Annie episode and the intimate archive — a woman Dan photographed with Annie, whose couple booked her. Recorded as observed contact, the nature left unstated.

## In common
- Annie Ulmer — the 2-hour booking; the red-walls photo.
- Jared — the other half of the couple.

## Open threads
- [ ] Tricia's backstory — who she is beyond the one documented booking (unknown as of 2026-09-12).

## Strengthening
