---
display_name: Vanessa
first_name: Vanessa
last_name: Frank
summary: Dan's younger sister — steady, low-conflict, minimal contact; works ski school in Vail; shared left politics.
rank: 8
updated: 2026-09-09
---

<!-- evidence: memory://md:MEMORY.md:9; corpus-extract/agent-B-people.md (§ Vanessa C. Frank — younger sister) -->

# Vanessa

## Facts
- Vanessa C. Frank, b. January 16, 1994 (Greensburg PA); Dan's younger sister.
- Works ski school in Vail; the people-extraction also records her living in NYC — the two records are not reconciled.
- Steady, low-conflict thread: 709 messages, 2015–2026; defined by shared left politics.
- Minimal contact overall.

## History
- 2015–2026: a thin but steady correspondence — no ruptures, no intensity, just continuity.

## The relationship
- The quietest family tie: low-conflict, low-frequency, defined by shared politics rather than shared history.

## In common
- Left politics; the Frank family; Lisa Durbin (extended-family relation) coordinates family gatherings with her.

## Open threads

## Strengthening
