---
display_name: Rick
first_name: Richard
last_name: Frank
nickname: Rick
summary: Dan's father — warm-but-strained; Dan broke an 18-month silence toward him on Sep 1, 2026, and a Sep 2 dinner was arranged (completion unconfirmed).
rank: 4
updated: 2026-09-18
---

<!-- evidence: memory://md:MEMORY.md:9; memory://md:memory/2026-09-09.md:187 (silence broke 2026-09-01); memory://md:memory/2026-09-09.md:203,209 (Sep 2 dinner arranged, completion unpinned); corpus-extract/agent-B-people.md (§ Rick Frank — father, warm-but-strained); window 2026-09-11 (Frank's Auto Supermarket research, assistant-msg-fc08e0d3); window 2026-09-18 story-time abortion sweep (assistant-msg-d672db3d-66c7-47bd-b47d-f7c9435fc40c) -->

# Rick

## Facts
- Richard Harrison Frank, b. 1959; tied to Frank's Auto Supermarket in Uniontown — the family business: founded 1938 per the company's own claim; 75 S Beeson Blvd; five stores across western PA; McKeesport ribbon-cutting April 6, 1990. PitchBook lists the company as acquired by O'Reilly Automotive (date unknown) — so the corpus claim that Rick runs it may be stale post-acquisition; unconfirmed (research surfaced 2026-09-11, corroboration pending).
- Dan's father. Married Suz Aug 31, 1985; divorced ~2005.
- Posture: the inverse of Suz — withdrew to low-frequency contact after the November 2005 rupture (a concealed alternate reality: his rehab admission, her affair with the family dealer).
- Real repair through 2020 and again 2023–24.
- Feb 26, 2025: Dan went silent after proposing a get-together — one-sided silence for 18 months.
- Sep 1, 2026: Dan broke the silence — his first message to Rick since Feb 2025, acting on Ally Lubin's standing push to re-engage.
- Sep 2, 2026: a dinner with Rick was arranged — completion unconfirmed; the corpus record ends Sep 7.
- With partner Lisa Frank (teacher) since at least December 2015.

## History
- Aug 31, 1985: married Suz. Nov 2005: the rupture — the corpus's named template for Dan's later attachment pattern.
- June 2017: funded the $1,000 for the abortion — "I'm trying not to let this fuck up all the hard work I've put in tying my name to the new course... Thank you for another bailout" (June 26). Dan lied to him that Suz didn't know yet — she'd been told June 24; the lie is in Dan's own words to Suz.
- 2020 and 2023–24: real repair episodes. Feb 2025: Dan went silent after proposing a get-together.
- Sep 1, 2026: Dan broke the silence — first message to Rick since Feb 2025. Sep 2, 2026: dinner arranged; whether it happened is unconfirmed in the record.

## The relationship
- Warm-but-strained: Dan separates the man from the template — the 2005 concealment is the authority-distrust template, but the person gets more care than the pattern suggests.
- The tie is in motion again: Ally's nudge landed Sep 1, 2026; the follow-through (the Sep 2 dinner) is the live question.

## In common
- Uniontown, the family estate ledger, the Frank line; the 463 Morgantown contractor set touches both sides of the family; Frank's Auto Supermarket — the family business whose founder (1938, Morley was 11 — presumably great-grandfather David J.?) and post-acquisition status only Dan can pin down.

## Open threads
- [x] Ally's instruction to Dan: text his father — done Sep 1, 2026 (first Dan→Rick message since Feb 2025).
- [ ] Whether the arranged Sep 2, 2026 dinner with Rick actually happened — the corpus record ends Sep 7 with completion unpinned.
- [ ] (2026-09-11) Frank's Auto: who founded it in 1938 (Morley was 11 — presumably great-grandfather David J.?); when O'Reilly acquired it and what Rick does there now — three questions only Dan can answer.

## Strengthening
- Confirm whether the Sep 2 dinner happened; if it didn't, re-book it — breaking the silence was the hard part, and the follow-through is what's live now.
