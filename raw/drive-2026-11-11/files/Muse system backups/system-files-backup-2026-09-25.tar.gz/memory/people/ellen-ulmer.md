---
display_name: Ellen
first_name: Ellen
last_name: Ulmer
summary: Annie's mother — "the relationship that outlasted the one it came from"; still sending birthday wishes in Nov 2025.
rank: 12
updated: 2026-09-09
---

<!-- evidence: corpus-extract/agent-B-people.md (§ Ellen Ulmer — Annie's mother); memory://md:memory/2026-09-09.md:68; window 2026-09-09 (transcript-validation) -->

# Ellen

## Facts
- Ellen Ulmer; Annie's mother.
- The thread opened with Jay Lauer's overdose (~April 11, 2017) — the network's only documented fatality.
- Still sending birthday wishes in November 2025 — after the terminal rupture.
- Described in the record as "the relationship that outlasted the one it came from."
- In the Aug 16, 2026 Annie–Jerel call, Dan used Ellen as leverage — threatening to send the recording to her to pressure Coles into returning Annie's phone; the leverage was aimed at Coles in the moment, with the ethical problem coming later when it was re-aimed toward Annie.

## History
- Apr 2017: the thread opens around Jay Lauer's death. Through the Annie decade and past its end: continued warmth. Aug 2026: named as leverage in the Morgantown St call.

## The relationship
- De facto in-law who became an independent tie: the maternal warmth that survived the severance it came from.

## In common
- Annie's family: Bill, Claire, Garrett, Alice, Otto; Jay Lauer's memory.

## Open threads

## Strengthening
