---
display_name: Kenney
first_name: Kenney
summary: Suz's boyfriend in 2010 — met Fran and Diane; surfaced in the recovered 2010 Suz↔Dan SMS.
rank: 82
updated: 2026-09-23
---

<!-- evidence: memory://md:memory/2026-09-23.md (2010 Suz↔Dan SMS batch content flags); window 2026-09-23 conversation (assistant-msg-0f1029f6-9502-d35b-b3d3-44e8d9de6074 — "New people: Kenney (Suz's boyfriend, met Gram and Diane)") -->

# Kenney

## Facts
- Kenney was Suz's boyfriend in 2010 — the recovered Jan–Aug 2010 Dan↔Suz SMS batch identifies him as such.
- He met Fran Coldren ("Gram") and Diane Moore.

## History
- Jan–Aug 2010: dating Suz, present enough in the family orbit to have met both Fran and Diane. No later trace on record.

## The relationship
- Known only through Suz — her 2010 boyfriend; no direct Dan↔Kenney contact on record. What the tie to Dan is beyond that is unstated.

## In common
- Suz; the maternal line (Fran, Diane).

## Open threads
- [ ] Last name and anything beyond the 2010 window are unknown — a candidate for the full Suz↔Dan gap-fill across the archives.

## Strengthening
