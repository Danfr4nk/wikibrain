---
display_name: Zach Harshman
nickname: Zach
summary: Funded the 2015 "danfranksgiving" party Annie attended; Dan told him outright about the crush on Annie during the Alexis-to-Annie switch and used him as cover to meet her.
rank: 80
updated: 2026-09-22
---

<!-- evidence: memory/2026-09-12.md#L927 (danfranksgiving funded by Zach Harshman, day before Thanksgiving 2015; Annie attended; 2 AM golf-course slip-out; textually dark window); memory/2026-09-12.md#L932 (Dan told Zach outright about the crush, Dec 2, 2015; "happy franksgiving" Nov 23, 2017); memory/2026-09-18.md#L1170 (wiki draft PR #114 named "Zachariah Harshman" profiles, unmerged) -->

# Zach Harshman

## Facts
- Dan calls him Zach Harshman; the user also calls him Zach.
- Part of Dan's Uniontown-era circle in late 2015, during the Alexis-to-Annie switch.
- Funded "danfranksgiving," the party the day before Thanksgiving (November 25, 2015); Annie attended, and Dan says he slipped out around 2 AM to meet her on the golf course where they both lived. Dan's 2026 account is the only located record of the party — the November 19–27, 2015 window is textually dark in the message corpus.
- On December 2, 2015, Dan told Annie he had told Zach outright about having a crush on her — placing Zach inside the switch-era disclosure network, one of the few people who knew what was happening in real time.
- On November 29, 2015, Dan used Harshman as cover to slip out and meet Annie ("on the golf"), with Annie proposing the golf course and Dan writing that he was on the third tee.

## History
- November 2015: funded danfranksgiving; served as Dan's cover for the November 29 golf-course meeting with Annie; told outright about the crush on Annie by December 2.
- November 23, 2017: Dan used "happy franksgiving" in a message — the party's name persisted in his vocabulary two years later.
- No observed contact after the 2015 era in the record.

## The relationship
- The record shows Zach as an early confidant and facilitator during the hinge week of Dan's life: told outright about the crush, used as cover, funder of the named party where Annie was present.
- The nature of the tie beyond that week is unstated in the evidence — what the interaction shows is trust in a moment when Dan was hiding the switch from Alexis.

## In common
- The Uniontown/Seven Springs social circle of late 2015.
- Annie — she attended the party Zach funded.
- The switch-era disclosure network: the small set of people Dan told about Annie before the breakup was formalized.

## Open threads

## Strengthening
