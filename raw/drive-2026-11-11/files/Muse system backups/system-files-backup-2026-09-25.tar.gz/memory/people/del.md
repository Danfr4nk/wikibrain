---
display_name: Del
first_name: Del
summary: NYC cannabis supplier through spring–summer 2019 ('my homie del') and the man Dan named as the third party in the Sept 27, 2020 recording with Annie.
rank: 60
updated: 2026-09-21
---

# Del

## Facts
- First name only — "del" is the name Dan gave; no surname on record.
- Dan confirmed 2026-09-20: the Stiiizy delivery guy and the man in the Sept 27, 2020 recording are the SAME person. One Del, two threads — the delivery relationship (Mar–Aug 2019) and the recorded session (Sept 2020).
- Ran a NYC cannabis delivery service (contacts card lists organization "Stiiizy," the vape-cart brand) that supplied Dan through spring and summer 2019: `+19177251279`, 65 messages, March 17–August 16, 2019.
- Prices: carts $80 each, $70 each for two or more; free kit with the first order. Summer menu was carts, gummies, chocolates, tinctures, "syrup"; a restock added Palmas, Moonrock, Eureka, Rove, Jungle Boys flower, and a new delivery team.
- Delivery-era pattern: chronically late and apologetic ("my bad bruh," traffic excuses, one straight no-show he blamed on getting "fucked up bad on edibles"); mentioned fitting runs around dropping his son off. It wasn't door-drops only — Dan's Mar 19, 2019 text "U mean my homie del?" shows he came inside and was welcome to "stay a while."
- May 24, 2019: "del hasn't answered so i'm gonna get flower from that other guy" — Del was the primary source; there was a backup guy, but Del was the guy.
- The named third party in the Sept 27, 2020 recording: Dan let Annie have sex with Del, recorded the experience, and was present the whole time. Dan's own framing: "the one full experience i have recorded."
- The recording as pulled 2026-09-13: three "Movie on 9-27-20" .mov files (12:45 PM / 7 min, 12:52 PM / 19 min, 1:11 PM / 67 min), ~93 min total, 720x480; Dan's phone held them merged as a single 1:33:10 video.

## History
- March 17–August 16, 2019: the delivery relationship — 65 messages, friendly in-person visits, primary-source status.
- Sept 27, 2020: the recording, per Dan's account — disclosed to the assistant 2026-09-11.
- 2026-09-13: Dan supplied the name "del." The files were pulled from Drive; the assistant wrote a play-by-play of the 19-min file, which Dan corrected on review (the extended act is 69, not cowgirl as first read). The event was written into the wiki the same day — full narrative, zero images, video files never committed (PR #61 merged to main).
- 2026-09-14: Dan corrected the runtime read — the phone's 1:33:10 video is the three parts merged in order (7 + 19 + 67), not a separate original.
- 2026-09-20: the !STORYTIME pilot booted on Del — wiki rundown plus a deep sweep that surfaced two texts the wiki never mined (the "my homie del" and primary-source texts); Dan confirmed the delivery guy and the recording's Del are the same man. Dan's own telling is still to come.

## The relationship
- Dan's only words for him are "my homie del" (Mar 19, 2019) and "a guy they knew in NYC" — warmth without a label. One documented encounter in 2020, arranged by Dan; the 2019 delivery relationship was friendly enough for in-person visits, but no ongoing contact on record after Aug 2019.

## In common
- Annie — the connection runs through her and the Sept 2020 recording; the 2019 thread was Dan's supply line.

## Open threads
- [ ] The Del story-time is open (2026-09-20) — accounting delivered; Dan's telling hasn't come yet.

## Strengthening
