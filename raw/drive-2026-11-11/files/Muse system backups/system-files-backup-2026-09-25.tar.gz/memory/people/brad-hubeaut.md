---
display_name: Brad Hubeaut
first_name: Brad
last_name: Hubeaut
summary: Dan's Nemacolin caddy manager (2017–18) — the yard's friction pole; in June 2017 he told Dan he'd been at the same abortion provider recently.
rank: 70
updated: 2026-09-18
---

<!-- evidence: corpus-extract/agent-B-people.md (§ Brad Hubeaut); window 2026-09-18 story-time (assistant-msg-d672db3d-66c7-47bd-b47d-f7c9435fc40c: "Brad said we could write off the procedure as an occupational expense lololol. He was there a few weeks ago") -->

# Brad Hubeaut

## Facts
- Caddy manager at Nemacolin Woodlands, 2017–18 — Dan's boss through his caddy years there (2016–19).
- The friction pole of the yard: documented April 2018 episode over uncleaned carts and turned-down shifts.
- June 24, 2017 (Annie relaying his words to Dan): "Brad said we could write off the procedure as an occupational expense lololol. He was there a few weeks ago" — he'd been at the same abortion provider recently, with someone else. The only Brad in Dan's Nemacolin circle; treated here as the caddy manager.

## History
- 2017–18: Dan's caddy manager at Nemacolin; the friction pole in the yard's dynamics.
- April 2018: the uncleaned-carts / turned-down-shifts episode.
- June 2017: the abortion-provider remark — the one personal disclosure on record between them.

## The relationship
- Boss and employee: Dan rank-and-file caddy, Brad the manager with the friction. The record shows a working-yard authority tie, not a friendship — the closest thing to personal between them is the June 2017 remark, relayed secondhand through Annie.

## In common
- The Nemacolin caddy yard, 2016–19.

## Open threads

## Strengthening
