---
display_name: Jesse T. Wallace III
first_name: Jesse
last_name: Wallace
summary: Laurel Highlands superintendent; Dan saved both his board evals and did a joint forensic read of them with Sammy on Sep 15, 2026, after the board rescinded his extension on Aug 5.
rank: 62
updated: 2026-09-15
---

# Jesse T. Wallace III

## Facts
- Superintendent of the Laurel Highlands School District, Dan's home district in the Uniontown, PA area (Dan described the coverage as "the press around here").
- Dan saved the district's 2024–25 superintendent evaluation PDF before it was pulled from the district site, and supplied it alongside the 2025–26 evaluation for a joint read on Sep 15, 2026.
- 2024–25 evaluation: a single-evaluator form by board president Joe D'Andrea — all six standards rated Distinguished; comments called Wallace "an extremely effective communicator." No tabulation, no other voices.
- 2025–26 evaluation: compiled by board president Marcus DiNunno from all nine board members' scores — nearly every indicator Needs Improvement or Failing; 6 of 9 rated him Failing at identifying and resolving district problems. DiNunno's comments accused him of micromanaging, being dismissive, and playing politics with board members. Wallace signed it under written protest, disputing its accuracy on the record. Presidency flipped from D'Andrea to DiNunno between the two evals.
- August 5, 2026: the board voted 6–3 to rescind Wallace's three-year contract extension (it would have run him through 2030; he now expires summer 2027). The no votes: Tom Landman, Ken Meadows, and Joe D'Andrea. D'Andrea called it "a complete ambush" and "politically motivated," and told the Daily Courier he'd contacted the Pennsylvania School Boards Association. The same night the board accepted the 2025–26 evaluation by majority vote (D'Andrea and Landman voted no).
- March 2026: teachers Martin Gatti (sexual comments to a student) and Daniel Cervone (sexual relationship with a student going back to 2020; charged with attempted institutional sexual assault, unlawful contact with a minor, corruption of minors) were arrested and fired. A third teacher was investigated in April over 2009 allegations and fired that summer.
- Earlier: 2023, teacher Ashley Thurby-Kolesar — 6,000+ texts with a 17-year-old, allegedly secretly recorded a 15-year-old; felony wiretapping charges; pleaded guilty; teaching certificate suspended effective Sept 30, 2025.
- Fallout: a Change.org petition called for Wallace's resignation (community, not the board — the board never moved against him); DA Mike Aubele warned that students were allegedly told not to discuss it; State Rep. Charity Grimm Krupa pushed for an AG investigation; the board hired Pittsburgh firm MBM Law for an outside review.
- Other findings from the Sep 15 research: Bobbi Downs became high school principal in August; the middle school opened the year with two weeks remote for mold remediation; the board bought two AR-15s and ammo for the schools around January; the FY2025 audit was clean.
- The joint read's key finding: the two documents agree on exactly two things — staff accountability is a real weakness (his ally D'Andrea named it first) and fiscal responsibility is a real strength (the hostile board conceded it). Everything else flipped 180°, which read as a broken relationship, not a changed man. Neither document contains a single verifiable outcome metric.
- Next regular board meeting: Wednesday, September 16 (6pm, HS library); no agenda published as of Sep 15, and no outlet had covered the September 1 evaluation itself.

## History
- Dan saved the 2024–25 evaluation from the district site before it was taken down (a search cache from ~Aug 31, 2026 still showed it; it was pulled sometime after).
- Sep 15, 2026: Dan uploaded both evaluation PDFs and asked Sammy to research everything around Wallace over the last year — then ran a joint forensic read of both documents, had three research agents sweep the press, the Aug 5 vote, and the community side, and synthesized the full timeline in one session.

## The relationship
No personal relationship — Dan has never met Wallace. The tie is a deliberately researched local-governance interest: Dan is a Uniontown resident who followed this story (he archived the eval before it disappeared), and the Sep 15 session was a joint analytical exercise with Sammy, not a personal encounter. It fits his broader appetite for reading political documents forensically — who wrote them, what function they serve, what changed between versions. The engagement is civic and analytical: the district is his home district, the scandals broke there, and the story is unfolding now.

## In common
- Laurel Highlands / Uniontown: the district is Dan's local one, the source of his interest.
- The forensic-politics lens: the Sep 15 session was built around Dan and Sammy's shared reading of documents as political instruments — the eval as paper trail, the "kill document" analysis, the through-line test of what survives when the authorship flips.

## Open threads
- [ ] Sep 16, 2026 board meeting (Wednesday, 6pm, HS library) — watch whether duties get stripped or an acting successor is named; no agenda published yet as of Sep 15.
- [ ] Gatti and Cervone criminal case outcomes — cases appeared pending with nothing reported through Sep 15, 2026.
- [ ] Whether the AG acted on Rep. Krupa's request; whether "Professional Employee A" was ever charged.

## Strengthening
