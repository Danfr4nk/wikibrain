---
display_name: Casey Bondarenka
first_name: Casey
last_name: Bondarenka
summary: Short-term late-2015 friend inside Dan's household for the Alexis eviction and Annie's first days — expelled within a fortnight; per Dan's 2026 account, the one who took the Dream Queen harvest.
rank: 57
updated: 2026-09-13
---

<!-- evidence: wiki/people/casey-bondarenka.md (36-message thread Nov 2015–Oct 2018; nine-week arc; "Can I fuck her?"; beer-buying 2015-11-30; Ellen informant attribution; 2017–18 check-ins); memory://md:MEMORY.md:101 (Dream Queen harvest testimony, presence 2015-11-29–12-02); memory://md:memory/2026-09-12.md:915 (opportunity corroborated; taking itself is testimony) -->

# Casey Bondarenka

## Facts
- Casey Bondarenka — a short-term friend of late 2015, documented in a 36-message thread (Nov 2015–Oct 2018, handle +17245626199) with a standing wiki entity page.
- Entered Dan's friend group about a week before 2015-11-30 ("He just started hanging out with us last week"), and was formally asked to stay away by 2015-12-02 — the full documented arc spans about nine weeks.
- Present in the household 2015-11-29–12-02: the exact Alexis-to-Annie switch fortnight.
- The first friend documented learning about Annie — "Wait is that Annie?" on 2015-11-29, the day Dan met her.
- Asked Dan directly whether he could pursue Alexis if the relationship ended ("if you're breaking things with Alexis... Can I fuck her?"); was in the house buying beer for Alexis at 00:39 on 2015-11-30 while the eviction was being staged.
- Blamed by both Dan and Annie as the likely informant who told Ellen that Annie's car was at Dan's house on 2015-12-02 — never confirmed.
- Per Dan's 2026-09-12 testimony, Casey took the Dream Queen harvest before it cured and smoked it in one night during the switch fortnight — his presence in the household corroborates opportunity; the taking itself rests on Dan's testimony.
- 2017–18: sporadic low-effort check-ins ("You working today dude?", "You duckin me bro or you just busy?"); final message Oct 2018 noted a medical marijuana card and offered to "float" Dan.

## History
- 2015-11-29: first documented contact; in the household; learns about Annie the day Dan meets her.
- 2015-11-30: buying beer for Alexis during the eviction staging; the "bombastic" dispute moves to a phone call and is never restated in text.
- 2015-12-02: formally asked to stay away.
- 2016-02-15: full apology text for "anything I may have done that need apologizing for."
- 2017–2018: sporadic check-ins.
- 2018-10: final message — medical marijuana card, offering to float Dan.
- 2026-09-12: Dan named Casey as the one who took the Dream Queen harvest before it cured.

## The relationship
- Dan's own framing was a friend who overstayed his welcome; the hand-read corrects it to a near-stranger present at close range for the most volatile fortnight in the record, then expelled. Nine weeks total, friction throughout, thin check-ins after. No current tie; the relationship is historical and closed.

## In common
- Alexis Armel — Casey was in the household through her eviction and asked to pursue her.
- Annie Ulmer — Casey was the first friend to learn about her.
- Ellen Ulmer — the unconfirmed car-informant attribution.
- Vanessa Frank — Casey upset her by smoking at the house.

## Open threads

## Strengthening
