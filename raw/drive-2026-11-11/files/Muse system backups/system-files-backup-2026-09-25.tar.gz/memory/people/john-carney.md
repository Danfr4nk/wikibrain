---
display_name: John Carney
first_name: John
last_name: Carney
summary: Contractor on the 463 Morgantown St work (10–20% complete); unreachable since March 2026 — the live contractor exposure.
rank: 40
updated: 2026-09-10
---

<!-- evidence: corpus-extract/agent-B-people.md (§ John Carney — 463 contractor exposure set); memory://md:MEMORY.md:36 -->

# John Carney

## Facts
- John Carney — contractor on the 463 Morgantown St work.
- The work sits 10–20% complete.
- Unreachable since March 2026.

## History
- Early 2026: contracted for work on 463 Morgantown St.
- March 2026: went unreachable; the work stalled at 10–20% complete.

## The relationship
- A work relationship turned open exposure — Dan and Suz live in the house the unfinished work attaches to.

## In common
- 463 Morgantown St; the contractor exposure set (Arnu, Felix).

## Open threads
- [ ] Unreachable since March 2026 with the work 10–20% complete — the exposure is unresolved.

## Strengthening
