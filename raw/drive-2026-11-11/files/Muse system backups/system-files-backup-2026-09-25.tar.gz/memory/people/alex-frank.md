---
display_name: Alex
first_name: Alex
last_name: Frank
summary: Paternal-line relative and working journalist (ex-FADER deputy editor, Vogue.com) whose byline Dan follows; his essay on Dan's grandfather Morley Frank's funeral is the family's frownie-cookie story.
rank: 19
updated: 2026-09-09
---

<!-- evidence: corpus__3.txt wiki/people/alex-frank.md (L45744-45845); corpus__3.txt wiki/people/morley-frank.md (L64940-65076) -->

# Alex

## Facts
- Alex Frank; a relative on Dan's paternal Frank line — Dan's grandfather Morley Jay Frank's brother is Alex's grandfather.
- Working journalist and editor based in Brooklyn, covering music, fashion, and culture: Deputy Editor at The FADER and Deputy Culture Editor at Vogue.com, with bylines at Vogue, The FADER, Pitchfork, ELLE, Dazed & Confused, New York Magazine, Vulture, the Village Voice, GQ, and The New York Times Style Magazine.
- Dan deliberately returns to his byline: 29 browser-history search hits, with a 2025 cluster of 10 around "alex frank mac miller / gq / malcolm" — the record reads it as proud-cousin interest and a recent re-engagement with a developmental-origin thread.
- Wrote the first-person essay on the funeral of Morley Frank — Dan's grandfather, Alex's "Uncle Morley" — in which the local Eat'n Park delivered boxes of "Frownie" cookies to the gathering, the inverted counterpart to the chain's Smiley Cookie, at the widow's arrangement. It is the only personal account of Morley anywhere in the corpus.
- Dan keeps the story live himself: logged 2025-09-03 in his life-events calendar — "eat n' park delivered frownie cookies to my granfather's funeral i swear to god lmao" — nearly three decades after the December 1998 funeral.
- Gaps: whether Alex's essay was published anywhere findable or shared privately within the family; no direct contact between Dan and Alex is documented beyond Dan reading and searching his work.

## History
- December 1998: Morley Frank's funeral in Hopwood, PA — the frownie-cookie gathering Alex's essay documents.
- 2025: Dan's search cluster around Alex's byline (Mac Miller / GQ); the 2025-09-03 log entry re-telling the cookie story unprompted.

## The relationship
- No documented correspondence or contact; the tie runs through shared bloodline and Dan's reader-side following of Alex's career. The frownie-cookie story is the family's one piece of jointly held mythology — Alex wrote it, Dan still quotes it.

## In common
- The paternal Frank line; Morley Frank; the frownie-cookie story as family texture.
- Music and culture journalism as a professional world adjacent to Dan's own.

## Open threads

## Strengthening
