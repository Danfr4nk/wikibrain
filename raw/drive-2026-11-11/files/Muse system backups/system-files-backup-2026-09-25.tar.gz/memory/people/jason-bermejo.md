---
display_name: Jason
first_name: Jason
last_name: Bermejo
summary: Full Sail-era friend (2008–) — the era's most durable friendship; the one who introduced Dan to Kid Cudi and DIY production.
rank: 16
updated: 2026-09-09
---

<!-- evidence: corpus-extract/agent-B-people.md (§ Jason Bermejo — Full Sail-era friend (2008–)) -->

# Jason

## Facts
- Jason Bermejo; Full Sail-era friend (2008–), "the era's most durable friendship."
- Formative music influence: introduced Dan to Kid Cudi and to DIY production.
- Still at message-volume peak in 2025 — the friendship hasn't decayed.

## History
- 2008: Full Sail. 2008–2025+: durable across the NYC years and the Uniontown return.

## The relationship
- The longest-running creative friendship: music taste and production talk across eighteen years without a rupture on record.

## In common
- Full Sail; Kid Cudi; DIY production; the cohort (Eric Jester, Jamie Mohler, Matt Dunn).

## Open threads

## Strengthening
