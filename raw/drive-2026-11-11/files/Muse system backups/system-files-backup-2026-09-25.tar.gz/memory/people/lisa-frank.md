---
display_name: Lisa Frank
first_name: Lisa
last_name: Frank
summary: Rick's partner since at least Dec 2015 (teacher); a decade of presence, written into the record only in Aug 2026.
rank: 13
updated: 2026-09-09
---

<!-- evidence: corpus-extract/agent-B-people.md (§ Lisa Frank — Rick's partner since at least Dec 2015) -->

# Lisa Frank

## Facts
- Lisa Frank; Rick's partner since at least December 2015; a teacher.
- "Frank" is the surname from household use — marriage unconfirmed.
- A decade of presence, only written into the wiki in August 2026.

## History
- Dec 2015–present: Rick's partner through the repair episodes and the current silence.

## The relationship
- Dan's connection to her runs entirely through Rick — she is the household he is currently silent toward.

## In common
- Rick; the Frank household.

## Open threads

## Strengthening
