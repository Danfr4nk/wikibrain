---
display_name: Emaly Minerd
first_name: Emaly
last_name: Minerd
summary: Three-burst relationship 2018–2020 — a drug-sourcing contact who kept trying to become a real friend; delivered the outside mirror 'you'll probably be dead in the next 15 years.'
rank: 43
updated: 2026-09-10
---

<!-- evidence: corpus-extract/agent-B-people.md (§ Emaly Minerd); corpus-extract/corpus_index.txt (wiki/people/emaly-minerd.md) -->

# Emaly Minerd

## Facts
- Emaly Minerd — three-burst relationship, 2018–2020: a 613-message intensive, an ugly 2019 revival, a 2020 coda.
- A drug-sourcing contact who kept trying to become a real friend; Dan pulled it back to "sex or nothing" each time.
- Delivered the corpus's outside mirror: "you'll probably be dead in the next 15 years."

## History
- 2018: the 613-message intensive.
- 2019: the ugly revival.
- 2020: the coda.

## The relationship
- A contact that kept reaching for friendship and kept getting refused it — the wiki's exhibit for the empty friend-who-isn't-a-hookup slot. Her mirror line is the one outside verdict Dan kept.

## In common
- The 2018 deep cycle; the arrangement years.

## Open threads

## Strengthening
