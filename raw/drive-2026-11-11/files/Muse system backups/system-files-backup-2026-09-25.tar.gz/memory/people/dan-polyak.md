---
display_name: Dan Polyak
first_name: Dan
last_name: Polyak
summary: Longtime friend — reintroduced Dan to Ally in Dec 2018; in Dan's 2012 self-enumerated core friend group.
rank: 17
updated: 2026-09-09
---

<!-- evidence: corpus-extract/agent-B-people.md (§ Dan Polyak — longtime friend; reintroduced Dan to Ally (Dec 2018)) -->

# Dan Polyak

## Facts
- Dan Polyak; longtime friend, in Dan's 2012 self-enumerated core friend group.
- Reintroduced Dan to Ally in December 2018 after a decade of one-sided idolization — Dan spoofed Polyak's number to reach her and paid Polyak $25 for the intro.
- Threatened to sue over the spoofed-number incident.

## History
- 2012: core group. Dec 2018: the Ally reintroduction and the spoofing fallout.

## The relationship
- Old friend and utility node: the reintroduction that made the Ally channel real again, at the cost of a lawsuit threat.

## In common
- Ally; the 2012 core friend group.

## Open threads

## Strengthening
