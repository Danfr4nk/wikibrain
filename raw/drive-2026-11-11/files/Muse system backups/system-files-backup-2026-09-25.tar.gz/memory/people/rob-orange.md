---
display_name: Rob Orange
first_name: Rob
last_name: Orange
summary: High-school-era friend — died Apr 2014 (suspected opioid OD, unconfirmed); the cohort loss that actually hurt.
rank: 36
updated: 2026-09-09
---

<!-- evidence: corpus-extract/agent-B-people.md (§ Rob Orange — high-school-era friend) -->

# Rob Orange

## Facts
- Rob Orange; high-school-era friend of Dan's.
- Died Apr 2014 — suspected opioid overdose, unconfirmed.
- Mourned years later by Dan and Jim Shaffer as the cohort loss that actually hurt.

## History
- High-school era: the friendship. Apr 2014: the death. Years later: the remembrance with Jim Shaffer.

## The relationship
- Gone before the record's dense years — what survives is the mourning: Dan kept naming him as the one that hurt.

## In common
- The childhood cohort; Jim Shaffer; Lauryn Ashly, who shared the real-time grief in Apr 2014.

## Open threads

## Strengthening
