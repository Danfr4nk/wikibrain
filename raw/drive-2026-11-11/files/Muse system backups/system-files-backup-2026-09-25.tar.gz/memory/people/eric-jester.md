---
display_name: Eric Jester
first_name: Eric
last_name: Jester
summary: Full Sail film-school friend — one of two people whose music taste Dan defers to.
rank: 26
updated: 2026-09-09
---

<!-- evidence: corpus-extract/agent-B-people.md (§ Eric Jester — Full Sail film-school friend) -->

# Eric Jester

## Facts
- Eric Jester; Full Sail film-school friend.
- Dense 2009–13 tweet banter, decaying to decade-spanning check-ins.
- One of two people whose music taste Dan defers to.
- The annual $5 birthday Venmo bit runs through him to Jamie Mohler and Matt Dunn.

## History
- 2009–2013: the dense-banquer years. Since: long-interval check-ins that never died.

## The relationship
- A low-frequency, high-trust peer — the one whose taste Dan respects enough to defer on music.

## In common
- The Full Sail cohort (Jamie Mohler, Matt Dunn, Jason Bermejo); the $5 birthday bit.

## Open threads

## Strengthening
