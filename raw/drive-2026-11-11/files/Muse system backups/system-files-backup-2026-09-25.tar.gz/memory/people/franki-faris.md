---
display_name: Franki Faris
first_name: Franki
last_name: Faris
summary: July 2013 interlude that ended the Alexis relationship — discovered ten minutes in; cocaine, fireworks, collapse within days.
rank: 45
updated: 2026-09-10
---

<!-- evidence: corpus-extract/agent-B-people.md (§ Franki Faris); corpus-extract/corpus_index.txt (wiki/people/franki-faris.md; wiki/timeline/events/franki-fireworks-day-2013.md) -->

# Franki Faris

## Facts
- Franki Faris — the July 2013 interlude that ended the Alexis relationship.
- Alexis discovered it ten minutes in; cocaine, fireworks, collapse within days.

## History
- July 2013: the interlude; its discovery ended the six-year Alexis relationship's final stretch.

## The relationship
- A brief encounter with outsized consequence — it detonated the Alexis relationship rather than becoming one.

## In common
- Alexis Armel; the summer of 2013.

## Open threads

## Strengthening
