---
display_name: Zac Shumar
first_name: Zac
last_name: Shumar
summary: Named in a thread Dan surfaced Sep 12, 2026 — shown as Alexis's boyfriend, living in the house, telling Dan he wanted Annie himself; tied to the Feb 2017 house-fire arrest behind Alexis's prison term.
rank: 55
updated: 2026-09-13
---

<!-- evidence: memory://md:memory/2026-09-13.md:43 (spelling correction; message:a75671ca-f2c8-481c-8735-219e5031ac6a); window 2026-09-12 (Zac Shumar thread surfaced during raw-sources review); ~/memory/people/alexis-armel.md (Feb 2017 house-fire arrest) -->

# Zac Shumar

## Facts
- Name spelling confirmed by Dan's one-line correction in the 2026-09-12 session: "Zac Shumar".
- Tied to the February 2017 house-fire arrest that led to Alexis Armel's prison term (per the durable Alexis page).
- A message thread Dan surfaced on 2026-09-12 shows Zac as Alexis's boyfriend, living in the house, telling Dan directly that he wanted Annie himself. Dan's in-session correction addressed the spelling only; the thread's date is unverified, so whether it is recent or historical is open.

## History
- Feb 2017: the house-fire arrest — Alexis's prison term follows.
- 2026-09-12: Dan surfaced the Zac Shumar thread during the raw-sources review.

## The relationship
- Dan has not named this relationship in his own words; the observed tie is direct message contact — Zac addressed Dan himself about wanting Annie — running through Alexis and Annie. Recorded as observed contact, the nature left unstated.

## In common
- Alexis Armel; Annie Ulmer (the object of the stated want, not a known meeting).

## Open threads
- [ ] Date of the surfaced Zac Shumar thread — recent or historical.
- [ ] Zac's exact role in the Feb 2017 house-fire arrest.

## Strengthening
