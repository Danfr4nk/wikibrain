---
display_name: RJ Ritchey
first_name: RJ
last_name: Ritchey
summary: Fayette County golfer from the caddie world — Dan's own word is "best friend" (2026-09-09); visited Dan and Annie in Manhattan in July 2019; eight unread 2022–23 messages are the last trace.
rank: 75
updated: 2026-09-22
---

<!-- evidence: wiki/people/rj-ritchey.md (rewritten 2026-09-21, pushed Danfr4nk/wikibrain@7f423ac); memory://md:memory/2026-09-21.md:1363 ("he's going to see RJ and wants to show it"); Dan's shorthand "best friend" 2026-09-09 -->

# RJ Ritchey

## Facts
- RJ Ritchey ("Robert Ritchey" appears as an unconfirmed alias); Fayette County golfer from the caddie world — worked at the Maywood on reduced hours while waiting to hear back from Nemacolin HR; films his swing in slow motion and shows his dad.
- Dan's own one-word shorthand for him, stated 2026-09-09: "best friend." The archive disagrees on the shape: 1,103 iMessages (2019-02-12 → 2020-05-19), 426 Facebook messages — peripheral-tier by volume. Both facts true at once; closeness is not message count.
- Feb 2019: invited into Dan and Annie's non-monogamy arrangement; said he wasn't comfortable once it stopped being hypothetical and withdrew. On Feb 19 the arrangement was closed by two "It's over" messages typed by Annie from Dan's phone — a reassurance, not a rejection — and the friendship did not end.
- July 5–8, 2019: visited Dan and Annie in Manhattan — bus from Pittsburgh, live updates as the skyline came through clouds; Dan booked the ticket (RJ asked rather than reimburse — he had no money and said so); Teddy vouched to an anxious RJ that Dan wouldn't strand him with a one-way ticket.
- Feb 7–8, 2020: Dan's Chapo evangelism target ("there's a podcast called 'chapo trap house'"). On this thread Dan wrote the one first-person political grievance in fifteen years of messages: "the doctor thing is a really big thing for me...like, there's no reason that 50,000 people die a year because they don't have insurance" (2020-02-07 21:17 EST).
- 2021–22: the Facebook thread stays alive — country-club talk, slow-motion footage, the ask that Dan get him in the door at Laurel Valley via Dan's father. 2022–23: "RJ Ritchey 8 new msgs" unread in Messenger, content not held — the last trace, one-directional.
- 2026-09-21: Dan commissioned a rewrite of RJ's wiki article and pushed it same-turn — he's going to see RJ and wants to show it.

## History
- Pre-2019: known through the Fayette County golf/caddie circle; knows Annie, Teddy, Jack Rusko.
- 2019-02-12: iMessage thread opens mid-arrangement; RJ's approach, discomfort, and withdrawal; asks that no video go online.
- 2019-02-19: the two "It's over" messages, typed by Annie from Dan's handle.
- 2019-06: visit logistics — reduced Maywood hours, Nemacolin HR wait, asks Dan to book the bus ticket; combative over the one-way worry, then apologises.
- 2019-07-05 → 08: the Manhattan visit; wants skating video for his mother.
- 2020-02-07/08: the healthcare grievance sentence and the Chapo pitch, six months before Dan's own conversion narration.
- 2020-05-19: iMessage thread ends; cause not recorded.
- 2021–22: Facebook thread — golf, footage for his dad, Laurel Valley ask, politics exchange where neither converts the other.
- 2022–23: eight unread Messenger messages; content not held.
- 2026-09-09: Dan's shorthand — "best friend."
- 2026-09-21: wiki article rewritten with the human-story lead for RJ-as-reader, pushed same-turn.

## The relationship
- Dan named it: "best friend" (his words, 2026-09-09). The shape is low-volume and long-durability — hundreds of messages, not tens of thousands, across six-plus years.
- Survived a real boundary: the Feb 2019 arrangement withdrawal was absorbed without rupture, unusual in this archive — most ruptures resume in under a minute or never resolve.
- The politics channel is where Dan was sincere rather than analytical: RJ, the conspiratorial golf-circle friend who disagreed, got the only first-person grievance in the record. Neither converted the other; neither stopped talking.
- Current state: one-directional since 2022 — eight unread messages from him, nothing back. Dan is about to see him again.

## In common
- Fayette County golf and the caddie world (Nemacolin, the Maywood, Laurel Valley); Jack Rusko and Marc Charles are the same cohort.
- The 2020 left-turn politics — Chapo evangelism both directions, positions intact.
- Teddy — the thread's quiet structural fact, vouching in 2019, missed as infrastructure in 2020.

## Open threads
- [ ] Dan plans to see RJ and show him the rewritten wiki article (commissioned 2026-09-21).

## Strengthening
