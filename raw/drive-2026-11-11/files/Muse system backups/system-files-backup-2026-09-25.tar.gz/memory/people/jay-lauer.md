---
display_name: Jay Lauer
first_name: Jay
last_name: Lauer
summary: Friend and reciprocal suboxone/cash trading peer — died of a heroin OD ~Apr 11, 2017, the network's only documented fatality.
rank: 35
updated: 2026-09-09
---

<!-- evidence: corpus-extract/agent-B-people.md (§ Jay Lauer — friend and reciprocal trading peer); memory://md:memory/2026-09-09.md (ellen-ulmer thread) -->

# Jay Lauer

## Facts
- Jay Lauer; friend and reciprocal suboxone/cash trading peer of Dan's.
- Died of a heroin overdose ~Apr 11, 2017 — the network's only documented fatality.
- His death opened the Ellen Ulmer thread: Betherin Mechling (his fiancée) returned his ring weeks before, and the grief line runs through Ellen.

## History
- Apr 2017: the overdose and the opening of the Ellen thread — the record's one documented death in the network.

## The relationship
- A peer in the trade-and-use years; the record holds him as a friend, and his death as the event that pulled Ellen Ulmer into Dan's graph.

## In common
- Ellen Ulmer; Betherin Mechling; the Apr 2017 grief.

## Open threads

## Strengthening
