---
display_name: Ally
first_name: Alexandra
last_name: Lubin
nickname: Ally
summary: 18-year attachment never met in person; first outsider to read his wiki (Aug 2026); severed in the Sep 7–8 blowup, final Sep 20 coda — she accused him of harassing texts, he cut her off.
rank: 3
updated: 2026-09-21
---

<!-- evidence: memory://md:MEMORY.md:10; memory://md:memory/2026-09-09.md:187; corpus-extract/agent-B-people.md (§ Ally Lubin); windows 2026-09-11/12; memory://md:MEMORY.md (Ally thread Sep 7–8 + Sep 20 coda); window 2026-09-21T03:38–04:01 (video parts 1–4 transcription; wiki rewrite cb9b89b, message:assistant-msg-012db7af) -->

# Ally

## Facts
- Alexandra Lubin, b. June 26, 1990; remote STEM professional in Charlotte, NC; tested ENTP-T (2026).
- 18-year attachment; Dan has never met her in person.
- First contact: May 20, 2011 — a decade of one-sided idolization, then reintroduced to Dan by Dan Polyak in December 2018 (Dan paid Polyak $25 for the intro; he had spoofed Polyak's number to reach her).
- 3,140 iMessages (count corrected in the 2026-09-21 wiki rewrite, superseding the earlier 1,987 figure); Dan sent her $2,100 in the Aug–Oct 2019 crisis window.
- Messenger channel: the thread there ends with her line "Delete this" (Nov 2024).
- The channel ran concurrently with the Annie relationship the whole time.
- In August 2026 she became the first person outside Dan ever to read the wiki (her joke about it got written into the page as fact).
- Aug 18–19, 2026 intensity burst: she read the wiki live — "I read May–August," "They kind of gagged," link-checking her own pages — while Dan sent her 419 messages on the 19th alone, the same night he declared "goodbye forever" to Annie. The slot transfer, attempted in real time (window 2026-09-11T21:38).
- Her reads on him are sharper than his own: "I don't think anyone will ever love me as much as you love Annie — but I can't tell if it's actually love or fear and codependency." "You say the same thing to every girl." "You just love bomb." "Most of her texts are just asking for drugs but Eggie is a cute nickname." "It was just weird to see you like spilling your guts and she was like ok I have $80." She named the price when he floated settling down: "Well first you'd have to be obsessed with me again." And the cost of being archived: "if someone ever archived my texts I'd kill myself."
- The "silence since Aug 19" story was wrong: her inbound texts Aug 30–Sep 2 (transcribed 2026-09-21 from her screen-recordings) show continuous contact; his Mac chat.db had been missing her entire inbound side for those days. The Snapchat "channel migration" framing was overstated — both channels were live.
- Sep 1–2 warm stretch (part 2): work venting — collections she wasn't supposed to do, the "bone collector" crash-out; Wayne, her cash/collections manager ($273k invoice); her Boca HS story (Mr. Hill was the dean; wpbf/Sun Sentinel pieces on the swim-coach investigations). His tenderness on record too: "fire hose of dopamine that I get about you," "most wonderful thing / Possibly ever / Certainly the most wonderful since antiquity," "my undying aspiration to ring up that finger," "I love you lol." Dan's Annie monologue to her as the audience — "biggest lame," the "chasm" of intellect/taste/human being-ness, "anti mbti type. ESFJ," "paw patrol of it all," "Could she spell pharaoh" — with her pushback on record: "You say that NOW with hindsight bias and hate in your heart" / "you also said she was perfect for a literal decade."
- Mouth abscess → urgent care → dentist (her dentist jabs = what he calls "insulting my fucking teeth"); the Eddie Schoeck GoFundMe (~$11k, sepsis 2024) was a flashpoint (she brought it up, he said "can't believe how many people donated," she read it as making it about him).
- Sep 5 door incident (Dan's account): 10 minutes of midday pounding on his door; he unblocked Annie to check, got "call 911" within 30 seconds; the pounder was Jerel, who had just tried to fight Annie's dad; Dan reblocked her, told Suz, and did not call police. The factual core of the Sep 7 fight ("You love the attention" / "trauma dumping" dispute).
- Sep 7 6:40–10:10 PM blowup (video part 4, transcribed 2026-09-21): GitHub suspended (hentai decor + API harness); Dan placed a moratorium: never update ally-lubin.md. Her charges: "It's not unbiased when you're PROMPT INJECTING and building a narrative" / "You literally described why people go to therapy." His defense: archival tool built to TEST assumptions against raw data. The block dispute on video: Sep 7, her "WELL YES YOU DID" vs his "I DIDNT IN THR FIRST PLACE LMAO" / "I swear I didn't"; Sep 8 12:36 AM inversion: "I already blocked you on everything and you're still texting." Ended: his "Grow up. Bye" / her "Twin is crazy lol you're actually mental" / his "Please Disappear."
- Sep 20 coda: she received harassing texts ("You're in unit 306, correct?", "Just called and you picked up"), accused Dan ("Dan Polyak clocked that it was probably you"); he denied and pasted a (336) 209-1951 lookup (Oakes, Asheboro NC) — wrong number, his own transposed-digit catch: the real number (336) 209-1591 traces to SARA ANNE OWEN, 49, Round Rock TX per FOREWARN — 336 is a Greensboro NC area code on a Texas address, so a ported/VoIP lead, not an ID.
- Sep 21 wiki rewrite (commit cb9b89b): full September arc, accusation section with the corrected lookup, corrected iMessage count; her wiki page status flipped to severed; Dan's Sep 7 moratorium on the page was lifted.

## History
- 2011: first contact. 2018: Polyak reintroduction after a decade of one-sided idolization. 2019: crisis-window money ($2,100). 2026: first outside wiki read (Aug), intensity burst and live audition (Aug 18–19), warm stretch (Sep 1–2), block dispute ignites (Sep 4), terminal blowup (Sep 7–8), harassing-texts coda and severance (Sep 20).

## The relationship
- The one tie that has never been a cohabitation or an arrangement: an 18-year attachment conducted almost entirely remotely.
- The confidant slot is structural — "someone has to be my confidant and be the true person who sees backstage" — and cannot be emptied, only reassigned. Aug 18–19 he tried to transfer it to Ally in real time; she saw the audition happening and walked. Her verdict stands as the page's cleanest outside read of the whole system: "I don't think anyone will ever love me as much as you love Annie — but I can't tell if it's actually love or fear and codependency."
- What broke it: he used her as the audience for processing Annie — her Sep 1 pushback is the diagnosis on the record ("hindsight bias and hate in your heart," "you also said she was perfect for a literal decade") — then the wiki-as-blackmail fight and the block dispute detonated Sep 7. The tape shows genuine tenderness and genuine harshness in the same stretch; she answered the monologues, not the sweetness.
- The block fight was mutual confusion, not delusion on either side: Sep 7 both accusing and denying, Sep 8 the inversion. The Sep 20 accusation ended it: her "Dan Polyak clocked that it was probably you," his denial and the corrected lookup lead, then nothing. His standing word is "Please Disappear"; the wiki page status is severed; Dan's own Sep 7 moratorium on the page was lifted Sep 21.

## In common
- The wiki itself — she is its first outside reader; the long shared message history; her directness.

## Open threads
- [x] Trust: she said she still didn't trust him — moot after the Sep 7–8 severance.
- [x] The confidant slot: transfer attempted Aug 18–19; she walked; the Sep 7–8 blowup ended it.
- [x] Her instruction to Dan: text Rick — acted on Sep 1, 2026 (first Dan→Rick message since Feb 2025).
- [x] Her other standing instruction to Dan: stop isolating — moot after severance.
- [x] The harassing-texter lead: FOREWARN SARA ANNE OWEN (49), Round Rock TX — a lead, not an ID; the accusation ended the thread.

## Strengthening
