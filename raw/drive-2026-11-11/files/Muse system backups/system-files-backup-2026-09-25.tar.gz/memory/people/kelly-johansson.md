---
display_name: Kelly Johansson
first_name: Kelly
last_name: Johansson
summary: Escort Dan booked for the fall-2019 threesome with Annie — the last event in his adjudicated G/G sequence; no other detail recorded.
rank: 72
updated: 2026-09-19
---

<!-- evidence: memory://md:MEMORY.md:27 (Sep 18 G/G sequence: fall Kelly Johansson booking); memory://md:memory/2026-09-18.md:1435 (adjudicated canon, event 9: "fall 2019 — Kelly Johansson threesome booking"; "those are, i believe, all of annie's lesbian experiences"); memory://md:memory/2026-09-18.md:1366 ("Kelly Johannson, second escort threesome") -->

# Kelly Johansson

## Facts
- Kelly Johansson: the escort Dan booked for a fall-2019 threesome with Annie.
- In Dan's adjudicated canonical history of Annie's girl/girl experiences (2026-09-18), this booking is the final event — event (9) of the sequence, after Trinity (Mar 2019), the Shelbie threesomes (Apr 2019), the Jared/Tricia booking (Jun 2019), and Skirt Club (Jul 18–19, 2019). Dan closed the list: "those are, i believe, all of annie's lesbian experiences."
- His 2026-09-18 seven-event account also calls it the "second escort threesome" — the second after the Trinity booking.
- The spelling is unconfirmed: his testimony records it as both "Kelly Johansson" and "Kelly Johannson"; no other identifying detail (no location, no agency, no further contact) is recorded.
- Dan has not named the relationship; the tie is the single documented booking. The nature is left unstated.

## History
- 2026-09-18: in held testimony adjudicating Annie's girl/girl history, Dan named the fall-2019 Kelly Johansson booking as the last of the canonical events.

## The relationship
- Transactional, single-episode: a booked threesome in fall 2019 involving Dan and Annie. Dan has not named the relationship in his own words; record the observed contact and leave the nature unstated.

## In common
- [Annie Ulmer](annie-ulmer.md) — the fall-2019 threesome booking.

## Open threads

## Strengthening
