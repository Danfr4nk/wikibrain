---
display_name: Danny Matthews
first_name: Danny
last_name: Matthews
summary: Annie's pre-NYC sexual partner; the only man Dan says he finds hot — known through watching them together, the Nov 2024 thread, and a role-reversal fantasy.
rank: 54
updated: 2026-09-12
---

<!-- evidence: MEMORY.md#L69,L71,L74; memory/2026-09-11.md#L1060-L1065,L1083-L1085; window 2026-09-12 (gooner-thread closure) -->

# Danny Matthews

## Facts
- Full name as Dan gave it: Danny Matthews. Savannah, Georgia — a field training rep, ~4 years there (per Dan's 2026-09-11 account).
- Annie's pre-NYC sexual partner. Dan describes him as the man who "fucked Annie the most and best" — Dan's words; his mythologizing (see the data-grounded read below).
- Dan says Danny is the only man he finds hot, while allowing the attraction may derive from Danny's sexual history with Annie rather than independent attraction.
- Dan never directly touched Danny — emphasized by Dan himself.
- Photographed evidence Dan shared: heavyset with a belly (bed photo); the explicit close-up shows an average-sized penis, the visible semen trail the conspicuous feature — not unusual dimensions. This contrasts with Dan's "perfect" framing.

## History
- Pre-NYC era: Danny's sexual relationship with Annie; Dan watched them together and loved it. Dan recalled a naked massage between them whose slow buildup and passion he found substantially hotter than watching intercourse.
- After Danny had sex with Annie on one occasion, Annie let Dan orally remove Danny's semen from her (Dan's 2026-09-11 disclosure).
- Nov 2024: Dan shared a screen recording of an iMessage thread — Annie (blue bubbles) sexting Danny explicitly, sending nude mirror selfies/photos and videos, inviting him to NYC for a long weekend ("with me on top"); a flight search Savannah→Newark under $100. "We have spoken about you often danny" and "Noooo we are staying in ny" indicate Dan's awareness and involvement. Dan framed it as arranged for his birthday (Nov 1, 2024); the thread itself has Annie saying her birthday is on Thanksgiving (Nov 28, 2024) — possible date displacement, flagged. Whether the trip happened was not established.
- 2026-09-11: Dan disclosed all of the above in a sexual-disclosure thread (later closed; he intended to delete the chat after useful facts were retained — deletion not verified), including the fantasy structure and the want-vs-let correction below.

## The relationship
- Dan has named no relationship with Danny — not a friend, not a contact; no direct Dan↔Danny contact is evidenced. The tie runs entirely through Annie: her former lover, an object of Dan's stated attraction.
- Fantasy structure, in Dan's account: role-reversal — Annie occupying Dan's former watcher seat while Dan receives Danny (massage/grab/tickle/lick sequence), i.e., taking her place in the scene he found hottest to watch.
- Collecting-her-experiences pattern: every fantasy item is something Dan first watched Annie receive from Danny — the desire reproduces her experiences rather than originating independently.
- Want vs let — Dan's own correction: not "I would let him" but "I would WANT him to" (Danny ejaculating on his face) — appetite, not permission; hedged with "I think" seconds later (the hedge-on-record pattern).
- Data-grounded read, per his governance rule: documented photos override the mythologizing. "Fucked her best" is Dan's curation; what the data shows is chemistry plus Dan's framing, with a mimetic-desire component (hot because she made him hot).

## In common
- [Annie](annie-ulmer.md) — the entire tie runs through her; Dan's stated attraction is to the man as Annie's lover.
- The Savannah→NYC geography of the Nov 2024 thread.

## Open threads
- [ ] Whether the proposed Nov 2024 NYC trip happened — outcome never established in the thread review.

## Strengthening
