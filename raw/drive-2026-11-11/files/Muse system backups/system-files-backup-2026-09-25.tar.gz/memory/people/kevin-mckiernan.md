---
display_name: Kevin McKiernan
first_name: Kevin
last_name: McKiernan
summary: President of Creative License, Dan's 2011–12 boss — the whistleblower dispute's other side.
rank: 33
updated: 2026-09-09
---

<!-- evidence: corpus-extract/agent-B-people.md (§ Kevin McKiernan — president of Creative License); memory://md:MEMORY.md:12 -->

# Kevin McKiernan

## Facts
- Kevin McKiernan; president of Creative License, Dan's boss in 2011–12.
- Per the record: used Dan's account to pressure ex-employees, altered intern contracts, and backed a false notarized LinkedIn claim in retaliation for Dan's whistleblowing.
- Dan exited Creative License with a whistleblower dispute against him.

## History
- 2011–12: the Creative License employment and the whistleblowing exit.

## The relationship
- The adversarial boss — the case Dan's authority-skepticism was built on, documented from his side of the dispute.

## In common
- Creative License: Katherine Palakovich, Marty Jackson, Renae Holland.

## Open threads

## Strengthening
