---
display_name: Ismaila Barry
first_name: Ismaila
last_name: Barry
nickname: DJ
summary: Senegalese busser-turned-server at Au Za'atar — the record counts him among Dan's best friends.
rank: 24
updated: 2026-09-09
---

<!-- evidence: corpus-extract/agent-B-people.md (§ Ismaila Barry ("DJ") — Senegalese busser-turned-server) -->

# Ismaila Barry

## Facts
- Ismaila Barry ("DJ"); Senegalese busser-turned-server at Au Za'atar.
- Made the same busser-to-server climb as Dan.
- The record counts him among Dan's best friends.

## History
- Au Za'atar years (2021–2024): parallel climb from busser to server; a peer friendship formed on the floor.

## The relationship
- A genuine peer friendship — one of the few the record ranks that high — built on the shared climb rather than history.

## In common
- Au Za'atar: Dimitri, Tarik Fallous, Manuel; the restaurant floor.

## Open threads

## Strengthening
