---
display_name: Felipe
first_name: Felipe
summary: Au Za'atar Midtown server — Dan's own words, 'unbelievably gay Colombian bff'; the friendship ended with the job (his confirmation, Jul 2026).
rank: 65
updated: 2026-09-16
---

<!-- evidence: wiki/people/felipe.md (stable 2026-07-14 — Dan's "unbelievably gay Colombian bff", glass-door first day, 77 messages Aug 2023–Aug 2024, contact ended with the job, surname unknown); wiki/people/valeria-iglesias-cid.md (workplace-cast section — judged "a diva" by both Dan and Valeria); memory/2026-09-12.md#L317 (Andrés Felipe — 993 Facebook messages, fifth-largest recovered thread); window 2026-09-16T22:26–23:24 (cliff-note list on the share-side copy of Valeria's article — message:assistant-msg-55831c4e-64d3-4a7b-9bfd-670b47dbe29e) -->

# Felipe

## Facts
- Au Za'atar Midtown server; Dan's own words (per the wiki): his "unbelievably gay Colombian bff."
- Announced himself on day one by shattering the old glass door with the metal legs of a table during the two-hour shed build.
- 77 direct messages at +13477913706, Aug 2023–Aug 2024 — the Shed era's tail.
- In Valeria's Instagram thread he is part of the workplace cast — judged "a diva" by both Dan and Valeria.
- Surname unknown to Dan; his tenure dates at the restaurant unrecorded.
- A Facebook thread under the handle "Andrés Felipe" holds 993 messages (Sep 2026 re-parse, the fifth-largest recovered thread) — possibly the same person, unconfirmed.

## History
- Joined Au Za'atar Midtown as a server (first contact in the record: Aug 11, 2023); the direct thread runs through Aug 2024.
- Jul 14, 2026: Dan confirmed the contact did not survive past the Au Za'atar job — hasn't spoken to Felipe since; an earlier "friendship outlived the job" framing was retracted as wrong.
- Sep 16, 2026: named among the nine cliff notes on the share-side copy of Valeria's wiki article Dan had made for her.

## The relationship
- A Shed-era coworker friendship Dan once called "bff" — era-bounded, warm in the telling, and finished when the job ended. No contact since Aug 2024, by Dan's own confirmation.

## In common
- Au Za'atar Midtown; the Shed-era crew — Dimitri, DJ, Tarik, Manuel, Valeria.

## Open threads
- [ ] Whether the 993-message "Andrés Felipe" Facebook thread is the same person — unverified.

## Strengthening
