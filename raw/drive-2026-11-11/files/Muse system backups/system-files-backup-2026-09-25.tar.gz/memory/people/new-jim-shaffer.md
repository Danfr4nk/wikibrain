---
display_name: Jim Shaffer
first_name: Jim
last_name: Shaffer
nickname: New Jim
summary: Wealthy childhood friend — "longest standing friend on the planet" in the record.
rank: 28
updated: 2026-09-09
---

<!-- evidence: corpus-extract/agent-B-people.md (§ New Jim Shaffer — wealthy childhood friend) -->

# Jim Shaffer

## Facts
- Jim Shaffer ("New Jim"); wealthy childhood friend, splits time between FL and PA.
- Called "longest standing friend on the planet" in the record.
- 894 messages, 2018–19; judgment-free about the arrangement.
- Carried the Rob Orange and Steve Kezmarsky remembrances with Dan.

## History
- Childhood onward: the longest-standing friendship in the record; an intense 2018–19 message window, then the usual dormancy.

## The relationship
- High-signal, low-frequency: the oldest friend who showed up in the record's hardest moments without judgment.

## In common
- The childhood cohort; Rob Orange's memory; Steve Kezmarsky.

## Open threads

## Strengthening
