---
display_name: Bobby Cole
first_name: Bobby
last_name: Cole
summary: Nine-year Facebook friend (2013–2022) bonded over Opie & Anthony / Ron & Fez; the record's only witness to Dan's 2019 open-mic stand-up attempt.
rank: 53
updated: 2026-09-10
---

<!-- evidence: corpus-extract/agent-B-people.md (§ Bobby Cole); corpus-extract/corpus_index.txt (wiki/people/bobby-cole.md) -->

# Bobby Cole

## Facts
- Bobby Cole — nine-year Facebook friendship, 2013–2022.
- Built on Opie & Anthony / Ron & Fez fandom.
- The sole evidence of Dan's 2019 open-mic stand-up attempt and a SiriusXM job application.

## History
- 2013–2022: the nine-year Facebook friendship.
- 2019: Dan's open-mic stand-up attempt, witnessed only in this thread.

## The relationship
- A fandom-built friendship — comedy radio as the entire shared ground, durable for nine years without ever needing more.

## In common
- Opie & Anthony / Ron & Fez; the 2019 comedy itch.

## Open threads

## Strengthening
