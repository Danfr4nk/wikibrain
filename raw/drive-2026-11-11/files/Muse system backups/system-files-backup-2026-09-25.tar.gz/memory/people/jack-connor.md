---
display_name: Jack Connor
first_name: Jack
last_name: Connor
summary: Fayette County defense lawyer (2015–16) who got Dan ARD against a DA policy categorically excluding cocaine charges — Dan's 'absolute LEGEND of a lawyer.'
rank: 49
updated: 2026-09-10
---

<!-- evidence: corpus-extract/agent-B-people.md (§ Jack Connor); corpus-extract/corpus_index.txt (wiki/people/jack-connor.md); memory://md:MEMORY.md:16 (2015 arrest → ARD) -->

# Jack Connor

## Facts
- Jack Connor — Fayette County defense lawyer, 2015–16.
- Got Dan ARD on the February 2015 possession arrest, against a DA policy that categorically excluded cocaine charges.
- Dan's own words: "my fucking absolute LEGEND of a lawyer."

## History
- February 2015: the possession arrest.
- 2015–16: Connor's defense; ARD granted February 2016.

## The relationship
- A professional relationship with genuine gratitude attached — the lawyer who beat the policy, remembered a decade later in superlatives.

## In common
- The 2015 arrest and ARD; Fayette County.

## Open threads

## Strengthening
