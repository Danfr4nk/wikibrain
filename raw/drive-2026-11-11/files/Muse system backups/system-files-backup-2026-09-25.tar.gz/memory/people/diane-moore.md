---
display_name: Diane
first_name: Rebecca
last_name: Moore
nickname: Diane
summary: Dan's maternal grandmother — Fran's only child; barred Dan from Fran's house during the 2018 death vigil; the hostile pole of the maternal line.
rank: 14
updated: 2026-09-11
---

<!-- evidence: corpus-extract/agent-B-people.md (§ Diane Moore (Rebecca Diane Van Voorhis) — maternal grandmother, b. 1939); window 2026-09-11 (2017 Palm City letters, assistant-msg-99ba0352) -->

# Diane

## Facts
- Rebecca Diane Van Voorhis ("Diane Moore"), b. 1939; Dan's maternal grandmother — Fran's only child.
- Served Dan the 2018 trespass letter barring him from Fran's house while Fran was dying; Dan believes the letter was drafted by her second husband Dave Moore, who acted as her proxy to hospital social workers during the vigil.
- 2017: pressed Fran to sell the Palm City, Florida house — an August 2017 letter (realtor lined up, Fred Adams already nodding along); by November 2017 the posture had shifted to a $20,000 loan against Fran's inheritance, Fred Adams formally cc'd, with Fran's shoulder surgery and the canceled Palm City trip in the same letter. Palm City's first appearance in the record (letters surfaced 2026-09-11).
- The hostile pole of the maternal line.

## History
- 2017: the Palm City letters — sale pressure in August, the inheritance-loan posture by November.
- 2018: the death-vigil conflict — trespass letter, the vigil's central family rupture.

## The relationship
- Adversarial and arm's-length: the one family member whose posture toward Dan is documented hostility rather than distance.

## In common
- Fran — the person they both claim, from opposite sides.

## Open threads

## Strengthening
