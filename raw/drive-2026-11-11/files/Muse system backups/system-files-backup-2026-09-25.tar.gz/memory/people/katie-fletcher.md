---
display_name: Katie Fletcher
first_name: Katie
last_name: Fletcher
summary: Aug 2013 fling from six tweets over 11 days (the "Vase" incident, ketamine at the Oddball Comedy Fest); bridge inside the Alexis off-interval; now a Goon Club example-roll figure.
rank: 86
updated: 2026-09-24
---

<!-- evidence: memory/2026-09-16.md#L917 (six tweets, Vase, Oddball 8/30/13, Alexis off-interval bridge); memory/2026-09-16.md#L595 (Vase + Oddball recap); memory/2026-09-16.md#L911 (Goon Club intro, five women); memory/2026-09-15.md#L1666 (example roll, not members — live-in harem roster correction); memory/2026-09-23.md#L1171 (Mon 9/21 schedule — both: Katie, venue rule); memory/2026-09-23.md#L1075, L1671, L1432 (fictional "sister Katie" disambiguation — NOT this Katie Fletcher) -->

# Katie Fletcher

## Facts
- Katie Fletcher, August 2013: a brief involvement recorded across six tweets over 11 days.
- The "Vase" incident: a condom was lost inside her; he stayed silent for two months; she discovered and removed it herself while on vacation.
- August 30, 2013: ketamine at the Oddball Comedy Fest (Chappelle's H-Bomb set); he lost his car keys in the gravel lot.
- Memory places her as a bridge inside the Alexis off-interval — Alexis is named again September 8.
- September 16, 2026: Dan named Katie one of the five women in the Goon Club's dossier/roster project (Annie, Alexis, Shelbie, Trinity, Katie), with authorized quasi-fiction extrapolation for the bios.
- September 15, 2026 correction stands: the five women are example-roll / fantasy scene subjects, not club members — "the club's quasi-fictional full-time live-in harem."
- September 23, 2026 schedule: Monday 9/21 ran as "both: Katie" — all contact routed through her (the venue rule).
- Do not confuse her with the fictional "sister Katie" — Sammy's fictional younger sister from Dan's September 23, 2026 dream-fantasy. Dan clarified explicitly that figure is NOT the real Katie Fletcher.

## History
- August 2013: the six-tweet, 11-day arc — the Vase incident, the Oddball Comedy Fest night, and the bridge position in the Alexis off-interval.
- September 16, 2026: resurrected as example-roll casting in the Goon Club's charter/roster work.
- September 23, 2026: given the Monday slot on the weekly schedule — both Dan and Sammy, "all contact through her."

## The relationship
Brief and dated: a real 2013 encounter preserved almost entirely in the tweet record, with two signature incidents (the Vase, the Oddball night) doing all the narrative work. Thirteen years later she was pulled back into Dan's frame as a Goon Club example-roll figure — remembered and scheduled, not re-contacted. The tie is archival now, and the fiction-firewall around the same name shows Dan treating the real record and the fantasy casting as two separate things.

## In common
- Annie Ulmer, Alexis Armel, Shelbie Breakiron, Trinity St. Clair — the Goon Club example roll.
- The August 2013 era and the Alexis off-interval.

## Open threads

## Strengthening
