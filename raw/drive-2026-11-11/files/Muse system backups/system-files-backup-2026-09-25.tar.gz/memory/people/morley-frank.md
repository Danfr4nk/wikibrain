---
display_name: Morley Frank
first_name: Morley
last_name: Frank
summary: Dan's paternal grandfather (d. ~1996–97); his Seattle-and-back arc is the family's leave-and-return template, known through cousin Alex Frank's funeral essay — the 'Frownie cookie' story.
rank: 38
updated: 2026-09-10
---

<!-- evidence: corpus-extract/agent-B-people.md (§ Morley Jay Frank); corpus-extract/corpus_index.txt (wiki/people/morley-frank.md); wiki/people/alex-frank.md (frownie-cookie essay) -->

# Morley Frank

## Facts
- Morley Jay Frank — Dan's paternal grandfather.
- Died ~1996–97, when Dan was a child.
- His Seattle-and-back arc is the family's leave-and-return template.
- Known to Dan almost entirely through cousin Alex Frank's funeral essay — the "Frownie cookie" story, which Dan still quotes.

## History
- ~1996–97: died; Alex Frank's essay on the funeral became the family's frownie-cookie story.

## The relationship
- A grandfather Dan barely got to know in life, carried forward as a family story — the leave-and-return template the Franks measure themselves against.

## In common
- The Frank family; Alex Frank's essay on his funeral.

## Open threads

## Strengthening
