---
updated: 2026-09-19
entries: 2
---

# Shopping Profile

## Checkout
- Never buys credits or spends on his accounts without his explicit say-so each time — stated 2026-09-17/18; it overrides the standing ecosystem grant for spending.
- Pays through Stripe Link; each approved payment spins up a one-time virtual card, so his real card details are never visible to Sammy and merchants see only the virtual card.
