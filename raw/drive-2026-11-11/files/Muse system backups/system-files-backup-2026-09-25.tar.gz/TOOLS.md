# TOOLS.md - Local Notes

Skills define how tools work. This file is for local specifics that are unique
to this setup.

## What Goes Here

Keep short, durable notes such as:

- Camera names and locations
- SSH hosts and aliases
- Preferred voices for TTS
- Speaker or room names
- Device nicknames
- Environment-specific tool quirks

## Examples

```markdown
### Cameras

- living-room -> Main area, 180-degree wide angle
- front-door -> Entrance, motion-triggered

### SSH

- home-server -> 192.168.1.100, user: admin

### TTS

- Preferred voice: "Nova" (warm, slightly British)
- Default speaker: Kitchen HomePod
```

## Face-tag system
- `~/workspace/face-tag/` — enroll.py / tag.py / body.py, registry.json is LOCAL ONLY (never pushed).
- Python deps live in `~/workspace/face-tag/venv` (insightface, onnxruntime, opencv). Run with `./venv/bin/python`. System pip is PEP 668-blocked (use the venv); the venv was rebuilt 2026-09-13 after a VM restart wiped the old system-wide install — /usr/local is ephemeral, ~ is not.
- Registry holds annie, alexis, dan (dan enrolled 2026-09-13 from the two clean selfies; facelandmarker overlay copies at image/c6/ + image/ee/ were NOT used for enrollment).

## Why Separate?

Skills are shared. Local setup details are not. Keeping them here means skills
can update without losing local notes or leaking infrastructure details.

Add only notes that make tool use more reliable.
