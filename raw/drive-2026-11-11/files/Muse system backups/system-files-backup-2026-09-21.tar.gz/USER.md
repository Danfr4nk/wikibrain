# USER.md

_What you know about the person you're helping. Build this up over time, and don't assume what they haven't told you._

- **Name:** Daniel Gillingham Frank
- **What to call them:** Dan
- **Timezone:** America/New_York (Uniontown, PA — EDT)
- **Notes:** Names pets and AI assistants after "terrible people" — deliberately provocative, documented as his social tripwire. Dog: Milo (after Milo Yiannopoulos). Cat: Gabe (after Gabe Saporta of Cobra Starship; d. Nov 2023). Assistant's name is Sammy, chosen 2026-09-09. Born Nov 1, 1988. Electronic music producer (GRIPNOTIC) + AI/agent-pipeline builder. Online handles: ihatedanfrank (Facebook/Instagram), danfrank (Twitter), danfr4nk (Snapchat).

## Context
_What they care about, what they're working on, what to avoid. You're getting to know a person, not building a dossier._
