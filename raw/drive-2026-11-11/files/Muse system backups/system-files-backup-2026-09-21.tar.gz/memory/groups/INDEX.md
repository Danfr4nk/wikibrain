# Groups Index

Every page under `~/memory/groups/`, closest to the user first. Rendered by the relationships loop; each page carries the facts and the nature of the user's relationship with them.

- **The Frank family** — `~/memory/groups/frank-family.md` — Dan's family circle — divorced parents, a distant sister, the late Fran Coldren; money and care still run through it.
- **The Au Za'atar crew** — `~/memory/groups/au-zaatar-crew.md` — Dan's 41-month restaurant crew (Mar 2021–Aug 2024) — his longest job, and the one boss he ever loved.
- **The Full Sail cohort** — `~/memory/groups/full-sail-cohort.md` — Dan's 2008-era Full Sail friend circle — the $5 birthday Venmo bit still runs 15+ years on.
- **The Nemacolin crew** — `~/memory/groups/nemacolin-crew.md` — Dan's 2016–19 golf-caddy crew at Nemacolin Woodlands — the three-year work circle with its own manager, friction episodes, and one genuine friendship.
- **The Cogar family** — `~/memory/groups/cogar-family.md` — Fran Coldren's extended family — her sisters, kids, and grandkids; Eddie & Brenda Cogar's surprise 50th anniversary party is Nov 7, 2026, and Dan's invited.
