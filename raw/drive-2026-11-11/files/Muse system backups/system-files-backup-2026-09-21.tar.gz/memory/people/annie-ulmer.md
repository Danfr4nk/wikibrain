---
display_name: Anne Ulmer
first_name: Anne
last_name: Ulmer
nickname: Annie
summary: Eleven-year partner, terminally ended Aug 2026; Sep 10 Mom Maruca's contact; the Aug-26 "block" never happened (retracted); LLM-to-Annie report on explicit-verbal commitments (Sep 2026).
rank: 1
updated: 2026-09-21
---

<!-- evidence: corpus-extract/agent-B-people.md; wiki/people/annie-ulmer.md; wiki/timeline/annie-record.md; memory/2026-09-11.md; windows 2026-09-12/16/18 (09-18: story-time abortion sweep + testimony); window 2026-09-20T03:24–04:23 (!BRIEF sexuality sweep); window 2026-09-21T03:38–04:01 -->

# Annie

## Facts
- Anne Louise Ulmer, Uniontown PA. Aliases: @Lo_weez, @Annelouise28, "smashonista"; escort alias "Hazel" summer 2019. Forensic read: ESFP, Enneagram 7w8 (moderate confidence).
- "Eggie" (analyzed 2026-09-17): third-person baby-talk persona (~40/41 msgs) — Dan's read: a REPAIR BID after transgressions, identity collateral ("you know me"). Rosetta Stone 2026-03-14: "is eggie just gone?" / "No Eggie is not gone" — Eggie is the version of her he recognizes as real. Dark modes exist ("Making Eggie ANGRY"). Terminal: 2026-09-03 "Let me know if you want to help fund Eggie today" — repair-bid became ask-bid. Sparse 2016–19, silent ~6 years (nickname dormant, NOT the relationship), flood Aug 2025–Sep 2026.
- Pet names: he calls her **"sweetie"** (145x); her food nickname is **"Eggie bagels"** (his words 2026-09-17).
- Met Dan ~2 AM Nov 29, 2015 at Uniontown Country Club; Alexis introduced her ("the cam girl"); she was ending things with Emilio that weekend; Suz brokered the transfer.
- Corpus's largest relationship record: 97,768 unique messages, 2015-11-28 → 2026-06-05, four handles.
- Decade arc: 2017 poverty floor; 2018 arrangement with Alexis; NYC 46 Nevins St (Feb 2019–Feb 2025); authored non-monogamy; drug logistics she joined; net ~$119–123K outflow Dan→Annie; $10K landlord balance; $7K ConEd debt.
- 2024 care work: paid care for Libby Titus (Feb–mid-Aug; unpaid-wages dispute; Libby died Oct 13, 2024); ~two years unpaid childcare for Alice and Otto.
- The Eli incident: concealed NYC affair Aug 2024–Jan 2025 (found Jan 9, 2025) — weaponized ambiguity violating the arrangement; Feb 22, 2025 NYC exit staged by Dan, concealed from Annie.
- June 1, 2026 closure: all Dan's own outbound (misattributed to Annie until Aug 2026 correction); her only contribution the June 5 apology. 1,880 messages, six meetings in eight days; re-entanglement via Milo.
- Terminal rupture Aug 16–19, 2026 around Jerel Wayne Coles — the man she left Dan for. Aug 16 Morgantown St call (204 turns): Coles holds her phone, won't return it; sent Dan's home address unprompted, threatened his mother.
- ~25 block declarations Aug 15–19, none executed ("there was never a block," 2026-09-11); texting continued Aug 27–Sep 7; "first held boundary" was retrospective performance.
- Sep 10, 2026: she said she waitresses at Mom Maruca's and got a bad review — none found on Google or Yelp.
- Dan's own tally of their non-monogamy (his 2025 [S3X] self-analysis): "about 12 non monogamous experiences" — 9 situations he set up where she hooked up with another guy, 3 where they were together with another girl, 1 where they both hooked up with another guy (his words: "my only non-heterosexual event").

## History
- 2017 abortion (June 24 → July 8): full spine from the 2026-09-18 story-time sweep — corrected to 2017 (not 2018) by photo timestamps. June 24: positive test photographed. June 28 sonogram: ~19 weeks (BPD 4.30cm / FEM 2.68cm); "10-27-17" handwriting corroborated by nothing. Rick funded the $1,000 ("Thank you for another bailout," June 26); Dan lied to Rick that Suz didn't know — she'd been told June 24. Procedure ~July 6–8: zero corpus messages July 5–7, tense future→past across the gap; Dan's reconstruction (procedure + recovery together, not texting) matches Suz's coaching. 5-year Nexplanon implant at the procedure. Aftermath: July 23 grief peak; Oct 12 "not a single day that it doesn't cross my mind"; Oct 26 dysfunction worry. His 2026-09-18 testimony: exactly one abortion — the 2017-08-08 "100%" joke to David Keller was just a joke. Open: 10-27-17 date, Magee vs the other place, a Dec 2015 scare (outcome unknown).
- Nov–Dec 2018: the Annie–Alexis affair — Annie drove it; $3,000 figure single-sourced, unconfirmed. Nov 14 peak: "It's literally the best thing that's ever happened to me… This is going to make me religious." Nov 6 bedroom-cam footage surfaced 2026-09-12.
- Feb 25, 2019: 307 E 76th St lease-signing — "our nyc apartment" iPhone-XR photos.
- 2026-09-05: door incident (Dan's account): Jerel Coles pounded on his door 10 min midday; Dan unblocked Annie to check, got "call 911" within 30s; Coles had just tried to fight her dad; Dan reblocked her, told Suz, no police call. (See [jerel-coles.md](jerel-coles.md).)
- 2026-09-10: LLM-to-Annie report on his explicit-verbal-commitment architecture.
- 2026-09-11: disclosed Danny Matthews — Annie's pre-NYC lover; the only man Dan says he finds hot ([danny-matthews.md](danny-matthews.md)).
- 2026-09-12: Annie trained Valeria Iglesias Cid as an Au Za'atar hostess ("hey i trained a new"); Dan: "the perfect handoff in the spirit of Alexis>annie" ([valeria-iglesias-cid.md](valeria-iglesias-cid.md)).
- 2026-09-12: his Annie media archive — his own stated explanation for staying. Escort booking (his account): Jared and Tricia, 2 hours ([jared.md](jared.md), [tricia.md](tricia.md)).
- 2026-09-13: black tribal-style glyph on left ribcage/flank; script "Hope is a waking dream." low on abdomen/hip.
- 2026-09-13: Del — man in Annie footage (oral video), name from Dan, no other data ([del.md](del.md)). Danny — man who was with Annie; Dan's account: secondhand, not "for real." His hard boundary (anal/pegging) was tried — her in the strap-on harness.
- 2026-09-16: footage shows Annie with Shelbie — first documented contact since April 2019 ([shelbie-breakiron.md](shelbie-breakiron.md)).
- His explicit framing (2026-09-17): NO split or gap in the relationship 2015–2025 — problems sparked by the Eli affair.
- Name-use pattern (2026-09-17): she says his name 2,396x vs his 875x "Annie" (2.7x). End-tag 1,199 / embedded 576 / start-frame 422 / name-only 199 (shoulder tap: 78% reply within 10min). "Daniel" 140x is the weight switch: early romantic inflation, late solemn mode. Rate climbs with precarity: 1.0% (2015) → 7.9% (2026). His read: regulatory — a control surface disguised as intimacy.

## The relationship
- The fallout verdict: Annie the primary agent of harm — wronged in fact — with Dan's diagnosis-to-behavior gap held in the same frame.
- Attachment model: no explicit severance signal in her 41,073 messages; the Aug 16–19 rupture differs from every prior severance on six endogenous features.
- Corroboration from her side, July 23–25, 2026 — "I put you through hell," "you were always true to me," accountability given to her parents, a rehab placement refused.
- His unprompted line: "even the worst thing I've done, getting you drugs, didn't really benefit me nearly as much as it was about that being the only way you would see me."
- Morgantown inverts the decade's power distribution: the primary agent of harm is the least powerful person in the recorded room — under coercive control, having disclosed a suicide attempt.
- His 2026-09-11 framing: "a sincere love/pussy hybrid" — "She also became my identity"; the friction was the receipt.

## In common
- Milo (co-held; Claire's stray rescue); the Uniontown/NYC years; the 2017–18 Fran caregiving rotation; Alexis (the 2018 arrangement); her family — Ellen, Bill, Claire, Garrett, Alice and Otto — whose tie to Dan outlasted the relationship.

## Open threads
- [x] Severance test VOID — retracted 2026-09-11; there was never a block.
- [ ] Milo co-held — the standing recontact channel.
- [x] Mom Maruca's bad review (Sep 10): none on Google/Yelp; Facebook not fully ruled out.
- [ ] Oct 26, 2025 stop: docket MJ-14101-CR-0000631-2025 names Annie — PA UJS lookup would settle it.

## Strengthening

## Handles
- 2026-09-21 (Dan's ID): +12124702449 is Annie's phone (212 number) — the 31k-row thread back to 2023 previously logged as "a different long-standing correspondent" was her all along. 1,748 of its messages recovered in the iPhone union merge (Mac never synced them).
