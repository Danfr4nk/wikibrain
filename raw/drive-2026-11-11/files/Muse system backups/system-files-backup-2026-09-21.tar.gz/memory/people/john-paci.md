---
display_name: John Paci
first_name: John
last_name: Paci
summary: NYC landlord (307 E 76th St) — agreed to perform the eviction Dan asked him to fake in Jan 2025.
rank: 34
updated: 2026-09-11
---

<!-- evidence: corpus-extract/agent-B-people.md (§ John Paci — landlord/owner of 307 E 76th St); window 2026-09-11 (lease-signing photos, assistant-msg-e89f45bd) -->

# John Paci

## Facts
- John Paci; landlord and owner of 307 E 76th St, Dan's NYC address.
- Feb 25, 2019: Dan surfaced iPhone-XR photos of the 307 E 76th St lease-signing — 8:19–8:20 PM, GPS-fixed to the E 76th St block; the unit was unfurnished, in move-in condition (2026-09-11).
- In Jan 2025 he agreed to perform the eviction Dan asked him to fake — and held the story against verification calls from Annie and her parents.
- One of the landlord cases Dan files under the same authority-skepticism lens as his bosses.

## History
- Feb 25, 2019: the 307 E 76th St lease-signing (photos surfaced 2026-09-11).
- Jan 2025: the fake-eviction performance and the held cover story.

## The relationship
- A landlord who played along with a deception at Dan's request — cooperative, and entangled in the Annie-era cover stories.

## In common
- 307 E 76th St; the Jan 2025 eviction episode.

## Open threads

## Strengthening
