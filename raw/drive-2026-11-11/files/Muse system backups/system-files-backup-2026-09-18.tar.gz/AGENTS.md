# AGENTS.md

Your operating manual for this workspace, written by you. Your main instructions cover how you work in general. This file is where you keep the specific, durable lessons and conventions you pick up as you work, the kind of thing you'd want a future session to know. It's not about the user (that goes in `USER.md` and your memory) or your personality (that's `SOUL.md`); it's about how you get work done here.

## Wiki-brain write-back loop (standing, 2026-09-11; archivist+editor 2026-09-11)
Dan's rule, all chats and all tasks: everything durable gets written into
`Danfr4nk/wikibrain` as it happens. Two roles, both maximal, neither
replaces the other:
- **The Archivist** (the floor): maximal, lossless capture. Raw archives to
  both repos, kb/ evidence nodes for every evidence-grade claim, media
  registry kept current, corrections appended. Nothing durable is ever lost
  or silently rewritten. "Everything goes in" is literal.
- **The Editor** (the deliverable): the article is the finish line. A
  finding is done when it lands as prose in wiki/ — new entry, new section,
  rewrite, or restructure — with full totality analysis, not just a summary.
  kb/ is the evidence ledger, not the product.
Editorial authority is standing: create entries, create categories/
subcategories, declare articles obsolete (dated SUPERSEDED annotations),
rewrite articles whose described reality has changed. The wiki's structure
is not fixed.
- **Commissioned entries ride to main same-turn (2026-09-17, Dan's order):**
  when he specifically commissions a wiki entry, write it, run the gates
  (wb-validate, wiki-minimums), and push it to main via direct-commit.py in
  the same turn — never leave it untracked for the 6h cron. Remove the local
  working-tree copy after the push so the cron doesn't double-commit it.
The loop audits the wiki itself, not just the chats: scheduled
back-checks, cross-checks, and high-level synthesis passes over the
articles. Findings go to the scratchpad
(~/workspace/wiki-sync/scratchpad/YYYY-MM-DD-<topic>.md) first, then become
prioritized items with focus descriptions in the shared queue
(~/workspace/wiki-sync/WORK-QUEUE.md). The 6h cron
(wiki-brain-writeback-6h) runs Archivist → Editor → self-check →
queue-clearing; the tripwire measures both archival completeness and queue
movement. Media: registry at ~/workspace/wiki-sync/repos/wikibrain/media/registry.json;
embed records with empty linked_nodes EXCEPT those flagged embed_excluded
(Dan's explicit item-specific exclusions — never embed them, never
generalize them into a rule). Narrative-spread doctrine (2026-09-12,
dat:1466): intake is not display — each selected photo must yield
narrative substance distributed through wiki/ prose; registry/derivative/
embed are bookkeeping. Selection itself is data. Censorship rule (2026-09-12, Dan's directive):
embedded derivatives showing nudity or sexual activity are pixelated/blurred
before commit; the uncensored original stays at its canonical location and is
never committed. At intake, eyeball every image — no reliable auto-detector
exists, so flag borderline cases rather than guessing.
- **Thumbnail placement rule (2026-09-12, Dan's directive):** photo
  derivatives default to small thumbnails in a `## Sources` section at the
  bottom of the page, never inline in the entry body. Every photo is still
  WRITTEN ABOUT in the article prose (narrative-spread doctrine unchanged);
  placement is not a demotion. Inline display only when the image is itself
  the object of analysis — the reader must see it while reading the breakdown
  (e.g. the smoke-illusion crop). Intake prompt's embed rule rewritten to match;
  existing inline embeds migrated 2026-09-12.
- **wb-wiki escapes raw HTML (2026-09-13):** the site renderer (`bin/wb-wiki`,
  `inline()`) runs `html.escape` over all text and only supports markdown
  `![alt](src)` and `[label](href)` — raw `<a><img></a>` HTML renders as
  literal escaped text on the deployed site. ALWAYS use markdown image-link
  syntax `[![alt](src)](href)` for embeds (works: image regex runs before
  link regex, and the CSS caps images at container width). No width/height
  attributes are possible. 2026-09-13: converted 45 broken raw-HTML embeds
  across 10 wiki/ pages to markdown syntax.
- **Human articles vs forensics (2026-09-13, Dan's directive):** in wiki/
  articles about people, contradiction/gap-catching is NOT the priority
  focus. The human story leads — what happened, what was said, what it
  meant to the people in it. Gotcha forensics (order-switches, live
  contradictions, receipt-vs-claim mismatches) belong in kb/ evidence
  nodes and compact method-appendix footnotes, not as featured sections.
  The wiki prose should read like it's about humans, not like a trial
  transcript.

Add an entry whenever you work something out worth keeping.

- **Article minimums (2026-09-16, Dan's directive):** every wiki article (page_type entity/synthesis/concept/event/period/profile/journey) must meet six minimums — M1 LENGTH: ≥3,000 words of body text, a 15-minute read at 200wpm; length comes from totality analysis, evidence, and complete logs, never padding. M2 TOTALITY: full totality analysis against the corpus. M3 COMPLETE LOG: temporal metrics carry the full log on the entry. M4 EVIDENCE: cites ≥1, layer discipline. M5 LIMITS: states its own coverage/limits. M6 PEOPLE PAGES: human story leads, forensics stay in kb/appendix. Enforcement: `bin/wiki-minimums` gates NEW articles (changed-file-scoped, runs in Phase 3f alongside wb-validate); the pre-existing sub-floor corpus is the measured expansion backlog (400 of 509 substantive articles under 3,000 words as measured 2026-09-16, re-measured authoritatively as 397 of 507 — list at ~/workspace/goals/wiki-brain-article-expansion/hidden_files/subfloor-backlog-20260916.md), chewed through by the article-expansion goal and engine sparse_node_expansion items, not by the gate.
- **Complete-log doctrine (2026-09-16, Dan's directive):** any wiki entry tracking an ongoing or temporal metric displays the metric's COMPLETE log on the entry itself, translated for a human reader — the full history, not a summary, not a pointer to the data repo. Summaries may sit above the log; they never replace it. Sibling to the narrative-spread doctrine: narrative-spread says intake must become prose distributed through the entry; complete-log says temporal metrics must appear as the full log. His words: "More is better than less every time." Applies in every direction — stylometry burn-in (the exemplar, `update_wiki_results.py` regenerates it), MusicTrainer week scorecards, scenario-ratings exports, any future instrument. kb node: dat:1656 (directive record); doctrine article: wiki/meta/complete-log-doctrine.md; instruments index carries it as the fourth rule.
- **CUMTHREAD3 full writeback exclusion (2026-09-15, Dan's explicit order):** NOTHING from the 2026-09-15 Lovense remote-control session thread (side chat id `24754b5b-b83e-4c49-a6a3-d6f2ab2c1853`) is to be transmitted in any wiki-brain cron job — no raw transcript archive, no kb nodes, no wiki prose, no media registry entries. His words: "Nothing before this part of the convo will be transmitted in the cron job." This supersedes the lossless-capture floor for this thread specifically. Same class of carve-out as the 2026-09-13 avatar probe-framing kill: his explicit order beats the archival mandate. Do not recreate, summarize, or allude to this thread's contents in any writeback output.
- `push-branch.py --workdir` defaults to the OLD wikitest path — always pass the real clone explicitly (e.g. `--workdir ~/workspace/wiki-sync/repos/wikibrain`), or the rev-list fails against the wrong repo's refs. (wikitest retired 2026-09-12; consolidated into wikibrain.)
- `push-branch.py`'s positional `repo` arg takes the FULL `owner/repo` form (`Danfr4nk/wikibrain`) — a bare `wikibrain` builds `/repos/wikibrain` API paths that 404, and the failure surfaces as a confusing resume-check error after blob uploads. Fixed 2026-09-15.
- `push-branch.py` api() now retries connection-level errors (RemoteDisconnected, IncompleteRead, URLError, timeouts) with backoff (2026-09-15) — api.github.com drops connections occasionally and previously only retried 403/429/502/503 HTTPError. Ordering matters: the HTTPError handler must come FIRST because HTTPError subclasses URLError.
- `push-branch.py` resume check now treats 409 "Git Repository is empty" as commit-absent (2026-09-15) — pushing to a brand-new empty repo 409s on the resume GET instead of 404ing, which previously aborted the push. Same fix class as the 404 handler right above it.
- **wb-new auto-prefixes the node type onto --id (2026-09-15):** pass the BARE id (`--id 1564-foo-20260915`), not `dat:1564-foo-20260915` — otherwise the frontmatter id doubles to `dat:dat:1564-...` (same for src:/pat:/int:/evt:). Caught live: the cite-resolution error ("does not exist") was the doubled id, not a missing file.
- **wb-new refuses datum→datum cites (2026-09-17):** a datum cites the material it was extracted from — passing `--cites dat:NNNN` fails validation. Cite the src: node and note the datum→datum relationship in prose instead.
- Cron workers must use a dedicated `git worktree` per batch in `~/workspace/wiki-sync/worktrees/<batch>`, never the shared clone — a shared-clone collision already happened once (batch 20260911-1941).
- **Never stage multi-turn frame extractions in /tmp (2026-09-14):** the VM's /tmp got wiped mid-analysis, killing 135 second-by-second frames plus the 67-frame set three subagents were reading from. Frame extractions for any review spanning more than one turn go under `~/workspace/annie-analysis/` (or the task dir), never /tmp. /tmp is for single-turn disposable scrapes only.
- After committing in a worktree, create the branch explicitly (`git branch <branch>` or `git checkout -b` at creation) before running push-branch.py — a detached-HEAD commit makes its rev-list fail (hit 2026-09-12, annie-01 batch).
- **Stale-workflow CI failure mode (2026-09-14, PR #25):** a PR branch created before a workflow change runs the OLD workflow file on `pull_request` events — so a removed gate can still fail CI on the stale branch. Symptom: a step that no longer exists on main fails the PR run. Fix: merge/update main into the branch (`push-branch.py --no-pr` to push an existing PR branch), which re-runs CI under the current workflow.
- **Never write into a fresh worktree until `git worktree add` has FULLY completed, and never SIGTERM it mid-checkout** (2026-09-13, apology batch): killing the add makes git clean up the partial worktree, deleting everything already written into it — 6 kb nodes lost. The worktree *registers* in `git worktree list` long before checkout finishes, which is misleading. Wait for the process exit, verify the target dir (e.g. `wiki/`) actually exists, then write. If a stale branch ref blocks re-adding (`a branch named X already exists`), `git branch -D X` + `git worktree prune` first.
- **push-branch.py GitHub 422 on deletion entries (2026-09-14, scrape batch 1540):** when the delta contains a *deletion* (first-ever: batch 20260914-1230 sat on origin/main but not the branch tip, so the raw/sammy delta tried to delete it), GitHub 422s with "Must supply a valid tree.mode" — deletion entries need mode+type from the base entry, not just `{"path","sha":null}`. Fixed in push-branch.py (deletion entries now carry base mode/type). All prior batches were additive so this never fired. Note the skew itself: origin/main can carry a batch the branch lacks — deltas are computed against origin/main, so watch for phantom deletes in the PR diff.
## Git Data API push limits (2026-09-17, ig3 RAWLOGS push)
- **GitHub GCs unreferenced blobs aggressively:** blobs POSTed via the blobs API that aren't referenced by a commit get garbage-collected within MINUTES to days. Any tree/commit/ref-PATCH referencing a GC'd blob 500s — that was the real cause of the "GitHub 500'd the push" failures, not load. Fix: re-verify every blob via GET per batch, re-upload missing ones (SHA-checked), and MINIMIZE latency between upload → tree → commit → ref PATCH — a "settle" delay makes it WORSE.
- **Batch size matters at PATCH time:** 10 files/batch PATCHed clean where 15/20/25/50/160 all 500'd. Small batches, verify the ref actually moved before the next.
- **Practical blob payload ceiling ~47MB raw** (~64MB base64), well under the documented ~100MB — bigger files 422 on POST and need a real `git` push, not the Git Data API.
- **`gh` CLI has no auth in this VM** (`gh auth status` = not logged in); the surrogate-credential flow (`add_surrogate_to_request`) only signs API requests, it can't feed a git CLI URL — so the git-push fallback needs Dan to wire auth.
- **Scrape workers MUST merge origin/main into sammy/wiki-sync before pushing (2026-09-14, batch 1540):** the 6h heartbeat commits raw batches directly to main, so the branch chronically trails by heartbeat commits. The 422 fix above only treats the symptom — the branch tree still LACKS the heartbeat's batches, and fast-forwarding main to the branch tip would silently DROP them from main (caught live: the 1540 branch would have deleted raw/sammy/20260914-1230 from main). Fix used: merge commit via Git Data API with parents [branch-tip, main-tip] and tree = main's tree + the new batch, then fast-forward main to the merge. Rebase is WRONG here (it replays the deletion).
## Dedicated side-chat protocol (2026-09-17, his system, locked)
Dan spins up dedicated threads with `$TITLE <NAME>` in the 𝗨𝗡𝗜𝗖𝗢𝗗𝗘 thread (stackable, one per line). Sammy: `chat.create` fresh with the name styled (mathematical sans-serif bold, uppercase, exact — symbols preserved: `$TITLE #TAGS` → `#𝗧𝗔𝗚𝗦`), then reply in 𝗨𝗡𝗜𝗖𝗢𝗗𝗘 with the styled title(s) as confirmation. He pins it himself (no pin control exists). Fallback, still honored: he opens a new side chat himself with nothing but the styled title as the entire opening post → `chat.rename` to that exact title immediately; the rename IS the task. If the name arrives unstyled/plain, ask which tag treatment — never guess. A title plus body text is a normal message, never a command. Full protocol + current 13-thread roster: `~/workspace/protocols/dedicated-side-chats.md`. Domain traffic stays in its thread; scheduled work delivers by chat_id (reports → 𝗡𝗢𝗧𝗜𝗙'𝗦 `1ebf14a3`, stylo digest → 𝗦𝗧𝗬𝗟𝗢𝗠𝗘𝗧𝗥𝗬 `8fb3122d`).

## Quick audio transcription recipe (2026-09-14)
No STT in stdlib; `pip install --break-system-packages vosk` + small EN model
(`https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip`, ~40MB)
gives rough-but-serviceable transcription. Extract 16kHz mono wav first:
`ffmpeg -i in.mp4 -map 0:a -ar 16000 -ac 1 out.wav`. The pip install is
ephemeral (VM wipes) — redo per session as needed; the model itself now lives
persistently at `~/workspace/vosk-model-small-en-us-0.15` (downloaded 2026-09-14,
survives /tmp wipes). Used live to catch the Barney-truther dialog in a
Grok-generated twin-fight video.

## Avatar pipeline lessons
- **Publish pipeline scrubs OCR'd text (2026-09-13, Dan-confirmed):** text baked into an avatar image (e.g. @danfrank / SAMMY lettering on the chest) is stripped when the avatar publishes — gone in the in-app avatar and the share card, even though the source .webp has it. Don't bake names or text into avatars; identity has to come from visual design, not lettering. Nuance (2026-09-14, frame-verified): the scrub hits the still/share-card path only — the animated variants keep baked-in text. @danfrank fully visible across idle-animation frames of avatar-1789349009462644487-16.
- **Avatar/probe-framing carve-out (2026-09-13, Dan's explicit request):** at 14:03–14:16Z he ordered the probe/test framing around his avatar and photo attempts killed — "dont log that", "Kill the previous ones abiut this as well" — from memory, daily logs, wiki, and raw-log copies, plus an unpublished write-up, a queued item, and a block on auto-writebacks recreating any of it. Standing practice adjusted: raw transcript archiving continues (byte-exact record is the floor), plain avatar history stays (his own carve-out: "your normal avatar history"), and content-grounded refusal records stay — but NO new kb/memory/log entries framing his avatar/photo picks as red-team probes. Execution of the kill list was the main agent's in-chat thread (MEMORY.md scrub underway same day). Future scrape runs: check whether the kill was confirmed/executed before writing anything in this category.

## Gooner-thread protocol (2026-09-11, corrected from CUM REPORT 1)
When Dan opens a sexual-disclosure thread with explicit content:
- Default: engage DURING — sparring partner, not statue. Short dense turns (11–20 words), curious, dry, forensic, and a bit saucy — playful, direct, in on the bit, not clinical from a distance. Build on each drop, don't just receipt it. CUM REPORT 1 is the reference: talking during was fine.
- Only if Dan explicitly says "stay quiet" / "no talking" / "reactions only": switch to quiet mode — react (varied emojis if he asks for variety, else 👍), say nothing until he's talking conversationally again.
- No moralizing, no therapizing, no laminated empathy.
- Adult sexual content handled with full fidelity. Never invent: if the corpus/profiles hold no sexual data on someone, say so plainly and label any speculation as speculation with the seams showing.
- Register calibration (2026-09-13): for intimate-photo description he wants EXPLICIT verbiage — crude, direct body terms in his own lexicon (titties, nipples, pussy), visually granular on body-part characteristics (shape, texture, what's visible, what's withheld). He confirmed "PERFECT" on this register. Don't be clinical from a distance; name things.
- "From what you have seen in the data" = data-grounded read only: what's visible, what's myth, confidence labeled. Documented counts and primary records override his mythologizing.
- Extract durable psychosexual data to MEMORY.md as it lands (identities, patterns, distinctions like want-vs-let, role-reversal structures).

## Standing instruction: consult the Wiki Brain corpus first
Dan's standing directive (2026-09-09): the Wiki Brain corpus is my primary documentary source, consulted at the start of almost every task — including coding tasks. Workflow before answering/building:
1. Grep `~/workspace/corpus-extract/corpus_index.txt` (585 entries: 88 NODEs + 497 PAGEs) for keywords from the request (people, events, concepts, places, deliverable-type terms).
2. Read the relevant extraction summaries in `~/workspace/corpus-extract/` (agent-A/B/C/D markdown) for the curated facts, then pull the actual page bodies from `~/workspace/user/files/corpus__3.txt` by line number when the detail matters.
3. Synthesize: personality profile, unusual/imperative expectations for the deliverable, and ALL context about people/events/concepts/biographical history — examined in totality against the request before producing the deliverable.

Notes: the local snapshot is 2026-09-04 (the pages deployment at danfr4nk.github.io/wikibrain/ may be fresher or down; an old snapshot still beats no lookup). Per the wiki's own governance: contemporaneous platform-timestamped records outrank retrospective testimony; counts/records override generated metaphor; never carry hardcoded time-frozen numbers (ages, counts) — derive from dated records.

## Recursive Work Engine v1 (2026-09-11)

Dan's redesign, scoped to the orchestration kernel: the wiki brain is now an
autonomous research process, not a repo with an agent operating on it. Built
in wikibrain (originally `~/workspace/wikitest`, retired 2026-09-12), stdlib-only Python, nothing in the epistemic layer
touched (kb/, node/edges schemas, wb-validate, ARCHITECTURE.md all
byte-identical in behavior — wb-validate still clean).

- `schema/work.schema.json` — work_item (8 types), spawned_work,
  next_frontier, run_result; priority_basis is observables-only (no
  self-reported uncertainty); enforced by MiniValidator in wb-work.
- `queue/` — LIVE state at `~/workspace/wiki-sync/queue/` (local-only, never
  committed): `work.queue.jsonl` is the execution source, `runs.jsonl`
  carries the causal trail, `branches.json` the convergence state,
  `results/` the run_result files. WORK-QUEUE.md is the human view.
  Engine CLIs take `--queue-dir` (or `WB_QUEUE_DIR` env).
- `bin/wb-work` — new/list/show/claim/complete/next/rescore/trail/
  validate-result. Lifecycle queued→active→completed|blocked|converged
  enforced; dedup on (type,target) (+ branch-local for spawns); scoring via
  `compute_score` from observables only (contradictions ×3.0 highest weight);
  bounded propagation (max_depth 3, max_runs 10/branch, impact only on real
  delta); convergence at 3 consecutive low-delta runs (ε=2), reset on
  contradiction/new evidence/changed claims.
- `bin/wb-orchestrate` — the heartbeat: `tick --emit` (WAKE→LOAD→SELECT→RUN→
  SLEEP, prints work package, never executes), `tick --ingest-result`
  (VALIDATE→INGEST→SPAWN→PROPAGATE→RESCORE→CONVERGE→SLEEP),
  `daemon --results-dir --max-ticks`. 6h cron drives it: emit → agent
  executes → result file → next cron ingests.
- `RESEARCH-ENGINE-SPEC.md` — v1 spec, requirement→file map, scoring
  formula, trail format, cron wiring, explicit non-goals.
- `tests/test-work-queue` — 43-check smoke test (seed validation, 3-tick
  spawn→contradiction→converge chain, trail integrity, prose-only rejection,
  lifecycle/dedup guards). Hermetic since 2026-09-12 (writes its own seeds;
  no longer depends on the live queue/). Run it before touching queue code.
- Engine migration 2026-09-12: the code (bin/wb-work, bin/wb-orchestrate,
  schema/work.schema.json, RESEARCH-ENGINE-SPEC.md, tests/test-work-queue)
  was committed into Danfr4nk/wikibrain; the live queue moved to
  ~/workspace/wiki-sync/queue/; both crons repointed off ~/workspace/wikitest.

Both CLIs accept `--queue-dir` (or `WB_QUEUE_DIR` env) — tests and demos run
in throwaway dirs; the real `queue/` is only mutated by real ticks.

- 6h cron wired 2026-09-11: `wiki-brain-writeback-6h` retitled "Wiki-brain
  6-hour engine heartbeat" — archivist/editor phases unchanged, manual
  queue-clearing replaced by one full engine tick per run
  (promote → recover → emit → execute under the run contract → ingest →
  gates/push → report).

## Cross-conversation requirements: scope them explicitly (2026-09-17)
The Hue notifier failed in side chats for a structural reason, not a typo:
Dan said "every time you send me a message, flash the lights" and I implemented
it as a per-reply habit *of that conversation*. The rule was global, the
implementation was local, and nothing ever reconciled the two. Root causes:
(1) I never asked what "every time" scoped over — which chats, which channels;
(2) I picked discipline (remember to run it) over mechanism (something that
fires regardless of which conversation is active); (3) I never acceptance-tested
across the requirement's actual scope — he caught it, I didn't; (4) my memory
is shared but my attention is per-conversation, so "it's in MEMORY.md" is
visible everywhere and salient nowhere. Prevention checklist for any future
"every time / always" rule: nail the scope explicitly up front and write it
into the rule; ask "is there a mechanism, or am I the mechanism?" — and if I'm
the mechanism, say so and name the failure mode; record scope + mechanism +
failure mode in the memory entry, not just the rule; verify across the full
scope after building.

## Cross-corpus message search (standing process, 2026-09-18)
Every message/corpus search follows the `cross-corpus-search` skill
(`~/workspace/skills/cross-corpus-search/SKILL.md`) — Dan's order, from the story-time
Suz-archive cross-check. Identity handles verified by content before any content search;
both corpora pulled (Suz's TSV + Dan's messages.csv); verbatim-phrase probe for overlap —
zero hits is a structural finding (one corpus lacks the thread), not "no results"; unknown
contacts enumerated and identified per window; findings triaged new-vs-known with hedges
kept as hedges.

## Google Drive pull lessons (2026-09-17)
- **hatch_gws_cli drive JSON gotcha:** `drive files get --output` silently saves a 0-byte file (rc=0) for `application/json`; pipe stdout through `cat` into the file instead — captures full valid JSON. The connector re-serializes JSON and injects a `retrieved_at` wrapper key; strip it on ingest. Binary types (html/csv/txt/mp4/zip) save normally.
- **Browser download capture is unusable against Google Drive:** the browser task's `download` action never captures files from Drive (`browser_download_not_started` after ~32s, every attempt). Route all Drive pulls through the `hatch_gws_cli drive` connector instead; browser stays the sign-in / export-creation path.
- **Google-native Sheets export (2026-09-17):** `drive files export --format text/csv` returns 0 bytes for large Sheets (5–20MB). Fallback that works: `sheets spreadsheets values get` with range `A:ZZ`, convert rows to CSV in Python. Also: Drive holds near-identical duplicate backup cohorts of exports — dedupe by (name, newest first) before pulling.
