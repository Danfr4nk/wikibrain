---
display_name: Del
first_name: Del
summary: The man Dan named as the third party in the Sept 27, 2020 recording with Annie — 'the one full experience I have recorded.'
rank: 60
updated: 2026-09-14
---

<!-- evidence: MEMORY.md#L14 (memory://md:MEMORY.md:14); memory/2026-09-11.md#L862; ~/memory/people/annie-ulmer.md (Del bullet, Strengthening); window 2026-09-13T22:30–23:23 UTC (play-by-play, 69 correction, wiki PR #61) -->

# Del

## Facts
- First name only — "del" is the name Dan gave; no surname on record.
- A man Dan and Annie knew in NYC. No other biographical data on record.
- The named third party in the Sept 27, 2020 recording: Dan let Annie have sex with Del, recorded the experience, and was present the whole time. Dan's own framing: "the one full experience i have recorded."
- The recording as pulled 2026-09-13: three "Movie on 9-27-20" .mov files (12:45 PM / 7 min, 12:52 PM / 19 min, 1:11 PM / 67 min), ~93 min total, 720x480.

## History
- Sept 27, 2020: the recording, per Dan's account — disclosed to the assistant 2026-09-11.
- 2026-09-13: Dan supplied the name "del." The files were pulled from Drive; the assistant wrote a play-by-play of the 19-min file, which Dan corrected on review (the extended act is 69, not cowgirl as first read). The event was written into the wiki the same day — full narrative, zero images, video files never committed (PR #61 merged to main).

## The relationship
- Dan never named what Del was to him beyond "a guy they knew in NYC" — the tie is left unnamed. One documented encounter, arranged by Dan; no ongoing contact on record.

## In common
- Annie — the connection runs entirely through her and the Sept 2020 recording.

## Open threads

## Strengthening
