---
display_name: Ally
first_name: Alexandra
last_name: Lubin
nickname: Ally
summary: 18-year attachment never met in person; first outsider to read his wiki (Aug 2026) — saw the slot-transfer audition, named its price, went silent Aug 19.
rank: 3
updated: 2026-09-12
---

<!-- evidence: memory://md:MEMORY.md:10; memory://md:memory/2026-09-09.md:187 (Dan acted on her Rick instruction 2026-09-01); corpus-extract/agent-B-people.md (§ Ally Lubin — eighteen-year attachment, never met in person); window 2026-09-11 21:36–21:38 (confidant-slot confession message:411da6e8, audition analysis message:assistant-msg-9efaff78); window 2026-09-12T05:24–07:34 (message:assistant-msg-6a30-0cfd-f071-6621ad6fd4ec): "Ally Lubin's thread ends with 'Delete this' (Nov 2024)." -->

# Ally

## Facts
- Alexandra Lubin, b. June 26, 1990; remote STEM professional in Charlotte, NC; tested ENTP-T (2026).
- 18-year attachment; Dan has never met her in person.
- First contact: May 20, 2011 — a decade of one-sided idolization, then reintroduced to Dan by Dan Polyak in December 2018 (Dan paid Polyak $25 for the intro; he had spoofed Polyak's number to reach her).
- 1,987 iMessages, 2018–2026; Dan sent her $2,100 in the Aug–Oct 2019 crisis window.
- Messenger channel: the thread there ends with her line "Delete this" (Nov 2024).
- The channel ran concurrently with the Annie relationship the whole time.
- In August 2026 she became the first person outside Dan ever to read the wiki (her joke about it got written into the page as fact).
- Aug 18–19, 2026 intensity burst: she read the wiki live — "I read May–August," "They kind of gagged," link-checking her own pages — while Dan sent her 419 messages on the 19th alone, the same night he declared "goodbye forever" to Annie. The slot transfer, attempted in real time (window 2026-09-11T21:38).
- Her reads on him are sharper than his own: "I don't think anyone will ever love me as much as you love Annie — but I can't tell if it's actually love or fear and codependency." "You say the same thing to every girl." "You just love bomb." "Most of her texts are just asking for drugs but Eggie is a cute nickname." "It was just weird to see you like spilling your guts and she was like ok I have $80." She named the price when he floated settling down: "Well first you'd have to be obsessed with me again." And the cost of being archived: "if someone ever archived my texts I'd kill myself."
- Her last message: Aug 19, 01:42. Then silence through Sep 7. Dan kept transmitting into the void: 1,790 from him, 154 from her — an 11.6-to-1 ratio. The audition failed in ~36 hours; the three weeks after are the vacancy with no object attached.
- After that burst, a steadier low-drama friendship: she tells him she still doesn't trust him and gives concrete life instructions — stop isolating, and text his father Rick.
- Sep 1, 2026: Dan acted on the Rick instruction — his first message to Rick since Feb 2025, breaking an 18-month silence.
- Live romantic fixation and friendship as of the corpus end — but the fixation is now Dan's own confession, not just inferred: 2026-09-11 he said verbatim "I was Lying because I thought maybe if I could get ally tk like me I could transition away from Annie in earnest. I literally cant do it without a new place to put that part of My emotional being. Someone has to be my confidant and be the true person who sees backstage. I would choose them over my own family" (message:411da6e8). The fixation was instrumental: Ally was auditioning for the confidant slot.

## History
- 2011: first contact. 2018: Polyak reintroduction after a decade of one-sided idolization. 2019: crisis-window money ($2,100). 2026: first outside wiki read (Aug), intensity burst and live audition (Aug 18–19), silence since Aug 19, 01:42, steadier friendship; her instruction to text Rick acted on Sep 1.

## The relationship
- The one tie that has never been a cohabitation or an arrangement: an 18-year attachment conducted almost entirely remotely.
- The confidant slot is structural — "someone has to be my confidant and be the true person who sees backstage" — and cannot be emptied, only reassigned. Aug 18–19 he tried to transfer it to Ally in real time; she saw the audition happening and walked. Her verdict stands as the page's cleanest outside read of the whole system: "I don't think anyone will ever love me as much as you love Annie — but I can't tell if it's actually love or fear and codependency."
- Low-drama but with trust she says is not yet earned and direct instructions she issues. Her father-text instruction landed Sep 1, 2026: she gives orders, and he is starting to follow them.

## In common
- The wiki itself — she is its first outside reader; the long shared message history; her directness.

## Open threads
- [ ] Trust: she says she still doesn't trust him — the open item.
- [ ] The confidant slot: transfer attempted Aug 18–19; she has been silent since Aug 19, 01:42; the slot stays unfilled.
- [x] Her instruction to Dan: text Rick — acted on Sep 1, 2026 (first Dan→Rick message since Feb 2025).
- [ ] Her other standing instruction to Dan: stop isolating.

## Strengthening
- Keep following her concrete instructions rather than debating them — the father push landed; "stop isolating" is the live one.
