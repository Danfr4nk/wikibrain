---
display_name: Jerel Coles
first_name: Jerel
last_name: Coles
nickname: Tuquick
summary: The man Annie left Dan for (May 2026) — never met in person; sent Dan's home address unprompted and threatened his mother.
rank: 10
updated: 2026-09-09
---

<!-- evidence: corpus-extract/agent-B-people.md (§ Jerel Wayne Coles ("Tuquick") — antagonist, never met in person); window 2026-09-09 (message:2c74b620-7c47-4f38-a55a-a111161205e8); memory://md:memory/2026-09-09.md:66; memory://md:memory/2026-09-09.md:68 -->

# Jerel Coles

## Facts
- Jerel Wayne Coles, known in the record as "Tuquick." Never met in person.
- The man Annie left Dan for — announced in a May 31, 2026 group chat.
- Dan identified him via a FOREWARN lookup on August 8, 2026.
- Recorded on tape going through Annie's phone and refusing to return it.
- Sent Dan's home address unprompted; threatened Dan's mother.
- The corpus carried him as two people ("Tuquick" and "the unnamed man") until an August 9, 2026 correction merged them.
- 2026-09-09: Dan surfaced an .m4a recording of the Aug 16, 2026 call between Jerel and Annie (Morgantown St; 15:27 Voice Memos recording, created 2026-08-16 23:54:50 EDT) and asked Muse to analyze it.
- The 2026-09-09 call analysis worked from the filed transcript — 204 turns (Coles 99, Annie 55, Dan 50); Coles admits searching Annie's phone while she slept; Annie repeatedly asks for her phone, says she wants to leave, and directly alleges he hit her (he denies it). The attempted independent transcription did not complete — no second independent transcript was produced.

## History
- May 31, 2026: Annie leaves Dan for him. Aug 8–9, 2026: identification and the corpus merge. Aug 16–19, 2026: the terminal Annie rupture runs around him. Sep 9, 2026: the Morgantown St call analysis and the transcript validation pass.

## The relationship
- No relationship with Dan — he is the antagonist of the severance: a one-sided threat vector documented in the record.

## In common
- Only Annie — and the events of May–August 2026.

## Open threads
- [ ] His unprompted address send and the threats to Dan's mother stand as the live facts; nothing resolved.

## Strengthening
