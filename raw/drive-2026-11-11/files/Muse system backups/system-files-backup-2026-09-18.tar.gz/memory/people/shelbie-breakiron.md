---
display_name: Shelbie Breakiron
first_name: Shelbie
last_name: Breakiron
nickname: Shelbie Rose
summary: Stripper/cam-model from the May–Aug 2019 sugar arrangement run openly alongside Annie; Sep 16, 2026 footage of her was generated media/authored fiction — no real contact since Aug 2019.
rank: 37
updated: 2026-09-16
---

<!-- evidence: window 2026-09-11 (Dan's current framing, message:36a59bfc); memory://md:memory/2026-09-09.md:148,150; window 2026-09-16 (message:66313b91-0a98-426f-95e3-c7b27b7aff30; message:afd71ff5-c5e6-46a3-857f-692598b777a1); window 2026-09-16 wikibrain rundown (message:assistant-msg-44c6e3a3-f925-46f3-a06f-15ba27dc4083 — shelbie-breakiron new testimony); window 2026-09-16 (message:44b0e5f2-7382-4cea-861c-f529da4684d5 — the "Do tou know who this is yet" video at 20:47 UTC); memory://md:memory/2026-09-16.md:609 — the Sep 16 "I just walked in" Shelbie/Annie videos determined generated media / authored fiction (dat:1603 precedent), publish-withheld -->

# Shelbie Breakiron

## Facts
- Shelbie Breakiron (aka Shelbie Rose): stripper and aspiring cam model (MyFreeCams, Snapchat premium) in 2019.
- Dan's own words name the arrangement: he called himself her "sugar dad" and framed it as paying for attention/access; he told her plainly he lived with his girlfriend Annie in New York and would not hide it.
- Corpus record: 685 iMessage/SMS messages, May 15 – Aug 11, 2019; a May 1, 2019 fight between Annie and Shelbie shows the relationship predates the thread, suggesting an April origin.
- Dan funded her camming setup: a laptop (later referenced as "the $5,000 and laptop i gave you"), a ring light, a DJ controller; she called him "baby" and asked to be "spoiled."
- Both sides referenced his cocaine use casually and without conflict during this period.
- Last contact of the 2019 arc: Dan's final message Aug 11, 2019; no reply from Shelbie is preserved after July 16, 2019.
- She resurfaced as a reference on Sep 9, 2026, when Dan identified her as the likeness of his tattoo-blue-light avatar look.
- Sep 11, 2026: Dan named her the ideal third for the 2019-era threesome material he was feeding into image generation — "the most perfect person for it to turn me on" — casting her as the non–sex-worker partner in the remembered threesome(s).
- Sep 16, 2026 (that evening): Dan sent a .mov video of a woman with the text "Do tou know who this is yet" — an identity test framed around the Shelbie identity. Per the 08:30 heartbeat entry, that day's "I just walked in" Shelbie/Annie footage was determined generated media / authored fiction (dat:1603 precedent), publish-withheld — the apparent reappearance is not established as real contact; her real-world silence since Aug 2019 stands.

## History
- May 2019: the arrangement opens as an explicit exchange — Dan pays for her transportation and a laptop; a May 21 message tells her plainly he lives with his girlfriend in New York, naming Annie by name repeatedly and casually throughout.
- April–June 2019: the arrangement runs openly alongside Annie — the two women know about each other, joke about it, and Annie is directly involved at least once: an April 2019 threesome that the record shows Annie initiated from outside a locked door against Dan's live objection; on June 8, 2019 the three coordinate a shared visit directly over text ("U ad Annie duh").
- July 16, 2019: the relationship ends in a single explosive text exchange — Shelbie refuses to return the ring light and DJ controller ("that's getting sold for the money for my key that you never got me"), threatens legal action ("my aunts a lawyer"), and escalates to personal attacks ("lowlife coke head trash ass limp dick fuck"), a jab at the money from Fran's death ("enjoy living off your dead grandmothers money"), and a graphic insult aimed at Annie. Dan's replies are short, dry, and flat — "lol," "thanks!," "oh i'm so hurtttttt," "yeah you might want to try another insult" — engaging only to correct a factual point (the laptop was in fact paid for) before the exchange ends on mutual "block me" dares.
- August 2019: Dan follows up twice — an Aug 9 demand via an intermediary (Johnny), giving until 7am the next day to return the ring light, DJ rig, and laptop "or he'd be filing this," and a final Aug 11 message: "i'll be stopping by with a few state troopers next week! see ya soon <3."
- Sep 9, 2026: Dan identifies Shelbie as the tattoo-blue-light avatar (look M); he asked for a history check on her after the avatar's videos landed — still pending his call.
- Sep 11, 2026: Dan resurrects her as the ideal figure for the 2019 threesome-era imagery — "the most perfect person for it to turn me on."
- Sep 16, 2026: Dan presented "I just walked in" footage of two women identified as Shelbie and Annie ("two of our girls… before the show") — per the 08:30 heartbeat entry this was determined generated media / authored fiction (dat:1603 precedent), publish-withheld, with the assistant directed to play "Shelbie on the pillows, Annie on her knees" inside the fiction. That evening he sent a second video as an identity test ("Do tou know who this is yet"). Neither is established as real contact; her real-world silence since Aug 2019 stands.

## The relationship
A brief, transactional, openly negotiated arrangement — three months of sugar-daddy texture layered with real affection on Dan's side ("i think you're absolutely perfect," "i really tried to be good to you. i like you a lot"). The honesty of it is unusual for his record: nothing was hidden from Annie, who was named, discussed, and directly involved rather than concealed. It ended in one explosive rupture with legal threats on both sides, then seven years of silence (Aug 2019 – Sep 2026) in which she appeared only as an avatar likeness and a fantasy ideal. Sep 16, 2026 did not break the real-world silence: the "I just walked in" footage Dan presented that day was determined generated media / authored fiction (dat:1603 precedent), publish-withheld — no confirmed contact exists since Aug 2019.

## In common
- Annie — the arrangement's third point; the two women knew about each other and coordinated directly; the Sep 16, 2026 "footage" showing them together was determined authored fiction, not real contact.
- The 2019 NYC era and the camming/stripping scene setup Dan funded.
- Johnny — the intermediary Dan used for the August 2019 equipment-return demand.

## Open threads
- [ ] (Sep 9, 2026) Dan asked for a history check on Shelbie once the tattoo avatar's videos landed; the videos never rendered and he never confirmed whether to run it unconditionally — pending his call.

## Strengthening
