---
domain: self
page_type: report
status: active
date_created: 2026-06-23
date_modified: 2026-06-23
sources: ["raw/self/facebook/facebook-ihatedanfrank/posts/"]
related: ["wiki/self/facebook", "wiki/interests/favorites/music", "wiki/timeline/periods/2010s", "wiki/self/location-history", "wiki/mind/synthesis/millennial-digital-witness"]
tags: [nyc-era, relationships, politics]
---

# Facebook Posts, Media & Albums (ihatedanfrank)

## Overview
Posts/ contains your_posts, archive, trash, your_photos, album/ (17 albums), media/ (~627 items: 605 jpg, gif, mp4, thumbnails). Visual life dominant. Text status updates concentrated early (2007) + scattered political later. Export snapshot Sep 2022.

## Media & Albums
~73 MB media. 17 albums + cover/timeline/profile/mobile/uncategorized.

Key albums (names + photo counts from your_photos.html):

- Electric Zoo 2010 — 4 photos (Jan 2019 album update date but content 2010). Electronic music festival. Direct tie to production (aliases), 2010 Brooklyn move (Jan 3 2010), ODESZA/JAUZ/Borgore likes era. Core music authenticity evidence.
- New Dwellings — 16 photos
- NYC — 6
- UPTOWN — 9
- Flux — 11
- Mobile uploads — 84
- Timeline photos — 40
- Profile pictures — 83
- Cover photos — 73
- Where There's Gold... — 15
- beauty in the eye of the beerholder — 28
- camwhore since I was 12 — 9 (self-deprecating/humorous title)
- twofourtyeightam — 17
- Instagram Photos / Nintendo Switch Share / PlayStation Network — 0 or low

Media files stored in posts/media/ with folder names like ElectricZoo2010_K8jOgsBANw, NewDwellings_7WHofGTjfQ. Limited extractable captions (image heavy); dates from album updates cluster 2018-2022 with 2010/2013-14 anchors.

## Early Text Posts / Status Updates (2007 origin)
your_posts_1.html reveals raw 2007- voice immediately post-account creation (first Jan 20 2007):

- Jan 20 2007: "currently swooning over the new FOB"
- Jan 25: "skiing for the weekend"
- Feb 5: "in New York City to see Fall Out Boy at TRL"
- May 7: "glad he saw Say Anything instead of studying for finals"
- May 10: "in West Palm Beach getting ill."
- Jul 21: "reading Harry Potter nonstop"
- Jul 26: "dead"
- Jul 30: "calculating infinity"
- Aug 6: "the truth"
- Aug 11: "getting his wisdom teeth out/playing xbox live for the next week"
- Aug 17: "in paaain"
- Oct 1: "listening to Tha Carter 3"
- Oct 2: "spun."
- Oct 3: "slaying on halo"
- Oct 8: "the dreamer, and you are the dream."
- Oct 10: "playing the new Radiohead album on loop"
- Oct 18: "in love with the new Say Anything disc"
- Nov 12: "is so excited for Super Mario Galaxy"
- Nov 13: "is lvl'ing"
- Nov 25: "is the patron saint of liars and fakes"
- Nov 26: "is a New Jersey success story"

Themes: Music obsession (FOB, Say Anything, Radiohead, Lil Wayne), gaming (Halo, Xbox, Mario Galaxy, lvl'ing), self-deprecating humor ("dead", "in paaain", "spun", "patron saint of liars and fakes"), NYC aspiration, teen/early adult life. This is pre-armor raw material that seeds "ihatedanfrank" ironic persona + groups posts (scam awareness + Say Anything nerdery).

## Later Posts / Archive (political + commentary)
your_posts / archive.html samples:

- Feb 9 2020: "there’s not really any excuse for losing an election to someone with these credentials. this would have been considered a politicians dream opponent. fuck tom perez, nancy pelosi, and chuck schumer. leftist is bestist."
- Jan 11 2021 (Timeline photos): "It’s never been edgy to be a conservative"
- Jan 15 2021: "Patriot or pussy?"

Consistent with likes (AOC, archived Trump WH, political philosophy) and skeptic stance.

## Analysis & Connections
- **Music thread:** 2007 FOB/Say Anything -> 2010 Electric Zoo photos -> 2012-2014 likes (Anamanaguchi to Borgore/ODESZA) -> 2014-2019 events (raves/DJ showcases/Freddie Gibbs) -> 2019 hiphop adds. Authentic non-ironic spine through ironic public layer.
- **Persona leak:** Humorous album titles ("camwhore since I was 12", "beauty in the eye of the beerholder") + early pain/status ("in paaain", "dead", "spun") show self-deprecation as consistent.
- **Visual as prosthesis:** 600+ media primary documentation method (cross location-history, periods). Photos > text for 2010s life record.
- **Millennial witness:** 2007 pre-smartphone text (Harry Potter, Halo, FOB TRL) to 2021 political image posts + tracked off-FB life. Bridge artifact.
- **No major caption text** in parses (images carry the data); metadata + album names + known events sufficient.

Cross [[wiki/self/facebook]], [[wiki/interests/favorites/music]], [[wiki/timeline/periods/2015-2016-annie-relationship-start]], [[wiki/mind/synthesis/millennial-digital-witness]], [[wiki/self/location-history]].

## Sources
raw/self/facebook/facebook-ihatedanfrank/posts/ (your_posts_1.html, archive.html, your_photos.html, album/*.html, media/*). Cleaned 2026-06-23.

## Related
[[wiki/self/facebook]]
[[wiki/interests/favorites/music]]
[[wiki/timeline/periods/2015-2016-annie-relationship-start]]
[[wiki/mind/synthesis/millennial-digital-witness]]
