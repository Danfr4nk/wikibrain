---
domain: self
page_type: entity
title: "Tattoos"
status: active
date_created: 2026-07-14
date_modified: 2026-07-19
knowledge: mixed
sources:
  - raw/self/captures/2026-07-14-tattoo-list.md
  - raw/self/captures/2026-07-15_195532_tattoo-artist.md
  - raw/self/message-csv/MASTER_MESSAGES_DB_DUMP.csv
  - raw/self/dox-scan/all_imessages_complete_dump.txt
  - raw/self/dox-scan/dan tom 2010 2022.txt
  - raw/self/facebook/facebook-ihatedanfrank/messages/inbox/chrisredmond_ewkx6qfqha/message_1.html
related:
  - wiki/self/ancestry
  - wiki/interests/favorites/music
  - wiki/interests/favorites/music/artists/kanye-west
  - wiki/interests/music/concepts/lyrics-as-timbre
  - wiki/people/annie-ulmer
  - wiki/people/tom
  - wiki/people/emaly-minerd
  - wiki/people/kristin
tags: [personality-profile, digital-footprint]
---

# Tattoos

Dan's body art is, as far as the corpus documents, entirely cultural
reference rather than abstract design — every known piece points at a
specific record, band, or artist rather than a generic symbol. The list
below starts with six pieces Dan named directly (2026-07-14); it is not
presented as complete, and further pieces should be added as they surface.

## The list

| Design | Style/reference | Placement | Artist/shop | Date |
|--------|------------------|-----------|-------------|------|
| Misfits skull in a pizza slice | Custom mashup of the Misfits' Crimson Ghost mascot and a pizza slice | Forearm, ~3"x1.5" | Chris Redmond (custom drawn), Uniontown-area | 2018-10-13 |
| Misfits logo (green lettering) | Band's own logo lettering, unmodified | Forearm, beneath the pizza slice | Chris Redmond | 2018-10-22 |
| Kanye West *808s & Heartbreak* KAWS bear | KAWS's reworked "Dropout Bear" from the *808s* era art/toy campaign | Unknown | Unknown | By Sept 22, 2025 |
| Radiohead bear | The "Modified Bear" / Stanley Donwood-era *Kid A* artwork | Unknown | Unknown | By Oct 27, 2018 |
| Old school traditional rose | American traditional flash | Brooklyn, NY | Ian Weidrick, Allied Tattoo (Brooklyn) | Possibly March 8, 2019 |
| Gravestone | Memorial-style piece | Brooklyn, NY | Ian Weidrick, Allied Tattoo (Brooklyn) | Undocumented |
| Flapper girl | American traditional flash (pin-up style) | Brooklyn, NY | Ian Weidrick, Allied Tattoo (Brooklyn) | Undocumented |

## Misfits: skull in a pizza slice, and a second Misfits piece

The earliest well-documented piece, and now precisely dated via a
direct Facebook Messenger thread with the artist: Dan first messages
**Chris Redmond** — a Uniontown-area artist (his own messages place him
near Cheat Lake and Hopwood, "coming down the mountain" for
appointments) — on October 12, 2018, explicitly framing it as the
first of "4 or 5 other pieces" he wants done before turning 30 on
November 1, and the pizza-slice piece is inked the next day, October
13, on his forearm at roughly 3" x 1.5". In a November 27, 2018
exchange with [[wiki/people/emaly-minerd|Emaly Minerd]] — who
compliments the tattoo and asks directly why he chose a pizza slice
over the band's standard imagery — Dan explains the design process: he
didn't want the conventional Misfits "Crimson Ghost" variant "where it
looks like it's in a coffin with the arms folded," found a pizza-slice
reinterpretation of the skull online, and had Chris draw it up custom
for him. Elsewhere in the corpus (an August 2018 message and a 2018
exchange with [[wiki/people/tom|Tom]]) Dan self-mockingly frames the
piece as evidence of being "a scumbag... immature" for getting it — "a
literal misfits tattoo" is invoked more than once, by Dan and by
others, as shorthand for arrested-development, still-into-the-
same-things-at-30 self-deprecation, rather than pure enthusiasm.

A **second, previously undocumented Misfits piece** follows quickly:
on October 18, 2018, Dan asks Chris to ink a green-lettering Misfits
band-logo design directly beneath the pizza slice on the same forearm,
explicitly calling it "this most cliché tattoo" — done October 22.
Chris, unprompted, volunteers that he "listen[s] to the misfits, still"
and declines to modify the logo beyond the band's own lettering,
calling it "all unique to the band."

## Kanye — *808s & Heartbreak*, via KAWS

Disclosed to Tom on September 22, 2025, with a specific and fairly
calculated rationale: "Did I ever tell you that I specifically got the
KAWS version off my Kanye tattoo. So that when he inevitably crashed out
I could say it was just a KAWS tattoo." The piece is the KAWS-reworked
"Dropout Bear," the mascot artist KAWS redesigned for Kanye's *808s &
Heartbreak* era promotional campaign and toy line — a real, specific,
dated collaboration, not a generic Kanye reference. The reasoning is
worth taking seriously as its own data point: Dan describes deliberately
choosing the art-world-adjacent, one-step-removed version of a tribute to
a musician with a well-documented pattern of public instability, so the
tattoo could be recontextualized ("just a KAWS tattoo") if Kanye's public
standing collapsed further — a hedge built into the ink itself. Tom's
reply, "Very old school Kanye," and Dan's own framing both treat this as
Kanye's more respected creative period, not a current-events endorsement.

## Radiohead: the bear

Documented by October 27, 2018 ("There's a pic of my Radiohead tattoo"),
matching the "Modified Bear" — the Stanley Donwood-designed mascot
associated with the *Kid A*/*Amnesiac* era, which Dan names directly in
the same conversation as his favorite Radiohead album ("I'm a Kid A guy
but on a rainy day... you gotta turn on OK Computer"). The piece recurs
as a running bit in Dan's own self-presentation — in a September 2019
message he jokes that his favorite Radiohead song is "Karma Police," the
one song the band itself refuses to play live, framing his own taste as
slightly contrarian even within his own fandom.

A September 24, 2025 exchange with [[wiki/people/kristin|Kristin]] adds a
genuinely self-aware complication to the whole piece's meaning. In the
middle of a long, unguarded late-night conversation about performing
identity for other people ("Why I am doing the stupid things I am doing.
Painting my nails, asking performative Van Halen questions... Getting
Radiohead tattoos"), Dan admits the fandom behind the tattoo is thinner
than the ink suggests: "Getting Radiohead tattoos when I like... 3, 4
songs total." Read together with the Misfits self-mockery above, this
suggests at least some of the tattoo choices are consciously understood,
by Dan himself, as identity performance rather than pure fan devotion —
worth holding onto as a caveat for reading the whole list, not just this
one piece.

## The sleeve ambition starts in Uniontown, not Brooklyn

The "full sleeve" idea documented below as a Brooklyn-era pursuit
actually originates three months earlier, with Chris Redmond: by
October 16, 2018 Dan is already asking to "start discussing concept for
a sleeve," and by November 25 he's explicit about the aesthetic —
"working it into a full sleeve of Old school/American traditional
motifs" — buying reference books from Amazon by November 27 ("I'm
finding it easier to evolve the vague ideas... into more specific
concepts... wish I would have started getting these tattoos years
ago"). On November 30, 2018 he sends Chris a **traditional rose**
reference image, wanting it placed near the existing forearm work; by
December 20 Chris confirms it's "always do-able," and the thread ends
there without a completed-session message. Whether this Uniontown rose
concept became the "old school traditional rose" Ian Weidrick executed
in Brooklyn roughly ten weeks later (March 2019, below) — i.e. the plan
moved with Dan to NYC before being realized — or whether it is a
separate, unfinished piece is not established; see Gaps.

## The traditional pieces: rose and flapper girl

On March 8, 2019, Dan texted [[wiki/people/annie-ulmer|Annie]] with
visible excitement about getting "a real tattoo" at a shop he describes
as specializing in "traditional tattoos" — American traditional flash
work, the genre both the rose and the flapper girl belong to. Annie's
reaction to the finished photo ("Omg that's fu\*king awesome... I love
it... Very very nice") and her comparison question — "Do you know how
long that would've taken **Chris at the edge** to do? LOL" — names a
second tattoo reference point (a different or possibly overlapping artist
named Chris, associated with a shop called "The Edge") against which this
this session's speed was being measured; Dan confirms the piece "took an hour
and a half total."

A July 15, 2026 capture resolves the artist and location for the traditional
cluster: Dan names **Ian Weidrick of Allied Tattoo in Brooklyn** as the artist
behind his "Brooklyn tattoos" — the flapper girl, the rose, and the gravestone.
This places all three pieces firmly in Dan's NYC era and confirms they share a
single artist and shop, though it does not settle whether they came from one
session or several. It also means "Chris at the Edge," the reference point in
Annie's March 2019 message, was a comparison shop, not the artist who did the
work — Weidrick/Allied was. Whether this specific session produced the rose, the
flapper girl, or both is still not established in the corpus — traditional flash
sessions commonly bundle multiple smaller pieces, so it's plausible more than
one came from the same visit, but that's inference, not confirmed fact.

## Gaps

The gravestone piece now has an artist and location (Ian Weidrick, Allied
Tattoo, Brooklyn) but still no date or corroborating message-corpus trace.
Body placement is unknown for every piece on this list; the corpus documents
*what* and often *when* and *who drew it*, but rarely *where on the body*. The full
tattoo count is unknown — Dan's own framing ("just to start you off")
indicates this list is a beginning, not an inventory, and this page
should be extended as further pieces are named or surface in raw sources.
Whether "Chris Redmond" (the Misfits artist) and "Chris at the Edge"
(Annie's March 2019 comparison reference) are the same person now reads as
unlikely rather than merely unconfirmed: Chris Redmond's own messages place
him working near Cheat Lake and Hopwood, PA — the Uniontown area, not NYC —
making him a plausible but unconfirmed match for a Uniontown-adjacent "Edge"
location rather than any Brooklyn shop; the March 2019 traditional pieces
themselves were done by Ian Weidrick at Allied Tattoo, not by either Chris.
Whether the November 2018 rose concept discussed with Chris Redmond ever
got inked in Uniontown, was carried to Brooklyn and became the Weidrick
rose, or remains a separate unfinished piece is unresolved — the Chris
Redmond thread ends December 20, 2018 without a completion message, and
the Weidrick rose follows about ten weeks later.

## Related

[[wiki/self/ancestry]] · [[wiki/interests/favorites/music]] · [[wiki/interests/favorites/music/artists/kanye-west]] · [[wiki/interests/music/concepts/lyrics-as-timbre]] · [[wiki/people/annie-ulmer]] · [[wiki/people/tom]] · [[wiki/people/emaly-minerd]] · [[wiki/people/kristin]]
