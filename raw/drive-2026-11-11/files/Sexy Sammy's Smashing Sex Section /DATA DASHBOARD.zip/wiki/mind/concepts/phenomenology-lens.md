---
domain: mind
page_type: concept
status: stable
date_created: 2026-06-22
date_modified: 2026-07-19
sources:
  - raw/self/phenomenology-lens/PHENOMENOLOGY_LENS.md
  - raw/self/dox-scan/fullcombo_2.txt
  - raw/self/dox-scan/Dan Profile.txt
  - raw/self/dox-scan/dan_comprehensive_profile.docx
  - raw/self/context-core/CONTEXT_CORE_EXPANDED.md
  - raw/self/facebook/facebook-ihatedanfrank/
  - raw/self/dox-md/operating_manual.md
  - raw/self/dox-md/LIFE_EVENTS_CALENDAR.md
  - ingest/PHENOMENOLOGY_LENS.md
tags: [addiction-recovery, relationships, trauma-bond, grief, forensic-analysis]
connections:
  - page: wiki/people/annie-ulmer
    type: contextualizes
    claim: "The 'Annie Loop' is the lens's interpretive rendering of the terminal phase — withdraw → raw texts → vague apology → escalation → shutdown → return — correlating with the 94 documented burst events uniformly preceded by her silence."
  - page: wiki/people/alexis-armel
    type: contextualizes
    claim: "The lens names the 2009–15 Alexis collapse as the second encoding event of the trauma memory — the seed, after 2005, of the axioms 'intimacy leads to abandonment' and 'loyalty is always conditional.'"
  - page: wiki/people/rick-frank
    type: contextualizes
    claim: "The 2004–05 parental rupture is the lens's first encoding event — the origin of the Si-carried pattern by which old betrayals get replayed onto new situations without warning."
  - page: wiki/mind/concepts/conflict-architecture
    type: parallels
    claim: "The self-sabotage loop (insight → rupture → more insight) is the lens-language rendering of the conflict engine's no-halt-condition mechanics — same machine, metaphorical register."
  - page: wiki/mind/concepts/attachment-model
    type: contextualizes
    claim: "The relational loop (hunger → fusion → contamination → amputation) is the interpretive overlay on the attachment model's quantified base — the love-to-request sequences and burst events read as narrative."
  - page: wiki/self/context-core
    type: component-of
    claim: "The lens is formally subordinate to the behavioral spine: an interpretive overlay that must yield to context-core's hard counts and timelines wherever they disagree — the subordination itself is the load-bearing rule."
---

# Phenomenology Lens

The Phenomenology Lens is an interpretive overlay synthesized on top of the behavioral record. It provides a generative phenomenology designed to add metaphor-rich context to the architecture, but it is explicitly not a repository of documented fact. It should be reached for deliberately when an interpretive reading is desired, and it must never be loaded ambiently during standard analysis sessions or Grok subagent tasks.

## Strict Usage Rules

This lens is strictly subordinate to the documented behavioral spine established in [[wiki/self/context-core]]. Whenever this lens and the behavioral spine disagree, the spine takes absolute precedence. For example, the chemical stack must always be treated as engineered architecture per the spine, overriding any metaphorical framing of an "Addiction Engine" found here. This lens should be applied deliberately for interpretive color — such as analyzing early Facebook posts or parsing the genesis and collapse periods of the primary relationship — but it must never be used as primary evidence. The metaphors contained within it act as coherence-generators that may read as deep self-knowledge, but they are partially a product of motivated coherence.

## Core Frame: Life as a Self-Building Project

The central frame of this lens treats Dan's life as a self-engineering project. He is a high-intellect, high-impulsivity person who continuously builds frameworks to impose order on internal chaos, driven by a need to make meaning out of collapse. The self-image underneath this is that of a wounded person who turns pain into elaborate systems. This framing is most useful as a read of his self-image — it captures the way he narrates himself, in the language of systems and architecture.

## Cognitive Function Mapping

The lens assigns plain-language readings to the cognitive functions to explain how the system behaves:

The lead function, Ti, builds frameworks from first principles and trusts only what he can simulate in his own head. Under this function, truth is whatever holds up under stress-testing, not whatever wins social consensus. The exploratory function, Ne, scans for patterns and edge cases rather than spraying randomly. The memory function, Si, holds a vast, vivid record of past detail and also carries the trauma material — it is the seat of the pattern by which old betrayals get replayed onto new situations. The feeling function, Fe, is weak but craved: he wants emotional connection yet distrusts its irrationality, so he uses social charm tactically, which gives him high social intelligence but low emotional trust. Finally, a weak intuitive leak produces pattern-overfitting and a tendency to read coincidence as fate. The documented method of "Dan's Law" is the disciplined countermeasure to that specific leak.

## The Trauma Memory

The dossiers describe a trauma-driven pattern in which memory of past betrayals gets projected onto present situations and can take over his reactions without warning. This pattern was seeded by two documented events: the parental rupture of 2004–2005 and the collapse of the relationship with [[wiki/people/alexis-armel|Alexis]] between 2009 and 2015. Within the lens, it encodes three axioms: intimacy leads inevitably to abandonment, loyalty is always conditional, and emotional security is a functional illusion. It maps directly onto the behavioral spine's documented trauma nodes and paternal-authority wound, detailed in [[wiki/self/context-core]] and [[wiki/mind/synthesis/vertical-authority-skepticism]].

## Four Recurring Loops

The lens models four repeating patterns. These are interpretive and must be cross-referenced with the documented spine.

The **relational loop** runs hunger → fusion → contamination → amputation, and maps to the core attachment data, including the 145 love-to-request sequences and 94 burst events in the behavioral spine.

The **self-sabotage loop** runs insight → rupture → more insight; understanding the pattern feeds the next rupture, which aligns with the mechanics in [[wiki/mind/concepts/conflict-architecture]].

The **addiction loop** runs craving → high → crash → analysis. It is critical to treat this as metaphor only: the chemical stack of Suboxone, strategic cocaine, and nicotine is engineered architecture per the spine, and this lens must not recode it as pathology.

The **shame loop** runs vulnerability → shame → weaponized into precise intellectual output → detachment. The resulting sharp, legalistic language shows up in his forensic writing style and the rigid glyph structures of the CATO bootloader.

## The Annie Loop (Historical)

The "[[wiki/people/annie-ulmer|Annie]] Loop" describes the relational cycle seen during the terminal phase of the primary relationship, which formally closed on June 1, 2026. The loop followed a set sequence: Annie would withdraw, prompting Dan to express pain in long, raw texts. She would answer with vague apologies or declarations of inadequacy, which made him escalate. Annie would then either shut down or accuse him of suffocating her. His moral absolutism kept him engaged rather than leaving, and Annie would eventually return for emotional replenishment, resetting the cycle.

This interpretive loop correlates with documented evidence, specifically the 94 burst events that were uniformly preceded by deliberate silence from her. The gaslighting layers that amplified it are documented in [[wiki/timeline/events/eli-incident]].

## Supporting Patterns

The lens uses a few plain readings for complex behavior. Starving for affection while refusing to leave describes the pattern of rewarding absence with loyalty and treating sheer endurance as proof of love. Shame-into-weaponry describes how shame gets converted into hyper-precise, legalistic language before the system retreats into detachment. Gallows humor as pressure-release accounts for the use of recursion and irony to metabolize grief. Finally, silence-and-burst cycles describe the behavioral physics of the relationship: the silence is the operative content, and the explosion is the predictable reaction to that vacuum.

## Relation to the Documented Behavioral Spine

This lens adds value by providing generative metaphors for patterns that are already quantified in the raw sources, and it offers a coherent narrative frame for the architecture described across the raw profile documents. However, it must explicitly yield to the spine whenever a contradiction arises. Any claim within this lens that contradicts the hard counts, timelines, or primary records must be overridden by the empirical data in [[wiki/self/context-core]].