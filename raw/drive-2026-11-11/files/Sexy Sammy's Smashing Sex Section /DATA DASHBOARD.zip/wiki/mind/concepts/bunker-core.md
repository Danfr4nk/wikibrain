---
domain: mind
page_type: concept
title: "Bunker Core"
status: active
knowledge: mixed
date_created: 2026-07-20
date_modified: 2026-07-20
sources:
  - "raw/self/dox-md/Gemini-_18.md"
  - "raw/self/dox-md/_Dan Frank's Digital Forensic Inventory .md"
  - "raw/self/dox-md/_Openclaw Agent Setup and Data .md"
  - raw/self/dox-md/MAX_PRIME.md
tags: [ai-collaboration, digital-footprint, career]
connections:
  - page: wiki/timeline/periods/2025-collapse
    type: component-of
    claim: "Bunker Core is named in Dan's own 2026 'Bifurcated Daily OS' self-description as one half of a two-track life — survival work (BFS Foods, Suzanne's property operations) alongside a self-built 'High-Autonomy Technical Stack.'"
  - page: wiki/mind/synthesis/ai-collaborative-analysis
    type: instantiates
    claim: "Local, self-hosted chat.db forensics is agent tooling that extends the same evidentiary-verification principle documented elsewhere in Dan's AI use — raw message history as proof against gaslighting, automated rather than manual."
  - page: wiki/work/tech/vibe-coding-games
    type: co-occurs
    claim: "Bunker Core, the iMessage Analysis Toolkit, and the vibe-coded games all belong to the same 2025–26 tool-building wave — the period context-core logs as 'agent/AI build work, music reactivation.'"
---

# Bunker Core

Bunker Core is the name Dan has given to a self-built, local-first
technical stack — SQLite-based forensics run directly against his own
`~/Library/Messages/chat.db`, framed in his own notes as "Epistemic
Verification" and a "cold-data ledger." It sits alongside a Gumroad
product, the iMessage Analysis Toolkit (launched February 2026), as the
concrete, dated output of what he calls his 2026 "High-Autonomy
Technical Stack" — one half of a self-described "Bifurcated Daily OS,"
the other half being survival work: [[wiki/work/bfs-foods|BFS Foods]]
counter shifts and property management alongside his mother
[[wiki/people/suzanne-frank|Suzanne]]. In his own framing, the return to
Uniontown in early 2025 was a deliberate trade — leaving expensive,
institutionally-dependent New York life for a lower-cost base from
which to build sovereign, local tooling.

## What it is, and what it isn't

The primary, verifiable fact is narrow: a local database-forensics
practice built on his own message history, plus a shipped commercial
tool derived from the same skillset. Beyond that, "Bunker Core" starts
functioning as much as a name for a psychological posture as for a
piece of software — an AI-generated forensic-inventory document
(unprompted, not primary self-report) elaborates it at length as an
"epistemic fortress," a system built so that "no one, not even a
partner or a platform, can rewrite his narrative without a SQL
receipt." That framing is interpretive, not something Dan states about
himself in the retained corpus, and the same document flags its own
double edge without prompting: the same architecture that protects
against being gaslit — facts that don't change based on who's shouting
loudest — also risks functioning as insulation, "a wall of text that
prevents external entry," optimizing for accuracy over access. Treat
the software as documented fact and the fortress framing as a plausible
but AI-authored interpretive overlay, not a claim Dan has made in his
own words anywhere in the corpus.

## Corpus record

| Metric | Value |
|---|---|
| Named alongside | iMessage Analysis Toolkit (Gumroad, launched Feb 2026) |
| Core method | Local SQLite forensics on ~/Library/Messages/chat.db |
| Self-framing | Half of a "Bifurcated Daily OS": survival work + technical sovereignty |

**Gaps:** whether Bunker Core is a single coherent codebase or a loose
label for an evolving set of scripts; any third-party involvement,
collaborators, or public release beyond the Gumroad toolkit; whether
the project is still active past its 2026 documentation window.
