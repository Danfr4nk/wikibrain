---
domain: mind
page_type: profile
title: "INTP — The Cognitive Function Stack"
aliases: ["Ti-Ne-Si-Fe", "cognitive functions"]
status: stable
importance: high
date_created: 2026-07-13
date_modified: 2026-07-13
sources:
  - raw/self/dox-md/FULL PROFILE 2026.md
  - raw/self/dox-scan/Dan Profile.txt
  - raw/self/context-core/CONTEXT_CORE_EXPANDED.md
related:
  - wiki/mind/profile/index
  - wiki/mind/profile/enneagram-5w4
  - wiki/mind/concepts/forensic-method
  - wiki/mind/concepts/conflict-architecture
  - wiki/mind/concepts/phenomenology-lens
tags: [personality-profile, trauma-bond, addiction-recovery]
connections:
  - page: wiki/interests/roman-republic
    type: evidenced-by
    claim: "The great-man-theory tag cluster on the 2024 Caesar/Alexander/Oppenheimer reads is corpus evidence for the singular-figure-versus-the-system self-myth this profile documents."
  - page: wiki/people/elizabeth-eleanor
    type: evidenced-by
    claim: "A July 2013 message — 'as an INTP and heavily introverted, logic-based dude...i can't see myself flourishing in AA/NA' — is the earliest dated primary-source instance of Dan self-typing INTP, used there to explain a rejection of group-based recovery in favor of self-directed reflection."
  - page: wiki/interests/film-canon
    type: evidenced-by
    claim: "The Taxi Driver / King of Comedy self-portrait pair in the film canon is the same hyperaware-observer self-myth chosen as a mirror in cinema."
---

# INTP — The Cognitive Function Stack

Dan types INTP on every pass, and the function measurements are extreme
enough to matter more than the four-letter label: dominant introverted
thinking near ceiling (Ti 96% latent / 95% aptitude), strong extraverted
intuition (Ne 84% latent / 80% valuing), an unusually loud introverted
intuition for an INTP (Ni 84% latent — the profile's single biggest
irregularity), middling introverted sensing (Si 57%), and an extraverted
feeling function that is barely valued at all (Fe 10% valuing / 46% active).
The dossiers stress that this is not the cheerful "scientist" INTP of type
descriptions: filtered through the 5w4 sx/sp emotional structure
([[wiki/mind/profile/enneagram-5w4]]), every function runs darker.

| Function | Score | Plain reading |
|----------|-------|---------------|
| Ti (dominant) | 96% latent / 95% aptitude | Lead logic; builds frameworks from first principles |
| Ne (auxiliary) | 84% latent / 80% valuing | Exploratory; scans for patterns and edge cases |
| Ni (leak) | 84% latent | Weak intuition; pattern-overfitting, reads coincidence as fate |
| Si (tertiary) | 57% latent | High-fidelity memory; also carries the trauma material |
| Fe (inferior) | 10% valuing / 46% active | Feeling function, weak but craved; used tactically |

## Ti — the existential scalpel

Dominant Ti is not applied to mechanical puzzles but to the self, social
systems, and the cosmos. It engineers frameworks from first principles and
defines truth as "a system that holds under recursive collapse, not social
consensus" — he trusts only what he can simulate in his own head, running
"internal simulation labs" where ideas, relationships, and futures are
stress-tested. The scalpel strips social niceties, dogma, and comforting
illusion on principle, and follows logical chains to their conclusions even
when the conclusions are psychologically devastating. Injustice registers as
logical inconsistency before it registers as feeling. The documented outputs:
philosophical nihilism as default resting state, compulsive system
deconstruction (legal, bureaucratic, social conventions exposed as arbitrary
machines), and the evidence-first analytical practice formalized in
[[wiki/mind/concepts/forensic-method]].

## Ne — the sniper scout

Auxiliary Ne is described as *selective divergence*, not brainstorming
spray: it explores conceptual space "like a sniper scout," projecting
implications ahead and generating edge-condition hypotheses that Ti then
weaves into arguments. It powers the cross-domain synthesis visible
everywhere in the corpus — politics read with the same tools as music trends,
geology-with-mythology-style combinations, the anomaly clustering behind
Dan's Law. Under stress it inverts into a paranoia generator, feeding the
5-core's fear with endless what-if scenarios and producing the documented
analysis paralysis: "conceptualize everything before acting."

## Ni — the leak

An INTP is not supposed to run this much introverted intuition. The 84%
latent Ni is flagged in the sources as a "shadow strategist" that leaks
mythic overfitting into the system: over-ascribing cosmic meaning to
coincidence, weaving events into a fated grand narrative, feeling the
"symbolic convergence" of a pattern before the evidence justifies it. This is
the engine of the pattern-apophenia risk, and the corpus treats
[[wiki/mind/concepts/dans-law]] as the deliberately installed countermeasure
— a formal procedure for stripping mythic gravity off genuine anomaly
clusters. The Ni leak also explains the fatalistic tone the Socionics reading
picks up ([[wiki/mind/profile/socionics-and-attitudinal]]).

## Si — memory and the trauma pattern

Tertiary Si maintains the vast high-fidelity archive — the minute recall of
years-old details that makes the whole self-documentation project (and this
wiki) possible. It is also where the old betrayal pattern lives: memory of
past betrayals (the 2004–05 parental rupture, the Alexis collapse) gets
projected onto present situations and can take over his reactions without
warning. The **Ti-Si loop** is the type's signature pathology and is well
documented in
the record: bypassing exploratory Ne to cycle between internal logic and past
experience — replaying failures in exhaustive detail, nocturnal schedule
displacement, rigid comfort-food ritual alongside broader physical neglect,
sensory hypochondria. The loop's interpretive elaboration lives at
[[wiki/mind/concepts/phenomenology-lens]].

## Fe — the feeling function, weak but craved

Inferior Fe is the weakest point and the most consequential. The need it
represents — connection, emotional truth, validation — is desperately real
(especially with the sx instinct), but the function itself is distrusted as
irrational and deployed tactically, "like an actor uses makeup": high social
intelligence, low emotional trust. Documented consequences: rejection
hypersensitivity that can turn a minor slight into withdrawal or explosive
sarcasm; immature eruptions under stress; genuine blindness to hierarchy,
reputation, and etiquette (identical irreverence toward authority and
subordinates); and the "invisible genius" outcome — high output, low
recognition, no networking instinct. In relationships, Fe-inferior is a
prime mover of [[wiki/mind/concepts/conflict-architecture]]: emotional bids
arrive as claim-shaped propositions and get adjudicated instead of met.

## The stack as one machine

Run together, the functions produce the behavioral record with uncomfortable
precision: Ti supplies the standard of proof, Ne supplies the anomaly
candidates, Si supplies the archive to check them against, Ni supplies the
narrative gravity that must be actively resisted, and Fe's absence removes
the social brake that would otherwise soften conclusions for company. That is
the forensic default, derived rather than chosen. The same arithmetic
explains the costs: a mind that can prove things cannot stop litigating
([[wiki/mind/concepts/conflict-architecture]]), and a memory that cannot
forget keeps every wound current
([[wiki/mind/concepts/attachment-model]]). The self-myth the stack
sustains — the singular perceiver against a system too dull to see what
he sees — also shows in what he chooses to consume: the great-man shelf
of the 2024 [[wiki/interests/roman-republic|Roman-Republic year]]
(Caesar, Alexander, Oppenheimer, all tagged great-man-theory) and the
Taxi Driver / King of Comedy self-portrait pair in his
[[wiki/interests/film-canon|film canon]] pick out the same figure in
history and cinema.

**Gaps:** function scores are AI-inferred from corpus behavior, not from a
proctored instrument; the Ni measurement in particular has no independent
confirmation; no data on how the stack presents post-closure (all sources
pre-date June 2026).
