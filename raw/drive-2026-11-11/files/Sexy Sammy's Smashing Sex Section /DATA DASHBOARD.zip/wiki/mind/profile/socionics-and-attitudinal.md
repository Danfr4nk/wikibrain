---
domain: mind
page_type: profile
title: "Socionics ILI-Ni, Attitudinal Psyche & Alignment"
aliases: ["ILI", "Balzac", "the Critic", "FLEV", "VLEF", "Chaotic Neutral"]
status: stable
date_created: 2026-07-13
date_modified: 2026-07-13
sources:
  - raw/self/dox-md/FULL PROFILE 2026.md
  - raw/self/dox-scan/Dan Profile.txt
related:
  - wiki/mind/profile/index
  - wiki/mind/profile/intp
  - wiki/mind/profile/enneagram-5w4
  - wiki/mind/synthesis/political-psyops
tags: [personality-profile, ai-collaboration, music-production]
connections:
  - page: wiki/mind/concepts/forensic-method
    type: evidences
    claim: "The ILI-Ni 'Ni leak' — pattern-hunting that runs more prophecy than a textbook INTP's Ti-Ne — is the trait-level substrate for the anomaly-detection engine the forensic-method page names as Dan's cognitive default."
---

# Socionics ILI-Ni, Attitudinal Psyche & Alignment

Three secondary systems round out the profile, and each captures something
the MBTI and Enneagram miss: Socionics explains the *fatalism*, Attitudinal
Psyche explains the *interrogation style*, and the D&D-derived moral
alignment — treated by the sources as a genuine psychological stance, not a
game statistic — explains the *relationship to rules*.

## Socionics: ILI-Ni, "the Critic" / "Balzac"

An MBTI INTP "should" map to Socionics LII. Dan instead correlates with
**ILI, intuitive subtype (ILI-Ni)** — and the mismatch is informative,
because ILI leads with introverted intuition rather than thinking. This is
the same irregularity the function measurements catch as the 84% Ni leak
([[wiki/mind/profile/intp]]): the system runs more prophecy than a textbook
INTP.

**Ni base — the inevitability engine.** Where Ne asks what *could* happen,
Ni concludes what *will*. The documented presentation: long periods of
motionless private contemplation punctuated by sudden bursts of visionary
clarity; eyes that "look through the present into the future"; predictions
that consistently forecast decline, decay, and systemic failure; comfort
with apocalyptic frames because the worst case has already been simulated.
This is the engine behind the corpus's structural-decay politics (Post-Pax
Americana, gerontocracy, "Trumpian Singularity" —
[[wiki/mind/synthesis/political-psyops]]) and behind the crisis stoicism the
dossiers note: when disaster actually strikes, he is calm, because Ni
already ran the simulation ("I knew this would happen").

**Te creative — the pragmatic externalizer.** Unlike the LII's Ti
structure-building, the ILI uses extraverted thinking to *criticize external
systems and engineer working replacements*: dry, biting, fact-anchored
humor; scathing demolition of existing institutions paired with detailed
construction of alternatives. The corpus instantiation is exact — the same
person who deconstructs institutional narratives builds functioning
replacement systems: the exocortex bootloaders, agent pipelines, message
tooling, and this wiki ([[wiki/mind/concepts/exocortex]],
[[wiki/work/tech/imessage-tooling/overview]]).

**Fi mobilizing — the passive yearning.** The ILI values deep personal
bonds but cannot initiate them: waits for others to break through the walls,
shows affection through remembered details and support for the other's
projects rather than warmth, and becomes vulnerable only with those who
prove themselves through persistence. This is the Socionics rendering of the
Witness need ([[wiki/mind/profile/enneagram-5w4]]).

## Attitudinal Psyche: FLEV and VLEF

The sources record two readings, treated as complementary rather than
contradictory:

| Type | Name | Reading |
|------|------|---------|
| FLEV | "The Alchemist" | Control via transformation — lives at the intersection of taste, transformation, and symbolic power; the sensualist who transmutes raw material (sound, chaos, wounds) into engineered artifacts |
| VLEF | "The Inquisitor" | Ontological authority via interrogation — questions as weapons; any belief system that cannot withstand probing is discarded |

The Alchemist face is the producer: sub-bass engineering, "architecting gods
out of wounds," the transmutation of collapse into structured output. The
Inquisitor face is the analyst: the adversarial steelman sessions, the
honesty-enforcement prompts, the refusal to hold any belief that has not
survived hostile questioning ([[wiki/mind/concepts/forensic-method]]).

## Alignment: Chaotic Neutral

The sources develop the alignment as a real psychological position with two
commitments and one refusal.

**Rejection of Law.** External structure — convention, tradition, hierarchy,
etiquette — is experienced as arbitrary performance: deadlines, dress codes,
and status games are not resented so much as genuinely not computed.
Behavioral record: identical irreverence to authority and subordinates,
arguing with experts on pure logic, missing "obvious" social cues because
they encode nothing.

**Embrace of Chaos.** The unpredictable is treated as more real than imposed
order: entropy as the fundamental truth, beauty in malfunction and glitch,
truth in randomness over constructed meaning. The aesthetic runs through the
music (maximalist bass, broken textures), the politics (fascination with
system-glitch figures — Trump analyzed as malfunction, not cause), and the
prose style's engineered ruptures.

**Neither good nor evil.** Not altruistic — Fe-inferior and Altruism-1
foreclose natural caregiving; not malicious — "harm caused is collateral
from indifference, not malice." The result the dossiers describe: a free
agent following internal logic incomprehensible from outside, "innocent and
dangerous simultaneously."

## Convergence

Each system independently derives the same figure: the ILI's decline-prophet,
the Inquisitor's weaponized questioning, the Alchemist's transformation
drive, and Chaotic Neutral's rule-exit are all restatements of the Ti-Ni
core under different coordinate systems. The value of keeping them separate
is diagnostic vocabulary: "Ni fatalism" explains a mood the Big30 numbers
can't, and "so-blindness" explains a career pattern MBTI can't.

**Gaps:** the ILI-Ni and Attitudinal readings appear only in the 2026-era
dossiers with no test provenance; Socionics intertype relations (e.g., what
the model predicts about the [[wiki/people/annie-ulmer|Annie]] ESFJ pairing) were never worked through
in the sources.
