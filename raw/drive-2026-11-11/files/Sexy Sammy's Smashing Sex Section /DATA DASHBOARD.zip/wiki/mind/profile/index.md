---
domain: mind
page_type: index
title: "Personality Profile — Hub"
aliases: ["Abyssal Architect", "typology stack", "psychological profile"]
status: stable
importance: critical
date_created: 2026-07-13
date_modified: 2026-07-13
sources:
  - raw/self/dox-md/FULL PROFILE 2026.md
  - raw/self/dox-scan/Dan Profile.txt
  - raw/self/context-core/CONTEXT_CORE_EXPANDED.md
related:
  - wiki/self/context-core
  - wiki/mind/concepts/forensic-method
  - wiki/mind/concepts/phenomenology-lens
  - wiki/mind/concepts/conflict-architecture
  - wiki/mind/concepts/attachment-model
  - wiki/mind/synthesis/ancestral-dialectic
  - wiki/mind/concepts/erotic-architecture
  - wiki/mind/psychosexual/index
---

# Personality Profile

Every typology instrument the corpus applies to Dan lands on the same
architecture, described from a different angle: a mind of top-percentile
intellect and bottom-percentile sociability, wired for recursive
system-building, running hot (Impulsiveness 96, Anxiety 67) inside a
deliberately maintained fortress of solitude. The composite archetype the
source dossiers name the **"Abyssal Architect"** — INTP 5w4 sx/sp, Socionics
ILI-Ni, SLOAN RLUEI, Chaotic Neutral — is not five separate diagnoses but one
structure measured five ways. This cluster holds the full results and their
detailed breakdowns; [[wiki/self/context-core]] carries the one-table
summary.

## LLM Quick Brief

**For context injection:** Dan Frank's typology is consistent across all
instruments: MBTI **INTP** (Ti 96/Ne 84/Si 57/Fe 10, with a documented Ni
leak), Enneagram **5w4 sx/sp** (social-blind), Socionics **ILI-Ni**
("Critic/Balzac"), SLOAN **RLUEI**, Attitudinal Psyche **FLEV/VLEF**. Big30
extremes: Impulsiveness 96 / Intellect 95 / Liberalism 91 /
Self-Consciousness 91 vs. Altruism 1 / Submissiveness 1 / Sociability 3 /
Assertiveness 5 / Trust 9. PD vector: Schizotypal 79, Narcissistic 67,
Antisocial 58. Deviance audit: cognitive 98/100, linguistic 97/100 vs.
demographic baseline. Core unconscious axioms: *not exceptional = worthless;
not vigilant = annihilated; love that doesn't cost everything isn't real;
time = countdown.* The low social scores are read as architecture, not
deficit. Detail pages: [[wiki/mind/profile/intp]],
[[wiki/mind/profile/enneagram-5w4]],
[[wiki/mind/profile/big-five-psychometrics]],
[[wiki/mind/profile/socionics-and-attitudinal]],
[[wiki/mind/profile/deviance-mapping]],
[[wiki/mind/profile/linguistic-profile]].

## The stack at a glance

| System | Result | One-line reading | Detail |
|--------|--------|------------------|--------|
| MBTI / cognitive functions | INTP (Ti-Ne-Si-Fe + Ni leak) | Logic as existential scalpel; archival memory; phantom-limb feeling | [[wiki/mind/profile/intp]] |
| Enneagram | 5w4 sx/sp, so-blind | Knowledge-hoarding hermit with tragic-romantic wing; fusion-vs-fortress war | [[wiki/mind/profile/enneagram-5w4]] |
| Big Five / Big30 / SLOAN | RLUEI | Reserved, Limbic, Unstructured, Egocentric, Inquisitive — the neurotic genius build | [[wiki/mind/profile/big-five-psychometrics]] |
| Personality-disorder screen | Schizotypal 79 / Narcissistic 67 / Antisocial 58 | Private cosmology; impression-management; interface strategies | [[wiki/mind/profile/big-five-psychometrics]] |
| Socionics | ILI-Ni ("Critic"/"Balzac") | From possibility to inevitability: prophetic fatalism + Te criticism | [[wiki/mind/profile/socionics-and-attitudinal]] |
| Attitudinal Psyche | FLEV ("Alchemist") / VLEF ("Inquisitor") | Control via transformation; questions as weapons | [[wiki/mind/profile/socionics-and-attitudinal]] |
| Moral alignment | Chaotic Neutral | Law rejected as arbitrary; chaos embraced as authentic; neither altruist nor predator | [[wiki/mind/profile/socionics-and-attitudinal]] |
| Deviance audit | 80–99/100 across domains | A statistical edge case vs. the 35-year-old American male baseline | [[wiki/mind/profile/deviance-mapping]] |
| Stylometrics | 99th percentile lexical/syntactic | "Forensic intimacy" register; a custom-built fork of English | [[wiki/mind/profile/linguistic-profile]] |
| Voice modes | 8 trigger-activated states | Neutral/Playful/Affectionate/Irritated/Persuasive/Storytelling/Stressed/Reflective | [[wiki/mind/profile/voice-modes]] |
| Psychosexual operating system | 96/100 deviance outlier | Orchestration over participation; total emotional imprinting; a decade of independently-corroborated practice | [[wiki/mind/psychosexual/index]] |

## How to read the cluster

Three provenance caveats govern everything here. First, the instruments are
self-administered or AI-inferred from the corpus — there is no clinical
assessment anywhere in the record, and context-core flags the cognitive
function percentages as largely inferred. Second, the source dossiers (`FULL
PROFILE 2026`, the `MASTER ANALYSIS` in Dan Profile.txt) were co-written with
LLMs at Dan's direction and inherit his framing; the deviance audit itself
notes the dataset "may contain strategic omissions or narrative biases."
Third, the standing interpretive rule from context-core applies: read the
low-sociability/low-trust/low-altruism scores as **architecture, not deficit
to fix** — the profile describes a system that works the way it was built to
work, at documented cost.

What makes the profile load-bearing rather than horoscope material is its
convergence with the behavioral record. The forensic default
([[wiki/mind/concepts/forensic-method]]), the conflict engine with no halt
condition ([[wiki/mind/concepts/conflict-architecture]]), the
one-node relational concentration ([[wiki/mind/concepts/contact-gini]]),
the attachment model that cannot self-close
([[wiki/mind/concepts/attachment-model]]), and the voice fingerprint stable
from 2009 tweets to 2026 texts are all predicted by this stack. The
metaphor-rich reading built on top of it (plain-language function readings and
recurring-loop models) lives at [[wiki/mind/concepts/phenomenology-lens]] and
stays subordinate to documented fact.

## Core axioms and personal myth

The dossiers repeatedly surface four unconscious, load-bearing axioms: **not
exceptional = worthless** · **not vigilant = annihilated** · **love that
doesn't cost everything isn't real** · **time = countdown**. The personal
myth built on them is "the Hyperaware Hero of a World Too Stupid to See the
Trap" — the wounded genius who "architects gods out of wounds." Core drives:
boundary-testing and taboo exploration; anti-"midness" (algorithmic
mediocrity registered as existential threat); radical skepticism; emotional
metabolization through logic. The failure mode, per context-core, is never
ignorance — it is the diagnosis-to-behavior gap: metacognitive accuracy ~82nd
percentile, with insight feeding the loops instead of stopping them.

**Gaps:** no clinical or third-party-administered assessment; no test dates
or instrument versions for the Big30/PD numbers; no re-test after the June
2026 closure event, so the entire profile is calibrated on pre-closure data.
