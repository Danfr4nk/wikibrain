---
domain: mind
page_type: concept
title: "Orchestration and Voyeurism"
status: stable
date_created: 2026-07-14
date_modified: 2026-07-19
knowledge: mixed
sources:
  - raw/self/dox-scan/Dan Profile.txt
  - raw/self/dox-scan/all_imessages_complete_dump.txt
  - raw/self/dansynth/DANSYNTH.txt
related:
  - wiki/mind/psychosexual/index
  - wiki/mind/psychosexual/arrangement-history
  - wiki/mind/concepts/erotic-architecture
  - wiki/people/annie-ulmer
  - wiki/people/alexis-armel
  - wiki/timeline/events/annie-alexis-reunion-november-2018
  - wiki/people/fran-coldren
tags: [relationships, trauma-bond, personality-profile]
connections:
  - page: wiki/mind/psychosexual/emotional-imprinting
    type: mirrors
    claim: "Total imprinting on contact and years of orchestrated exposure sit in documented tension — unless authorship over the boundary routes around the imprinting channel, the framework's open structural question."
  - page: wiki/mind/concepts/erotic-architecture
    type: parallels
    claim: "The director stance and 'externalized libido' are the same claim in two registers — this page's primary-source treatment against the OS report's AI-theoretic framing."
  - page: wiki/mind/psychosexual/arrangement-history
    type: evidenced-by
    claim: "The arrangement timeline is the practice-side record of the director stance this page theorizes — arranged conditions, controlled access, Dan as architect rather than participant."
  - page: wiki/interests/film-canon
    type: evidenced-by
    claim: "The 2019-07-18 'living some eyes wide shut shit vicariously through her' message shows Dan reaching for his canon's masked-voyeur film as the lens on his own arrangement — primary self-description of the spectator frame."
  - page: wiki/people/vaughn
    type: co-occurs
    claim: "The February 2018 Vaughn exchange — explicit photos shared to a curated audience, an offer to film, a 1 AM visit under 'complete gentleman' terms — pattern-matches the arrangement-onset orchestration window, though identity and outcome are uncorroborated."
---

# Orchestration and Voyeurism

The single most consistent claim across every source that touches Dan's
sexuality — AI-authored dossiers and primary message threads alike — is
that he is a **director, not a participant**. Arousal and satisfaction are
reported as coming from constructing a scenario and then witnessing it
unfold, with the partner cast as the active party and Dan cast as the
architect who arranged the conditions. The source dossier calls this
"externalized libido" and frames it as "voyeurism as active
orchestration... a chess game where arousal is fueled by engineering and
witnessing 'chaos emerging from order.'" This is theory built on top of a
practice that is, unusually for this cluster, extremely well documented.

## The mechanism, in the dossier's own terms

Per `Dan Profile.txt`'s "Psychosexual Crucible" section: the "Non-Monogamy
Experiment" is dated to "Summer 2018," said to have been initiated by Dan
in response to [[wiki/people/annie-ulmer|Annie]]'s chronic sexting with
other men, and framed not as an ultimatum but an "expansion" — though the
report is explicit that it functioned as "high-stakes emotional game
theory" rather than straightforward permissiveness. The core structural
claim: Annie has had sex with other people while Dan watched, repeatedly,
across years; the reverse — Dan with another partner while Annie watches —
is not documented anywhere in the corpus. The report names this
asymmetry directly: "curated voyeurism with structured power dynamics," a
"psychosexual inversion" in which control is maintained precisely by not
participating. Dan supplied his own name for the frame in real time: on
2019-07-18, mid-arrangement, he described himself as "living some eyes
wide shut shit vicariously through her" — reaching for the masked-voyeur
film in his own [[wiki/interests/film-canon|film canon]] as the lens on
what he had built. The staging reflex also ran outside the arrangement
entirely: in the [[wiki/people/valeria-iglesias-cid|Valeria]] courtship
he planned a reunion moment in advance and set up a hidden camera to
film it — orchestrated witnessing applied to romance, not transgression,
which is evidence the architecture is general rather than
arrangement-specific.

One specific claim from this same passage — that Annie's "profound
pleasure during a long massage with another man 'broke Dan's brain' and
'rewired' him" (the report's "Danny" incident) — has no corroboration
anywhere else in the corpus searched for this page. A second claim in the
same passage, that [[wiki/people/fran-coldren|Fran]]'s hip broke "at the
exact moment" of this "psychosexual rite of passage," reads as poetic
"cosmic irony" construction rather than a verified simultaneity claim: the
best-corroborated date for Fran's catastrophic fall, cross-checked against
primary sources (DANSYNTH's own account, GEDCOM-adjacent records) on
[[wiki/timeline/events/fran-death-vigil]], is **April 1, 2018** — spring,
not the "Summer 2018" the non-monogamy report itself claims for the
massage incident. Either the dating on one side is wrong, or the "exact
moment" framing is dossier-authored myth-making layered onto two real but
non-simultaneous events. Treat the "Danny" massage incident and its
Fran-timing coincidence as unverified narrative color, not established fact.

## The documented practice

Where the theory is thin, the practice is not. The orchestration pattern
has primary-source corroboration going back to at least 2016 (the jealousy
kink is "first named Feb 2016" per [[wiki/people/annie-ulmer]]) and recurs
across the whole decade documented in [[wiki/mind/psychosexual/arrangement-history]].
The single richest documented instance is the November 2018 reunion between
Annie and Dan's ex, [[wiki/people/alexis-armel|Alexis]]
([[wiki/timeline/events/annie-alexis-reunion-november-2018]]), which shows
the orchestration mechanism in granular, real-time detail rather than
retrospective summary: Dan requesting a hidden camera "as long as I have
something to 'remember' the occasion by," explicitly declining to
participate even when invited ("If I was asked I would join but I'm
sosososo happy just having you guys into each other... I don't know how it
would even get better if I was involved"), leaving the house to run drug
logistics so the two women would have privacy, and describing the
experience in explicitly religious terms — "This is going to make me
religious. God must exist if I can watch something so beautiful." That
last line is the clearest primary-source match anywhere in the corpus for
the dossier's abstract claim that "sex is his church": here it's not
metaphor imposed after the fact, it's Dan's own real-time language.

The same structure — Dan initiating, arranging logistics, explicitly
opting out of participation, and deriving satisfaction from the fact of
Annie's pleasure with someone else — recurs with [[wiki/people/shelbie-breakiron|Shelbie Breakiron]]
(April 2019 threesome, later a two-person dynamic with Annie alone),
[[wiki/people/trinity-st-clair|Trinity St. Clair]] and
[[wiki/people/kelly-johansson|Kelly Johansson]] (paid professional
bookings, spring and fall 2019), and in the "purity test" architecture of
the [[wiki/people/kristin|Kristin]] relationship (2025), where exclusivity
was demanded of her in a mirror-image structure to the openness practiced
with Annie — full inventory at [[wiki/mind/psychosexual/arrangement-history]].

## The escalation: speaking as the partner

One documented instance goes past orchestration into direct
impersonation. In an August 2019 follow-up conversation with
[[wiki/people/jaredtricia|Jared and Tricia]] — the couple Annie had
worked a paid group session with in June 2019 under the alias "Hazel" —
Dan wrote to the couple *as* Hazel, in her voice and cadence, requesting
a keepsake from the earlier session: "i forgot to ask last time i saw you
if i'd be allowed to get one or two of the pictures of the 'girl fun'
from the first time we met... that was the most amazing experience it
still works me up." Asked directly why, his own answer was unadorned: "i
wanted that picture." Full account: [[wiki/people/jaredtricia]]. Where
the rest of this page's practice involves Dan authoring the *conditions*
of an encounter and then withdrawing to watch, this instance has him
authoring Annie's actual *voice* after the fact, to extract a physical
artifact of an encounter he wasn't present to document himself — the
clearest documented case of the orchestration impulse extending from
staging the scene to ventriloquizing the person in it.

## Reading the pattern

The dossier connects this directly to the cognitive-typological profile
already established on [[wiki/mind/profile/enneagram-5w4]] and
[[wiki/mind/profile/intp]]: a dominant Ti (control through internally
generated logic) paired with a starved Fe (inferior, weak feeling function)
produces a person who can permit — even engineer —
emotional and physical intimacy between his partner and someone else
specifically *because* his own participation isn't the mechanism by which
he extracts meaning from it; authorship over the boundary is. This reading
is consistent with, but not independently proven by, the arrangement
history — the corpus never records Dan explaining his own motivation in
these terms; the "director not participant" framing is the dossier's
synthesis of a pattern that is otherwise just described, not theorized, in
the primary messages themselves.

**Gaps:** no primary-source account exists of Dan explaining, in his own
words and outside AI-collaborative analysis sessions, *why* orchestration
without participation is the preferred structure — every explicit
theorization in the corpus is either AI-authored or AI-co-written. The
"Danny" massage incident and the Fran-timing coincidence remain
uncorroborated and should not be treated as established fact pending a
primary source.

## Related

[[wiki/mind/psychosexual/index]] · [[wiki/mind/psychosexual/arrangement-history]] · [[wiki/mind/concepts/erotic-architecture]] · [[wiki/people/annie-ulmer]] · [[wiki/people/alexis-armel]] · [[wiki/timeline/events/annie-alexis-reunion-november-2018]] · [[wiki/people/fran-coldren]]
