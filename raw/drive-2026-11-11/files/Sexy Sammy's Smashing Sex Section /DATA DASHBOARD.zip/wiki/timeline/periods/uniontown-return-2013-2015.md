---
domain: timeline
page_type: period
status: stable
knowledge: mixed
date_created: 2026-07-18
date_modified: 2026-07-18
date_range_start: 2013-05-01
date_range_end: 2015-11-28
sources: ["raw/self/context-core/CONTEXT_CORE_EXPANDED.md", "raw/self/dox-scan/Gemini-_58.txt", "raw/self/dox-md/LIFE_EVENTS_CALENDAR.md", "raw/self/facebook/facebook-ihatedanfrank/"]
tags: [relationships, uniontown-era, addiction-recovery]
connections:
  - page: wiki/timeline/periods/2010s
    type: follows
    claim: "This period opens the moment NYC-1 closes — the May 2013 departure from Manhattan back to Uniontown is the hinge, and it is the fact the old timeline framing got wrong by filing these years under New York."
  - page: wiki/timeline/periods/2015-2016-annie-relationship-start
    type: precedes
    claim: "The period ends exactly at the Alexis→Annie switch of Thanksgiving weekend 2015 — Alexis cheated Nov 28, Dan met Annie Nov 29 — which opens the relationship-start period."
  - page: wiki/interests/music/aliases/sloppp
    type: contains
    claim: "SLOPPP — Dan's first named production alias (2013 launch, 2014 output peak) — is the era's signature project, the recording-arts ambition surviving the NYC-career failure by migrating to a Uniontown SoundCloud."
  - page: wiki/interests/music/aliases/mogzart
    type: contains
    claim: "The SLOPPP→MOGZART alias handoff (~2014) lands inside this period and on the May-2014 account rotation the migration-grammar analysis flags — the identity churn is dateable to these years."
  - page: wiki/people/alexis-armel
    type: contains
    claim: "The five-year Alexis relationship runs out its endgame here, ending Nov 28 2015 when she cheated 'two weeks in after I moved her to fla' — the collapse that immediately precedes the Annie genesis."
  - page: wiki/mind/synthesis/bond-switch-2015
    type: precedes
    claim: "This period is the runway to the single-bond switch: the whole 2013–2015 stretch is the Alexis relationship winding down toward the same-week transfer that this synthesis page analyzes."
  - page: wiki/places/155-virginia-ave
    type: contains
    claim: "The January 2015 move to 155 Virginia Ave — the 'Alexis lair,' leased during the relationship's end — happens in this period and becomes the physical continuity Annie inherits, the lair-continuity the bond-switch turns on."
---

# Uniontown Return (2013–2015)

The most-corrected stretch in the whole timeline. For two and a half
years — **May 2013 to Thanksgiving 2015** — Dan was back in Uniontown,
not New York, and nearly everything the old framing misfiled as "later
NYC" actually happened here: the producer aliases took shape, the
five-year [[wiki/people/alexis-armel|Alexis]] relationship ran out its
endgame, and the single-bond switch to [[wiki/people/annie-ulmer|Annie]]
was set up. Context-core is emphatic that this correction matters —
"the producer-alias development, the Alexis→Annie transition, and the
poverty/deep-cycle years all happened in *Uniontown*, not NYC" — because
the geography changes what the period *means*: this is not a metropolitan
chapter but a return home, and the creative and relational reorganization
that defines it is a small-town reorganization.

## The return

Dan left Manhattan in May 2013 — the event the Twitter record's "2013
systemic rupture" actually marks (the rupture was the leaving, not a New
York event) — and moved back into **337 Saratoga Drive**, the family
home, where he stayed through January 2015. The audio-engineering career
the [[wiki/timeline/periods/2010s|NYC-1]] years had attempted did not
come back with him; what came back instead was the ambition in a new
form.

## SLOPPP: the recording-arts ambition, migrated

The most productive throughline of the period is the birth of Dan's
**named production identity**. [[wiki/interests/music/aliases/sloppp|SLOPPP]]
— a trap/festival-trap SoundCloud project — launched in 2013, the same
year as the return, and peaked in output in **2014** (its 113-hit
high-water mark): weekly mix series ("SLOPPP's Week in Trap"), the
signature "SLOPPPED N SCREWED" reworks, originals, and edits, all dated
tightly across 2013–14. The recording-arts training that failed to
convert into a New York career survived by migrating to a Uniontown
bedroom and a free hosting platform. Around 2014 the alias handed off to
[[wiki/interests/music/aliases/mogzart|MOGZART]] — a transition that
lands on the **May 2014 account rotation** the
[[wiki/mind/synthesis/totality-themes|migration-grammar]] analysis reads
as an identity-amputation event. The alias churn is not incidental to the
period; it is one of its dateable signatures.

## The Alexis endgame and the switch

The five-year Alexis relationship — begun at Full Sail, sustained through
all of NYC-1 — reached its end in this period. The
[[wiki/mind/synthesis/bond-switch-2015|single-bond switch]] analysis
covers the mechanics in full; the period-level fact is the sequence.
**January 2015:** Dan moved into **155 Virginia Ave**, the apartment
context-core calls "the Alexis lair," leased during the relationship's
end phase. **November 28, 2015:** Alexis cheated — "two weeks in after I
moved her to fla," per the life calendar. **November 29, 2015:** Dan met
Annie, at the Uniontown Country Club golf course around 2am in the rain,
and left Alexis within a day. Annie moved into 155 Virginia — the same
apartment — making the transfer a *swap*, not a relocation: the
[[wiki/places/155-virginia-ave|lair-continuity]] the switch turns on. A
brief 2013 [[wiki/people/franki-faris|Franki]] blip earlier in the
period ("I really didn't have the romantic feelings for franki that i
said i did at the time," then a return to Alexis) had already rehearsed
the same slot mechanics.

## Transition

The period ends precisely at the switch. November 28–29, 2015 closes the
Alexis era and opens
[[wiki/timeline/periods/2015-2016-annie-relationship-start|the Annie
relationship]] — which inherits the apartment, the town, and the alias
identity mid-transition, and runs from here to 2026.

**Gaps:** the message corpus is silent for almost all of this period —
the earliest real-text rows in any on-disk export begin November 12,
2015, days before the switch — so 2013 through mid-November 2015 rests
on context-core, the SoundCloud/Facebook record, the Gemini-_58
reconstruction, and the life calendar, not on primary message data. The
155 Virginia lease terms and exact move-in are undocumented; the precise
SLOPPP→MOGZART handoff date is bracketed to ~2014 by the account
rotation, not pinned.
