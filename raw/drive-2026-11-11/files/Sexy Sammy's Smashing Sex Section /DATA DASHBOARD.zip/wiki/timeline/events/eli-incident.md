---
domain: timeline
page_type: event
title: "The Eli Incident"
importance: critical
status: stable
date_created: 2026-06-22
date_modified: 2026-07-20
infobox:
  name: The Eli Incident
  type: Relationship rupture
  discovered: January 2025
  closed: June 1, 2026
  duration: 2015–2026 (relationship)
  outcome: Termination of [[wiki/people/annie-ulmer|Annie]] relationship
  partner: "[[wiki/people/annie-ulmer|Annie Ulmer]]"
  notes: Central betrayal event; recoded Annie in Dan's model
date_range_start: 2024-08-01
date_range_end: 2026-06-01
sources:
  - raw/self/dox-md/Honest assessment and value judgment analysis.md
  - raw/self/dox-scan/DanAnnie_CorrectiveAddendum.txt
  - raw/self/dox-scan/Dan Profile.txt
  - raw/self/dox-scan/DanAnnie_MasterRecord_March16.docx
  - raw/self/dox-scan/DanAnnie_MasterRecord_FINAL.docx
  - raw/self/dox-scan/DanAnnie_CompleteRecord_Final.docx
  - raw/self/dox-scan/DanAnnie_TenYears_WithAmendments.docx
  - raw/self/message-csv/imessages_2124702449_last6months.csv
  - raw/self/dox-scan/all_imessages_complete_dump.txt
tags: [infidelity, trauma-bond, nyc-era]
connections:
  - page: wiki/mind/concepts/node-locking
    type: evidenced-by
    claim: "The selective Eli purge at every AI export boundary measures this event's severity in Dan's own curation behavior — the one node too loaded to propagate."
  - page: wiki/mind/synthesis/dan-annie-fallout-verdict
    type: evidences
    claim: "The discovery sequence documented here is the first pillar of the fallout verdict's concealed-affair finding."
  - page: wiki/mind/concepts/attachment-model
    type: evidences
    claim: "The concealment is the attachment model's live stress test: sustained deception answered with 'your suspicions are insane,' keeping the contradiction flagged as anomaly rather than closing the model."
  - page: wiki/mind/concepts/conflict-architecture
    type: evidences
    claim: "The affair put the conflict engine in its worst documented mode — accurate forensic detection reframed as paranoia by the person deceiving it, the machine's correct outputs weaponized against its operator."
  - page: wiki/mind/synthesis/attachment-trauma-bond
    type: evidences
    claim: "This is the primary case the page's weaponized-ambiguity mechanism is built from — obvious data patterns met with DARVO shutdowns during acute attachment activation."
---


# Eli Incident

The event that ended the Annie decade in substance if not yet in form: a
sustained concealed affair between [[wiki/people/annie-ulmer]] and her coworker
Eli, active from at least August 2024, discovered physically in early 2025,
and — the documented center of gravity — defended throughout by months of
gaslighting that attacked Dan's capacity to trust his own accurate
perception. The corrective sources rank the gaslighting, not the affair,
as the most serious moral failure of the terminal phase.

## What happened
Sustained concealed affair between Annie and coworker Eli (male). The affair was ongoing for months before any single "discovery" moment — a later cross-reference of the raw 2024 record moves the documented floor earlier than previously established. Her GPS had already been disabled "for weeks" by late July 2024, by her own confirmation — six-plus months before the formal 2025 GPS demand that earlier pages treated as the removal's start. In August 2024, Dan caught her going out after work with someone and lying about it ("You barely apologized to me for SERIOUSLY breaking my trust AGAIN" — the "Isaac Trust Breach"). Key documented episode: October 19 2024 housewarming party argument lasting hours across dozens of messages, during which Annie told Dan "THERE IS NO SITUATION.", "You're literally fucking insane.", and "Grow up. And fucking trust me." while the affair was active.

Discovery trigger: on January 9, 2025, starting at 11:18 PM, Dan's phone received six rapid-fire messages from Eli, texting from Annie's phone — a male coworker identifying himself by name, late at night, with Annie not at home. Annie did not address it in any logged message for two days. The physical discovery: Annie unconscious with vomit nearby in the building lobby ~80 minutes after her shift (5-minute walk from home), location tracking disabled. Confrontation met with physical violence from Annie ("I found your phone, cheater."). The move from NYC accelerated dramatically in the days after January 9 (~4–5 weeks to departure).

> **REVISED [2026-07-20]:** the Eli discovery text was dossier-transcribed only through 2026-07-18 (three prior re-searches of `raw/` came up empty because the quote was searched as one string; iMessage actually split it into six separate messages). Located this pass, primary-confirmed in `raw/self/message-csv/imessages_2124702449_last6months.csv` and independently in `raw/self/dox-scan/all_imessages_complete_dump.txt`, with a genuinely new fact — Dan's real-time reply, previously undocumented — folded into the sequence:
>
> | Time | Direction | Text |
> |------|-----------|------|
> | 23:18:49 | Received | Hey Dan |
> | 23:18:53 | Received | It's Eli |
> | 23:19:20 | Received | Annie is down stairs |
> | 23:19:42 | **Sent** | **Who are you?** (Dan's own reply, in the moment — not previously documented) |
> | 23:19:54 | Received | I work with her |
> | 23:20:24 | Received | She and Andrea had drinks at work but u guess they didn't eat |
>
> Dan had already been trying to reach Annie for over an hour before Eli's texts arrived — "Are you done" (22:27:32) and "Your phone goes straight to voicemail" (22:28:05), both **[Sent]**, plus an unlabeled photo attachment at 23:08:08 — meaning the vigilance that later produced the discovery was already active before Eli made contact, not triggered by it. "Andrea" (a coworker present that night, per Eli's own text) has no other reference anywhere in the corpus and remains unidentified beyond this line.

Dan later chose to believe Annie's account sufficiently to attempt returning to "normal life" rather than sustain proof-gathering. The record's most direct admission came after the move, in a March 2025 message from Annie to Dan (verbatim, pronouns as written): "you decided to split our lives up. you lied to me for months and cheated on me" — read literally it accuses Dan, but every dossier that cites it treats it as her acknowledgment of the months of lying and the cheating, and rates it "the most direct admission in the record."

**The arrangement context (CompleteRecord Part XIII):** the couple ran a Dan-architected quasi-non-monogamous framework from 2018 — Dan arranging, Dan present, typically with his own friends (the mechanism documented at length in [[wiki/mind/psychosexual/orchestration-and-voyeurism]]). Eli had none of those features: not arranged, not disclosed, not addressed honestly. The dossiers' finding: within their arrangement the Tom-type encounters were not cheating; Eli was — "she had a framework within which she had freedom. She went outside that framework, secretly, with someone from work. That is exactly what Dan had proposed the arrangement to prevent." The affair's moral clarity is sharpened, not reduced, by the arrangement's existence: the violation is legible precisely because the authorized version — orchestration, presence, control over the boundary — is so well documented elsewhere.

## When
- Affair active/sustained: At minimum autumn 2024 (August 2024 record shows Dan already identifying the gaslighting mechanism in real time); continued through at least early 2025 and until closure.
- October 19 2024: Extended housewarming confrontation and gaslighting.
- January 9 2025, 11:18 PM (exact, per MasterRecord_FINAL): Eli's self-introduction text; physical discovery.
- Post-incident: Dan's retrospective accounts (Feb–May 2025) confirming he chose to believe despite accurate perception.

## People involved
- [[wiki/people/annie-ulmer]] (primary actor conducting affair and gaslighting)
- Dan
- [[wiki/people/eli]] (coworker; affair partner; "I work with her" texts from Annie's phone; preemptive framing of incident)

## Significance
Central rupture that recoded Annie in Dan's internal model from chaotic mirror to dissociated saboteur. Reaffirmed the old fear that betrayal happens when vigilance slips.

The sustained gaslighting of accurate perception (months of being told suspicions = mental illness while the deception continued) is identified in corrective sources as the single most serious moral failure in the terminal phase — more serious than procurement patterns or silences because it attacked Dan's capacity to know reality itself.

Directly explanatory of attachment closure failure: the architecture (weighted positive rhetoric + no explicit severance) was compounded by active training to distrust one's own accurate perception. See [[wiki/mind/concepts/attachment-model]].

Template repetition: Annie's behavior replicated the structure of the 2004–05 parental rupture (trusted attachment figure maintaining hidden alternate reality during period of maximum vulnerability).

## Related events
- [[wiki/timeline/events/group-chat-closure]] (final confirmation of third-party relationship and concurrent defamation)
- October 19 2024 housewarming argument (longest single documented gaslighting episode during active affair)

## Data Record
| Signal | Detail |
|--------|--------|
| Affair duration (corrective) | Sustained, unknown start date, ongoing through autumn 2024 and beyond (reframes "single incident" discovery) |
| Gaslighting during active phase | Multiple documented instances (Aug 6, Aug 9, Oct 19 2024 messages); Annie called suspicions "insane" while affair continued |
| Discovery details | Eli text from Annie's phone; Annie unconscious + vomit in lobby; location disabled; ~80 min post-shift |
| Confrontation response | Physical (Annie attacked when confronted) |
| Dan's post-hoc acknowledgment | May 27 2025: chose to believe to "get back to a normal life where i didn't have to try to find the evidence" |
| Retrospective language (Dan) | Repeated use of "torture", "gaslit me into literally breaking", "playing games with his head" |

> **REVISED [2026-07-13]:** Operator correction on scope: the Eli affair ended with the February 2025 NYC departure (Eli lives in NYC). The 2025–26 terminal phase and the June 1, 2026 closure involve a different third party — Tuquick ([[wiki/people/tuquick-17248123683]]), who Annie left Dan for. This page covers the NYC affair and its discovery only.
