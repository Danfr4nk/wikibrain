---
domain: timeline
page_type: event
title: "April–May 2026 — The Final Documented Weeks"
importance: high
status: stable
date_created: 2026-07-13
date_modified: 2026-07-20
date_range_start: 2026-04-01
date_range_end: 2026-05-06
sources:
  - raw/self/dox-md/Ethics of leaving without communication.md
  - "raw/self/dox-md/Crisis mode briefing.md"
related:
  - wiki/people/annie-ulmer
  - wiki/timeline/events/march-2026-terminal-phase
  - wiki/timeline/events/group-chat-closure
  - wiki/mind/concepts/attachment-model
  - wiki/mind/concepts/conflict-architecture
tags: [relationships]
connections:
  - page: wiki/people/suzanne-frank
    type: co-occurs
    claim: "The recurring blocked-caller impersonation campaign targeted Suz directly (personally insulted, threatened arrest-worthy retaliation) — the only documented instance of the relationship's terminal-phase conflict machinery reaching a third-party family member this directly."
  - page: wiki/mind/concepts/conflict-architecture
    type: instantiates
    claim: "The live screaming match with Suz over whose grievance mattered more is a real-time instance of the resolution-seeking engine misreading an emotional bid as a proposition to be litigated, the same mechanism documented at scale in the Annie relationship."
  - page: wiki/mind/synthesis/ai-collaborative-analysis
    type: evidenced-by
    claim: "An AI-drafted letter to Suz, explicitly authorized to include any criticism, is genuinely vulnerable first-person material Dan then declines to send in his own voice — outsourcing the authorship of vulnerability itself, not just memory or analysis."
---

# April–May 2026 — The Final Documented Weeks

The March 16, 2026 retraction ("I misunderstood the conversation") was not the record's actual end — a later analysis session, working from the same message corpus, extends the documented timeline seven more weeks, to May 6, 2026, roughly three and a half weeks before the June 1 group-chat closure. This page covers that gap: the last stretch of the relationship's text record before the closing confrontation.

## The shape of it

Communication in this window did not decline steadily — it oscillated with a worsening floor. April 20–26 is the one week in the entire extended record where Annie out-messaged Dan (206 received vs. 164 sent, a 0.80 ratio) — it opened with a warm, playful, detailed dream narrative about their dogs on a golf course, and produced enough goodwill that it visibly re-engaged Dan for the following weeks. By the next week the ratio had collapsed back to 3.36:1.

May is rated the worst period in the full record — not by volume, but by content. Across a three-hour window at 3:30–5:57 AM on May 6, Dan sent the most explicit and sustained suicidal language in the entire corpus: "I wish I were fucking dead after today," "I don't think I'll ever be able to feel happy or okay ever again," "I don't want to do this anymore," "this is going to end so fucking badly I'm losing my fucking mind." Annie's documented responses that window: "Can we please just talk tomorrow Dan," "Please Dan," "I am not okay with that," "STOP IT DAN," "wtf Dan" — the same non-substantive pattern documented across the twelve terminal-phase crisis statements, now in its 37th week.

## Three findings not captured anywhere else in the record

**GPS shared with a third party, not just withheld from Dan.** On May 5 at 3:09 PM, Dan wrote: "stay away from me you liar I can not believe you would give someone else your location after what you did to me." This is the first documented instance of Annie's location access being actively extended to someone else while still refused to Dan — a materially different finding than the prior "she just turned it off" reading, and it eliminates any residual privacy-as-principle explanation for the removal.

**A new job.** Annie mentions starting work at "Marucas" on the morning of May 5 — in the same message exchange where she opens with a drug-supply-chain logistics request, meaning the request preceded the job announcement in sequence. The new income source reduces her financial dependency on the Uniontown supply chain in the weeks immediately before the June 1 closure.

**Dan self-periodizes the relationship.** On May 4 at 8:10 PM, Dan sent the bare timestamp "25 Nov 2015 – 04 May 2026" — not as an ultimatum or a goodbye, but annotating the relationship with a closing date in his own framing, the only instance in the full record of him doing this unprompted.

**An unresolved third-party contact, recurring (April 1, re-firing ~late April).** Dan's message at 12:57 AM, April 1: "my mom gets a call from a guy looking for you at 8:30. He calls again at 10:00. What the FUCK could that mean." A man called Suz's number twice looking for Annie on a night she was unaccounted for; the thread ran through April 8 ("just refusing to discuss or give me any clarity aout who the fuck was calling my mom") and then went dormant. A separate AI-chat session (dox-md, undated but self-referencing the April 1–8 thread as "three weeks" prior, placing it roughly in late April) documents the pattern re-firing: someone using Annie's number called Suz directly, insulted her personally ("called her a junkie"), and sent Dan a message reading "you had guys molest me" — which Dan, in the same session, explains as a garbled hostile reference to the couple's [[wiki/mind/psychosexual/arrangement-history|non-monogamous arrangement]], one he maintains was consensual. Suz reacted with rage serious enough to threaten arrest-worthy action ("if I call you, call bop to come bail me out"), producing a screaming match between her and Dan over whose grievance mattered more that the session frames as a live instance of the same conflict-engine mechanism documented at scale elsewhere in the corpus. A forensic read built in the same session — Suboxone consistently misnamed "heroin/Percocets" (Annie would know the actual regimen), a narrative-voice register mismatch, and the total absence of Dan's name in the hostile messages (a corpus-level signature Annie's own hostile register always carries) — argues this was not Annie personally, though whether she was aware, complicit, or an unwitting source of the "close household knowledge" (the caller knew the water had been shut off) is explicitly left unresolved, including whether her family even owns the Volvo the impersonator's message referenced. The identity of the caller is not established anywhere in the corpus. It predates and is separate from the confirmed June 1 third party ([[wiki/people/tuquick-17248123683|Tuquick]]).

## What still held from the terminal-phase mechanism catalog

The love-to-request procurement pattern, the moral-debt pivot, and the crash-out trap all continued unchanged through this window: on May 4, warmth the prior evening ("I am not okay with that" in response to a suicide statement) was followed the next morning by a cardless-ATM-code request; on May 5, Annie arrived without her phone, collected supply, and left. The mechanisms documented for August 2025–March 2026 in [[wiki/people/annie-ulmer]] did not relax in the final seven weeks — if anything the ratio (climbing past 4:1 in the most recent full week measured) and the late-night-availability gap (a roughly 6:1 divergence between Dan's and Annie's overnight output) both worsened.

## Final message of this extract

May 6, 2026, 5:57 AM — the last message in this analysis session's record: "IF YOU DON'T WANT TO BE WITH ME YOU HAVE TO SAY SOMETHING. I AM NOT GOING TO FUCKING PROCESS ANYTHING UNLESS YOU DO THAT. You don't get it this is going to end so fucking badly I'm losing. My fucking. Mind." Three and a half weeks later, on June 1, that "something" arrived — in a group chat, from third parties rather than from Annie — and closed the relationship ([[wiki/timeline/events/group-chat-closure]]).

## Gaps

This page is sourced from a single chat-based analysis session, not a directly re-verified raw CSV extract the way the rest of the corpus is — the underlying message log for April 1–May 6, 2026 has not been independently located and cross-checked in raw/. The same source claims a much larger "Betrayal Catalog" (14 incidents), a formal BPD-criteria assessment, and — flagged only once, not elaborated — a pregnancy, none of which are corroborated elsewhere in the wiki's sources and are **not** adopted here pending verification against primary message data. Treat everything above this section as reasonably reliable (it's tied to specific dated, quoted messages); treat anything not explicitly repeated here as unverified.
