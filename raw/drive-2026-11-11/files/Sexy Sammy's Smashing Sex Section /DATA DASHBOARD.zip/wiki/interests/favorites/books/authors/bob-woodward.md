---
domain: interests
page_type: entity
status: active
importance: medium
date_created: 2026-06-22
date_modified: 2026-07-11
sources: ["raw/self/favorites/FAVS MASTERLIST.csv"]
related:
  - "wiki/interests/favorites/books"
  - "wiki/mind/concepts/forensic-method"
  - "wiki/self/context-core"
changelog:
  - 2026-07-11: Full rewrite from stub. Added contextual analysis, comparative framing against Wolff, wiki links.
tags: [politics]
---

# Bob Woodward

American journalist, Washington Post institution, Watergate co-byline. For fifty years, Woodward has been the template for what access journalism at the highest level looks like: cultivate sources inside the machine, protect them, publish what they allow, and let the accumulation of authorized quotes build a portrait that official Washington can live with.

## In Favorites

5 books — tied for the highest count of any author in the favorites list. Zero 5-star ratings.

## Why This Author

Five books with no 5-stars is the most interesting data point in the whole journalism cluster, and the contrast with Michael Wolff tells you almost everything. Wolff has 3 five-stars from 5 books. Woodward has none from 5. The books get read; they don't get loved.

Woodward is respected the way you respect a rigorous institutional process — for its reliability, its repeatability, its refusal to go places it hasn't earned permission to go. His Trump books (*Fear*, *Rage*, *Peril*, *War*) are exhaustive and credible and consistently feel like they're missing the thing you most want to know. The sources talk, but they talk in ways that protect themselves, and Woodward's commitment to the transaction — access for discretion — is built into the methodology at a structural level.

From the perspective of [[wiki/mind/concepts/forensic-method]], Woodward's method is authoritative but fundamentally mediated. You're reading what people chose to tell him, filtered through his professional obligation not to burn them. That's useful evidence, but it's not primary source material. It's testimony carefully managed on its way to the record.

The 5-book count without a single 5-star maps accurately onto a reading relationship that is thorough without being moved — the way you'd engage with a well-produced documentary that you trust but don't find revelatory.

## In the Trump Journalism Cluster

Alongside [[wiki/interests/favorites/books/authors/jonathan-karl]] and [[wiki/interests/favorites/books/authors/michael-wolff]], Woodward completes a triangulation of how three different journalism methodologies processed the same administration. Karl is the beat reporter's view from the briefing room. Woodward is the access-maximizing long game. Wolff is the open mic someone forgot to turn off.
