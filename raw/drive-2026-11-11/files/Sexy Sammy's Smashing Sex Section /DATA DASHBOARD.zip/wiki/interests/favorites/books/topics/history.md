---
domain: interests
page_type: synthesis
status: archived
date_created: 2026-06-22
date_modified: 2026-06-22
sources: ["raw/self/favorites/FAVS MASTERLIST.csv"]
related: ["wiki/interests/favorites/books", "wiki/self/context-core"]
---

# History (Book Favorites)

## Count
69 tagged books.

## Sub-themes
Recent-history, american-history, ancient-history, war.

## Reflection
Broad historical curiosity providing context for current politics. Roman Republic interest noted in spine.
