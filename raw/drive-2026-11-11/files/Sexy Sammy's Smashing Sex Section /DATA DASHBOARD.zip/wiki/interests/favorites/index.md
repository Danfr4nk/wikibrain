---
domain: interests
page_type: index
status: archived
date_created: 2026-06-22
date_modified: 2026-06-23
sources: ["raw/self/favorites/FAVS MASTERLIST.csv"]
related: ["wiki/self/context-core", "wiki/self/overview", "wiki/interests/music/index", "wiki/self/favorites", "wiki/self/facebook", "wiki/interests/favorites/eclecticism", "wiki/interests/favorites/taste-profile", "wiki/mind/synthesis/totality-themes", "wiki/timeline/periods/2025-collapse"]
---

# Favorites

_Last updated: 2026-06-23_ (FB archive music likes + EDM events cross-ref; ancestry music influence via Fran)

This is the dedicated category for personal favorites data from the master list (music, books, art, movies).

**Total entries:** 2,016 (raw count from FAVS MASTERLIST.csv)

| Category | Count | %     | Notes |
|----------|-------|-------|-------|
| Music    | 1,860 | 92.3% | 1,477 unique artists (~1.26 avg); inclusion only (0 rated) |
| Book     | 120   | 6.0%  | 98 unique authors; all rated (29 @5, 42 @4) |
| Art      | 25    | 1.2%  | 25 unique creators (all rated 5); painters/architects |
| Movie    | 11    | 0.5%  | 11 titles (unrated); sparse metadata |
| **Total**| **2,016** | 100% | — |

## Key Patterns from Deep Parse
- **Music releases**: 2025 (530), 2026 (197), 2024 (145) dominant — aligns recent listening with [[wiki/timeline/periods/2025-collapse]] music reactivation.
- **Books read**: Primarily 2024 (53), 2023 (16) — heavy non-fiction politics/history focus.
- **Clusters (music)**: ~balanced experimental hip-hop, emo/punk/rock, electronic/bass (~90-96 tracks each indicative); high long-tail eclecticism.
- **FB continuity**: Overlaps with [[wiki/self/facebook]] music likes (Elliott Smith 7, Fall Out Boy 6, Say Anything 6, Lil Wayne 5); 2007 status updates prefigure current top artists.
- No "sub-bass" or "Jimmy Pop" strings in CSV itself; those are contextual from chats + production spine.

The list reflects an eclectic, high-intensity taste profile consistent with the behavioral spine in [[wiki/self/context-core]]: high Artistic Interests (81st), political focus, and music as a core sincere channel. See [[wiki/interests/favorites/eclecticism]], [[wiki/interests/favorites/taste-profile]].

## Sections
- [[wiki/interests/favorites/music]] — Music favorites breakdown (expanded top artists, clusters, FB ties, release dates)
- [[wiki/interests/favorites/books]] — Book favorites and reading patterns
- [[wiki/interests/favorites/art-and-movies]] — Art and film

## Analysis Pages
See subpages for clusters, top artists, authors, and topics. Cross [[wiki/mind/synthesis/totality-themes]] for corpus integration.

This data feeds self-model insights (eclecticism, political engagement, production taste) and should be cross-referenced with the authoritative [[wiki/self/context-core]]. Sources defer to raw/self/favorites/FAVS MASTERLIST.csv (immutable).
