---
domain: interests
page_type: summary
status: stable
date_created: 2026-07-11
date_modified: 2026-07-11
sources: []
related: []
---

# interests — index


- [[wiki/interests/golf]] — three generations of family golf, a real amateur game rekindled by the caddying job, and the sport's decade-long role as a marker of the Annie relationship's temperature, start to end.
- [[wiki/interests/rock-irrelevance-thesis]] — the argument (with streaming/market data) that guitar rock is culturally irrelevant for the first time since 1963.
- [[wiki/interests/the-office]] — not a rated favorite, but its comic grammar (the "Schrute Farms" concert alias, the "that's what she said" tic, the Michael Scott political comparator) is woven into the idiom.
- [[wiki/interests/gore-vidal]] — hero-figure litmus test, a literal shelf object, and a deadpan groomsmen-bit constant; an identity anchor with no books entry.
- [[wiki/interests/video-games]] — from the 2007 "slaying on halo" teen signal through the 2016–2018 PlayStation ownership/ban saga to the 2025 Wii/Xbox liquidation.
- [[wiki/interests/stand-up-comedy]] — not a passive favorite: a dated 2019 New York club-going run, a real ambition to perform (the "Nad Knarf" stage name, the five-minute open-mic goal), and comedy specials as a family ritual.
- [[wiki/interests/opie-and-anthony]] — the single most-watched thing in his YouTube history: the 2012–13 shock-radio archive binge (~450 watches) that trained his humor and fed the live-comedy taste.
- [[wiki/interests/film-canon]] — the 11-title movie list read as a real canon he evangelizes and tests partners with; Kubrick completism, Eyes Wide Shut as "favorite Christmas movie," and the King of Comedy/Taxi Driver self-portrait pair.
- [[wiki/interests/roman-republic]] — the 2024 full-immersion ancient-history year: Carlin→Holland→Goldsworthy→Plutarch read back to back, and the evangelism of Caesar/Rome to everyone around him.

## favorites

- [[wiki/interests/favorites/art-and-movies]] — Minor categories in the masterlist (Art 25, Movies 11). All Art entries rated 5; movies unrated with…
- [[wiki/interests/favorites/books]] — This reading list is a direct window into political and intellectual dimensions of the self model.
- [[wiki/interests/favorites/books/want-to-read]] — 149 titles on the "want to read" shelf, never before mined — Rome, Trump-era politics, intelligence/conspiracy history, plus an NYC-history thread.
- [[wiki/interests/favorites/eclecticism]] — 1,477 unique artists in 1,860 tracks — deliberately broad (avg 1.26 tracks/artist). Three main clusters…
- [[wiki/interests/favorites/music]] — Music entries carry no My Rating (inclusion signal only, primarily from Spotify likes); contrast with…
- [[wiki/interests/favorites/taste-profile]] — The FAVS MASTERLIST reveals an eclectic but focused consumer. Deep re-parse: 2,016 total, 1,477 music artists.

## favorites/books/authors

- [[wiki/interests/favorites/books/authors/adrian-goldsworthy]] — 4 books.
- [[wiki/interests/favorites/books/authors/bob-woodward]] — 5 books.
- [[wiki/interests/favorites/books/authors/dan-carlin]] — 2 books (Hardcore History).
- [[wiki/interests/favorites/books/authors/jonathan-karl]] — 3 books.
- [[wiki/interests/favorites/books/authors/michael-wolff]] — 5 books.

## favorites/books/topics

- [[wiki/interests/favorites/books/topics/ancient-history]] — Interest in foundational power dynamics, empires, and leaders (Caesar, Plutarch). Provides long-view…
- [[wiki/interests/favorites/books/topics/history]] — 69 tagged books.
- [[wiki/interests/favorites/books/topics/journalism]] — 31 tagged.
- [[wiki/interests/favorites/books/topics/politics]] — 79 tagged books.
- [[wiki/interests/favorites/books/topics/trump]] — 40+ tagged around trump / president / election.
- [[wiki/interests/favorites/books/topics/war]] — Military and conflict history as part of broader analytical framework.

## favorites/music

- [[wiki/interests/favorites/music/electronic-bass]] — Strong modern electronic and bass presence. Directly relevant to current production (Gripnotic) and…

## favorites/music/artists

- [[wiki/interests/favorites/music/artists/elliott-smith]] — 7 tracks, the #1 individual artist in a bass-music library; the "patron saint of liars and fakes" 2013 handle and the 2025 R&B-before-1979 gate.
- [[wiki/interests/favorites/music/artists/fall-out-boy]] — 6 tracks, but a 2007 tour-following artifact: 3 shows + TRL taping, the Buffalo "Schrute Farms" secret show, love cut off at Folie à Deux.
- [[wiki/interests/favorites/music/artists/jpegmafia]] — 13 tracks — highest count in the masterlist.
- [[wiki/interests/favorites/music/artists/kanye-west]] — 11 tracks.
- [[wiki/interests/favorites/music/artists/knock2]] — 6 tracks.
- [[wiki/interests/favorites/music/artists/lyny]] — 7 tracks.
- [[wiki/interests/favorites/music/artists/my-chemical-romance]] — 9 tracks.
- [[wiki/interests/favorites/music/artists/new-found-glory]] — 8 tracks.
- [[wiki/interests/favorites/music/artists/say-anything]] — 6 tracks.
- [[wiki/interests/favorites/music/artists/taking-back-sunday]] — 6 tracks.

## music

- [[wiki/interests/music/overview]] — Dan Frank is an independent music producer and label operator based in SW Pennsylvania, operating since…

## music/aliases

- [[wiki/interests/music/aliases/gripnotic]] — GRIPNOTIC is the operational alias, not an archive. It is the identity Dan promotes on Twitter (@danfrank,…
- [[wiki/interests/music/aliases/mogged-up]] — Mogged Up exists as a practical release vehicle rather than an aesthetic identity. Bootleg imprints allow…
- [[wiki/interests/music/aliases/mogzart]] — Context Core and Twitter samples reference MOGZART in the context of music promo alongside GRIPNOTIC,…
- [[wiki/interests/music/aliases/sloppp]] — SLOPPP is the earliest production alias with a confirmed name in the context-core timeline. It emerges…

## music/concepts

- [[wiki/interests/music/concepts/sub-bass-signature]] — The sub-bass signature is the defining acoustic fingerprint across all of Dan Frank's production output —…
