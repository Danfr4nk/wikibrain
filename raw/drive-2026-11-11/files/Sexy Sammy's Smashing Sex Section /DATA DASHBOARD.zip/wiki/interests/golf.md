---
domain: interests
page_type: summary
status: active
date_created: 2026-07-14
date_modified: 2026-07-18
sources:
  - raw/self/dox-scan/all_imessages_complete_dump.txt
  - raw/self/message-csv/MASTER_MESSAGES_DB_DUMP.csv
  - raw/self/dox-scan/Resume.txt
  - raw/self/dansynth/DANSYNTH.txt
tags: [family, uniontown-era, relationships]
knowledge: mixed
connections:
  - page: wiki/people/steve-kezmarsky
    type: evidenced-by
    claim: "The Kezmarsky thread is a working exhibit of golf as the connective tissue of the Uniontown male friendships — club talk, stolen Scotty Cameron, vicarious rounds, a caddying ask."
  - page: wiki/mind/synthesis/interests-as-era-markers
    type: instantiates
    claim: "The 2016–19 era-marker where the interest literally was the era: sport, social world, and primary paycheck at once through the caddying years."
  - page: wiki/work/nemacolin-caddying
    type: contains
    claim: "The caddying career is the professional component of the golf thread — the April 2016 hire is what reignited the playing interest and made the sport his main income through 2019."
  - page: wiki/people/fran-coldren
    type: caused-by
    claim: "The access runs through Fran: western-PA golf royalty whose fifty years on the UCC fairway made the course family terrain — and the site of the November 2015 meeting with Annie."
  - page: wiki/timeline/periods/2015-2016-annie-relationship-start
    type: contextualizes
    claim: "Supplies the setting of the origin event: the 2 AM meeting in the rain happened on the same UCC fairway Fran had dominated for half a century."
  - page: wiki/timeline/periods/dec-2025-spike
    type: evidences
    claim: "The December 13 2025 'like when we used to, when you ACTUALLY liked me' line weaponizes golf as the relationship's named good-era memory — the loop that opened on a fairway closes as its eulogy."
  - page: wiki/people/annie-ulmer
    type: contextualizes
    claim: "Golf brackets the relationship: its best-documented origin moment in 2015 and its sharpest terminal-phase callback in 2025 both happen on or about a golf course."
  - page: wiki/people/christian-hanson
    type: co-occurs
    claim: "Hanson is the marquee playing partner of the caddying era — an NHL client Dan both looped for and played rounds with through 2017–18."
  - page: wiki/places/117-belmont-circle
    type: co-occurs
    claim: "Fran's house on the UCC fairway is the physical anchor where the family golf lineage and the Annie origin story share an address."
---

# Golf

Golf runs through three generations of the family and both ends of Dan's relationship with [[wiki/people/annie-ulmer|Annie]] — he met her on a golf course at 2 AM in the rain, and a bitter callback to walking courses together closes out the relationship's final year. In between, it was his actual sport: a real, moderately skilled amateur game (occasionally breaking 90), a four-year caddying career at three elite regional clubs that doubled as his main income during the hardest financial years, and a running attempt — never fully successful — to get Annie to share it with him.

## The family lineage

Golf at this level of the family predates Dan by decades. His great-grandmother [[wiki/people/fran-coldren|Fran]] was, per the record on her own page, genuine western-Pennsylvania golf royalty: **two documented holes-in-one** — 1959 at LaGorce Country Club in Miami Beach, then 1969 at the Uniontown Country Club (the 153-yard No. 11, struck with a No. 5 wood) — the **UCC Women's Golf Crown** (342 over 72 holes, won by seven strokes), a 200 game at Manor Lanes, and family photographs placing her beside Arnold Palmer's private plane — she was socially close with Palmer himself. She lived on the UCC fairway for over fifty years, at [[wiki/places/117-belmont-circle]], literally a "golf course house." That fairway is also where, on the night of **November 29, 2015**, at roughly 2 AM in the rain, Dan met Annie — the single most consequential event in the whole message corpus, and it happened on the same course his great-grandmother had dominated for half a century (see [[wiki/timeline/periods/2015-2016-annie-relationship-start]]).

## Dan's own game

Dan plays, and by his own account is a competent but unspectacular amateur — "That was a fluke today tho. Idk how I played as well as I did...and I still probably barely broke 90" (May 9, 2018) is as good as his self-reported scores get; a June 2017 message logs a more ordinary "Got a par 4 and then par 3 to finish." He studies the game seriously rather than just playing casually: in June 2016 he watched a full broadcast of the 84 Lumber Classic specifically "to better understand course strategy for my low handicap loops" — treating tournament golf as professional development for the caddying job, not just entertainment. His closest documented brush with real skill is a near-miss rather than a triumph: on **November 5, 2017** — his birthday — playing as "the last player of the season" on Mystic Rock, he came "2 feet from an ace on 17 which is the last hole today."

Regular playing partners across the record include his caddying boss **Brad** (a $150 straight-stroke-play bet at Pikewood that ended with Brad drunkenly snapping a club and standing Dan up), and NHL forward [[wiki/people/christian-hanson|Christian Hanson]], a Nemacolin regular Dan both caddied for and played rounds with through 2017–2018 (full account on Christian's own page). He also floated bringing Annie into actual play rather than just spectating — "I don't know let's take her Togo play nine holes" (May 2018) and, more bluntly, "I spend all this fucking money to try to get you excit[ed] about actually playing golf" (June 2018) — and tried to get her out on the course directly ("How about playing golf with Annie and I on the new course tonight," Aug 2018). The record suggests it never fully took: a 2020 message elsewhere shows Dan trying, without success, to get someone else to "come walk the golf course with me."

## The caddying career (2016–2019)

Getting hired at Nemacolin in April 2016 didn't just give Dan an income — it visibly reignited his own interest in playing: "I really really dig it. Spending all day on the golf course is a blast and it's getting me back into playing in a big way. Also mystic rock is top notch and really hard" (May 11, 2016), written days into the job, with an employee discount making rounds on Nemacolin's two courses — **Mystic Rock** and **Shepherd's Rock** — cheap enough to actually use ("We can play mystic rock for $15 with my employee discount"). The caddying itself ran across three elite regional clubs — Nemacolin, Laurel Valley Golf Club, and Pikewood National — and is documented in full detail, including the caddie-hierarchy politics, the pairing with caddie master Carl (also head of the TPC Scottsdale program), and its overlap with [[wiki/people/fran-coldren|Fran]]'s hospitalization and death, at [[wiki/work/nemacolin-caddying]]. The job years (2016–2019) run concurrent with the hardest financial stretch documented elsewhere in the wiki, making golf simultaneously his sport, his social world, and his primary paycheck for most of his twenties.

## Golf as relationship touchstone

Golf's role in the Annie relationship doesn't end with how they met — it recurs as a marker of the relationship's emotional temperature for a decade afterward. In April 2020, mid-pandemic, a friend's reaction to seeing Dan's Instagram ("LOOK HE PLAYS GOLF TOO!!") shows it was still a visible part of his public identity years after he'd stopped caddying professionally. That August, missing a round near his mother's birthday reads as a small, wistful regret rather than a major event. By **December 13, 2025** — deep in the relationship's terminal decline (see [[wiki/timeline/periods/dec-2025-spike]]) — golf resurfaces as something much sharper: Annie tells Dan "you would just have to walk out your door, i wouldn't make you go out on the golf course like when [we] used to, when you ACTUALLY liked me" — invoking walking golf courses together as a specific, named memory of when the relationship was good, thrown back at him as evidence of how far it had fallen. The full arc closes a loop that opened on a golf course in the rain in 2015: golf as the site of the relationship's best-documented origin moment becomes, a decade later, the site of its own eulogy.

## Gaps

No childhood or junior-golf origin story is documented — the corpus picks the sport up already in progress by the time messaging begins in 2015, and it's unclear whether Dan played growing up or took it up as an adult alongside the family's country-club world. Exact handicap, if he ever calculated one formally, is not recorded. Whether he golfed at all between the 2019 end of the caddying job and the 2020 Instagram/nostalgia references, or after 2020, is not documented in detail — 2025's only golf reference (a "GOLF themed YouTube channel" he watches, and a self-deprecating story about avoiding polo shirts since being told he "dressed like a golfer's little brother") suggests the interest persisted as media consumption and self-image even without confirmed active play.