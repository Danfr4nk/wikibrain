---
domain: interests
page_type: entity
status: closed
date_created: 2026-06-22
date_modified: 2026-07-13
sources:
  - raw/self/context-core/CONTEXT_CORE_EXPANDED.md
  - raw/self/message-csv/imessage_ALL_both_all_now.csv
related:
  - wiki/interests/music/overview
  - wiki/interests/music/aliases/sloppp
  - wiki/interests/music/aliases/mogzart
  - wiki/interests/music/aliases/gripnotic
  - wiki/interests/music/concepts/sub-bass-signature
tags: [music-production]
---

# Mogged Up

## Identity

**Mogged Up** is a bootleg/edit imprint — not a primary production alias but a release vehicle for unofficial edits and bootlegs. It operated concurrently with the SLOPPP and MOGZART eras. Status is `closed` as an active release vehicle.

## Genre & Style

| Dimension | Details |
|-----------|---------|
| Function | Bootleg / edit imprint (release vehicle, not production identity) |
| Genre | Electronic edits — genre-agnostic depending on source material |
| Era | Concurrent with SLOPPP/MOGZART (~2013–2016) |
| Status | Archived; no revival signals |

## Narrative

One release is confirmed by link slug in the message corpus: **Uffie – "The Art of Uff" (MOGGED UP)**, hosted on the MOGZART SoundCloud (`soundcloud.com/mogzartmusic/uffie-the-art-of-uff-mogged-up`) — establishing that Mogged Up functioned as a bootleg *series branding* on the MOGZART channel rather than a standalone account.

Mogged Up exists as a practical release vehicle rather than an aesthetic identity. Bootleg imprints allow release of unofficial edits without tying them to the primary alias — a standard practice in electronic production that separates catalog identity from experimental/unofficial output.

The name is a vernacular derivation: "mogged" (from "mog/mewing" subculture — being dominated or surpassed) repurposed as a production brand identity with some self-aware irony. Context for the name choice would need a dedicated source ingest.

## Related
- [[wiki/interests/music/overview]]
- [[wiki/interests/music/aliases/mogzart]]
- [[wiki/interests/music/aliases/sloppp]]
