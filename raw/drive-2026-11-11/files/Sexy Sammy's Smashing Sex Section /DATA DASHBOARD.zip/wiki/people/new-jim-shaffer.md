---
domain: people
page_type: entity
status: closed
date_created: 2026-06-23
date_modified: 2026-07-19
date_range_start: 2018-04-22
date_range_end: 2019-10-20
sources: ["raw/self/message-csv/MASTER_MESSAGES_DB_DUMP.csv", "raw/self/facebook/facebook-ihatedanfrank/messages/inbox/laurynashly_4_5jbvoqow/message_1.html"]
tags: [relationships, career, financial-stress]
knowledge: mixed
infobox:
  name: "New Jim Shaffer"
  relationship_to_dan: unknown
  sex: male
  location: nyc
  first_contact: 2018-04-22
  known_for: "Jim Shaffer — 'not the only Jim Shaffer' in Dan's life, hence the 'new' contacts-card label — is a wealthy childhood fri"
connections:
  - page: wiki/people/annie-ulmer
    type: co-occurs
    claim: "Jim's enthusiastic, judgment-free reaction to learning about the Dan/Annie arrangement — disclosing his own interest in swinging and negotiating toward joining an encounter — is a friend-group data point on how normalized the arrangement was among Dan's peers."
  - page: wiki/people/rob-orange
    type: co-occurs
    claim: "Jim's Dec 2018 remembrance and the Tom Petty minivan story are the corpus's second independent account of Rob, four years after his death — corroborating the 'live wire' character sketch Lauryn Ashly gives in real time the day he died."
  - page: wiki/people/steve-kezmarsky
    type: co-occurs
    claim: "Steve's death reaches the record through this thread — Jim hadn't heard, December 2018 — the second dead member (after Rob Orange) of the same high-school-era Uniontown circle."
---

# "New Jim Shaffer" (Jim Shaffer)

Jim Shaffer — "not the only Jim Shaffer" in Dan's life, hence the "new" contacts-card label — is a wealthy childhood friend from the same Fayette County high-school cohort, self-described as Dan's "longest standing friend on the planet" (`+14125139408`, 894 messages, April 2018 – October 2019). He splits time between a Florida golf community (Bay Hill) and Pennsylvania, collects high-end tour-issued golf equipment through a Titleist tour-van contact, and had just resolved a serious embezzlement accusation when the thread opens.

## The embezzlement case

The very first messages (April 22, 2018) find Jim mid-vindication: accused of stealing roughly $200K, he says a "terrible prelim investigation" and a Herald-Standard "smear campaign" overstated the amount and falsely implicated his mother's house. He'd left the company six months before it collapsed with $235K of his own invested capital never collected — a fact he says made the theft accusation illogical on its face. He spent $55,000 on an attorney specifically to demonstrate he had no financial motive, and by June 2018 was paying a $115,800 settlement to the Fayette County courthouse to close the matter, with plans to countersue the six people who'd accused him. He calls the county's justice system "a fuckin joke."

## Golf and wealth

A huge share of the thread is granular, expert-level golf-equipment talk — shaft specs, tour-issued Scotty Cameron and TaylorMade putters sourced through his contact "Eddie Castleman" (a 20-year Titleist tour-van employee), a self-described "$10K putter collection," and repeated offers to build Dan custom clubs at cost. Jim plays to a legitimate scratch-golfer standard, references a Bay Hill membership and matches for real money against strangers he deliberately "embarrasses," and treats golf gear as a genuine passion rather than a status prop, though the wealth is conspicuous throughout (a $1,500 abstract JFK painting he flips for profit, framed tour memorabilia, a motorcycle, casual references to inheritance).

## The non-monogamy proposition

On learning about the Dan/Annie arrangement (April 22, 2018), Jim reacts with detailed, enthusiastic curiosity rather than judgment, disclosing his own interest in swinging (a dedicated "red room" at his townhouse, a wife he hasn't been able to persuade) and negotiating in explicit detail toward joining an encounter with Annie — discretion terms, logistics, a proposed low-key first meeting over a shared bowl before anything further. The specific proposition's outcome isn't confirmed in the surviving thread, though by February 2019 the two are still discussing similar territory in a joking register, and Jim needles Dan for what reads as a parallel arrangement Dan was running with someone else that spring ("so then you have veto rights over who she fucks?").

Jim is also aware of, and treats as funny running gossip, Dan's 2019 NYC "hooker thing" — an October 2019 message ("bro. the hooker thing. I'm fucking DYING") that fits the same paid-companion economy documented on [[wiki/people/brian]] and [[wiki/people/jaredtricia]].

## Shared history and grief

The friendship's emotional core surfaces around [[wiki/people/fran-coldren|Fran]]'s death: Jim didn't know she'd died and is visibly upset he wasn't told, asks to see a video of the family together, and reacts warmly to a detail of Fran smoking marijuana with Dan near the end of her life. A December 2018 exchange remembers a mutual friend, [[wiki/people/rob-orange|Rob Orange]] — dead since April 2014 — first through a shared adventure ("Do you remember when me, you and rob orange took that suped up mini van to the Tom Petty concert"), then with real tenderness underneath the jokes: "Rob and I would talk on the phone and laugh till we cried for 2 hours at a time, 5 days a week. I'd trade everyone in that photo for one more call" — the one place in a thread otherwise dense with shock humor where the register drops entirely. The same conversation turns to [[wiki/people/steve-kezmarsky|Steve Kezmarsky]], another shared high-school-era contact: Jim briefly misunderstands Dan's joke and asks "Wait... he's dead?", but Dan corrects him — Steve was alive, sober, and raising two kids while his father faced a life sentence ("He's alive but living the least enviable life EVER").

> **REVISED [2026-07-19]:** This paragraph previously repeated the
> misreading that Steve Kezmarsky had died. The raw thread shows Dan
> explicitly correcting Jim's "Wait... he's dead?" in the next message.

**A note on tone:** the thread's humor throughout is dense with racial slurs, ethnic jokes, and shock-value dark comedy in the register of edgy 2010s internet humor. That register is described here rather than reproduced.

## Corpus Dimensions

| Metric | Value |
|--------|-------|
| Messages | 894 |
| Date range | 2018-04-22 to 2019-10-20 |
| Direction | Unreliable in this export (marked "Received" throughout) — read as one-way (Jim to Dan) |
| Handle | +14125139408 |
