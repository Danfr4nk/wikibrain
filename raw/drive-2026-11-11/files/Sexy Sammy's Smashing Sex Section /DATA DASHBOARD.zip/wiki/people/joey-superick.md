---
domain: people
page_type: entity
status: closed
date_created: 2026-06-23
date_modified: 2026-07-14
date_range_start: 2018-06-03
date_range_end: 2018-06-29
sources: ["raw/self/message-csv/MASTER_MESSAGES_DB_DUMP.csv"]
related: ["wiki/work/nemacolin-caddying", "wiki/self/message-corpora/master-message-dump"]
tags: [career, music-production, uniontown-era]
knowledge: mixed
infobox:
  name: "Joey Superick"
  relationship_to_dan: unknown
  first_contact: 2018-06-03
  known_for: "A warm, brief golf-and-music friendship from June 2018 (+17245623673, 23 messages) — Joey invites Dan to play, and the t"
---

# Joey Superick

A warm, brief golf-and-music friendship from June 2018 (`+17245623673`, 23 messages) — Joey invites Dan to play, and the thread's centerpiece is Dan apparently finding a pair of Joey's lost sunglasses on a gravel road ("No fucking way dude... You're the man!!!"). The two trade emo/post-hardcore music opinions (Brand New, Jesse Lacey, Taking Back Sunday's back catalog, "The Devil and God Are Raging Inside Me") with genuine enthusiasm, closing on a "talk later fuckboi" register that reads as established, easy friendship rather than a new acquaintance.

## Corpus Dimensions

| Metric | Value |
|--------|-------|
| Messages | 23 |
| Date range | 2018-06-03 to 2018-06-29 |
| Direction | Unreliable in this export (marked "Received" throughout) — read as one-way (Joey to Dan) |
| Handle | +17245623673 |

## Related

[[wiki/work/nemacolin-caddying]] · [[wiki/self/message-corpora/master-message-dump]]
