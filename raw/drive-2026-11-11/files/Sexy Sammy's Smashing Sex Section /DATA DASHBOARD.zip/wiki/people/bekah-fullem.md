---
domain: people
page_type: entity
status: closed
date_created: 2026-06-23
date_modified: 2026-07-20
date_range_start: 2020-02-09
date_range_end: 2020-03-29
sources:
  - raw/self/message-csv/imessage_export_17245629389_both_all_now.csv
tags: [mental-health, financial-stress, digital-footprint]
knowledge: mixed
infobox:
  name: "Bekah Fullem"
  relationship_to_dan: unknown
  sex: female
  first_contact: 2020-02-09
  known_for: "A brief pre-existing flirtation that turned into two crisis contacts in early 2020 — a dying cat and a rape disclosure Dan responded to with real warmth"
connections:
  - page: wiki/people/annie-ulmer
    type: evidenced-by
    claim: "In comforting Bekah after her rape disclosure, Dan discloses that Annie is herself a rape survivor, describing years before she reported it, a painful trial, and a 45-year sentence for the assailant — a previously undocumented fact about Annie's own history, sourced here to Dan's own account rather than a primary Annie-side source."
---

# Bekah Fullem

Rebekah "Bekah" Fullem's contact with Dan is preserved in a single
iMessage thread that a full two-sided export (handle `+17245629389`,
153 messages, Feb 9 – Mar 29, 2020) substantially recontextualizes.
The earlier one-sided extract — missing Dan's replies entirely — made
the thread read as a stranger's crisis outreach; the complete record
shows a pre-existing flirtation, a resolved financial request, and a
warm, appropriate response to a serious disclosure, plus one previously
undocumented fact about [[wiki/people/annie-ulmer|Annie]]'s own history.

## February 11: a flirtation, then a crisis

The thread opens not with crisis but with mutual flirtation: Bekah
responds to something Dan sent on Facebook, and Dan tells her plainly
"you have the privilege of being someone ive silently crushed on
for...ever" and "don't apologize to me!" The tone shifts fast when
Bekah, joking she has "no comment" but genuinely needing help, asks for
$40–50 for her cat Gideon's medication and food, warning he'll "get put
down" without it; Dan responds with a joking-but-real #MeToo-adjacent
line ("soooooo sell me some nudity and take care of that AND go
shopping?") before actually sending the money that same night — an
image (likely a payment screenshot) followed by "that'll even the
score" — resolving what the earlier extract left as an open question.
Payment-app trouble (Cash App broken, no PayPal, no working card)
extends the crisis into February 13, when Bekah says she'd had to push
Gideon's vet appointment to avoid an immediate euthanasia decision;
whether Gideon ultimately survived isn't recorded.

## March 29: disclosure, and a correction to the record

Six weeks later, Bekah opens a second exchange with "I was raped dude.
I haven't slept with anyone since then," describing a hostile police
response (asked why the assailant's parents hadn't heard her from
across the hall, why she'd previously had a relationship with him, why
she hadn't indicated interest in "that kind of sex"), that the
assailant got a lawyer and stalked her, and that she lost her job over
the fallout. Dan's actual response, previously undocumented, is direct
and validating: "wow i'm really sorry to hear that. i had no idea,"
followed by "well stay safe and feel better and i truly am sorry that
someone would be so awful to you to do that," and — reaching for
something concrete rather than just sympathy — "it's not going to make
you feel much better, i know...but at least you started a paper trail
that would be evidentiary if he ever does it again," closing with "so
if and when the time comes that you are ready: tell your story."

In the course of that support, Dan discloses that Annie went through
something similar: "i won't get into too much detail but Annie has been
through that and it took her years to report it. even the trial was
super painful and full of ptsd moments, but the shitbag who did it is
now in jail for 45 years (he was a serial rapist)." This is not
documented anywhere else in the corpus and is sourced here only to
Dan's own secondhand account, offered in the context of comforting a
third party — treat as a real but unverified claim about Annie's
history pending independent corroboration.

**A correction to the previous read of this page:** the earlier version
described Bekah as "insisting" COVID-19 was undercounted against "what
reads as Dan's skepticism" — the full export shows this was backward.
It is **Dan** who insists the pandemic is worse than officially reported,
drawing on a frontline New York vantage point just before the city's
lockdown peak ("nyc is still 3 weeks away from peak infection rates,"
"i have friends my age that are in ICU and can't get ventilators,"
"there are cops on every block of nyc"), while Bekah repeatedly pushes
back that she already knows and isn't being dismissive ("I know it's
bad," "I'm very aware it's underreported," "I know nurses"). She also
mentions her mother has cancer. The thread ends there, mid-exchange,
with no further contact recorded.

## Corpus record

| Metric | Value |
|---|---|
| Messages | 153 (iMessage, both directions) |
| Date range | 2020-02-09 – 2020-03-29 (two isolated clusters) |
| Handle | +17245629389 |
| Defining content | The March 29 rape disclosure and Dan's response; the Annie-assault disclosure |

**Gaps:** no prior or later contact with Bekah appears in the corpus.
The outcome of the cat's medical crisis, the disposition of her assault
report, and any relationship to Dan beyond these two crisis contacts
are undocumented. The Annie-assault claim has no independent
corroboration anywhere else in the corpus.
