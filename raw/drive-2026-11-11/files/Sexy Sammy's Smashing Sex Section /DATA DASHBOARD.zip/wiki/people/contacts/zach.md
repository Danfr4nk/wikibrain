---
domain: people
page_type: entity
status: stub
date_created: 2026-06-23
date_modified: 2026-07-14
date_range_start: 2017-09-27
date_range_end: 2018-04-13
sources: ["raw/self/message-csv/MASTER_MESSAGES_DB_DUMP.csv"]
related: ["wiki/self/message-corpora/master-message-dump", "wiki/mind/concepts/contact-gini"]
tags: [digital-footprint]
infobox:
  name: "Zach"
  relationship_to_dan: unknown
  first_contact: 2017-09-27
  known_for: "Contact identified via Google Contacts as Zach. Previously unresolved contact from iMessage corpus at handle +1843990326"
---

# Zach

## Identity
Contact identified via Google Contacts as Zach. Previously unresolved contact from iMessage corpus at handle `+18439903264`. 22 messages exchanged over 2017-09-27 to 2018-04-13. Sample interaction: "Bro can I grab some smoke 💨?? You work today ??". Appears in personal message contexts (not obvious spam per filter).

## Corpus Dimensions
| Metric | Value |
|--------|-------|
| Messages | 22 |
| Date range | 2017-09-27 – 2018-04-13 |
| Sent / Received (approx) | 0 / 22 |
| Sample | Bro can I grab some smoke 💨?? You work today ?? |

## Domain: Self
Part of the long-tail or mid-tier social graph. Contributes to contact Gini distribution and period behavioral profiles.

## Notes
Stub generated from MASTER_MESSAGES_DB_DUMP.csv analysis. Expand with any additional context from dox, FB, or other threads if identity emerges. Personal vs transactional role not fully resolved from this source alone.

## Related
- [[wiki/self/message-corpora/master-message-dump]]
- [[wiki/mind/concepts/contact-gini]]
