---
domain: people
page_type: entity
status: archived
date_created: 2026-06-23
date_modified: 2026-07-11
date_range_start: 2025-03-17
date_range_end: 2026-01-27
sources: ["raw/self/message-csv/MASTER_MESSAGES_DB_DUMP.csv"]
related: ["wiki/self/message-corpora/master-message-dump", "wiki/mind/concepts/contact-gini"]
---

# John Carney## Identity
Contact identified via Google Contacts as John Carney. Previously unresolved contact from iMessage corpus at handle `+17248759432`. 26 messages exchanged over 2025-03-17 to 2026-01-27. Sample interaction: "I forgot to hit send 30 min ago". Appears in personal message contexts (not obvious spam per filter).

## Corpus Dimensions
| Metric | Value |
|--------|-------|
| Messages | 26 |
| Date range | 2025-03-17 – 2026-01-27 |
| Sent / Received (approx) | 0 / 26 |
| Sample | I forgot to hit send 30 min ago |

## Domain: Self
Part of the long-tail or mid-tier social graph. Contributes to contact Gini distribution and period behavioral profiles.

## Notes
Stub generated from MASTER_MESSAGES_DB_DUMP.csv analysis. Expand with any additional context from dox, FB, or other threads if identity emerges. Personal vs transactional role not fully resolved from this source alone.

## Related
- [[wiki/self/message-corpora/master-message-dump]]
- [[wiki/mind/concepts/contact-gini]]
