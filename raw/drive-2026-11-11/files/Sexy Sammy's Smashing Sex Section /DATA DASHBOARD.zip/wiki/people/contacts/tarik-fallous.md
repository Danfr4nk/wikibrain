---
domain: people
page_type: entity
status: archived
date_created: 2026-06-23
date_modified: 2026-07-11
date_range_start: 2023-08-11
date_range_end: 2024-09-28
sources: ["raw/self/message-csv/MASTER_MESSAGES_DB_DUMP.csv"]
related: ["wiki/self/message-corpora/master-message-dump", "wiki/mind/concepts/contact-gini"]
---

# Tarik Fallous## Identity
Contact identified via Google Contacts as Tarik Fallous. Previously unresolved contact from iMessage corpus at handle `+19178259183`. 20 messages exchanged over 2023-08-11 to 2024-09-28. Sample interaction: "Whispering Angel - 0 

Chateau La Coste Rose - 0



La Luca Prosecco: 0

Fidora Prosecco - 0 





C". Appears in personal message contexts (not obvious spam per filter).

## Corpus Dimensions
| Metric | Value |
|--------|-------|
| Messages | 20 |
| Date range | 2023-08-11 – 2024-09-28 |
| Sent / Received (approx) | 0 / 20 |
| Sample | Whispering Angel - 0 

Chateau La Coste Rose - 0



La Luca Prosecco: 0

Fidora Prosecco - 0 





Charles de ferre, Bla |

## Domain: Self
Part of the long-tail or mid-tier social graph. Contributes to contact Gini distribution and period behavioral profiles.

## Notes
Stub generated from MASTER_MESSAGES_DB_DUMP.csv analysis. Expand with any additional context from dox, FB, or other threads if identity emerges. Personal vs transactional role not fully resolved from this source alone.

## Related
- [[wiki/self/message-corpora/master-message-dump]]
- [[wiki/mind/concepts/contact-gini]]
