---
domain: people
page_type: entity
status: archived
date_created: 2026-06-23
date_modified: 2026-07-11
date_range_start: 2018-11-10
date_range_end: 2019-01-11
sources: ["raw/self/message-csv/MASTER_MESSAGES_DB_DUMP.csv"]
related: ["wiki/self/message-corpora/master-message-dump", "wiki/mind/concepts/contact-gini"]
---

# Shannon## Identity
Contact identified via Google Contacts as Shannon. Previously unresolved contact from iMessage corpus at handle `+17245575578`. 23 messages exchanged over 2018-11-10 to 2019-01-11. Sample interaction: "Hey Daniel it’s Shannon give me a call when you get a chance". Appears in personal message contexts (not obvious spam per filter).

## Corpus Dimensions
| Metric | Value |
|--------|-------|
| Messages | 23 |
| Date range | 2018-11-10 – 2019-01-11 |
| Sent / Received (approx) | 0 / 23 |
| Sample | Hey Daniel it’s Shannon give me a call when you get a chance |

## Domain: Self
Part of the long-tail or mid-tier social graph. Contributes to contact Gini distribution and period behavioral profiles.

## Notes
Stub generated from MASTER_MESSAGES_DB_DUMP.csv analysis. Expand with any additional context from dox, FB, or other threads if identity emerges. Personal vs transactional role not fully resolved from this source alone.

## Related
- [[wiki/self/message-corpora/master-message-dump]]
- [[wiki/mind/concepts/contact-gini]]
