---
domain: people
page_type: entity
status: stub
date_created: 2026-06-23
date_modified: 2026-07-14
date_range_start: 2016-02-12
date_range_end: 2020-05-09
sources: ["raw/self/message-csv/MASTER_MESSAGES_DB_DUMP.csv"]
related: ["wiki/self/message-corpora/master-message-dump", "wiki/mind/concepts/contact-gini"]
tags: [digital-footprint]
infobox:
  name: "Tan Calabrese"
  relationship_to_dan: unknown
  first_contact: 2016-02-12
  known_for: "Contact identified via Google Contacts as Tan Calabrese. Previously unresolved contact from iMessage corpus at handle +1"
---

# Tan Calabrese

## Identity
Contact identified via Google Contacts as Tan Calabrese. Previously unresolved contact from iMessage corpus at handle `+17249846086`. 57 messages exchanged over 2016-02-12 to 2020-05-09. Sample interaction: "Fuck I wish I would've seen that earlier... Feel like saving me some until tomorrow?  I'll throw you". Appears in personal message contexts (not obvious spam per filter).

## Corpus Dimensions
| Metric | Value |
|--------|-------|
| Messages | 57 |
| Date range | 2016-02-12 – 2020-05-09 |
| Sent / Received (approx) | 0 / 57 |
| Sample | Fuck I wish I would've seen that earlier... Feel like saving me some until tomorrow?  I'll throw you whatever |

## Domain: Self
Part of the long-tail or mid-tier social graph. Contributes to contact Gini distribution and period behavioral profiles.

## Notes
Stub generated from MASTER_MESSAGES_DB_DUMP.csv analysis. Expand with any additional context from dox, FB, or other threads if identity emerges. Personal vs transactional role not fully resolved from this source alone.

## Related
- [[wiki/self/message-corpora/master-message-dump]]
- [[wiki/mind/concepts/contact-gini]]
