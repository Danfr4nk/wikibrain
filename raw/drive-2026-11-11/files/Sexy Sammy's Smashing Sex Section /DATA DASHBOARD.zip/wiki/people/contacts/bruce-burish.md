---
domain: people
page_type: entity
status: archived
date_created: 2026-06-23
date_modified: 2026-07-11
date_range_start: 2018-10-23
date_range_end: 2018-10-27
sources: ["raw/self/message-csv/MASTER_MESSAGES_DB_DUMP.csv"]
related: ["wiki/self/message-corpora/master-message-dump", "wiki/mind/concepts/contact-gini"]
---

# Bruce Burish## Identity
Contact identified via Google Contacts as Bruce Burish. Previously unresolved contact from iMessage corpus at handle `+17249848911`. 181 messages exchanged over 2018-10-23 to 2018-10-27. Sample interaction: "Yo man! It’s Bruce". Appears in personal message contexts (not obvious spam per filter).

## Corpus Dimensions
| Metric | Value |
|--------|-------|
| Messages | 181 |
| Date range | 2018-10-23 – 2018-10-27 |
| Sent / Received (approx) | 0 / 181 |
| Sample | Yo man! It’s Bruce |

## Domain: Self
Part of the long-tail or mid-tier social graph. Contributes to contact Gini distribution and period behavioral profiles.

## Notes
Stub generated from MASTER_MESSAGES_DB_DUMP.csv analysis. Expand with any additional context from dox, FB, or other threads if identity emerges. Personal vs transactional role not fully resolved from this source alone.

## Related
- [[wiki/self/message-corpora/master-message-dump]]
- [[wiki/mind/concepts/contact-gini]]
