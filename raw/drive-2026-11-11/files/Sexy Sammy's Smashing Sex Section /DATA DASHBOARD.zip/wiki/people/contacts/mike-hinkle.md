---
domain: people
page_type: entity
status: archived
date_created: 2026-06-23
date_modified: 2026-07-11
date_range_start: 2018-03-08
date_range_end: 2019-07-03
sources: ["raw/self/message-csv/MASTER_MESSAGES_DB_DUMP.csv"]
related: ["wiki/self/message-corpora/master-message-dump", "wiki/mind/concepts/contact-gini"]
---

# Mike Hinkle## Identity
Contact identified via Google Contacts as Mike Hinkle. Previously unresolved contact from iMessage corpus at handle `+19043124149`. 21 messages exchanged over 2018-03-08 to 2019-07-03. Sample interaction: "What? Are you a pimp now or something? Hope Fran is ok". Appears in personal message contexts (not obvious spam per filter).

## Corpus Dimensions
| Metric | Value |
|--------|-------|
| Messages | 21 |
| Date range | 2018-03-08 – 2019-07-03 |
| Sent / Received (approx) | 0 / 21 |
| Sample | What? Are you a pimp now or something? Hope Fran is ok |

## Domain: Self
Part of the long-tail or mid-tier social graph. Contributes to contact Gini distribution and period behavioral profiles.

## Notes
Stub generated from MASTER_MESSAGES_DB_DUMP.csv analysis. Expand with any additional context from dox, FB, or other threads if identity emerges. Personal vs transactional role not fully resolved from this source alone.

## Related
- [[wiki/self/message-corpora/master-message-dump]]
- [[wiki/mind/concepts/contact-gini]]
