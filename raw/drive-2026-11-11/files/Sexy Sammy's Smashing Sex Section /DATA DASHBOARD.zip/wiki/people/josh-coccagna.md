---
domain: people
page_type: entity
status: closed
date_created: 2026-06-23
date_modified: 2026-07-14
date_range_start: 2017-04-12
date_range_end: 2019-02-01
sources: ["raw/self/message-csv/MASTER_MESSAGES_DB_DUMP.csv"]
related: ["wiki/work/nemacolin-caddying", "wiki/self/message-corpora/master-message-dump"]
tags: [career, addiction-recovery, uniontown-era]
knowledge: mixed
infobox:
  name: "Josh Coccagna"
  relationship_to_dan: unknown
  first_contact: 2017-04-12
  known_for: "Josh Coccagna's relationship with Dan shifts registers entirely over its two-year span (+14124450765, 32 messages, April"
---

# Josh Coccagna

Josh Coccagna's relationship with Dan shifts registers entirely over its two-year span (`+14124450765`, 32 messages, April 2017 – February 2019): it opens as a golf-professional mentor relationship — swing tips ("keep your weight on the inside sole of your foot"), updates on a new Mountain Course and clubhouse renovation at what reads as a competing high-end resort to Nemacolin (one hole "hosted a Ryder Cup"), and a November 2017 reference-check call about a golf-staff intern applicant — and ends, by February 2019, as a psychedelics supply contact: Josh describing $80 DMT carts ordered by mail, having sent one to a mutual friend "Jerad," and offering to keep Dan in mind for the next batch.

## Corpus Dimensions

| Metric | Value |
|--------|-------|
| Messages | 32 |
| Date range | 2017-04-12 to 2019-02-01 |
| Direction | Unreliable in this export (marked "Received" throughout) — read as one-way (Josh to Dan) |
| Handle | +14124450765 |

## Related

[[wiki/work/nemacolin-caddying]] · [[wiki/self/message-corpora/master-message-dump]]
