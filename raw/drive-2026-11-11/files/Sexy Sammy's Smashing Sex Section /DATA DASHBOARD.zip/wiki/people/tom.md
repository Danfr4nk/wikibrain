---
domain: people
page_type: entity
status: active
date_created: 2026-06-22
date_modified: 2026-07-18
sources: ["raw/self/dox-scan/dan tom 2010 2022.txt", "raw/self/dox-scan/Dan Profile.txt", "raw/self/message-csv/MASTER_MESSAGES_DB_DUMP.csv", "raw/self/message-csv/imessage_ALL_both_all_now.csv", "raw/self/dox-md/operating_manual.md", "raw/self/dox-md/tom_kristin_master_dossier.md", "raw/self/context-core/CONTEXT_CORE_EXPANDED.md", "raw/self/dox-md/Gemini-_18.md", "raw/self/dox-scan/DanAnnie_CompleteRecord_Final.docx", "raw/self/dox-md/LIFE_EVENTS_CALENDAR.md", "raw/self/dox-md/Cash register shortage explanation.md", "raw/self/dox-md/_Deconstructing a Chaotic 24 Hours .md"]
tags: [addiction-recovery, dui, ai-collaboration, relationships, mental-health]
infobox:
  name: "Tom"
  relationship_to_dan: unknown
  sex: male
  location: uniontown
  known_for: "Tom Maison — Dan's primary male ally and, for most of the corpus, the clearest instance of safe, lateral (peer, non-pate"
connections:
  - page: wiki/mind/synthesis/block-unblock-loop
    type: component-of
    claim: "The May 18 2026 conditional unblock and the 2014 declared-done-then-return precedent are the loop's peer-bond case — blocks failed both times because Tom was the sole supply node."
  - page: wiki/mind/synthesis/vertical-authority-skepticism
    type: evidences
    claim: "Tom is the positive-case exhibit: the clearest safe lateral (peer, non-paternal) attachment in the corpus, against which the vertical-suspect pattern is measured."
  - page: wiki/mind/concepts/attachment-model
    type: instantiates
    claim: "The May 2026 block/unblock cycling with Tom shows the conflict architecture running on a peer bond at lower amplitude — the model is partner-independent."
  - page: wiki/people/kristin
    type: contains
    claim: "The intense late-2025 Kristin thread enters the graph through Tom's social circle; he is the introduction vector."
  - page: wiki/people/annie-ulmer
    type: co-occurs
    claim: "Tom is a recurring selected participant in the 2018-2024 arrangement, chosen because aftermath with a friend was manageable — see arrangement-history for the framework."
  - page: wiki/timeline/periods/2025-collapse
    type: supplies
    claim: "During the Annie collapse Tom is simultaneously crisis anchor and supply line; the dual role is what makes the spring 2026 supply failures a relationship-ending event rather than a logistics problem."
  - page: wiki/work/bfs-foods
    type: causes
    claim: "Tom's mid-May 2026 string-along supply failure is the first domino of the BFS crisis — the withdrawal it caused impaired the shift the drawer variance was pinned to, and the 2014 precedent recovered there reframes his reliability as transactional across the whole record."
  - page: wiki/mind/synthesis/supply-network
    type: component-of
    claim: "Tom is the network's terminal-era sole node and its characteristic failure mode: the friendship-embedded supplier whose owe-and-silence cycles (2014, 2026) demonstrate that in this market intimacy licenses failure while distance disciplines."
  - page: wiki/people/johnny-dealer
    type: follows
    claim: "Tom succeeded Johnny (via the undocumented Tim) as primary strip source by 2025 — the succession from transactional dealer to friendship-embedded friend-supplier that exposed the network to the owe-and-silence failure mode."
---


# Tom

## Identity

Tom Maison — Dan's primary male ally and, for most of the corpus, the clearest instance of safe, lateral (peer, non-paternal) attachment in the record — the positive-case exhibit for [[wiki/mind/synthesis/vertical-authority-skepticism|the lateral-trusted, vertical-suspect split]] that structures Dan's relationship to authority generally. He is also the "Tom" of the October 2024 incident referenced on [[wiki/people/annie-ulmer]]: a participant, alongside Dan and Annie, in the couple's established quasi-non-monogamous arrangement (2018–2024) — the dossiers' final assessment revises that encounter from apparent coercion to exhaustion-within-an-established-consensual-framework, with Tom as one of the recurring participants Dan selected specifically because he was a friend he could manage the aftermath with; full arrangement context at [[wiki/mind/psychosexual/arrangement-history]]. About three weeks older than Dan, based in the Pittsburgh area, with Ohiopyle excursions a recurring shared setting. He functions simultaneously as anchor and supply line (Suboxone, mushrooms, cocaine, klonopin), and was described, through most of the record, as "the one place Dan is not performing." The friendship dates to roughly 2010. Handle +17249987341 (~4,160 messages in the master dump; a further ~1,600 under phloxenheim@gmail.com). Tom is also the connective tissue to [[wiki/people/kristin]], whose intense late-2025 thread runs through his social circle.

**The characterization above no longer holds without qualification.** The final months of the message record (March–May 2026) document the friendship's collapse under exactly the supply-line strain the "anchor" framing depended on. See "The Collapse (Spring 2026)" below.

The Tom/Kristin dossier characterizes Tom as an irony-poisoned stoic — a pragmatic "narco-logistician" who stays unflappable through Dan's suicide threats and withdrawals, offering validation without judgment or any push toward rehab. In the Gemini-_18 profile transfer he is framed as "primary peer collaborator… core close friend and external peer collaborator" engaged in recurring creative and technical dialogue — the role designated as social-graph redundancy after the Annie closure.

## Corpus Dimensions

| Metric | Value |
|--------|-------|
| Total messages (master) | 4,160 (handle +17249987341); ~1,603 more under phloxenheim@gmail.com |
| Volume rank | #5 in the master top handles (after the Annie threads and Kristin) |
| Date range | Documented friendship 2010–May 30 2026 (last dated message) |
| Peak periods | 2017–2018 (supply during the poverty floor), 2025 Annie collapse, spring 2026 (own collapse — see below) |

## Behavioral Counts (Tom)

| Pattern | Evidence |
|---------|----------|
| Supply events | Repeatedly "shows up with cocaine and mushrooms"; Suboxone strips during withdrawal |
| First-call for major events | Trump shooting, Biden dropout, GameStop, the FSLY tip (Sep 2020) |
| Parallel silences | Goes radio-silent when he owes a delivery (e.g. May 2016 during Dan's withdrawal) |

## Behavioral Counts (Dan, Calibrated)

Dan's reliance on Tom is high during mutual alignment and drops to blocking behavior during asymmetric periods (when Tom owes and goes silent). The relationship reads as a reliable lateral ally when incentives align and an unreliable one when they don't — a pattern distinct from the vertical/paternal loads elsewhere in the graph. The spring 2026 collapse (below) shows this same pattern running to actual rupture rather than self-correcting: real blocking, real financial accusations, real threat of third-party (Phil) involvement.

## Domain: Self

Safe attachment with minimal forensic mode engaged through most of the record — notable precisely because almost every other major relationship in the corpus triggers analysis. That distinction narrows at the very end: by May 2026 the friendship is generating its own documented conflict-escalation and blocking behavior, the same architecture seen elsewhere in the corpus, just at lower amplitude. See [[wiki/mind/concepts/attachment-model]] and the collapse-period supply role in [[wiki/timeline/periods/2025-collapse]].

## Texture from the corpus

The two handles capture two registers. The primary number (+17249987341)
runs the day-to-day logistics and politics: quick supply coordination ("Do
you need some tomorrow?"), running political commentary (a January 2026 riff
imagining Trump announcing a move "for the people of Isr—Venezuela"), and the
low-grade owe-and-silence maintenance that ends, characteristically, on
"testing" as the final message. The banter is dense with in-jokes and casual
cruelty toward shared targets — the "narco-logistician" stoicism the dossier
describes, rendered in practice as unbothered absorption of whatever Dan
brings.

The phloxenheim@gmail.com handle (early–2026, ~1,600 messages) is where the
technical-collaborator role is most visible and most current. By March 2026
Tom is evangelizing agentic AI to Dan — describing "Antigravity … the new
google AGENT ai which means it can act like a person," and boasting that he
had one AI "interview" his other AI and build him "a custom GROUP CHAT" to
talk to both at once. The thread also carries the friendship's darker
undertow: a March 24 message, "Will you talk to me for a little bit?", lands
after a stretch of one-sided sends — the same lateral-ally-goes-quiet pattern,
this time with Tom on the asking side.

## A supply crisis and a car battery (undated Gemini/"Max" chat)

A separate, undated AI chat log captures a real-time Suboxone supply
crisis and the loyalty gesture that resolved it: someone "jumped
[Dan's] place in line" and bought out a dealer's stock right when Dan
needed to restock, and Tom — described in the same conversation as "my
main guy for, well... everything" — came through anyway, apparently at
his own financial loss ("he probably literally lost money on it too").
The same exchange carries the fullest documented texture of Suz's own
relationship with Tom: she is the only one who can call him directly
(despite Tom being younger than Dan), he "LOVES" her, and he'd bought
her a replacement car battery the week before when hers died and she
couldn't afford one — unprompted, no request made. The conversation
closes with Dan floating making a song for Tom, on the condition it
include "a reference to lil lexie" — an inside reference otherwise
undocumented in the corpus.

## The DUI (fall 2025 – early 2026)

The "DUI-court scheduling conflicts" that surface as friction in the spring
2026 collapse (below) trace back to a traffic stop in Fayette County on
2025-10-11: Tom blew clean on a breathalyzer but was held for field sobriety
testing anyway ("Bored 51 cops trying to find a reason... they ran me
through field sobriety until they felt satisfied with charging me"), and
reasoned in the moment that if it had happened in Fayette rather than
elsewhere he'd have spent the weekend in jail. It became a real,
lawyered-up case: by November 10 he describes "macro panic attacks about
this dui hearing" and the cost of paying a lawyer; by December 31 he's
citing a PA Supreme Court precedent on totality-of-circumstances DUI
charging, evidently researching his own defense; a January 14, 2026 message
still references an unresolved trial. This runs concurrently with, and is
distinct from, [[wiki/people/annie-ulmer]]'s own October 26, 2025 DUI arrest
in the same county.

## The Collapse (Spring 2026)

The phloxenheim thread runs continuously from March 24 through May 30, 2026
(the last dated message in the corpus for either handle), and read in full it
documents the friendship coming apart under its own supply-line economics —
not a single rupture but an accelerating cycle of the same "owe-and-silence"
pattern noted above, run enough times to burn out the reserve of goodwill it
had always run on.

**Late March: parallel breakups, mutual scaffolding.** The month opens with
real reciprocity — the two trade AI-manipulation tactics for their respective
relationships (Tom workshopping an "art of seduction" strategy on a new,
short-lived girlfriend — confirmed by Dan (2026-07-14) to also be named
**Kristin**, a coincidence and a different person entirely from
[[wiki/people/kristin]]; Dan running Annie/Kristin analysis prompts for him),
and Dan talks Tom through a possible suicidal ideation on March 31 ("I'm a
fucking mess Dan and I'm gonna make it your problem" / "considering the rope
just so this stops") with the same dark, deflecting affection that defines
the friendship at its best ("YOU were the one who kept popping it... you
don't get to be fucking emo"). This is the friendship functioning as designed.

**April: the transactional layer visibly thins.** Sub (Suboxone) handoffs
continue on a roughly weekly cadence, but delays start compounding — missed
windows ("4p?" / "???" / "helllooo" un-answered for hours on Apr 10),
Dan's April 9 "I am going to be totally out of subs so please figure it out"
already reads as a person managing a supplier, not a friend. By late April
Tom has cycled through a new girlfriend ("Brandy") and started declining
Dan's calls to be with her ("I can't really talk. I have Brandy here with
me."), which Dan needles as a status reversal — "NOW I AM COOLGUY... SORRY
CAN'T TALK COOLGUY HAS A GIRL IN HIS BED."

**May: the supply relationship fails and the friendship fails with it.** The
pattern of "cash app me $30, I'll give you 2" repeats through early May with
growing friction (Annie's ex-boyfriend commentary, DUI-court scheduling
conflicts on Tom's side). It reaches its breaking point on May 15–16: Tom
promises to bring subs after "weed whacking," goes silent for hours while
Dan escalates from "Tom / What the uck" through repeated unanswered pings to
"Come on dude seriously" to "Fuck you dude" — Dan facing a real consequence
(calling off work, risk of termination) from the no-show. By May 18 Dan has
apparently blocked Tom and unblocks him only to set an ultimatum — the
[[wiki/mind/synthesis/block-unblock-loop|block/unblock loop]] running on a
peer bond, and failing to hold for exactly the reason that page argues
(the supply dependency still ran through the channel) ("I'm
unblocking you for the moment — if you want to let me know what's going on
this morning I'll keep it open otherwise fuck you"), then pivots the same day
to a straight financial demand: "How long will it take you to get the $36
you owe me / I don't want the tex I want the money back." The thread goes
quiet for eleven days. It resumes May 29 with Dan accusing Tom of running "a
$30 come up" on him, and by May 30 — the record's last message on this
thread — Dan is threatening to route the dispute through Tom's father: "if it
really becomes necessary I can just explain to Phil that I would like the
object back that is very obviously not something that tom got."

The record ends there, unresolved: no reconciliation, no formal severance,
just the same silence pattern that used to resolve itself running out its
string. Whether the friendship recovers past May 30, 2026 is not documented.

## The pattern is twelve years old, not new (2014 precedent)

The spring-2026 collapse is often read as a late-life degradation of an
otherwise-safe bond, but the BFS drawer-dispute reconstruction
([[wiki/work/bfs-foods]]) surfaced a near-identical episode from **twelve
years earlier**, and it forces a revision. In August–September 2014 Tom
ran the same owe-and-silence sequence: Dan on Aug 20, 2014 —
"Do you have any fucking clue how shitty I feel? I waited 2 weeks
already… you need to get me the rest of what you owe me TODAY"; Sept 1 —
"What the fuck man"; Sept 10 — "remember how you stopped giving a fuck
that you owed me when you didn't need me to buy your shit anymore?"
followed by "I'm done and I'm going to make it my dumb fuck mission in
life to blow your spot up. I'm not doing this stupid fucking dance with
you anymore"; then, on Sept 15, right back to him — "yo looking to
purchase sub/tex whatevz. anything around?" — the channel reopening the
moment Dan needed product again. That is not "a day or two" of
unreliability. It is a multi-week owe-stonewall-escalate-declare-done-
reconcile cycle, documented in 2014 and re-run identically in 2026, with
Dan's own 2014 diagnosis naming the mechanism precisely: Tom's
reliability is transactional — high during mutual dependence, degrading
to indifference once he no longer needs Dan as a buyer. The language even
rhymes across the twelve years: 2014's "I'm not doing this stupid fucking
dance with you anymore" and 2026's "this is some real
[[wiki/people/kristin|Kristin]]-coded shit" are the same affective
category — *this person is producing outputs functionally
indistinguishable from someone untrustworthy* — the 2026 version simply
having the Kristin deception-cost slot available to anchor it.

The load-bearing revision is Dan's own, and it is what finally names what
"safe" was carrying. Asked what bothered him most about the 2026 failure,
he answered that it wasn't the money: "the thing that bothers me the most
is not money but that he would be okay letting me go sick." The
"unconditional safe attachment" framing does not survive that unrevised —
not because Tom is bad, but because most of what made him feel safe was
that he was *available during the periods when being available cost him
nothing*, which is a real form of presence but is not what Dan wanted
"safe" to mean (the person who treats my baseline okayness as
non-negotiable). The corpus-consistent version, fitting the years of real
connection AND the 2014 episode AND 2026, is: **lateral ally during
periods of mutual alignment, unreliable to indifference during asymmetric
periods.** The three-burns-in-four-days cascade that helped end the BFS
job (Tom Friday, a second contact Sunday, a workplace customer during the
shift) is that same asymmetric-period unreliability at its most costly —
Tom's string-along "soon"s consumed the optionality Dan needed to source
elsewhere while alternatives still existed.

## Domain: Tech

Recurring conversations on AI, image generation, agentic tooling, and bots —
the "creative/technical collaborator" framing from the Gemini profile, borne
out in the phloxenheim thread above.

A late-October 2025 (Oct 28) exchange (found 2026-07-14, random corpus
sample; re-examined 2026-07-14 with the full night's thread — the earlier
summary had the speaker attributions backwards on the music half) adds
self-description on both sides. Tom, needled by Dan ("leftist tom maison"),
self-deprecates in the third person — "Leftist Tom is even more soy than I
am now" — while Dan separately claims electoral politics and "several very
specific music flavors" as the two subjects where his opinion still
carries weight with Tom ("nobody should listen to me about literally
anything ever... unless it has to do with electoral politics or several
very specific music flavors"). It's Dan, not Tom, who goes on to describe
having gone roughly seven years without caring about music before
recently picking dance-music production back up — "i swear i forget how
to produce music... i can not for the life of me remember how to actually
throw a song together" — and finding the genre's build/drop structure
("intro, build, drop reset, build, drop") harder to internalize than the
verse-chorus songwriting he grew up on, adding "dance music is literally
not the same as the music i have encoded in my brain. it is literally 98%
about evoking emotional response rather than crafting something catchy."
This lines up with [[wiki/interests/music/overview]]'s own account of a
2026 production "reactivation" under the GRIPNOTIC alias — this Oct 2025
exchange is an early, dated data point for that reactivation, not a Tom
biography detail. Tom's own music history surfaces separately in the same
session, as a listener rather than producer: "I got my fill of house music
living with Jake Thwaite doing poppers."

## Timeline

| Date | Event |
|------|-------|
| 2010+ | Friendship forms post-dropout |
| 2017–2018 | Supply and anchor during the poverty floor |
| 2020-09 | FSLY stock tip |
| 2024 | Political-burst exchanges |
| 2025 | Supply during the Annie collapse; recurring silence patterns |
| 2026-03-31 | Dan talks Tom through crisis/suicidal ideation ("I'm gonna make it your problem") |
| 2026-04 | Sub-supply delays compound; Tom's "Brandy" relationship displaces call availability |
| 2026-05-15/16 | No-show breaking point: Dan risks his job over an unfulfilled sub promise |
| 2026-05-18 | Dan blocks/unblocks Tom; pivots to demanding the $36 owed back as cash, not product |
| 2026-05-29/30 | Renewed accusation ("$30 come up"); Dan threatens to go through Tom's father Phil over a disputed possession — last dated message in the record |

## Notes

The BFS bootloader records a small standing debt ("Tom still in Uniontown, $36 still owed") — consistent with, and likely the same debt named in, the May 18 2026 demand documented in the Collapse section above; what reads elsewhere as trivial is, by that point, the proximate trigger of an actual rupture.

**Gaps:** whether the friendship recovered after May 30, 2026 is undocumented — the record simply stops. Phil is confirmed as Tom's father (2026-07-14). The March "cabin"/pagan-occult girlfriend is confirmed to also be named Kristin (unrelated to [[wiki/people/kristin]]) but her surname is unknown; "Brandy"'s surname is likewise not established.

