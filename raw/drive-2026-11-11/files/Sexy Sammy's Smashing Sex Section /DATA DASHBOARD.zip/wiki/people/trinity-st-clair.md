---
domain: people
page_type: entity
status: closed
date_created: 2026-06-23
date_modified: 2026-07-14
date_range_start: 2019-03-12
date_range_end: 2019-12-24
sources: ["raw/self/message-csv/MASTER_MESSAGES_DB_DUMP.csv", "raw/self/dox-scan/history.txt", "raw/people/annie-ulmer/escort-messages-chatgpt-export-2025-08.md"]
related: ["wiki/people/annie-ulmer", "wiki/timeline/events/shelbie-annie-threesome-april-2019", "wiki/people/eric-jester", "wiki/self/message-corpora/master-message-dump", "wiki/mind/psychosexual/arrangement-history"]
tags: [relationships, digital-footprint]
knowledge: mixed
infobox:
  name: "Trinity St Clair"
  relationship_to_dan: unknown
  location: nyc
  first_contact: 2019-03-12
  known_for: "Trinity St. Clair — the adult film performer of that name, per the contact card (booking email booktrinitystclair@gmail."
---

# Trinity St. Clair

Trinity St. Clair — the adult film performer of that name, per the contact card (booking email `booktrinitystclair@gmail.com` alongside a personal one) — was a paid companion Dan and Annie booked days after Dan's March 2019 move back to New York, in the same broad March–June 2019 window as the [[wiki/timeline/events/shelbie-annie-threesome-april-2019|Shelbie threesome]] where the couple's non-monogamous arrangement was running with women rather than the more commonly documented male friends. The direct thread with Trinity (`+18186510883`, 20 messages) shows two rounds of cancellation and a comedy-of-errors delay — the "tryst or lack thereof" the thread itself leaves genuinely ambiguous — but a separate, independently dated message to a friend confirms flatly that it happened: paid, completed, and framed as one of the first things Dan did on returning to the city.

## The booking: "the first thing I did"

The origin is dated precisely and given real context. On March 12, 2019, minutes into catching an old friend up on his life, Dan announces: "Dude you're gonna love this. I moved back to nyc. And the first thing I did was booked an hour with trinity st clair for an hour with my girlfriend and I. So on March 20 I get to fuck trinity st clair for $1500." The framing to his friend is part celebration, part financial justification — "you're gonna pay 1000 for any high class call girl here, so for an extra 500" — and part general largesse: in the same conversation he offers to fly the friend and his girlfriend out to visit, unprompted ("I will book you a flight if I have to... I'm rich now I can do that stuff"). The booking reads less as a considered relationship decision and more as the inaugural extravagance of a flush, freshly-returned New York chapter — the same energy that funded it shows up nowhere else as clearly as in this one conversation.

## The thread itself: sick, groggy, and twice rescheduled

The direct messages from Trinity, starting March 21, are almost entirely apologetic. She opens warmly ("Hey luv... it's trin") but within hours is postponing, citing a sore throat she jokes came from "the insane deep throat scene I just did" and promising to make it work "maybe this weekend." They land on Sunday the 24th at 7 PM. That afternoon she asks Dan to send an Uber; a message mid-afternoon — "Moving slowly ask ur girl if i should bring this" [image not preserved] — confirms Annie was directly involved in the planning, not a passive third party. Then, at 7:55 PM, the visit collapses a second time: "Omg.... i'm so sorry I totally just doze off... Slept like shit last night," followed by an outright cancellation two and a half hours later — "Fuck tell the lady I'm just not feeling up to par.... so I'm going to try and go to bed early... if you guys will have me tomorrow I promise to make it an awesome fantastic sexual escape!!! I feel groggy as fuck like I took half a Xanax LOL." The thread's last message in this cluster is a bare "Hey there" the next afternoon (March 25) — and then nothing. Read in isolation, the thread ends on a cliffhanger: booked, twice postponed, last contact a non-committal greeting with no confirmed follow-through.

## What actually happened

It happened — just not inside this thread. Two terse, undated-in-context solo texts bracket the likely date: "Trinity st clair," sent March 20 (the original scheduled date, before the reschedules) and again March 26 (the day after the thread goes quiet) — plausibly a brag or a note-to-self on each end of the actual event. The firm confirmation comes from a completely separate conversation: on April 8, 2019, catching up with a friend, Dan writes, unprompted, "ps i paid $1500 last week to have pornstar trinity st clair come hang out with my girlfriend and i for exactly one hour last week soooooooo things are shaping up pretty well here in nyc too lololol" — past tense, specific, and dating the actual visit to roughly March 28 – April 1, a few days after the direct thread's last "Hey there." The $1500 figure matches the March 12 price quote exactly. So the record shows real, well-documented friction (sickness, oversleeping, a canceled Sunday) resolving into a completed booking that simply isn't captured in the surviving Trinity-handle export — probably closed out by phone call or a message thread not preserved in this corpus.

## The afterlife: Trinity as social proof

Trinity's role in the record didn't end with the visit. On July 9, 2019 — three and a half months later, in the middle of an unrelated conversation about one of Annie's own paid client bookings — Dan mentions he had recently emailed a prospective companion quoting $1700, and that he'd used the March booking as a credibility anchor in that outreach: "in my email i said (if you happen to know trinity st clair she can vouch for us)." He follows up moments later with an observation that the two performers were personally connected — "i think the $1700 girl that i emailed is staying with trinity... they're together at the very least, she was in her snap story." Trinity had become, by mid-2019, less a one-off transaction than a reference point: proof of a successful, no-drama prior booking that Dan actively invoked to vet and reassure future ones.

## December 2019: a second inquiry

The only other contact is a single-day cluster on December 24, 2019: Trinity opens with "Merry Christmas," then immediately pivots to business — "1300 per hr" — and asks for verification. Whether this was Dan reaching out first (the greeting reads like a warm re-approach to an existing contact) or Trinity's own holiday outreach to past clients is unclear from the surviving side of the thread; either way it reads as a fresh booking inquiry restarting the professional relationship at a slightly lower advertised rate than the original $1500, rather than a continuation of the March visit. Nothing in the corpus confirms whether this second booking happened.

## Corpus Dimensions

| Metric | Value |
|--------|-------|
| Messages (direct thread) | 20 |
| Date range | 2019-03-21 to 2019-12-24 (two isolated clusters) |
| Direction | Marked "Received" throughout in this export — read as two-way; the confirming context comes from separately-dated Sent messages to third parties |
| Handle | +18186510883 |
| Price | $1500 for one hour (March 2019); $1300/hr quoted (December 2019) |

## The recommendation trail

By August 2019, the booking had become a reference point Dan used more
than once. Beyond the [[wiki/people/jaredtricia|Jared/Tricia]] email
citation already noted above, a separately recovered thread shows the
same couple asking directly for a provider recommendation and Dan (again
writing in Annie's "Hazel" voice — see [[wiki/people/jaredtricia]] for
the full context of that impersonation) naming Trinity as the only
provider he had "personal experience with," quoting a price of "1400" —
a minor $100 discrepancy against the $1,500 documented above from two
independent contemporaneous sources, plausibly just loose recall in a
casual text rather than a real second rate.

## Gaps

The December 2019 booking inquiry's outcome is undocumented. No literal OnlyFans DM export or email correspondence with Trinity herself survives in the raw corpus — the "vouch for us" reference is known only from Dan's own retelling in a text to Annie, not from the email itself. Whether the browser-history download of a Trinity St. Clair clip (undated, found in a late-night viewing session alongside dozens of other performers' content) predates or postdates the March 2019 booking is not established — it may represent prior familiarity with her work that led to the booking, or unrelated later viewing.

## Related

[[wiki/people/annie-ulmer]] · [[wiki/timeline/events/shelbie-annie-threesome-april-2019]] · [[wiki/people/eric-jester]] · [[wiki/self/message-corpora/master-message-dump]] · [[wiki/mind/psychosexual/arrangement-history]]
