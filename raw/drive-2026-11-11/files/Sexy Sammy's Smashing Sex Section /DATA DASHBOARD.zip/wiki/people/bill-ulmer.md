---
domain: people
page_type: entity
status: closed
date_created: 2026-06-23
date_modified: 2026-07-14
date_range_start: 2017-04-22
date_range_end: 2020-06-02
sources: ["raw/self/message-csv/MASTER_MESSAGES_DB_DUMP.csv"]
related: ["wiki/people/annie-ulmer", "wiki/people/ellen-ulmer", "wiki/timeline/events/fran-death-vigil", "wiki/self/message-corpora/master-message-dump"]
tags: [relationships, family]
knowledge: mixed
infobox:
  name: "Bill Ulmer"
  relationship_to_dan: unknown
  location: nyc
  first_contact: 2017-04-22
  known_for: "Bill Ulmer is [[wiki/people/annie-ulmer|Annie]]'s father — the warmest and most consistently affectionate adult presence"
---

# Bill Ulmer

Bill Ulmer is [[wiki/people/annie-ulmer|Annie]]'s father — the warmest and most consistently affectionate adult presence toward Dan documented anywhere in the corpus outside Dan's own immediate family. The 58-message thread (`+17249840793`, April 2017 – June 2020) is sparse but unbroken: birthday greetings, condolences, small favors, and repeated signs that Bill treated Dan as family rather than as his daughter's boyfriend.

## The relationship

Bill's messages read as a father-in-law's, not an acquaintance's. On April 4, 2018, days after [[wiki/people/fran-coldren|Fran]]'s death, he sends an unprompted, lengthy condolence — calling Fran "a lady of class, friendliness to all and grace" whom he'd known over 40 years — and pairs it with a note that Annie's love for her grandmother-in-law-to-be had "been given freely." He sends Dan a "Happy Birthday" every November without fail (2018, 2019), signs off a 2020 message "Miss and love you both. Dad/Bill," and in late 2019 helps coordinate a package delivery to Dan's NYC apartment, walking through building-entry logistics and joking about taping names to the buzzer.

A recurring thread through 2018 is golf: Bill asks about tee-time deals at NWL (New Wall/local club terminology) courses, references Dan caddying, and treats it as ordinary shared interest rather than small talk.

## Corpus Dimensions

| Metric | Value |
|--------|-------|
| Messages | 58 |
| Date range | 2017-04-22 to 2020-06-02 |
| Direction | Unreliable in this export (marked "Received" throughout) — read as mostly one-way (Bill to Dan) |
| Handle | +17249840793 |

## Gaps

No message after June 2020 appears in the corpus; whether contact continued past that point, and whether it survived the eventual end of the Dan/Annie relationship, is undocumented.

## Related

[[wiki/people/annie-ulmer]] · [[wiki/people/ellen-ulmer]] · [[wiki/timeline/events/fran-death-vigil]] · [[wiki/self/message-corpora/master-message-dump]]
