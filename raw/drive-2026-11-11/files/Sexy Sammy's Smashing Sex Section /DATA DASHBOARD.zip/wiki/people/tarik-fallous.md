---
domain: people
page_type: entity
status: active
date_created: 2026-06-23
date_modified: 2026-07-20
date_range_start: 2021-03-01
date_range_end: 2026-04-12
sources: ["raw/self/dox-md/Gemini-_00.md", "raw/self/dox-md/Gemini-_02.md", "raw/self/gemini-activity/Gemini Activity.html", "raw/self/dox-md/LIFE_EVENTS_CALENDAR.md", "raw/self/facebook/facebook-ihatedanfrank/", "raw/self/message-csv/imessage_19178259183_both_all_now.csv"]
tags: [ai-collaboration, career, nyc-era]
knowledge: mixed
infobox:
  name: "Tarik Fallous"
  relationship_to_dan: unknown
  location: nyc
  first_contact: 2021-03-01
  known_for: "Tarik Fallous — owner-operator (with his brother Ghassan) of [[wiki/work/au-zaatar|Au Za'atar]], the Lebanese restaurant"
connections:
  - page: wiki/work/au-zaatar
    type: component-of
    claim: "Tarik's ownership decisions — hiring Dan on the spot with zero food-service experience, the equal FOH tip split, and later routing back-of-house logistics (wine inventory, hiring) through him — are the founding condition the whole 41-month Au Za'atar era runs on."
  - page: wiki/mind/synthesis/vertical-authority-skepticism
    type: evidences
    claim: "The direct correspondence — grocery-run errands, hiring coordination, a payroll dispute, and warm post-termination contact running to April 2026 — shows Dan distinguishing the individual (genuine affection for Tarik) from the institution (the 'decentralized audit' skepticism of ownership generally), complicating a simple anti-authority read of the Au Za'atar years."
  - page: wiki/people/ismaila-barry
    type: co-occurs
    claim: "Dan's Aug 21 2024 'CIA agent' tip to Tarik was specifically about DJ (Ismaila Barry) possibly not returning from vacation — informal post-employment intel-sharing about a close friend's own uncertain exit, source of the unconfirmed 'DJ did what MD did' lead."
  - page: wiki/timeline/periods/2021-2023-employment-block
    type: component-of
    claim: "The grocery-run, inventory, and hiring texts are ground-truth day-to-day texture for the period this page otherwise records only as 'employed at volume.'"
---

# Tarik Fallous

## Identity

Tarik Fallous — owner-operator (with his brother Ghassan) of [[wiki/work/au-zaatar|Au Za'atar]], the Lebanese restaurant near 58th and 1st in Midtown Manhattan where Dan worked as a busser-turned-server from roughly March 2021 to August 2024. Tarik hired Dan on the spot at his application interview despite no prior food-service experience. His defining structural decision, from Dan's point of view, was an equal front-of-house tip split — bussers paid the same as waiters — which Dan's Gemini reconstruction repeatedly calls "a glitch in the matrix," the economic condition that made the whole tenure viable. Tarik and Ghassan rented an apartment above the restaurant purely to watch the floor, an arrangement Dan frames as an "acerbic surveillance" panopticon. Dan's affection for the brothers was tribal as much as economic: he characterizes the Lebanese humor of the house as "incapable of not making fun of everyone and their flaws," and credits the fit directly — "they liked me because i, too, am both an asshole and a sonofabitch" — adding that as the only white FOH employee he benefited from the owners' own prejudices.

> **REVISED [2026-07-20]:** the prior version of this page stated flatly that "Tarik is a peripheral work figure with no independent message corpus" and that everything here came from the Gemini "STORYTIME" reconstruction. That was wrong — a direct iMessage thread with Tarik (`+19178259183`, 80 messages, August 2023 – April 2026) exists in the corpus and had simply not been filed or mined. It shows a real, sustained, and warm relationship that ran well past the August 2024 termination: Dan continued passing Tarik informal workplace intel three weeks after filing for unemployment, and the two were still in affectionate, politically candid contact as recently as April 2026 — nearly two years after the job ended. See Direct Correspondence below.

## Direct Correspondence (Aug 2023 – Apr 2026)

The 80-message thread splits cleanly into an employment-logistics phase (Aug 2023 – Aug 2024) and a post-termination phase (Aug 2024 onward) that is, on its own, the strongest evidence in the corpus that Dan's relationships with authority figures were never purely adversarial.

**Employment logistics.** The texts show Dan's actual day-to-day scope ran well past serving tables. He ran personal/restaurant grocery errands for Tarik (photographing substitute produce for approval — spinach, snow peas standing in for Romano beans, no Swiss chard at Morton Williams so a Whole Foods run instead) while holding Tarik's own Barclays card for the purpose. He tracked bar inventory directly: two liquor/wine stock counts survive verbatim (Aug 11 2023, all zero; Aug 12 2023, restocked — Whispering Angel, Chateau La Coste Rose, La Luca Prosecco, Fidora Prosecco, Charles de Ferre Blanc de Brut, ViNO CasaSmith, Langewalter Riesling, Valdemonxes, Chateau la Croix Lartigue, Fattoria Casa Sola, Barolo), a responsibility not documented anywhere else in the corpus and a concrete data point for the "de facto manager" role [[wiki/work/au-zaatar]] already ascribes to him. He coordinated hiring directly — "Just fyi I have 2 people outside for interviews. One of them is from the agency" (Sep 27 2023), "First Interview is here" / Tarik's "Speak to him and write his info plz" (Nov 3 2023) — and ran an AV-cable errand (low-voltage speaker wire, the wrong "AC" vs. "MC" gauge, Oct 2023) and a print-shop errand inspecting a proof copy before a full run (Dec 2023), suggesting some signage or menu project. A December 13, 2023 payroll dispute — a missing Dec 2 punch, tips already distributed, asking whether he could still claim the hourly — corroborates the tip-pool opacity already documented on au-zaatar.md. Five separate sick-day call-outs are logged between Nov 2023 and Apr 2024, with some opening "Hey it's dan" or similar. A previously unknown name, **"Modi,"** surfaces once (Apr 20 2024: "Modi came in to see you. He'll be around the neighborhood later tonight") — unidentified, no other reference in the corpus. On June 14, 2024, Dan sent an unprompted Arabic message, "مبروك للعرسان!" ("Congratulations to the newlyweds!"), for a wedding — Tarik's, a family member's, or a staff member's is unclear — answered with a simple "Thank you" the next day. The final logistics exchange, August 11, 2024, is the termination made concrete: Dan arranging to "grab my check," told by Tarik "I would have loved to see you. But I'm not there now. You can take from Patricia" — introducing **Patricia**, evidently the bookkeeper/cashier who handled payroll, otherwise undocumented.

**Post-termination.** Thirteen days after filing for unemployment (per [[wiki/work/au-zaatar]]'s Aug 8, 2024 date), Dan texted Tarik unprompted, Aug 21 2024: "I know I'm not an *official* CIA agent anymore but I did hear some intel today that might interest you…don't get too excited though, it's not very important or surprising. You didn't hear it from me but, based on my conversation with him — I wouldn't be surprised if DJ does what MD did and doesn't 'return' when he gets back from his vacation." Tarik: "Thank you for the tip. I will send your regards to Ghassan." "DJ" is [[wiki/people/ismaila-barry|Ismaila Barry]], one of Dan's closest friends from the restaurant; "MD" is an unresolved initials-only reference to some earlier staff departure, not otherwise documented. The exchange is notable less for the content (Dan is explicit it isn't important) than for the frame: even after an involuntary termination, Dan positioned himself as a voluntary informal source for the owner, and Tarik received it exactly that way — gratitude, not suspicion. On Sep 28, 2024, during that autumn's escalation of the Israel–Lebanon conflict, Dan initiated: "Was thinking about you guys with everything going on in Lebanon. Hope your family over there is safe and well." Tarik: "Yes pretty bad." The relationship's most recent documented contact, April 12, 2026 — a year and eight months after termination — is the thread's longest and most substantive message: Dan telling Tarik that recent events had made him newly grateful for what his years at Au Za'atar had taught him about Lebanon — "how beautiful and unique the cultural tradition is, how nice and funny and diverse the people are" — and naming his disgust that "my country has enabled and facilitated" what he calls "evil, genocidal attacks," closing by asking after Ghassan and two names new to the corpus, **Khalid** and **Hani** (evidently Tarik's family or close friends in Lebanon, otherwise unidentified). Tarik's reply, same day: "everything is well here thank you for asking. Scary things happening all around. Hope you are well too."

## Corpus Dimensions

| Metric | Value |
|--------|-------|
| Messages | 80 (59 sent, 21 received) |
| Date range | 2023-08-11 to 2026-04-12 |
| Handle | +19178259183 |
| Direction | Reliable — genuine two-way conversation, heavily Dan-initiated (consistent with an employee-to-owner logistics channel) |

The full staff roster, the shed-build saga, the Valeria romance, and the "9 PM alibi" material live on [[wiki/work/au-zaatar]] (which has absorbed both STORYTIME volumes) and the period page [[wiki/timeline/periods/2021-2023-employment-block]]. This page keeps only what concerns Tarik directly.

| Term | Gemini _02 | Gemini _00 |
|------|-----------|-----------|
| tarik | 23 | 10 |
| ghassan | 4 | 5 |

## Role in the Work Power Dynamic

Tarik reads, in Dan's analysis, as high-visible-investment against high-human-friction: he built elaborate outdoor dining sheds (which ran for three winters because the promised interior renovation never happened) while presiding over crazy staff turnover that let Dan become the self-styled "High Priest of Protocol" — the keeper of the opener routine (sleep till 1, build 2–5, cut by 9–10, never close). The equal tip split is the pivot of the whole [[wiki/mind/synthesis/vertical-authority-skepticism]] analysis: it removed the usual busser/waiter hierarchy and enabled Dan's "Ambassador of the Shed and its most effective saboteur" self-description — the fictitious "night class" alibi that let him leave at 9 PM for 18+ months. Tarik's mediation style shows up in the "Nonsense Meeting" with Ghassan over staff "lanes."

The recurring contrast Dan draws: [[wiki/people/annie-ulmer]], "the avatar of reliability," was fired from her own hosting job with zero notice, while Dan survived 2.5 years under Tarik — his gloss, "the universe rewards the sonofabitch over the proper."

## Timeline

| Date | Event |
|------|-------|
| Early 2021 | Hired on the spot as busser; equal tip split begins; 20 blocks from 307 E 76th |
| Spring 2021 | Outdoor sheds built first; interior renovation delayed ~9 months; Annie hired as EV hostess |
| Nov 2021 | First outdoor winter; tableside shawarma in the cold; [[wiki/people/dimitri|Dimitri]] joins and promotes Dan to server tasks |
| 2022–2023 | Second and third outdoor winters ("there is no construction"); the Valeria episode ([[wiki/people/valeria-iglesias-cid]]) runs and collapses |
| Aug 2023 – Aug 2024 | Direct texts document grocery runs, wine inventory, hiring coordination, a payroll dispute, and five sick-day call-outs |
| 2023–2024 | Finale phase — Sergio, the Tunisian tip-siphon, the "9 PM alibi" post-mortem; ~41 months total |
| Aug 11, 2024 | Termination; final paycheck collected via "Patricia" |
| Aug 21, 2024 | Post-termination "CIA agent" intel tip about DJ's uncertain return |
| Sep 28, 2024 | Lebanon-conflict check-in |
| Apr 12, 2026 | Most recent contact — extended Lebanon solidarity message; Ghassan, Khalid, and Hani asked after |

## Notes

Tarik is not to be confused with the other Au Za'atar staff (DJ/Ismaila Barry, Dimitri, Sergio, Felipe), who have their own stubs or roster entries on the chat pages. Ghassan appears throughout as co-owner. The phantom-tender and alibi-construction patterns from this era rhyme with the later BFS material — see [[wiki/work/bfs-foods]].

**Gaps:** "Modi," "MD," "Patricia," "Khalid," and "Hani" are all new, unresolved names surfaced by the direct thread — none has any other reference elsewhere in the corpus. The occasion for the June 2024 Arabic wedding congratulations is unidentified.
