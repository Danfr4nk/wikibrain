---
domain: people
page_type: entity
status: closed
date_created: 2026-06-23
date_modified: 2026-07-20
date_range_start: 2024-07-28
date_range_end: 2024-08-09
sources: ["raw/self/message-csv/MASTER_MESSAGES_DB_DUMP.csv", "raw/self/message-csv/imessage_17243226739_both_all_now.csv"]
tags: [relationships, politics, uniontown-era]
knowledge: mixed
infobox:
  name: "Mike Cordaro"
  relationship_to_dan: unknown
  first_contact: 2024-07-28
  known_for: "Mike Cordaro is a childhood-era friend — the two attended the 'Rolling Rock Town Fair' together as kids, a concert serie"
connections:
  - page: wiki/people/rick-frank
    type: parallels
    claim: "Rick Frank and Mike's father Pete Cordaro are drawn as a matched pair in the thread — two Uniontown-area fathers who both drifted into MAGA politics, framed by their politically-opposite sons as an ironic, near-interchangeable phenomenon rather than a personal grievance."
---

# Mike Cordaro

Mike Cordaro is a childhood-era friend — the two attended the "Rolling Rock Town Fair" together as kids, a concert series Mike calculates they'd seen Def Leppard at "21 years and 1 day" before reaching back out — who resurfaces with a single warm, substantive two-week exchange in summer 2024 (`+17243226739`, 50 messages, July 28 – August 9). The reconnection was prompted by Mike spotting a Def Leppard/Journey show at Heinz Field and thinking of Dan.

## Texture

The full per-contact export (filed 2026-07-20, superseding the earlier 28-message partial pull from the unreliable-direction master CSV) shows a real two-way conversation, not a one-sided text: Mike opens July 28 asking how Dan is feeling about Kamala's chances, then the substantive exchange runs August 6–9. It covers real ground — Mike's dog had to be put down the week they reconnected; a detailed, good-faith discussion of the 2024 ticket that runs well past the "maga-tized dads" joke. Mike's own case for the pick: he'd wanted Mark Kelly for the astronaut/military credibility and the gun-reform angle, was lukewarm on Shapiro ("never thought he was going to light the base on fire"), and ultimately backed Walz on Bernie Sanders's endorsement carrying real weight with him. Dan's counter-case, in his own words: the "enthusiasm boost that Walz will have on the 18-35 demo is going to be important enough in a race with such narrow margins." Both read the pick as strategy rather than personal preference, and both mock JD Vance-style "DEI hire" rhetoric as self-undermining — Mike's line, "The funny part is, HE is the dei hire lol. Totally targeting a certain demographic." A recurring joke frames their two fathers — his own ("Pete Cordaro") and Dan's ([[wiki/people/rick-frank|Rick Frank]]) — as a matched, near-interchangeable pair who've both gone "maga-tized," used as a shorthand for how thoroughly Walz reads as their kind of politician ("Should have Pete Cordaro and Rick Frank written all over"). Mike separately mentions running into and mountain-biking with "your uncle Dave" in Ohiopyle days after reconnecting with Dan, and a mutual friend, Matt Ross, came up independently the same day — neither relation otherwise documented in the corpus.

## Corpus Dimensions

| Metric | Value |
|--------|-------|
| Messages | 50 |
| Date range | 2024-07-28 to 2024-08-09 |
| Direction | Reliable in this export — genuine two-way conversation (22 sent, 28 received) |
| Handle | +17243226739 |

## Gaps

"Uncle Dave" and "Matt Ross" are new, unconfirmed leads — neither has any other reference elsewhere in the corpus read so far.
