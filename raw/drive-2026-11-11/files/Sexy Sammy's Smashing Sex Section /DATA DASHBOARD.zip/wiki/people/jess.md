---
domain: people
page_type: entity
status: closed
date_created: 2026-06-23
date_modified: 2026-07-14
date_range_start: 2017-04-20
date_range_end: 2017-07-02
sources: ["raw/self/message-csv/MASTER_MESSAGES_DB_DUMP.csv"]
related: ["wiki/self/message-corpora/master-message-dump", "wiki/mind/concepts/contact-gini"]
tags: [relationships, digital-footprint]
knowledge: mixed
infobox:
  name: "Jess"
  relationship_to_dan: unknown
  first_contact: 2017-04-20
  known_for: "Jess introduces herself April 20, 2017 as part of a swinging couple recruiting through a group or platform called 'Fem' "
---

# Jess (from "Fem")

Jess introduces herself April 20, 2017 as part of a swinging couple recruiting through a group or platform called "Fem" (`+13042793075`, 36 messages, April–July 2017), opening with photos and an explicit vetting conversation about her partner Mike — his size, whether he's "a problem," and whether Dan and any partner would want to meet the couple, who describe themselves as usually bringing in a woman rather than another man. The opening exchange is dense (April 20 alone) but the interest doesn't convert: after one intensive day of messaging, contact drops to occasional "hey" check-ins with no further logistics discussed, tapering out by early July.

## Corpus Dimensions

| Metric | Value |
|--------|-------|
| Messages | 36 |
| Date range | 2017-04-20 to 2017-07-02 |
| Direction | Unreliable in this export (marked "Received" throughout) — read as one-way (Jess to Dan) |
| Handle | +13042793075 |

## Gaps

Last name and any resolution (a meeting, or a decline) are undocumented — the thread simply cools off.

## Related

[[wiki/self/message-corpora/master-message-dump]] · [[wiki/mind/concepts/contact-gini]]
