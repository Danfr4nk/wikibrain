---
domain: people
page_type: entity
status: active
date_created: 2026-06-23
date_modified: 2026-07-18
date_range_start: 2023-08-13
date_range_end: 2026-02-25
sources: ["raw/self/message-csv/MASTER_MESSAGES_DB_DUMP.csv"]
related: ["wiki/work/au-zaatar", "wiki/people/tarik-fallous", "wiki/people/valeria-iglesias-cid", "wiki/people/annie-ulmer", "wiki/self/message-corpora/master-message-dump"]
tags: [career, relationships, nyc-era]
knowledge: mixed
infobox:
  name: "Manuel"
  relationship_to_dan: unknown
  first_contact: 2023-08-13
  known_for: "Manuel was a coworker at [[wiki/work/au-zaatar|Au Za'atar]] — the thread opens with an October 2023 message referencing "
---

# Manuel

Manuel was a coworker at [[wiki/work/au-zaatar|Au Za'atar]] — the thread opens with an October 2023 message referencing [[wiki/people/tarik-fallous|Tarik]] telling him to stay and work — who became a genuine, ongoing friendship that outlasted the job itself, running from August 2023 into 2026 (`+13472828140`, 45 messages; unlike most contacts in this corpus, direction is reliably recorded here: 11 sent, 34 received). The relationship is conducted mostly in Spanish, register loose and joking throughout — nicknames ("puto," "michi"), birthday teasing, and running banter about "perico" (cocaine).

## Texture

Early messages are workplace-adjacent (spinach sourcing, an October 2023 birthday party, a joke about Shakespeare being "aburrido" because he doesn't do coke like El Chapo). The friendship persists past Au Za'atar: by December 2025 Manuel is asking after "mi novia" (Dan confirms, "Me encanta valeria," referencing [[wiki/people/valeria-iglesias-cid|Valeria]]) and separately after "mi Ani" — [[wiki/people/annie-ulmer|Annie]] — with Dan replying she's there with him and that they have "tres gramas de perico." A December 23, 2025 exchange has Dan sending a Spotify track, being told "no puto," and joking back "okay I'm calling ICE" / "Vale, voy a llamar a ICE" — dark humor between established friends, not a real threat. The final exchange (February 2026) has Dan joking "Yo soy el mencho" (a reference to the real Jalisco New Generation Cartel leader) in response to Manuel again asking after "mi novia."

## Corpus Dimensions

| Metric | Value |
|--------|-------|
| Messages | 45 (11 sent, 34 received) |
| Date range | 2023-08-13 to 2026-02-25 |
| Handle | +13472828140 |

## Gaps

Last name is not on file. A different, unrelated "Manuel" is referenced in passing in [[wiki/people/jack-rusko]]'s 2017 thread — a different person from an earlier, unconnected era; not to be conflated with this contact.

## Related

[[wiki/work/au-zaatar]] · [[wiki/people/tarik-fallous]] · [[wiki/people/valeria-iglesias-cid]] · [[wiki/people/annie-ulmer]] · [[wiki/self/message-corpora/master-message-dump]]
