---
domain: people
page_type: entity
status: closed
date_created: 2026-06-23
date_modified: 2026-07-14
date_range_start: 2016-02-07
date_range_end: 2016-04-19
sources: ["raw/self/message-csv/MASTER_MESSAGES_DB_DUMP.csv"]
related: ["wiki/self/message-corpora/master-message-dump", "wiki/mind/concepts/contact-gini"]
tags: [addiction-recovery, financial-stress, digital-footprint]
knowledge: mixed
infobox:
  name: "Brennan Meadows"
  relationship_to_dan: unknown
  first_contact: 2016-02-07
  known_for: "A brief early-2016 contact (+17243227262, 28 messages, Feb–Apr) whose thread mixes small-scale suboxone sourcing ('Did y"
---

# Brennan Meadows

A brief early-2016 contact (`+17243227262`, 28 messages, Feb–Apr) whose thread mixes small-scale suboxone sourcing ("Did you ever find subs") with a small personal loan request. Brennan says he found a source willing to sell "a half" and asks Dan to lend him $20 to be repaid $30 on the following Wednesday's paycheck, mentioning a possible tax-refund windfall as a backup repayment plan. A later message asks if Dan would want to buy part of a sub strip. The thread fades after mid-February with only a single unanswered "What's up what are you doing" in April.

## Corpus Dimensions

| Metric | Value |
|--------|-------|
| Messages | 28 |
| Date range | 2016-02-07 to 2016-04-19 |
| Direction | Unreliable in this export (marked "Received" throughout) — read as one-way (Brennan to Dan) |
| Handle | +17243227262 |

## Gaps

No contacts.csv match and no further mentions elsewhere in the corpus; identity beyond the name is unconfirmed.

## Related

[[wiki/self/message-corpora/master-message-dump]] · [[wiki/mind/concepts/contact-gini]]
