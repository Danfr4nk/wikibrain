---
domain: people
page_type: entity
status: closed
date_created: 2026-06-23
date_modified: 2026-07-14
date_range_start: 2017-04-22
date_range_end: 2020-10-07
sources: ["raw/self/message-csv/MASTER_MESSAGES_DB_DUMP.csv"]
related: ["wiki/self/message-corpora/master-message-dump", "wiki/mind/concepts/contact-gini"]
tags: [relationships, digital-footprint]
knowledge: mixed
infobox:
  name: "Bub"
  relationship_to_dan: unknown
  first_contact: 2017-04-22
  known_for: "'Bub' (contacts label, real name undocumented) is a low-intensity but long-running college-friend-register contact spann"
---

# Bub

"Bub" (contacts label, real name undocumented) is a low-intensity but long-running college-friend-register contact spanning three and a half years (`+17249635394`, 86 messages, April 2017 – October 2020). The relationship is casual and evenly reciprocal, organized around music/DJ logistics, tech troubleshooting, and gaming — with none of the transactional or crisis texture common to many other stub contacts in this corpus.

## Texture

Early messages (April 2017) coordinate a party where Dan is DJing, at an address in Columbus — "you're the dj after all," cable/adapter logistics (RCA to 3.5mm), and a joke about a roommate's unreliable car. Late 2017 into early 2018 shifts to an extended tech-support thread: Bub walks Dan through installing an old Mac OS (Leopard/El Capitan-era) onto a salvaged 2006–2009 Mac Pro via a bootable USB, troubleshooting BIOS boot order and TransMac disk mounting over several sessions. Other recurring threads: shared taste in Wes Anderson films, a 2019 note about being "in Greenwich," and — from 2020 onward — a purely gaming-focused register (Call of Duty stats, monitor and GPU recommendations, PC-build talk), the relationship's final documented form before the corpus ends.

## Corpus Dimensions

| Metric | Value |
|--------|-------|
| Messages | 86 |
| Date range | 2017-04-22 to 2020-10-07 |
| Direction | Unreliable in this export (marked "Received" throughout) — read as two-way |
| Handle | +17249635394 |

## Gaps

Real name and how the friendship originated (likely college, given the roommate references) are undocumented.

## Related

[[wiki/self/message-corpora/master-message-dump]] · [[wiki/mind/concepts/contact-gini]]
