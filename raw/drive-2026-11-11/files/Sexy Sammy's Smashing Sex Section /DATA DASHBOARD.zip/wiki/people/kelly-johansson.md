---
domain: people
page_type: entity
status: closed
date_created: 2026-06-23
date_modified: 2026-07-19
date_range_start: 2019-09-27
date_range_end: 2019-10-23
sources: ["raw/self/message-csv/MASTER_MESSAGES_DB_DUMP.csv"]
related: ["wiki/people/annie-ulmer", "wiki/timeline/events/shelbie-annie-threesome-april-2019", "wiki/self/message-corpora/master-message-dump", "wiki/mind/psychosexual/arrangement-history"]
tags: [relationships, digital-footprint, nyc-era]
knowledge: mixed
infobox:
  name: "Kelly Johansson"
  relationship_to_dan: unknown
  sex: female
  location: nyc
  first_contact: 2019-09-27
  known_for: "Kelly Johansson was a New York escort (Upper East Side, 152 East 65th Street) Dan and Annie booked for paid sessions tog"
connections:
  - page: wiki/mind/psychosexual/arrangement-history
    type: component-of
    claim: "The Sep–Oct 2019 run is the arrangement at its most professionalized — a repeat working relationship in which Kelly treated Annie as a peer and pitched the couple as co-providers."
---

# Kelly Johansson

Kelly Johansson was a New York escort (Upper East Side, 152 East 65th Street) Dan and Annie booked for paid sessions together over a five-week stretch in fall 2019 (`+13108018083`, 64 messages, 2019-09-27 to 2019-10-23; CashApp `$kellyjohansson`, Venmo `@Andrianna_Cole`). It's the most professionalized instance of the couple's non-monogamous arrangement documented in the corpus — not a friend or a one-off booking but a repeat working relationship with an escort who was, in turn, trying to bring Dan and Annie in as co-providers for one of her own paying clients.

## The arrangement

The first session (Sept 27, 2019) is a straightforward paid booking: Kelly quotes a "donation" of $1,200 for the night, asks for half up front by Venmo, and hosts at her townhome with champagne on ice. It goes well enough that within days she's pitching something bigger: bringing Dan and Annie in on sessions with one of her own regular clients, a wealthy "hobbyist" who has "been with over 100 providers" and has erectile difficulty. On October 6, 2019 she texts out a full session script in advance — drinks, watching a cam video together to set the mood, Kelly and Annie kissing while Dan watches, Annie giving the client oral while Kelly does the same for Dan, and an explicit ask to bring Cialis for the client "because he is big money" and might book them all on a trip to Mexico if the session goes well. The client session itself was rescheduled repeatedly (stomach ache, travel conflicts) and, per the surviving thread, never actually happened — the last several messages are just Kelly and the couple negotiating ordinary one-on-one session times into late October.

Kelly treats Annie as a professional peer more than a customer's girlfriend: she tells Dan directly "she should take deposits. She is beautiful and that way she isn't out anything," and floats sending Annie clients of her own ("I texted Annie about a client and perhaps you both can think about it") — a passing suggestion that Annie could work as a provider herself, not something the corpus shows being taken up.

## Corpus Dimensions

| Metric | Value |
|--------|-------|
| Messages | 64 |
| Date range | 2019-09-27 to 2019-10-23 |
| Direction | Unreliable in this export (marked "Received" throughout) — read as two-way |
| Handle | +13108018083 |

## Gaps

Whether the scripted client session ever occurred beyond the corpus's window, and whether Annie ever took Kelly up on independent client referrals, are both undocumented — the thread simply stops in late October 2019 with ordinary scheduling still in progress.

## Related

[[wiki/people/annie-ulmer]] · [[wiki/timeline/events/shelbie-annie-threesome-april-2019]] · [[wiki/self/message-corpora/master-message-dump]]
