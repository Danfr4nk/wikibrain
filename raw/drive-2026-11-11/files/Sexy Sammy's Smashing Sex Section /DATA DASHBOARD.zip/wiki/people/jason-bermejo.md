---
domain: people
page_type: entity
status: active
date_created: 2026-06-23
date_modified: 2026-07-19
date_range_start: 2017-01-20
date_range_end: 2026-03-21
sources:
  - "raw/self/message-csv/MASTER_MESSAGES_DB_DUMP.csv"
  - "raw/self/message-csv/imessage_export_+18172693422_20260714055318.csv"
  - "raw/self/message-csv/interspersed_messages.csv"
  - "raw/self/captures/2026-07-19_operator-note-full-sail-mohler.md"
tags: [digital-footprint, music-production, addiction-recovery, relationships, uniontown-era]
connections:
  - page: wiki/people/eric-jester
    type: co-occurs
    claim: "Jason and Eric are both named in Dan's own 2025 'Florida head' rundown of the Full Sail cohort — the two threads independently corroborate the same four-person friend group."
  - page: wiki/people/matt-dunn
    type: co-occurs
    claim: "Dunn is named alongside Jester and Mohler in the same Sept/Oct 2025 exchanges, confirming the four-person Full Sail cohort from Jason's own side of the corpus."
  - page: wiki/people/jamie-mohler
    type: co-occurs
    claim: "Jason's Oct 6, 2025 exchange ('Mohler = a literal woman' / 'Haha she badass') is the primary corpus corroboration of Mohler's transition, delivered as a casual, unremarkable update inside the Full Sail friend group."
  - page: wiki/timeline/periods/full-sail-2008-2010
    type: instance-of
    claim: "The friendship is the era's clearest survivor: a formative-era bond that never needed repair to resume, still active fifteen years later at its all-time message-volume peak."
knowledge: earned
infobox:
  name: "Jason Bermejo"
  relationship_to_dan: friend
  sex: male
  location: remote
  role: "DJ / producer (Texas)"
  first_contact: 2017-01-20
  handles: ["+18172693422"]
  known_for: "One of two people whose music taste Dan defers to; formative Full Sail-era friend; Feb 2026 renewal at 400+ messages/month"
---

# Jason Bermejo

Jason Bermejo is one of the two people alive whose musical taste Dan
genuinely defers to (the other is a stranger: Anthony Fantano) — the
Full Sail–era friend who built Dan's musical identity circa 2009–2011
and, fifteen years later, is still doing it. A DJ and producer now in
Texas (`+18172693422`, 451+ messages, 2017–2026), he re-entered Dan's
life in force in February 2026 — 400+ messages in a single month, the
thread's all-time peak, landing in the raw aftermath of the Uniontown
return — and the two fell instantly back into the old shape: beat-flip
competitions, all-night recommendation threads, production shop-talk,
and the shared, matter-of-fact chemical culture of the Orlando years.
Of all the formative-era friendships in the corpus, this is the one
that never needed repair to resume.

## Relationship & Role in Dan's Life

**Phase 1: Formative era (2009–2015)**
Jason was a formative influence during Dan's most musically curious period. Introduced Dan to:
- Kid Cudi (breakthrough hip-hop moment)
- Cool Kids (LCD Soundsystem Williamsburg era music)
- Skinny jeans aesthetic / blog-era hip-hop culture
- Recording and production basics (recording in closet, early DIY studio ethos)

Dan describes him as a gateway to "a different style of music that still resonates with me today" — the respect runs deep enough that Dan cites Jason as one of only two people (other than Anthony Fantano) whose music taste Dan genuinely defers to.

**Phase 2: Sustained contact (2017–2026)**
- Renewed engagement in early 2026 after messaging gap
- Sustained music conversation: song recommendations (JPEGMAFIA, $uicideboys, Bring Me The Horizon, Deftones, Thundercat, SiR, Molchat Doma, X-Ecutioners)
- Producer talk: Serum synth, Bitwig DAW, wavetables, drum kit composition, sample flipping
- Shared substance use context: weed, cocaine, ketamine mentioned in matter-of-fact ways
- Romantic life updates (girlfriend references, relationship status shifts)

## Musical Taste & Production Practice

**Jason's aesthetic**: DJ/producer sensibility spanning:
- UK garage, electronic dance music (Odd Mob, NXSTY trap packs, Westwood)
- Hip-hop (Clipse, Push T, A$AP Rocky, Imogen Heap mashups, Papoose, early 2000s Bronx rappers)
- R&B/neo-soul (SiR, Thundercat, Crosses)
- Post-hardcore/alternative (Deftones, Bring Me The Horizon, Limp Bizkit, Billy Idol, BMTH)
- Experimental/underground (Molchat Doma — Belarus indie rock; Atmosphere; King Von)
- Indie/alternative (Neutral Milk Hotel, The Smiths)
- Vaporwave/sample culture (Nujabes, J Dilla references)

**Production style**: Jason uses/recommends Bitwig (switched from Logic Pro in 2026), Serum synths, wavetable manipulation, modulation-heavy approach. He curates sample packs (Westwood NXSTY trap loops via Splice) and does beat flipping/remixing work. Recently shifted to sample-direct workflow for CPU optimization on ancient laptop.

**Taste philosophy**: "It's all about talent and ideas put into original music bro" — values authenticity and innovation over scene/credential. He and Dan bond over rejecting poseur culture (e.g., dismissing early 2010s EDM kids at Full Sail as fuccbois).

**Producing with Dan**: They have a standing "2-week competition" dynamic (theme-based beat flips, remixes). Jason shows willingness to critique Dan's work ("Does this work at all") and Dan sends him new music discoveries constantly.

## Substance Use & Lifestyle Context

**Cannabis & Tobacco**
- Vaping long-term, recently (Feb 2026) switched back to cigarettes after 10-year vape streak
- Black and Milds mentioned — Dan finds it amusing, considers it characteristic

**Cocaine**
- Regular, normalized in conversation ("I'm still running her for like 2 grams of blow a day and she has no idea")
- Light references to cocaine being the substrate of night-long conversations and music discovery sessions
- Matter-of-fact tone; no judgment from Dan
- 5 years' worth of cocaine straws accumulated (visual evidence in March 2026)

**Ketamine**
- Dan describes ketamine as "the best music drug I've ever tried" — 45-minute duration, dissociative without long comedown
- K-holed while discovering new music (incidental discovery of Jason listening to track on Spotify)
- Framed as a deliberate tool for altered listening state

**Lean/Opioids**
- Fake lean incident (Jason sold non-lean product; Dan warns against white dealers)
- Percocet references (Dan doesn't regularly take them but appreciates the name "pabloPERCasso")

**Heroin**
- Attempted purchase story (Orlando-era, Dan + Alexis tried to buy heroin; deal went bad; Jason/Spetch had to pick them up at The Social in middle of night)

## Social Graph & Shared History

> **REVISED [2026-07-19]:** This section previously listed "Jamie
> Mohler" as Jason's current girlfriend. That was a misread of a
> single out-of-context corpus line. In full context (2025-10-06,
> Jason's thread), Dan is telling Jason which Full Sail-era friends his
> mother still remembers — "Jester = forgettable / Dunn = gross and
> forgettable / Mohler = a literal woman" — to which Jason answers
> "Haha she badass." Mohler (now Jamie, per the operator; pre-2023
> known as Jim) is a **fourth member of the same Full Sail friend
> group**, not Jason's partner. See [[wiki/people/jamie-mohler]] for
> the full page.

**Shared circle (2009–2015 Full Sail / Orlando era)**:
- **Spetch** — another close friend, part of same cohort; currently with girlfriend in Texas
- **Johnny** — "follower" type who would bite Jason's swag, looked up to him; shared music interests; Dan thinks Johnny was "low key follower" who absorbed swag but it worked
- **[[wiki/people/eric-jester|Eric Jester]]** — shorter than Dan and Jason, part of Full Sail cohort; his own thread confirms he was in the 2019 group chat Dan set up to "roast" Jason around his engagement
- **Ross Lara** — "the world's first fuccboi," EDM kid at Full Sail, source of derision
- **[[wiki/people/matt-dunn|Matt Dunn]]** — "world's most annoying man woman or child," Full Sail era
- **Oscar** — Ran into Oscar years later in NYC (impossible coincidence in 9M person city); was waiting tables, Oscar showed up at Dan's table
- **Alexis** — Dan's ex, met Thanksgiving break (3 days in hometown), moved in with Dan. Dan is genuinely proud of the "Alexis situation" (left her for another girl, got both to hook up). Described as hot but transactional/unreliable. Nearly killed with Jason when attempted heroin buy went bad.
- **Donato "Steez McQueen"** — Died 2022 (fentanyl-laced xanax, implied); wore Steve McQueen Alexander McQueen jackets; made beats like J Dilla and Nujabes
- **Gabe** — A cat, not a person: died 2023-10-30 ("I had to put gabe down today"), confirmed by [[wiki/people/eric-jester|Eric Jester]]'s independent same-date message ("I'm so sorry man. He was the cat that made me love cats!")
- **[[wiki/people/jamie-mohler|Jamie Mohler]]** — fellow Full Sail
  friend, not a girlfriend (see REVISED note above); part of the same
  named cohort as Dunn and Jester in Dan's own 2025 messages
- **Kayden** — Someone in photos from the heroin-attempt era
- **Mike Marino** — Knew him in Florida, wishes had photos to prove it

## Recent Life Milestones (2025–2026)

- DAW migration: Logic Pro → Bitwig (reports "fucking insane" modulation capability)
- Concert-going with girlfriend (Deftones, Billy Idol, Limp Bizkit, Bring Me The Horizon)
- Relationship anchored; girlfriend present in conversations, travels to shows
- Music output steady (beat-making, sample pack curation, remix/flip work)
- Production constraints: ancient laptop, CPU-limited, using sample-direct workflow workarounds
- Renewed heavy contact with Dan in Feb 2026 (400+ messages in single month)
- Reflective on aging ("can you believe that was 15 fucking years ago"; "36-year-old living in mom's basement" self-aware joke)

## Conversation Style & Humor

- Heavy use of "haha," "fucking," ethnic/cultural humor (Dominican coke homies, Spicy Nacho Doritos + choulula, mestiza references)
- Self-deprecating ("I'm a cokehead," "36-year-old living in basement," "newb as fuck with Bitwig")
- Music nerd passion: deep dives into production minutiae, drops entire recommendation threads late at night
- Nostalgia-driven ("can you believe that was 15 fucking years ago")
- Generous with time despite distance (sends sample packs, does production critique, endless song links)
- Playful but dark humor (deepfake porn, jailbreaking Snapchat, gun-in-mouth video, mock suicide)

## Significance in Dan's Life

**Earned status**: Jason ranks in Dan's top-tier music influences — equivalent to Anthony Fantano in critical weight. Dan consciously defers to his taste and credits him with forming his musical identity circa 2009–2011.

**Anchoring function**: Represents the "formative friend" archetype — someone from a high-creativity, high-risk era (Full Sail, Orlando drugs/music scene) who stayed connected across geographic distance and life stage changes. Renewal of contact in early 2026 suggests re-engagement with that period.

**Complementary skills**: Jason's producer discipline and sample-pack depth vs. Dan's broader eclecticism — they push each other on taste and production.

## Corpus Dimensions
| Metric | Value |
|--------|-------|
| Messages (total) | 451+ |
| Date range | 2017-01-20 – 2026-03-21 |
| Sent / Received | ~187 / 264 (approx) |
| Peak month | Feb 2026 (400+ messages) |
| Service | iMessage, SMS |
| Topics | Music (60%), production (25%), life updates (10%), substances (5%) |

## Notes & Gaps

- Full timeline of how they met (likely Full Sail, ~2009) not explicit in corpus but strongly implied
- Current Jason location: Texas (likely Austin or DFW area based on references)
- Ex-girlfriend mentioned (Feb 2026) but not named; current girlfriend also unnamed in corpus
- Last message: 2026-03-21 (gap since February spike suggests lower contact post-winter)
- Music output / release status: unclear if Jason has released material or remains hobbyist
- Full Sail attendance dates: ~2009-2011 implied

