---
domain: people
page_type: entity
status: closed
date_created: 2026-06-23
date_modified: 2026-07-19
date_range_start: 2025-09-01
date_range_end: 2025-12-10
sources: ["raw/people/kristin/chimera-genesis-addendum.md", "raw/self/message-csv/MASTER_MESSAGES_DB_DUMP.csv", "raw/self/message-csv/imessage_3307038747_both_all_now.csv", "raw/self/message-csv/imessage_export_3307038747_20260624.csv", "raw/self/dox-md/operating_manual.md", "raw/self/dox-scan/messenger_Kristin Shaelene_2025-09-01-07-53-22.txt", "raw/self/dox-md/tom_kristin_master_dossier.md", "raw/self/dox-md/LIFE_EVENTS_CALENDAR.md"]
related: ["wiki/people/tom", "wiki/people/annie-ulmer", "wiki/mind/concepts/contact-gini", "wiki/timeline/periods/2025-collapse", "wiki/timeline/periods/dec-2025-spike", "wiki/self/message-corpora/master-message-dump", "wiki/mind/synthesis/attachment-trauma-bond", "wiki/mind/psychosexual/arrangement-history", "wiki/mind/synthesis/ai-collaborative-analysis", "wiki/mind/concepts/conflict-architecture"]
tags: [relationships, trauma-bond, digital-footprint, legal, ai-collaboration]
infobox:
  name: "Kristin"
  relationship_to_dan: unknown
  sex: female
  location: nyc
  first_contact: 2025-09-01
  known_for: "Kristin Shaelene (handle +13307038747), introduced through [[wiki/people/tom]] as 'Tom's friend.' She became Dan's most "
connections:
  - page: wiki/mind/psychosexual/arrangement-history
    type: component-of
    claim: "The 2025 relationship is the arrangement's documented inversion — total-exclusivity demands and purity tests where the Annie structure practiced authored openness."
  - page: wiki/mind/synthesis/block-unblock-loop
    type: component-of
    claim: "Kristin's Dec 9 2025 block of Dan held permanently — the loop's inbound control case: her severance was structural because she needed nothing from the channel."
  - page: wiki/people/tom
    type: component-of
    claim: "The Kristin thread enters the corpus through Tom's social circle; he is the introduction vector."
---


# Kristin

## Identity

Kristin Shaelene (handle +13307038747), introduced through [[wiki/people/tom]] as "Tom's friend." She became Dan's most intense non-Annie messaging node during the late-2025 collapse: a flirtatious, sexual, high-volume thread that ran from September 1 to December 10, 2025 and ended in a hostile blockade involving threats of law enforcement. The relationship is a textbook instance of the redundancy impulse — an attempt to open a new attachment channel while the primary Annie thread was disintegrating.

She lives in a rural area outside the city — the corpus has her describing roads with "no fucking lights … for hundreds of miles" and her inability to drive at night — and pieces together income across three jobs: a pharmacy on weekends, DoorDash four days a week, and courthouse work she references having done twice as a legal secretary/legal assistant. She is a mother, and custody and court recur as live stressors in the thread.

> **CONTRADICTION:** A prior version of this page described Kristin as "an ex-Brooklyn librarian living in Pittsburgh." The message corpus does not support this — it shows pharmacy, DoorDash, and courthouse legal-secretary work, and a rural (not Pittsburgh) residence. The librarian claim is unsourced and likely an error; corrected here pending confirmation.

> **REVISED [2026-02-17]:** Per [[wiki/people/tom]] (not the direct Kristin thread, which had already gone dark by then): "Kristin got kicked out of her pharmacy over benzos." One leg of the three-job income stack above no longer holds as of this date.

## Corpus Dimensions

| Metric | Value |
|--------|-------|
| Total messages (master dump) | 16,563 |
| Volume rank | #3 overall — the top non-Annie node |
| Date range | 2025-09-01 to 2025-12-10 (a single ~14-week burst) |
| Direction | High bidirectional through the flirtation phase; sharply asymmetric (Dan-heavy) in the terminal week |
| Dedicated sources | imessage_3307038747_both_all_now.csv; terminal export imessage_export_3307038747_20260624.csv; Tom-side detail in tom_kristin_master_dossier.md |

## Behavioral Counts (Dan, Calibrated)

| Pattern | Evidence |
|---------|----------|
| Rapid multi-burst texting | Sustained high-frequency sends across Sep–Dec |
| Transparency/control-cede framing | Early offers of "full transparency, honesty, and accountability" and explicit no-commitment framing |
| AI-mediated conflict analysis | Ran a ChatGPT analysis of their fights mid-thread and told her he had done so — a small, real-time instance of the [[wiki/mind/synthesis/ai-collaborative-analysis|AI-collaborative analysis]] pattern documented at scale elsewhere in the corpus, here deployed on a fourteen-week relationship rather than a decade-long one |
| Escalation under rejection | Dec 9 pivot to technical threats (see Terminal Phase) |

The purity-test structure itself — exclusivity demanded of Kristin as a
condition of intimacy, mirrored against the openness practiced in the
[[wiki/people/annie-ulmer|Annie]] relationship during the same broad
window — reads as the [[wiki/mind/concepts/conflict-architecture|conflict
architecture]]'s resolution-engine logic applied to relational structure
itself: a fixed rule imposed and then rigidly enforced, rather than a
negotiated boundary that could flex.

## Attachment Context (from the Tom/Kristin dossier)

The dossier frames Kristin primarily through her dynamic with Tom: maternal agony over Kayden, "brat"-style boundary testing, edge play, and chemical escapism (cabin trips on ketamine, MDMA, and LSD) with Tom acting as the stoic absorber and supply line. Dan's thread runs parallel to that dyad rather than inside it — a separate, direct, flirtatious channel. Kristin surfaces in the Suz thread only as logistics ("Kristin who?", "kristin is working for another few hours"), which places her in Dan's lateral (Tom-circle) social load rather than the vertical family load.

## The girlfriend era: genesis architecture (Project Chimera addendum)

The relationship was, for its fourteen weeks, a real girlfriend era — and
the Genesis-phase Messenger logs (September 1, 2025, pre-dating the
iMessage thread) show its entire architecture installed within the first
48–72 hours. Within the first day Dan set the Messenger nicknames himself:
his own to "⛤✵ LONELY LOSER ✵⛤" and hers to "☉☾ ᴇɴɪɢᴍᴀ ☾☉" — supplicant and
gatekeeper, self-assigned. Within the same hours Kristin laid down the
system's explicit rules: total sexual exclusivity ("That is my cum. Mine."),
abandonment as the standing consequence ("I don't settle… I leave"), and
climax-as-oath ("If I cum with you in my presence I'll be with you until
death. That is a very serious thing to me"). The foundational myth
underneath, disclosed almost immediately, was **Danny** — her prior
great-intensity partner, dead ("there was never supposed to be 'on and off'
with Danny") — with Dan explicitly auditioning for the role of the Danny
who stays: "I am the person who can give you the passion, intensity and
real spirit of romantic adventure that you've described in your
relationship with danny, but with a sense of permanence and stability"
(Sep 25). Ahmed, the Egyptian ex, entered the record the same first night.

The Chimera addendum's model (an AI analysis Dan commissioned; read with
that provenance): a **hyper-accelerated trauma bond** (assessed at 80%
probability over "authentic partnership" at 15%), gated by escalating
"purity tests" of unconditional devotion — the porn pop-up and the
weed-vs-coke lie being documented failures — built by both parties as a
deliberately totalizing world ("us against the world"; Dan: "completely
throw myself into the situation"). Its bleakest structural finding: the
system's failure state was success — full trust would have ended the
game that powered it, so crisis was load-bearing. The forecast it issued
(stagnation via cyclical conflict, death by attrition) is roughly what the
terminal record shows happening by December.

## Texture from the corpus

The thread's register is immediate and destabilizing from day one — the very
first morning (moving day, September 1) already mixes "I love you stupid"
with negotiation and jealousy. The pattern that recurs across the fourteen
weeks is the collision of intense affection with logistical churn: pledges
like "I'll quit today for you," offers of a step-father's loan, and repeated
demands to "Call me now" set against Dan's documented need to litigate every
ambiguity.

An unexpected recurring bonding activity, expanded 2026-07-14: astrology,
running from Sept 1 through at least Sept 9, 2025, with Kristin as the
expert rather than Dan. She sends her exact birth data and insists on a
"Western style chart — Placidus style specifically," then walks Dan through
her own chart in real time ("You have a birth chart of your life from
start to finish... I showed you the chart graphs. Those are the literal
degrees the planets sit in the sky... 12 houses. 12 signs. 10 planets.")
and cross-reads it against his: her Moon in Leo against his Mercury in
Leo, her Mercury in Libra, a 2nd-house Taurus Mars against what she reads
as his Aries Mars near a "critical degree." She frames it as earned
expertise, not vibes — "18 years of personal test theory," self-taught —
and offers it as evidence-based rather than mystical, citing a friend's
dog getting sick because "Mars was transiting her 6th house conjunct her
moon." The exchange sours by Sept 6–7 into the same trust/ex-partner
territory as the rest of the thread: she tells him "I don't know your
stance with your x or other females," says she "didn't like that you hung
up" on a related call, and pivots into naming the pattern she says defines
her — "I leave instantly at the first sign of" trouble, versus Dan, who
"stayed and tried to make things work to an extreme degree" — turning what
started as a shared hobby into another vector for the same abandonment-vs-
persistence dynamic that structures the whole relationship.

A September 19, 2025 exchange (expanded 2026-07-14) traces a specific
trigger-to-withdrawal sequence rather than a single line. Late that night,
mid-conversation about her mother's garage sale, Kristin abruptly pivots
after Dan shares results of a self-administered psychological "disorder
test": "I feel some type of way about your little disorder test... I'm now
concerned and I'm going to do the thing I do — like... pull away." She
frames the retreat as a defense mechanism she names explicitly ("I have the
ability to replace my feelings inside of me. Odd. But are we surprised?
No") rather than rejection, and tells him he needs "more time to heal
before you start pouring your unhealed pain into my purity." She then
surfaces a dead ex-partner, "Jeff," whose name she had tattooed and later
covered up, as the analogy for her own right to control emotional exposure
— contrasted with Dan apparently not wanting to cover a tattoo tied to his
own past: "There's a reason I got Jeff covered. And there's a reason you
don't want to. There's just a lot of things." Within the hour she partially
walks it back ("Ughhhhhhh don't read anything I said. I can't get it
together. I'm unhinged... I have fought so hard to get where I am and I'm
nowhere close to where I need to be. You are amazing. But you are
damaged"), citing an unresolved "girlfriend that I still don't know that
you do[ne with]" as a live source of her own doubt, before signing off with
love and an offer to meet the next day. The whole arc — instant retreat,
self-diagnosed pattern, partial retraction, love restated — is one of the
clearest single-session demonstrations of the same "leave at the first
sign of trouble" self-description she gives elsewhere in the thread.

Tom sits inside the thread as an active irritant rather than a background
figure. During a September 20 crisis over where Kristin would sleep, she
refuses to stay at another man's house out of stated loyalty to Dan while he
rages about having to "hide … from Tom fucking faggot Maison" — the supply
logistics, the jealousy triangle, and the drug-stashing plans ("stash it for
me at his fucking grandparents in their backyard") all braided together in a
single evening. Her own self-aware line, "WHAT IS MY LIFE," captures the tone.

A September 9, 2025 exchange (found 2026-07-14, random corpus sample; expanded 2026-07-14 with the surrounding half-hour) is not a spontaneous confession but the product of a joint digital-archaeology session: the two of them going through her old, apparently deactivated Twitter account (@kpdope) together, with Dan offering to run it through the Wayback Machine to recover deleted history and to use ChatGPT to help her sort and caption what she says is a backlog of "7K photos." Along the way Kristin raises, with real uncertainty rather than confidence, a possibly-related old handle or nickname — "Krazy Krez" — and a name, "Daniel Kresowaty," that she isn't sure is even connected to her; neither is resolved in the thread. Inside that archival dig she surfaces the meth/homelessness photos unprompted — one she captions "that's me on meth... I was homeless in that pic... calling around, methed up," adding she'd "been trying to do this since 8/14/15" (get clean, on the evidence of the date). Dan responds with curiosity rather than alarm ("i am so FUCKING curious about young kristin"). It's the clearest first-person disclosure of her own addiction and homelessness history anywhere in the thread, offered within the first two weeks of the relationship, and it arrives embedded in a collaborative project to reconstruct her own digital past rather than as an isolated admission.

A late-October message shows Dan naming the redundancy dynamic to her face:
he asks what she would think if he "notably started talking to annie
regularly and then backed out of a relationship immediately and then put you
on pause" — the exact sequence she later accuses him of. It is a rare instance
of the pattern being described by its own subject in real time.

## Terminal Phase (December 7–10, 2025)

The relationship did not fade; it collapsed over four days into a hostile blockade.

| Date | What happened |
|------|---------------|
| Dec 7–8 | Extreme asymmetry: Dan pushes for connection and recounts a sex dream; Kristin responds with flat dismissal and hostility |
| Dec 9 (a.m.) | Fight over $40 Kristin allegedly took from Dan's mother |
| Dec 9 (mid) | Dan escalates by claiming technical supremacy — that he has her WPA2 password and IP address and can throttle her Wi-Fi |
| Dec 9 (end) | Kristin calls the bluff, sends links to the FBI IC3 and DHS IPR Center complaint portals, says everything is screenshotted, blocks him, and warns that an officer will reach out |
| Dec 10 | A final outbound message from Dan (likely undelivered through the block) |

## Domain: Legal

The terminal exchange produced an explicit but uncharged threat surface on both sides: Dan's stated intent to compromise her Wi-Fi and Kristin's report threat via IC3 and the IPR Center, plus her claim that an officer would make contact. No charges are documented. Recorded for completeness alongside the [[wiki/work/bfs-foods]] and BFS material from the same window.

## Timeline

| Date | Event |
|------|-------|
| 2025-09-01 | Thread ignites on iMessage (moving day); early flirtation and an "i'm in love" send; Tom acid-trip reference |
| 2025-10-02 | Dan tells [[wiki/people/tom]] he and Kristin have "worked out that we are now officially dating" — the relationship's only explicit-commitment milestone |
| 2025-09 to 2025-11 | Sustained high-intensity flirtation, sexual negotiation, and boundary testing; AI-mediated conflict analysis |
| 2025-12-07/08 | Asymmetry peaks; Dan pursues, Kristin dismisses |
| 2025-12-09 | $40 dispute → Wi-Fi hack threat → IC3/DHS links → block |
| 2025-12-10 | Final outbound message from Dan |

## Notes

Last name confirmed as Shaelene from the dox-scan messenger export (the operating manual had listed "Shalene or Prentiss" as unknown). No evidence of continuation past the December 2025 burst appears in the master dump. Extreme volume concentrated in a short window makes this a strong data point for [[wiki/mind/concepts/contact-gini]], and the redundancy-under-collapse framing ties it directly to [[wiki/timeline/periods/2025-collapse]] and [[wiki/mind/synthesis/attachment-trauma-bond]].

## Related

[[wiki/people/tom]] · [[wiki/people/annie-ulmer]] · [[wiki/mind/concepts/contact-gini]] · [[wiki/timeline/periods/2025-collapse]] · [[wiki/timeline/periods/dec-2025-spike]] · [[wiki/self/message-corpora/master-message-dump]] · [[wiki/mind/synthesis/attachment-trauma-bond]]
