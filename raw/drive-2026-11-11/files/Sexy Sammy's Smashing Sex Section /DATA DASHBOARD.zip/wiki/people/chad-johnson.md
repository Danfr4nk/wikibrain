---
domain: people
page_type: entity
status: closed
date_created: 2026-06-23
date_modified: 2026-07-14
date_range_start: 2017-05-29
date_range_end: 2018-06-03
sources: ["raw/self/message-csv/MASTER_MESSAGES_DB_DUMP.csv"]
related: ["wiki/work/nemacolin-caddying", "wiki/people/brad-hubeaut", "wiki/self/message-corpora/master-message-dump"]
tags: [career, uniontown-era]
knowledge: mixed
infobox:
  name: "Chad Johnson"
  relationship_to_dan: unknown
  first_contact: 2017-05-29
  known_for: "Chad Johnson was a fellow caddy at [[wiki/work/nemacolin-caddying|Nemacolin Woodlands]] and a college student (reference"
---

# Chad Johnson

Chad Johnson was a fellow caddy at [[wiki/work/nemacolin-caddying|Nemacolin Woodlands]] and a college student (references 8am classes, being "out of school in a few weeks") who overlapped with Dan through the 2017–2018 seasons (`+13042165438`, 42 messages). Much of the thread runs through shift coordination relayed via caddy manager [[wiki/people/brad-hubeaut|Brad]] — "Did brad text you yet?", "Chad Johnson F2 both rounds" — and casual course hangouts.

## Texture

Early messages (May–June 2017) are mid-round check-ins on the course itself. A recurring bit through spring 2018 has Chad asking whether Brad had sent report times and joking about his golf ambitions ("I'm going pro soon!"). One April 2018 message asks whether he could live with Dan in town for a month before heading to a summer camp job — outcome undocumented. A November 2017 exchange references a night out that got hazy enough for Chad to ask what time he'd left and whether he'd "done anything stupid."

## Corpus Dimensions

| Metric | Value |
|--------|-------|
| Messages | 42 |
| Date range | 2017-05-29 to 2018-06-03 |
| Direction | Unreliable in this export (marked "Received" throughout) — read as one-way (Chad to Dan) |
| Handle | +13042165438 |

## Related

[[wiki/work/nemacolin-caddying]] · [[wiki/people/brad-hubeaut]] · [[wiki/self/message-corpora/master-message-dump]]
