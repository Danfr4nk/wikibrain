---
domain: people
page_type: entity
status: closed
knowledge: mixed
date_created: 2026-07-19
date_modified: 2026-07-19
date_range_start: 2013-03-26
date_range_end: 2018-12-09
sources:
  - "raw/self/facebook/facebook-ihatedanfrank/messages/inbox/laurynashly_4_5jbvoqow/message_1.html"
  - "raw/self/dox-scan/all_imessages_complete_dump.txt"
tags: [uniontown-era, addiction-recovery, grief]
infobox:
  name: "Rob Orange"
  sex: male
  location: uniontown
  relationship_to_dan: friend
  known_for: "High-school-era Uniontown friend; died April 2014, suspected opioid overdose, cause never confirmed in the corpus; mourned years later by both Dan and Jim Shaffer as the one loss among the cohort that actually hurt"
connections:
  - page: wiki/people/new-jim-shaffer
    type: co-occurs
    claim: "Jim's Dec 2018 remembrance — 'Rob and I would talk on the phone and laugh till we cried for 2 hours at a time, 5 days a week' — and the Tom Petty minivan story are the corpus's second independent account of the friendship, four years after his death."
  - page: wiki/people/lauryn-ashly
    type: evidenced-by
    claim: "Lauryn's April 11, 2014 real-time reaction to the death, traded with Dan the day the news broke, is the corpus's only contemporaneous account of Rob's death and its suspected cause."
  - page: wiki/people/steve-kezmarsky
    type: co-occurs
    claim: "Jim's Dec 2018 thread names Rob and Steve back to back as the cohort's losses — except Steve, per a correction the same conversation forces, was misheard as dead and was actually alive."
---

# Rob Orange

Rob Orange was a Uniontown high-school-era friend who died on or
around April 11, 2014 — the one loss in Dan's cohort that, years
later, both he and [[wiki/people/new-jim-shaffer|Jim Shaffer]]
independently describe as the one that actually hurt, in a friend
group otherwise known for treating its own losses as dark-comedy
material.

## The death (April 2014)

The corpus's only contemporaneous account comes from
[[wiki/people/lauryn-ashly|Lauryn Ashly]]'s Facebook thread, traded
with Dan the day the news broke. Neither of them knew the cause for
certain: "no he wasn't [in bad shape], he was doing great for a good
min now, and rob was never good at hiding using as much as he thought
he was, i have no clue what happened unless maybe his tolerance was low
and he got a few on a whim." Both suspected an opioid overdose but
disagreed on the drug — Lauryn: "I've never seen him do H though, only
blues [oxycodone 30mg pills]... even when he was really bad, i never
saw that" — while a public statement (sent to the family for approval
before release) contained "a quote" that made her think "he'd been
shooting something." Neither reading is confirmed; Dan himself says
"i almost know he was clean so I'm not sure at all." A location,
"Edgewood," is mentioned once without explanation. A funeral was
expected that Tuesday or Wednesday; neither Dan (newly started at a job
he "royally hate[d]") nor Lauryn (four hours away, unable to face
seeing him "like that") could attend, and both talk themselves into a
version of "he would probably be more upset if we all went and sat
nicely until it ended."

## Who he was

The corpus's character sketch is consistent across both this thread and
Jim Shaffer's, four years apart. Lauryn: "he was so fucking alive all
the time... such a live wire," recalling how they'd "cruise around all
the time just ripping on each other constantly" and a running joke
where she'd text him "i fucking hate engineers" to wind him up. Jim, in
a December 2018 exchange with Dan mourning him alongside remembering a
shared adventure — "Do you remember when me, you and rob orange took
that suped up mini van to the Tom Petty concert" — and, more quietly:
"Rob and I would talk on the phone and laugh till we cried for 2 hours
at a time, 5 days a week. I'd trade everyone in that photo for one more
call." Jim's tribute is notable for its register — the same thread runs
on dense, edgy shock humor throughout, and this is the one place it
drops entirely.

## Corpus record

| Metric | Value |
|---|---|
| Death | ~April 11, 2014 (news breaking date); cause never confirmed |
| Contemporaneous account | Lauryn Ashly thread, Apr 11, 2014 |
| Retrospective mourning | Jim Shaffer thread, Dec 2018 |

**Gaps:** confirmed cause of death; the significance of "Edgewood";
whether Dan or Lauryn ultimately attended the funeral; Rob's full name
and any surviving family.
