---
domain: people
page_type: entity
status: closed
knowledge: mixed
date_created: 2026-07-20
date_modified: 2026-07-20
date_range_start: 2020-02-08
date_range_end: 2020-02-08
sources:
  - "raw/self/facebook/facebook-ihatedanfrank/messages/inbox/ryanscherich_z-v_ahjumq/message_1.html"
tags: [ideology, politics, uniontown-era]
infobox:
  name: "Ryan Scherich"
  sex: male
  relationship_to_dan: acquaintance
  known_for: "Single-day Feb 8, 2020 political flame war ending in a remark Dan calls racist and cuts contact over"
connections:
  - page: wiki/mind/synthesis/2020-left-turn
    type: co-occurs
    claim: "The Feb 8, 2020 argument lands squarely inside the documented Bernie-2020 evangelism window (Iowa caucus texts dated Feb 3), giving the pre-COVID conversion period a real, contemporaneous conflict rather than only Dan's own messaging to allies."
---

# Ryan Scherich

Ryan Scherich is a barely-known acquaintance ("i barely fucking know
you") with whom Dan has a single, self-contained political flame war on
February 8, 2020 — the entire relationship the corpus documents.

## The argument

It starts over a Facebook comment implying Dan should "get a job,"
which Dan reads as ignorant of New York's cost of living, and escalates
fast once Ryan clarifies his actual target: "the ppl who don't have
jobs and want everything handed out to them for free. The Democrats...
Socialism doesn't work... Bernie Sanders says it is a good thing ppl
[are] waiting in lines for handouts for the Gov't. He is stupid." Dan
cuts him off ("you just lied... go fuck your self... i really don't
need to hear your brainwashed maga shit") and the exchange sharpens
until Ryan, telling Dan to enjoy New York, adds: "U know how they
[illegals] kill and rape ppl. Hits the news on all stations" — which
Dan calls out directly ("dude you are a RACIST") before ending contact.
Ryan's closing message, unapologetic, insists "that's not racist."

The argument falls squarely inside the documented Bernie 2020
evangelism window on
[[wiki/mind/synthesis/2020-left-turn|the 2020 left turn]] page (Dan's
Iowa-caucus texts to friends are dated five days earlier, February 3) —
a real, dated instance of the pre-COVID political identity clashing
with an opposing view in the wild, months before the fuller
lockdown-era radicalization the other page documents in more depth.

## Corpus record

| Metric | Value |
|---|---|
| Messages | ~63 (Facebook Messenger, both directions) |
| Date range | 2020-02-08 (single day) |

**Gaps:** how Dan and Ryan knew each other in the first place; whether
any contact occurred before or after this single exchange.
