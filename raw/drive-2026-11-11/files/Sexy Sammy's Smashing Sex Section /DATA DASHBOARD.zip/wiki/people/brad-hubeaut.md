---
domain: people
page_type: entity
status: closed
date_created: 2026-06-23
date_modified: 2026-07-14
date_range_start: 2017-10-13
date_range_end: 2018-10-03
sources: ["raw/self/message-csv/MASTER_MESSAGES_DB_DUMP.csv"]
related: ["wiki/work/nemacolin-caddying", "wiki/timeline/periods/2017-poverty-floor", "wiki/self/message-corpora/master-message-dump"]
tags: [career, uniontown-era]
knowledge: mixed
infobox:
  name: "Brad Hubeaut"
  relationship_to_dan: unknown
  location: uniontown
  first_contact: 2017-10-13
  known_for: "Brad Hubeaut was Dan's caddy manager at [[wiki/work/nemacolin-caddying|Nemacolin Woodlands]] through the 2017–2018 caddy"
---

# Brad Hubeaut

Brad Hubeaut was Dan's caddy manager at [[wiki/work/nemacolin-caddying|Nemacolin Woodlands]] through the 2017–2018 caddying seasons — the day-to-day dispatcher who assigned report times, ran hiring paperwork, and managed the caddie roster across Nemacolin's multiple courses (Mystic, Shepherd's, Laurel Valley, occasional trips to Oakmont). The 163-message thread (`+13042162954`, October 2017 – October 2018) is dominated by routine scheduling but also documents a real workplace friction episode in April 2018.

## The job

Most of the thread is mechanical: daily "X:00 report" texts, availability checks ("Hey buddy can you work today?"), and seasonal admin — reminders to bring a Social Security card for new paperwork, group carpool logistics for early loops at Oakmont ("leave from Uniontown super early"), and periodic all-caddie broadcasts about big groups needing coverage. Brad's tone is casual and collegial ("buddy," "gents," "boys"), consistent with a shift-lead managing a crew of young, informally organized workers.

## The April 2018 friction

On April 20, 2018, Brad relays a complaint from another staffer (Tyler) that Dan hadn't cleaned his carts, and separately notes to another recipient that "Dan Frank booked it and didn't clean his carts at all. Just left them at the bottom of the ramp." Five days later, after Dan apparently declined a shift, Brad snaps: "Wow man so all that texting about helping out was bullshit... I ask you do the same. Let's keep it strictly professional," and two days after that lists specific violations — turning down work four times, turning down a "hitting" assignment, the uncleaned carts — before telling Dan to "come talk to me" once conditions improve. The relationship cools noticeably but doesn't end: report-time texts and shift offers resume within days and continue through the 2018 season, including an April 22 message forwarding two names (Trevor Bains, Nathan Younkin) as fellow caddies, and Brad closing out the corpus in October 2018 with a friendly aside about Dan's "drone gig."

## Corpus Dimensions

| Metric | Value |
|--------|-------|
| Messages | 163 |
| Date range | 2017-10-13 to 2018-10-03 |
| Direction | Unreliable in this export (marked "Received" throughout) — read as mostly one-way (Brad to Dan, as a shift-lead broadcasting to his crew) |
| Handle | +13042162954 |

## Related

[[wiki/work/nemacolin-caddying]] · [[wiki/timeline/periods/2017-poverty-floor]] · [[wiki/self/message-corpora/master-message-dump]]
