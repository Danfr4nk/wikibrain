---
domain: people
page_type: entity
status: closed
date_created: 2026-06-23
date_modified: 2026-07-14
date_range_start: 2023-09-29
date_range_end: 2024-08-12
sources: ["raw/self/message-csv/MASTER_MESSAGES_DB_DUMP.csv"]
related: ["wiki/work/au-zaatar", "wiki/people/md", "wiki/self/message-corpora/master-message-dump"]
tags: [relationships, addiction-recovery, nyc-era]
knowledge: mixed
infobox:
  name: "Mohammed Bin Salman"
  relationship_to_dan: unknown
  first_contact: 2023-09-29
  known_for: "The contact name is a joke, not a real identity — this is a young, close friend Dan games with heavily over ten months ("
---

# "Mohammed Bin Salman" (gaming friend, 2023–2024)

The contact name is a joke, not a real identity — this is a young, close friend Dan games with heavily over ten months (`+13474936671`, 281 messages, September 2023 – August 2024), mostly Apex Legends, with side trips into Fortnite, Call of Duty Mobile, and Fall Guys. The relationship is dense in a short window: most of the corpus is concentrated in a single stretch, December 5–17, 2023, of near-nightly co-op sessions with real teaching/learning texture — sliding mechanics, sound cues, ammo crafting, hot-drop strategy — and easy trash talk.

## Beyond the games

The friendship has real personal register underneath the gaming banter: a January 2024 "shieet bro i been stressed outta my mind lately," a shared joke about being broke, and a matter-of-fact December 2023 exchange comparing Xanax to cocaine ("u on xanax now / hows that compared to good ol snow") that reads as two people genuinely comparing notes rather than a transaction. Political and cultural asides surface unprompted — a passing comment about Palestine/Algeria territorial disputes, a joking reference to "Modi and dj" — and a recurring "md" appears in a dream he recounts, possibly the same contact documented at [[wiki/people/md]] (unconfirmed link) or an Au Za'atar-adjacent nickname for someone in [[wiki/work/au-zaatar|that circle]].

## Corpus Dimensions

| Metric | Value |
|--------|-------|
| Messages | 281 |
| Date range | 2023-09-29 to 2024-08-12 |
| Direction | Unreliable in this export (marked "Received" throughout) — read as one-way (friend to Dan) |
| Handle | +13474936671 |

## Gaps

Real name and identity are unknown — the contacts card is a joke. Whether the "md" dream reference connects to the documented [[wiki/people/md]] contact is unconfirmed.

## Related

[[wiki/work/au-zaatar]] · [[wiki/people/md]] · [[wiki/self/message-corpora/master-message-dump]]
