---
domain: people
page_type: entity
status: closed
date_created: 2026-06-23
date_modified: 2026-07-19
date_range_start: 2019-06-10
date_range_end: 2019-07-09
sources: ["raw/self/message-csv/MASTER_MESSAGES_DB_DUMP.csv"]
related: ["wiki/people/jaredtricia", "wiki/people/kelly-johansson", "wiki/people/trinity-st-clair", "wiki/people/annie-ulmer", "wiki/self/message-corpora/master-message-dump", "wiki/mind/concepts/contact-gini"]
tags: [relationships, nyc-era, digital-footprint]
knowledge: mixed
infobox:
  name: "Brian"
  relationship_to_dan: unknown
  location: nyc
  first_contact: 2019-06-10
  known_for: "Brian was an older, financially comfortable NYC client who booked [[wiki/people/annie-ulmer|Annie]] — working that summe"
---

# Brian (NYC, 2019)

> *Not to be confused with [[wiki/people/bryan-5088682461|Bryan]], the third participant in the October 20, 2019 filmed MMF — same-sounding name, different man.*

Brian was an older, financially comfortable NYC client who booked [[wiki/people/annie-ulmer|Annie]] — working that summer under the alias "Hazel" (confirmed by Dan, 2026-07-14; Annie also used "Lily Lush" and the joint Chaturbate handles "smashonistaa"/"sofvded") — for two paid visits in summer 2019 (`+13137181574`, 43 messages, June 10 – July 9). A separate thread, [[wiki/people/jaredtricia|Jared and Tricia]], books the same "Hazel" persona against what they call "the Eros ad" at a confirmed $1,000/2-hour rate — the same summer the couple was also paying escorts [[wiki/people/kelly-johansson|Kelly Johansson]] and [[wiki/people/trinity-st-clair|Trinity St. Clair]] for group sessions, meaning Annie was working both sides of the arrangement's economy that year: booked as a provider and booking providers.

Every message in this export is prefixed with a second number, `+12039170139`, embedded literally in the text — likely an artifact of how the thread was exported rather than two separate contacts; both numbers are treated here as the same "Brian."

## What the thread shows

Brian proposes meeting from an apartment in Riverdale with a terrace, offers to send an Uber, and notes the trip would be "only 15-20min." He offers to compensate for "extras," jokes about "Hazel" needing to "get used to me," and gives Dan's own documented NYC address, 307 E 76th Street, as the Uber pickup point for the second visit on July 9, 2019: "Do you want to txt me when you're ready and I'll send a car. Same address? 307 E 76th Street." Both visits — mid-June and the July 9 follow-up — end in warm, casual sign-offs.

## Corpus Dimensions

| Metric | Value |
|--------|-------|
| Messages | 43 |
| Date range | 2019-06-10 to 2019-07-09 |
| Direction | Unreliable in this export (marked "Received" throughout) — read as one-way (Brian to "Hazel") |
| Handle | +13137181574 (messages self-prefixed with +12039170139) |

## Related

[[wiki/people/jaredtricia]] · [[wiki/people/kelly-johansson]] · [[wiki/people/trinity-st-clair]] · [[wiki/people/annie-ulmer]] · [[wiki/self/message-corpora/master-message-dump]] · [[wiki/mind/concepts/contact-gini]]
