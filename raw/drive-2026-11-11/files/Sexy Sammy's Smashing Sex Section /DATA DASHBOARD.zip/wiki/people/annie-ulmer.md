---
domain: people
page_type: entity
title: "Annie (Anne Louise Ulmer)"
aliases: ["Annie", "Anne Ulmer", "Anne Louise Ulmer", "@Lo_weez"]
importance: critical
knowledge: mixed
status: closed
date_created: 2026-06-22
date_modified: 2026-07-19
date_range_start: 2015-11-01
date_range_end: 2026-06-01
infobox:
  name: Annie Ulmer
  status: Closed (relationship ended 2026-06-01)
  type: Partner (2015–2026)
  known_for: Decade-long relationship; subject of forensic dossiers
  partner: "[[wiki/self/overview|Dan Frank]]"
  first_mentioned: November 2015
  closed: June 1, 2026
  notes: See [[wiki/timeline/events/eli-incident|the Eli incident]]
  relationship_to_dan: ex-partner
  location: nyc
  first_contact: 2015-11-01
  handles: ["@Annelouise28", "@Lo_weez", "@alexisarmel"]
changelog:
  - date: 2026-07-15
    note: "Extended with single-bond-switch thesis (2015 Alexis→Annie same-week transfer) + verified onset flood (728/682/363/679 sent Dec 10-13 2015, recomputed from MASTER_MESSAGES_DB_DUMP.csv); cross-linked bond-switch-2015, 155-virginia-ave, alexis-armel"
  - date: 2026-07-13
    note: "Full rewrite from complete dossier corpus (all 6 FINAL/amended dossiers + addenda, DUI megadoc, Target G forensics)"
  - date: 2026-07-11
    note: "Data audit: burst-event misattribution fixed, financial amendments folded in"
sources:
  - raw/self/message-csv/imessage_export_17245629389_both_all_now.csv
  - raw/self/dox-scan/DanAnnie_MasterRecord_FINAL.docx
  - raw/self/dox-scan/DanAnnie_MasterRecord_March16.docx
  - raw/self/dox-scan/DanAnnie_TenYears_WithAmendments.docx
  - raw/self/dox-scan/DanAnnie_TheoryOfEverything_Updated.docx
  - raw/self/dox-scan/DanAnnie_CompleteRecord_Final.docx
  - raw/self/dox-scan/DanAnnie_CompleteAnalysis_Final.docx
  - raw/self/dox-scan/DanAnnie_MoralAnalysis_SFW.docx
  - raw/self/dox-scan/DanAnnie_CorrectiveAddendum.txt
  - raw/self/dox-scan/Annie Affadavit.txt
  - raw/self/dox-md/ulmer_dui_megadoc.md
  - raw/self/dox-md/CATO_BOOTLOADER_DANFRANK.md
  - raw/self/dox-scan/FULL TWITTER ANALYSIS.txt
  - raw/self/dox-md/Honest assessment and value judgment analysis.md
  - raw/self/dox-md/Gemini-_07.md
  - raw/self/dox-md/Gemini-_18.md
  - raw/self/dox-md/LIFE_EVENTS_CALENDAR.md
  - raw/self/message-csv/imessage_7244346811+2124702449_both_all_now.csv
  - raw/self/message-csv/annie_all_time_logs.csv
  - raw/self/message-csv/THE END FIGHT.csv
  - raw/self/message-csv/imessage_export_7248123683_20260624.csv
  - raw/self/facebook/facebook-ihatedanfrank/
  - raw/self/gemini-activity/Gemini Activity.html
  - raw/self/dox-md/THE_DAN_FRANK_BOOTLOADER.md
related:
  - wiki/mind/concepts/attachment-model
  - wiki/mind/concepts/conflict-architecture
  - wiki/mind/synthesis/attachment-trauma-bond
  - wiki/mind/synthesis/bond-switch-2015
  - wiki/mind/synthesis/dan-annie-fallout-verdict
  - wiki/people/alexis-armel
  - wiki/places/155-virginia-ave
  - wiki/timeline/events/eli-incident
  - wiki/timeline/events/end-fight
  - wiki/timeline/events/march-2026-terminal-phase
  - wiki/timeline/events/april-may-2026-final-weeks
  - wiki/timeline/events/group-chat-closure
  - wiki/timeline/periods/dec-2025-spike
  - wiki/timeline/periods/2015-2016-annie-relationship-start
  - wiki/timeline/periods/2025-collapse
  - wiki/mind/concepts/erotic-architecture
  - wiki/timeline/periods/covid-era-2020
  - wiki/people/eli
  - wiki/mind/psychosexual/index
  - wiki/mind/psychosexual/arrangement-history
  - wiki/people/tuquick-17248123683
  - wiki/work/au-zaatar
  - wiki/people/shelbie-breakiron
  - wiki/people/trinity-st-clair
  - wiki/mind/concepts/contact-gini
  - wiki/mind/concepts/forensic-method
  - wiki/mind/concepts/dans-law
  - wiki/people/kelly-johansson
  - wiki/people/jaredtricia
  - wiki/people/brian
tags: [relationships, infidelity, nyc-era, trauma-bond, ai-collaboration]
connections:
  - page: wiki/people/bekah-fullem
    type: evidences
    claim: "Dan's March 2020 disclosure to Bekah — that Annie is herself a rape survivor with a 45-year sentence for the assailant — is the only source for this fact anywhere in the corpus; unverified independently."
  - page: wiki/mind/concepts/node-locking
    type: evidenced-by
    claim: "The master node set Dan locks across AI sessions — the Loop, the Signals, Separation Logistics — is his own curated minimal model of this relationship's collapse, evidence of which facts he treated as load-bearing."
  - page: wiki/mind/psychosexual/arrangement-history
    type: component-of
    claim: "Annie is the constant across every documented arrangement instance — the architecture is structurally a property of this relationship, from the 2016 jealousy-kink baseline through smashonista to the 2019 paid-model window."
  - page: wiki/mind/synthesis/block-unblock-loop
    type: component-of
    claim: "The 127/110 exit-relapse record is the loop's central case, and the March 2026 fight shows Annie running the same block-unblock operation back at Dan — the loop is bidirectional inside the bond."
  - page: wiki/people/nick-mattie
    type: evidenced-by
    claim: "The May 2, 2017 Nick Mattie handoff — product left with Annie after she messaged him on Facebook — dates her supply-logistics facilitation a full year before the documented 2018–19 Johnny-era role."
  - page: wiki/mind/concepts/attachment-model
    type: evidences
    claim: "The ten-year Annie corpus is the attachment model's quantitative base: 0 explicit severance signals across 41,073 of her messages, the 187-of-191 affection-to-request pairing, 24 alibis, 13 unchanged-behavior apologies."
  - page: wiki/mind/concepts/conflict-architecture
    type: evidences
    claim: "The Annie corpus is the conflict engine's fingerprint at full load: the 74/17/11 abuse triad, 127/110 exit-relapse record, 94 silence-preceded bursts, and the terminal-phase volume asymmetry."
  - page: wiki/mind/synthesis/estate-money-spine
    type: component-of
    claim: "The ~$119–123K net payment-app outflow to Annie is the money spine's largest documented drain — roughly the size of the entire estate distribution, exiting through the relationship over the decade."
  - page: wiki/people/tom
    type: co-occurs
    claim: "Tom is a recurring selected participant in the 2018-2024 arrangement documented on this page."
  - page: wiki/mind/synthesis/supply-network
    type: component-of
    claim: "Annie occupies both seats in the supply network across its life — logistics facilitator in the 2018–19 Johnny era, dependent consumer in the terminal phase, when Dan's control of the supply ('bop') was the relationship's primary retention mechanism."
  - page: wiki/people/johnny-dealer
    type: co-occurs
    claim: "Annie ran facilitation through Johnny's node — drops, pickups, 'I'm at Johnny's' — making her a logistics participant in the 2018–19 supply chain, not a bystander to it."
  - page: wiki/people/teddy
    type: co-occurs
    claim: "Teddy's final exchange checks whether both Dan's and Annie's numbers are current, placing Annie inside the supply thread's contact routine."
  - page: wiki/mind/synthesis/message-circadian-latency
    type: evidenced-by
    claim: "The circadian/latency cut supplies the quantitative case for the relationship's singularity: median 9-minute mutual reply latency against hour-scale delays everywhere else."
  - page: wiki/timeline/periods/feb-apr-2025-return-and-rupture
    type: evidences
    claim: "Annie's unilateral move to her parents' house rather than accepting Dan's open-ended offer to fund an apartment anywhere she chose is the first concrete post-affair decision-making asymmetry in the corpus, predating the terminal-phase asymmetry by roughly eight months."
  - page: wiki/work/tech/danmodel
    type: evidenced-by
    claim: "Annie (early) alone accounts for 40% of the 39,378 stimulus-response pairs DANMODEL extracted from Dan's full message corpus — a mechanical, independently-derived confirmation of her centrality."
---


# Annie (Anne Louise Ulmer)

This page is also the largest single deployment anywhere in the corpus of
[[wiki/mind/concepts/forensic-method|the forensic method]] — the same
anomaly-hunting, primary-record-over-narrative default documented as
Dan's cognitive baseline, here run for over a decade against the person
who mattered most, producing the dossier corpus this page compresses.

Anne Louise "Annie" Ulmer was the defining relationship of Dan's adult life:
ten years and seven months, from November 28, 2015 (the Saturday after
Thanksgiving) to June 1, 2026, including roughly eight years of
cohabitation in New York. It ended involuntarily, in a group chat, when
third parties confirmed two things at once — a sustained concealed
third-party relationship, and a defamation campaign she had been running
against Dan inside their shared network while privately assuring him of
her loyalty. The relationship is closed and historical. Its documented
conclusion, carried throughout this wiki, is that **the gaslighting
outweighed the affair** — and the corrective record sharpens what that
means: the central moral event of the final phase was not the infidelity
itself but the months Annie spent forcefully convincing Dan that his
*accurate* perception of the ongoing affair was mental illness. He was
right; he was told he was insane for being right; and he eventually chose
to believe her because the alternative was worse. That injury — an attack
on his capacity to know his own reality — is rated in the final dossiers
as more serious than the procurement system, the silences, or the
betrayal it concealed.

## LLM Quick Brief

**For context injection:** Annie (Anne Louise Ulmer), Dan's partner
2015–2026, the first relationship to fully activate his attachment system.
Met through [[wiki/people/alexis-armel|Alexis]]; Annie left her prior
partner within 24 hours. Former MyFreeCams cam model; the couple later
cammed together as "smashonista" and ran a Dan-architected
quasi-non-monogamous arrangement (2018–2024, Dan present/arranging).
Cohabited ~8 years (155 Virginia Ave, then NYC, largely Dan-funded early);
financial burden oscillated by era. Concealed affair with NYC coworker
[[wiki/people/eli|Eli]] through autumn 2024 (Eli's 11:18 PM self-introduction
text, Jan 9 2025) while gaslighting Dan's accurate suspicions as paranoia;
ended cohabitation on the Feb 2025 PA return. Terminal phase (Aug 2025–Mar
2026): drug-supply dependency, 187:4 love-to-request ratio, 12 uncared-for
crisis statements, two written denials, GPS removal. Left Dan for
[[wiki/people/tuquick-17248123683|Tuquick]]; June 1 2026 group-chat closure
confirmed the relationship and a defamation campaign (false rape and
"junkie" narratives). Tuquick defected 14 days later, independently calling
her a compulsive liar. 126,683-message corpus is the empirical base of the
wiki's attachment and conflict models. Closed — not a live thread. At a
0.961 [[wiki/mind/concepts/contact-gini|Contact Gini]] coefficient, Annie's
two handles alone account for the overwhelming share of Dan's entire
relational volume across the corpus — a concentration the redundancy
concept treats as the structural precondition for how total the June 2026
collapse was.

## Who she was

Annie came into the relationship a former MyFreeCams model who described
her camming as the product of a dissociative period after her prior
relationship: "That's when I started camming. Because I didn't care about
myself. I wanted to be looked at." Dan knew this before they met — his
ex told him — and was drawn to it rather than troubled by it. Her family
anchors her Uniontown world: parents whose friendship with Dan's mother's
circle goes back decades, her grandmother Sugie (a genuine, documented
caretaking obligation that later doubled as her most-used alibi), a sister
[[wiki/people/claire-ulmer|Claire]], a niece and nephew she helped care
for, and the dog [[wiki/people/milo|Milo]], a fixture of the NYC domestic
record — Claire is
the one who first found Milo as a starving stray in her neighborhood.

A single, undated-elsewhere data point on Annie's history before Dan:
in a March 29, 2020 message comforting [[wiki/people/bekah-fullem|Bekah
Fullem]] through her own rape disclosure, Dan states that Annie is
herself a rape survivor — that it took her years to report it, that the
trial was "super painful and full of ptsd moments," and that the
assailant, "a serial rapist," received a 45-year sentence. This is
sourced only to Dan's own secondhand account, offered in the context of
supporting a third party, and has no independent corroboration anywhere
else in the corpus — treat as a real but unverified claim pending a
primary source or a more direct account.

The early record is unambiguous about the love being real. On day three
of the documented corpus (Nov 29, 2015) she wrote "YOU ARE MY EVERYTHING"
and "You are my full life." Her love-language frequency peaked in 2016 at
5.3% of all her messages — the highest of any year — and she initiated
contact on 62% of days in 2015. The dossiers insist on this baseline
because it makes the later record legible: the failures were trajectory,
not character-from-birth. The same texture of voice that sent "wittle guy"
in 2024 sent "I love you in every single inch of your being" in 2015. The
target changed, not the voice.

## The arc

They met through Alexis in November 2015; Annie ended her existing
relationship within twenty-four hours of the introduction. This was the
first relationship in Dan's documented history to trigger full attachment
activation — nothing comparable appears in the
[[wiki/people/danielle-onesi]] or [[wiki/people/alexis-armel]] eras. Dan
was afraid of losing her from day three ("I'm really really scared that
you won't want this anymore," Dec 2 2015) — before any betrayal existed —
and that fear became the organizing principle of the decade. From 2016
she lived with him at 155 Virginia Avenue, then through the New York
years, a move Dan funded and sustained: he was the household's financial
foundation for roughly the first five NYC years, drawing on
[[wiki/people/suzanne-frank|Suz]]'s resources. Dan's public Twitter
independently corroborates the timing: the handle **@Lo_weez** enters
as his "new primary" relational tag in December 2015 — "worlds best
girlfriend" — continuing through 2016 with matching personal detail
("Girlfriend drinks too much Cherry Coke," "@Lo_weez ur next
maxxinista"), while @alexisarmel goes fully silent the same window. This
resolves a standing gap on [[wiki/people/katie-fletcher]]'s page, which
had flagged @Lo_weez as possibly a third person.

The near-simultaneous Alexis-ending / Annie-beginning is documented as
the **single-bond switch** at [[wiki/mind/synthesis/bond-switch-2015]]:
the sx/sp stack vacates one singular bond slot and reoccupies it near-
simultaneously rather than running two bonds in parallel, and the shared
"lair" at 155 Virginia Avenue (leased during the Alexis years, into which
Annie moved) is the physical proof that the transfer was a swap, not a
relocation. The bootloader corpus corroborates the activation's intensity
with a verified onset flood: Dan sent **728 messages on 2015-12-10**, then
682 (Dec 11), 363 (Dec 12), 679 (Dec 13) — the highest daily sent-volume
anywhere in the 2011–2026 record except the 2025–26 termination window,
and recomputed exactly from `MASTER_MESSAGES_DB_DUMP.csv` during the
2026-07-15 pass. The same maximum-output-under-maximum-attachment shape
appears at both ends of the relationship.

> **CONTRADICTION (origin story):** `CATO_BOOTLOADER_DANFRANK.md`
> preserves a different, more colorful origin account: Alexis, as
> Annie's coworker, sent Dan to buy drugs from Annie, and the two hooked
> up during that transaction, dated loosely to "~2014-15" rather than the
> corpus-anchored November 28, 2015. The dated message record (day-three
> "YOU ARE MY EVERYTHING," Dec 2 2015 abandonment-fear text) is the
> stronger source and is what this page follows; the bootloader's version
> is preserved here as an unresolved, stylized alternate account rather
> than adopted or discarded outright — it may be dramatized retelling of
> the same event, or a distinct, earlier first contact that predates the
> relationship's documented start.

The same bootloader session records the immediate aftermath: after the
breakup, Alexis returned to stay with Dan and Annie for about a month,
bringing a new boyfriend who was — per the same account — both Dan's
sister [[wiki/people/vanessa-frank|Vanessa]]'s first boyfriend and someone
who had lost his virginity to Annie. That boyfriend was arrested during
the stay picking up a mailed weed parcel.

> **REVISED [2026-07-14]:** independent corroboration has since surfaced
> on [[wiki/people/alexis-armel]] — a retelling by Dan to
> [[wiki/people/new-jim-shaffer]] (April 2018) describing the same
> mechanism (a mail-order weed pickup that walked into an unrelated police
> warrant) but dated concretely to **Valentine's Day 2017**, not the
> immediate December 2015 aftermath, and naming Alexis herself (not only
> the boyfriend, identified by full name as **Zac Shumar** — also
> Vanessa's own ex-boyfriend before Alexis dated him) as arrested,
> charged with felonies, and later incarcerated at SCI Muncy after
> violating probation. A second independent retelling to
> [[wiki/people/tom]] (Aug 2018) confirms the scale (10 pounds of
> marijuana mailed) and sharpens the legal asymmetry: Zac's paid lawyer
> got him out of the group plea deal's consequences while Alexis served
> the time. Whether this is the same event as the bootloader's account
> with the date and details corrected, or a second, separate arrest, is
> unresolved — but the core mechanism (mail-drop bust) matching across
> two independent sources makes
> a single conflated/misdated event the more likely reading.

**The arrangement (2018–2024).** Camming was discussed within weeks of the
start (Dec 2015) and the couple streamed together on Chaturbate as
**smashonista** (confirmed Aug 2018; Patreon Oct 2019; Annie also ran an
OnlyFans). Around 2018, after discovering Annie talking to other men
online, Dan proposed a quasi-non-monogamous structure rather than an
ultimatum: he would arrange encounters — typically with his own friends,
always with himself present — built around his explicitly named jealousy
kink (first named Feb 2016). The record confirms he genuinely embraced it
rather than tolerated it, and that Annie participated across years and
said she enjoyed it ("I did enjoy our relationship/situation/arrangement
we had with him," Nov 3 2024). The asymmetry is also documented: Annie
never delivered the reciprocal side, and she often agreed to encounters
that never materialized. The earliest concrete instance found so far runs
even earlier than the arrangement's "formalized" 2018 date implies, and it
is with a woman from Dan's own romantic history rather than a stranger or
one of his friends: days after [[wiki/people/alexis-armel|Alexis]]'s
release from her year at SCI Muncy, she and Annie hooked up at Dan and
Annie's house with Dan present (Nov 3, 2018), and the household prepared
for a same-week repeat the following evening — full account at
[[wiki/timeline/events/annie-alexis-reunion-november-2018]]. The next
well-documented instance with a woman is the
[[wiki/timeline/events/shelbie-annie-threesome-april-2019|April 2019 threesome]]
with [[wiki/people/shelbie-breakiron|Shelbie Breakiron]], whom Dan was
also seeing one-on-one that spring — Shelbie's own messages through June
2019 treat Annie's presence as an unremarkable condition of the
relationship. The same spring also produced a paid encounter with adult
performer [[wiki/people/trinity-st-clair|Trinity St. Clair]], booked and
scheduled with both of them addressed directly, and by that fall the
arrangement had a professionalized edge: a five-week run of paid sessions
with NYC escort [[wiki/people/kelly-johansson|Kelly Johansson]], who
treated Annie as a working peer rather than a client's girlfriend and
pitched bringing both of them in as co-providers for one of her own
regular clients. That same June, Annie was on the other side of that
same economy: working as a paid provider herself under the alias
**"Hazel"** (she also used "Lily Lush," alongside the joint Chaturbate
handles "smashonistaa"/"sofvded" from the camming side of the
arrangement), booked twice by [[wiki/people/jaredtricia|a married
Gramercy couple]] and once by [[wiki/people/brian|an older NYC
client]] at a confirmed $1,000/2-hour rate advertised via an Eros
listing. The final dossiers read the arrangement as the
most concentrated expression of Dan's retention architecture — he
converted the greatest threat to the relationship into its central kink,
and it worked for years. The October 2024 Tom incident, first analyzed as
coercion, was **materially revised** on full context: an established
six-year framework, a willing historical participant, in a specific
instance where she was exhausted and chemically depleted and said so
bluntly ("Numb. I'm cool") while choosing to proceed. Her "I've lost all
morals at this point… I don't care or feel anything anymore" (Oct 31
2024) still stands as the record of her interior dissolution going into
the terminal era.

**The Train Plan (September 2020).** The largest documented pre-2025
crisis, previously invisible because 2020 was a near-absent year in some
of the message exports. During COVID lockdown at Annie's parents' home,
Dan discovered she had been telling another man "terrible, unforgivable,
untrue things" about him, and that the man had made plans to pick her up
from the train station. Dan took seven Xanax bars, threatened to leave
permanently, and sent 200+ messages over several days. Annie's own words
afterward: "I know what I said and I fucking regret it… I have messed
shit up. Multiple times." Dan's characterization of the cumulative
pattern used the word "cheated"; she did not contest it. See
[[wiki/timeline/periods/covid-era-2020]] for the lockdown context this
sits inside.

**The financial oscillation.** Per the three accepted amendments: Dan
funded the early NYC years; in 2021 he was also her employment vector —
a month into his own Au Za'atar hire he got her the hostess job at the
original East Village location (she was later fired from it with zero
notice, the "avatar of reliability" contrast documented on
[[wiki/work/au-zaatar]]); in 2023 he worked at
[[wiki/work/au-zaatar|Au Za'atar]] while an unemployed Annie shared in
accumulating ~$10,000 of landlord debt (paid down $650/week); he was
involuntarily managed out in June 2024 (hours cut to dodge unemployment
obligations; unemployment filed Aug 8 2024 amid an active job search).
Only then did the "Annie working, Dan home" window open — the one her "I
WORK 6 FUCKING DAYS A WEEK" grievance (Nov 15 2024) generalized from. In
2024 she was the sole earner, carrying rent, the phone bill, a PNC loan,
and the shared drug budget; the grievance was locally valid and
historically partial, and the dossiers note that citing the most recent
data in her favor was characteristic. In Uniontown the dependency
inverted a third time: she lost income, independence, and drug supply in
one move, and Dan became the supply chain. Each phase featured one party
holding structural leverage over the other's exit; neither did it
consciously; both did it effectively.

**The money — quantified.** The oscillation above is the qualitative shape;
the payment-app ledgers put a hard number on it. Per operator-provided
screenshots of Annie's profiles viewed from Dan's own payment apps
(2026-07-15; these are **not** in `raw/`, and the two totals come from two
separate apps, so they are not a single summed ledger):

- **Cash App** (Annie as `@Annelouise28`): Dan's "Total Sent" to that profile =
  **$139,184.96**. This lines up with Dan's own account dashboard, which shows
  **Total Sent $138,249.40 / Received $20,243.37 / 807 transactions** across
  all contacts — i.e. Annie was the dominant destination of his outflow.
- **Venmo** (Annie as `@$Louisexoxo`): Dan's "Sent" to that profile =
  **$99.8K**, "Received" from it = **$15.8K**, across **448 payments**.

Read together (and noting the two apps are separate ledgers), Dan sent Annie
on the order of **~$139K** and received back only **~$16–20K** — a net outflow
to her of roughly **$119K–$123K** over the relationship. A control screenshot
of a *different* contact (Shelby Breakiron, `@$ShelbieRose`) shows the same
schema — Dan's "Total Sent" $4,687.69 / "Received" $0.00 — confirming that
when Dan views another profile, the Sent/Received figures are *his* flows with
that person, not theirs. The ~$139K figure is the concrete floor under the
"Dan-funded" and "supply-chain architect" reads elsewhere on this page: the
relationship was not just emotionally asymmetric but financially lopsided by
roughly six-to-one in her favor. (Caveat: these are point-in-time screenshots
of totals, not a per-month reconciliation; the exact share attributable to
drugs vs household vs gifts is not separable from the totals alone.)

**The Eli affair and the gaslighting of accurate perception.** By autumn
2024 at the latest, Annie's concealed relationship with her restaurant
coworker Eli was active. Dan sensed it and said so, repeatedly, in real
time — and was told, at length and by name, that his perception was
insanity. The October 19, 2024 housewarming argument is the clearest
single episode: "THERE IS NO SITUATION." / "You're literally fucking
insane." / "Grow up. And fucking trust me." — all said while the affair
was ongoing. The Corrective Addendum retracts the earlier "controlling
behavior" framing of Dan's autumn-2024 vigilance: his instincts were
right, and his distress was proportionate to a real deception he was
correctly detecting. He eventually chose to believe her — his May 2025
retrospective names the mechanism: he stopped looking "to get back to a
normal life where i didn't have to try to find the evidence i would need
to prove it." On January 9, 2025 at 11:18 PM, Eli introduced himself by
text ("Hey Dan. It's Eli. Annie is down stairs. I work with her.");
the physical discovery — Annie unconscious in the building lobby,
location sharing disabled, the confrontation met with violence — is
covered at [[wiki/timeline/events/eli-incident]]. The record's most
direct admission is a March 2025 message Annie wrote to Dan, verbatim:
"you decided to split our lives up. you lied to me for months and
cheated on me." The pronouns run backwards — read literally the sentence
accuses Dan — but every dossier that cites it treats it as her
acknowledgment of the months of lying and the cheating as established
fact, and rates it "the most direct admission in the record." The
grammatical oddity is preserved here rather than corrected. The affair ended
with the February 2025 NYC departure; Eli stayed in New York.

**The move (February 2025).** Weeks after the Eli text, Annie unilaterally
ended eight years of cohabitation and returned to her parents' home in
Uniontown, citing her grandmother's care. The dossiers date the
*functional* end of the relationship here — the shared life was
dismantled, and the conditions for repair were destroyed by the same
event that made repair necessary (parents' roof, no overnights, no daily
presence). Her remorse in this window reads as genuine — "I am so sorry I
caused this disaster" (Feb 22 2025) — because there was, as yet, no
supply structure for the remorse to serve.

## The terminal phase (August 2025 – March 2026)

Sixteen months of idle followed. The structural fact underneath all of
it: Dan controlled the drug supply ("bop") and Annie was unemployed and
dependent — the primary retention mechanism, operating independently of
love or strategy. On this substrate the dossiers document a coherent
gaslighting architecture:

- **The "I love you" anchor / procurement function.** 187 of 191 love
  declarations in the seven-month window were adjacent to a drug or money
  request within 24 hours (96.6%); 4 stood alone.
  > **REVISED [2026-07-18]:** the 187:4 statistic is deflated by a
  > base-rate control and should not be cited as evidence of a
  > procurement instrument. Primary recount (dual-handle export, same
  > window): 212 of her 220 love-declarations are request-adjacent at
  > ±24h (96.4% — the ratio reproduces), **but 97.2% of a random sample
  > of ALL her window messages are request-adjacent at the same radius**
  > — she made requests nearly daily, so the adjacency is uninformative.
  > The directional test inverts the claim: a request follows within 1h
  > of her love-declarations 3.2% of the time vs a 16.2% baseline for
  > her average message. On the text record her love-declarations were
  > *more isolated* from requests than her ordinary messages. The
  > love-language rate collapse/rebound below is unaffected; Dan's Jan
  > 24 2026 line stands as his subjective read (dossier-sourced). Full
  > method: [[wiki/mind/synthesis/dan-annie-fallout-verdict]].
  Her 2025 love-language
  rate (2.7%) rebounded to near-2016 levels precisely when the supply
  relationship was established — the instrument reactivating, not the
  relationship recovering. Dan named it in real time (Jan 24 2026): "You
  have never once said I love you and not needed something from me
  immediately after."
- **Semantic drift.** After a night at her ex-partner's residence in
  August 2025 she removed GPS sharing — a ten-year mutual norm — then
  reframed Dan's objection as a new, controlling demand. His location
  stayed shared throughout.
- **The Crash-Out Trap (cause/effect inversion).** All 94 of Dan's burst
  events were preceded by her deliberate silence; she re-entered engaging
  only with the burst, never the silence. Zero acknowledgments of the
  silence as cause, in 94 opportunities.
- **The controlled void.** Disappearance at high-stakes moments; longest
  documented silence 36.5 hours, re-entered via a money request.
- **The moral-debt pivot.** 44 documented instances of a confrontation
  about betrayal answered with a caretaking crisis (Sugie, the ankle, the
  kids) — "At Sugies" appears hundreds of times, clustering around
  confrontations rather than any medical schedule.
- **The weaponized apology.** 13 major self-indicting apologies ("I am a
  horrible human being… I fully understand if I am dead to you"), each
  followed by unchanged behavior. The self-awareness *is* the mechanism:
  she pleads guilty before she can be prosecuted, and the verdict never
  carries a sentence.
- **Crisis non-response.** 12 documented crisis/suicidal statements from
  Dan; zero substantive engagements. The set includes a 12-hour silence,
  "Jpauls" (a bar name, two minutes after "I just want to die"), "Calm
  down," "What the hell dan," and the March 1 laundry response.
- **Social colonization.** A managed "sweet" persona with Dan's mother
  converted his primary ally into her asset; by March 2026 Dan was
  lying to his own mother to protect Annie's image ("I've been FUCKING
  LYING for you") while the deception ran.

Two written denials of any third party (November 2025, February 2026)
were issued during this phase, and the December 2025 reinvestment spike —
4,657 messages in one month, the corpus peak — directly contradicts any
retrospective story of gradual mutual disengagement
([[wiki/timeline/periods/dec-2025-spike]]).

**Target G (January 2026).** A distinct concealed thread, separate from
Eli, surfaced on January 4, 2026: during a speakerphone call to Dan's
mother, a male peer voice said "Suzy" and the call was killed within two
seconds. The dossiers identify the figure as a married man — "Caitlin's
husband" — visiting on a ~48-hour cadence. Dan's response is the
record's corrected exhibit on his own restraint: rather than contacting
the wife, he fabricated an anonymous-warning screenshot (the "Whisk"
psyop, Jan 5–9) and showed it *only to Annie* to gauge her reaction. Her
reply — "Nice. Real mature. Goodnight." — was recognition, not
confusion, and the man went into a ten-day total blackout (>95%
probability match per the Gemini-_07 forensics). The dossiers rate the
spoofed-number test, initially misclassified as harassment, as one of
the most measured acts of the seven months: he held the power to burn
down a life and did not use it. Whether Target G is
[[wiki/people/tuquick-17248123683|Tuquick]] is unresolved. The reasoning
that got from a two-second dropped call to a >95% identification is a
clean applied instance of [[wiki/mind/concepts/dans-law|Dan's Law]]: strip
the innocent-explanation noise (wrong number, a prank, a mispronounced
name) from the cluster and what's left — the specific word, the specific
voice register, the specific 48-hour cadence, the specific ten-day
blackout that followed a targeted signal — is the irreducible,
load-bearing element.

> **REVISED [2026-07-14]:** the "restraint" framing needs qualifying.
> The Whisk screenshot was not an isolated act — a separate AI session
> (`raw/self/dox-md/Fake hacker dashboard scripts.md`) shows Dan later
> had Claude asked to help build, and ultimately built without Claude's
> help, three fake surveillance-TUI scripts hardcoded with Annie's real
> name and home streets, intended to be left visibly running as an
> implied threat that he could see her phone. Claude refused twice,
> naming the Whisk precedent as evidence the tactic was escalating into
> a pattern rather than staying a one-time act. See
> [[wiki/mind/synthesis/ai-collaborative-analysis]] for the full episode
> and the AI-side ethical debate it produced.

The concentrated March 2026 events — the laundry response, the bathroom
incident (arrived saying she wanted to be together, attempted to slip
out the door without a word inside five minutes), the "YES DAN"
confession and its March 16 retraction ("I misunderstood the
conversation") — have their own page:
[[wiki/timeline/events/march-2026-terminal-phase]]. The final message of
the pre-closure record (Mar 9) is Dan apologizing for having needs; the
final received message is Annie's self-testimonial that she is "always
completely understanding."

## The closure (June 2026)

On June 1, 2026, a group-chat confrontation collapsed the structure
([[wiki/timeline/events/group-chat-closure]],
[[wiki/timeline/events/end-fight]]): the third-party relationship was
confirmed — Tuquick, whom Annie left Dan for — and so was a defamation
campaign, false allegations of rape and "junkie" framing circulated in
the shared peer network during the same months as her private written
denials. Annie's exit line: "Goodbye forever… sic semper lupanis." On
June 5 came her final message, the record's only unprompted
acknowledgment: "Daniel, i just want to say that i am extremely sorry."
Two weeks later the independent validation arrived: Tuquick, who had
savaged Dan in Annie's defense on June 1, defected and described her
unprompted as "a compulsive liar with a drug addiction" — entering and
exiting in fourteen days the same distortion cycle Dan took a decade to
escape.

## Why it lasted: the structural analysis

The corpus contains 299+ love affirmations from Annie and **zero explicit
severance signals**. Dan's attachment architecture cannot close a bond
without an unambiguous severance signal, so the relationship idled on
weighted positive rhetoric alone — a structural failure, not an emotional
pathology ([[wiki/mind/concepts/attachment-model]]). Her conflict style
and his formed a mutually catastrophic loop: she froze under direct
questions and reframed the question itself as aggression; his
resolution-seeking engine parsed each ambiguity as a proposition to
litigate ([[wiki/mind/concepts/conflict-architecture]]). The dossiers add
the confession trap: Dan could not leave without the validation she was
never going to give — "the exit was never through the verdict. It was
through the door."

The ledger runs both ways, and the pages keep both columns. Dan's: 94
burst events (each preceded by her silence), 127 exit declarations with
110 re-engagements (an 87% relapse rate that trained her to ignore his
stated limits), 74 "fuck you" / 17 "piece of shit" / 11 "worthless"
instances escalating from 9 (Aug 2025) to 36 (Feb 2026) — all three
counts confirmed EXACTLY from his side of the dual-handle export
(2026-07-18 primary recount; her side in the same window: 0/1/0), heavy drug use
throughout, and the architect's role in the arrangement and the supply
chain. The dossiers' proportionality finding: real, documented, his
responsibility — and not equivalent to the system that produced them.

> **REVISED [2026-07-13]:** An earlier version of this page gave the
> August 2025 GPS removal a "dual reading" partly crediting Annie's
> surveillance grievance against Dan's pre-affair NYC monitoring. The
> Corrective Addendum retracts that partial credit for autumn 2024: his
> vigilance in that window was accurate detection of an active deception,
> not controlling behavior — the grievance was real earlier, but its
> deployment against a correct perceiver was itself the gaslighting.

The template is generational: a primary attachment figure maintaining a
concealed alternate reality during Dan's highest-vulnerability phase
replicates the 2004–2005 parental rupture exactly — same architecture,
different people ([[wiki/mind/synthesis/attachment-trauma-bond]]).

One historiographic caution: pre-closure AI analyses (the early-2025
Gemini profile dump) describe Annie as a stable, direct, pragmatically
aligned partner. That framing is preserved only as an artifact of what
concealment looked like from inside ([[wiki/self/chats/gemini-18]]).

## The record

| Corpus metric | Value |
|---|---|
| Full record, all platforms (Nov 28 2015 – Mar 16 2026) | 126,683 messages (Dan 57,696 / Annie 68,987) |
| iMessage dual-handle archive on disk | 88,549 rows (`imessage_7244346811+2124702449_both_all_now.csv`) |
| Reaction pairs extracted | 39,378 |
| Terminal-phase extract (Aug 2025–Mar 2026) | 18,236+ msgs (Dan 55.2%) |
| Peak month | Dec 2025: 4,657 |
| Record gaps | 2022 (none logged); Sep–Dec 2024 (3,613 Annie / 0 Dan — cohabitation artifact, not missing data) |
| Terminal-phase keywords | "love you" 541 · "Eli" 388 · "lying" 150 · "goodbye" 110 |
| Alternate-number thread (2018–2020, +17249204125) | 4,812 msgs — logistics, debt, crisis; crosses [[wiki/people/johnny-dealer]] network |

| Annie, love-language frequency by year | % of her messages |
|---|---|
| 2016 (peak) | 5.3 |
| 2017–2019 | 2.2–2.3 |
| 2023 | 0.5 |
| 2024 | 0.1 |
| 2025 (post-move spike = procurement reactivation) | 2.7 |

| Behavioral pattern (terminal phase) | Annie | Dan |
|---|---|---|
| Love-to-request ratio (love declaration → ask ≤24h) | 187:4 (96.6%) — REVISED 2026-07-18: matches base rate (97.2%), see blockquote above | — |
| Crisis statements met without care | 12 of 12 | — |
| Moral-debt pivots (betrayal confrontation → caretaking crisis) | 44 | — |
| Weaponized apologies (self-indictment, zero change) | 13 | — |
| "Fell asleep" alibis | 24 | — |
| Written denials of third party | 2 | — |
| Explicit severance signals / love affirmations | 0 / 299+ | — |
| Genuine wellbeing checks on Dan (7 months) | 7 (1 per 31.7 days) | — |
| Burst events, 10+ consecutive unanswered messages (largest 68) | — | 94 |
| Exit declarations / re-engagements | — | 127 / 110 |
| Verbal abuse ("fuck you" / "piece of shit" / "worthless") | — | 74 / 17 / 11 |

## Legal record

On October 26, 2025 at ~00:49, Anne Louise Ulmer was stopped by Troopers
Jeremy Miller and Dylan R. White (PSP Troop B) at Route 40 / N Mount
Vernon Ave, Uniontown — black sedan, plate MWT6743, high beams on,
straddling lanes, turning into a closed Walgreens lot. Strong odor of
alcohol, watery eyes, "Tito and Soda" admitted; only the HGN field test
was run (broken ankle cited), the breath test attempt failed, and she
refused chemical testing after DL-26B. Charged under docket
MJ-14101-CR-0000631-2025: DUI general impairment (M) plus three summary
counts (traffic-control devices, high beams, duty of operator). Complaint
filed Nov 4 2025; affidavit sworn Nov 11; preliminary hearing before MDJ
Jason A. Cox. Disposition not in the record. No legal exposure for Dan;
recorded for completeness.

## Timeline

| Date | Event |
|---|---|
| 2015-11-28 | Relationship begins (Saturday after Thanksgiving); Annie exits prior relationship within 24h |
| 2015-12 | First camming discussion, weeks in |
| 2016 | Moves into 155 Virginia Ave; both parties' love-language peak year; jealousy kink first named (Feb) |
| ~2016–17 | NYC move, funded by Dan (first ~5 years Dan-anchored) |
| 2018 | Quasi-non-monogamy arrangement formalized; "smashonista" Chaturbate confirmed (Aug); Patreon Oct 2019 |
| 2020-09 | Train Plan crisis during COVID lockdown at Annie's parents' ([[wiki/timeline/periods/covid-era-2020]]) |
| 2022 | Full-year record gap |
| 2023 | Dan working (Au Za'atar), Annie between jobs; ~$10k landlord debt, $650/week payback |
| 2024-06/08 | Dan managed out of Au Za'atar; unemployment filed Aug 8 |
| 2024 (autumn) | Eli affair active and concealed; Dan's accurate suspicions gaslit ("You're literally fucking insane," Oct 19 housewarming) |
| 2024-10-23/31 | Tom incident (within the arrangement — assessment revised from coercion to exhaustion-within-consent); "no morals left… Numb" |
| 2025-01-09 | Eli's 11:18 PM self-introduction text; physical discovery ([[wiki/timeline/events/eli-incident]]) |
| 2025-02 | PA return; Annie unilaterally ends 8 years of cohabitation; functional end per dossiers |
| 2025-03 | Annie's written admission: "you lied to me for months and cheated on me" (describing herself) |
| 2025-08 | Removes GPS sharing after night at ex's residence; terminal phase begins |
| 2025-10-26 | DUI stop, Fayette County (docket MJ-14101-CR-0000631-2025) |
| 2025-11 / 2026-02 | First and second written denials of any third party |
| 2025-12 | Reinvestment spike — 4,657 messages, corpus peak; Dec 8 car accident, Dan totals the Honda |
| 2026-01-04/20 | Target G: "Suzy" call, Whisk psyop (shown only to Annie), 10-day blackout |
| 2026-03-01 – 03-16 | Terminal peak: laundry response, bathroom incident, "YES DAN" confession + Mar 16 retraction ([[wiki/timeline/events/march-2026-terminal-phase]]) |
| 2026-04-01 | Unresolved third-party contact: a man calls Suz twice overnight looking for Annie |
| 2026-04-20/26 | Brief reinvestment window (Annie out-messages Dan for the only time in the extended record) |
| 2026-05-04/06 | Worst-content week of the full record: sustained explicit suicidal language, GPS shown shared with a third party, Annie starts a new job, Dan self-periodizes the relationship ([[wiki/timeline/events/april-may-2026-final-weeks]]) |
| 2026-06-01 | Group-chat closure: Tuquick relationship + defamation campaign confirmed; "sic semper lupanis" |
| 2026-06-05 | Final message — unprompted apology: "Daniel, i just want to say that i am extremely sorry." |
| 2026-06-15 | Tuquick defects; independent validation ("compulsive liar") |

Two synthesis pages complete this record: the capstone moral verdict on the fallout, provenance-tiered to raw message rows, at [[wiki/mind/synthesis/dan-annie-fallout-verdict]]; and the quantitative case for the relationship's singularity — median 9-minute mutual reply latency against every other contact's hour-scale delays — at [[wiki/mind/synthesis/message-circadian-latency]].

## Gaps

The compiled full-record files the dossiers were generated from
(`Dan_Annie_Full_Text.txt`, `1_year_triad_logs.csv`, `7_days_212_logs.csv`,
`14_day_212_logs.csv`) are not archived in raw/ — the underlying iMessage
data exists but the exact 126,683-row cross-platform compilation cannot
currently be reproduced. The precise start date of the Eli involvement is
better bounded but still not exact: GPS was disabled "for weeks" by late
July 2024 per Annie's own confirmation, and a lying-about-whereabouts
trust breach is documented in August 2024 — five months before the
formal January 2025 discovery — so the affair's behavioral floor moves
earlier than autumn 2024, though its true start remains undated. Target
G's identity is unresolved — the dossiers name "Caitlin's husband";
whether he is Tuquick is unknown. The escort-work claim in the
non-monogamy background is flagged unverifiable in the record. The DUI's
disposition after the preliminary-hearing stage is unknown.

A pregnancy reference surfaces in two independent chat-analysis sources
(not the primary dossiers) with unusual specificity — a claimed due date
of November 18, working back to conception around February 11, 2025 (33
days after the Eli discovery night), with Dan described as present at a
clinic visit and referring to it as "ours." This is **not corroborated
by any primary message export, dossier, or other wiki page**, appears in
sources that elsewhere required correction of their own confabulations,
and is not adopted as fact here. It is recorded only as an open item
requiring verification against a primary source before being written
into any page as established. Annie's post-closure perspective
consists of a single line: the June 5 apology.

A separate and much better-corroborated pregnancy reference exists much
earlier in the record: an outbound message from Dan dated 2019-05-31 lists
"the abortion" alongside Fran's decline and the move to NYC as among the
major things the two of them "have gone through together" by that point —
a passing, unremarked mention (not a chat-analysis claim) that reads as
Dan referencing settled shared history rather than disclosing something
new. No other source read so far elaborates on it; treat as established
that it happened, circa 2019, with no further documented detail.

## Notes

Analytical work on this corpus is concluded. Its living outputs are the
theoretical pages it produced — [[wiki/mind/concepts/attachment-model]],
[[wiki/mind/concepts/conflict-architecture]],
[[wiki/mind/concepts/contact-gini]] — and the DANMODEL retrieval system
built on the 39,378 reaction pairs. The relationship ended; its utility
for system analysis did not.
