---
domain: people
page_type: entity
status: closed
date_created: 2026-06-23
date_modified: 2026-07-14
date_range_start: 2019-03-27
date_range_end: 2020-01-12
sources: ["raw/self/message-csv/MASTER_MESSAGES_DB_DUMP.csv"]
related: ["wiki/people/del", "wiki/people/menore", "wiki/self/message-corpora/master-message-dump"]
tags: [addiction-recovery, nyc-era, digital-footprint]
knowledge: mixed
infobox:
  name: "Clyde"
  relationship_to_dan: unknown
  location: nyc
  first_contact: 2019-03-27
  known_for: "Clyde was a NYC psychedelics dealer — LSD (150–275ug tabs), DMT (crystal and vape carts), mushrooms, and occasional xana"
---

# Clyde

Clyde was a NYC psychedelics dealer — LSD (150–275ug tabs), DMT (crystal and vape carts), mushrooms, and occasional xanax — who delivered directly to Dan's apartment (307 E 76th Street, apartment 17) over roughly ten months spanning 2019 (`+16469534978`, 125 messages, March 2019 – January 2020, saved under the joke "Socialist" contacts label). The relationship is warm and quality-conscious rather than purely transactional: Clyde asks Dan's age and jokes about vetting him as "not a police officer" at their first meeting, apologizes and offers a discount when a batch of mushrooms gave shakes, and promises "free squares" after a leaky cart.

## The relationship

Pricing is explicit and varies by product: LSD tabs at $15 singles / $10 for 5+, a gram of DMT crystal around $170–260 depending on availability, an eighth of mushrooms for $50. Clyde discusses dosing philosophy unprompted — smoking DMT crystal versus vape carts, potency comparisons between batches — suggesting genuine product knowledge rather than a purely arm's-length dealer relationship. He goes quiet for stretches (out of state trips referenced twice) but always resumes with an apology and a restock update. The thread's most vivid moment is a "liked" message from Clyde quoting Dan's own account of a heavy trip: "those doses were from fucking saturn for fucking real. i made my girlfriend watch a bunch of gaspar noe films when she was half dosed and subsequently she no longer believes in the divinity of Jesus Christ or watches the E! channel" — a specific, dated data point on the intensity of Dan's 2020 psychedelic use.

## Corpus Dimensions

| Metric | Value |
|--------|-------|
| Messages | 125 |
| Date range | 2019-03-27 to 2020-01-12 |
| Direction | Unreliable in this export (marked "Received" throughout) — read as two-way |
| Handle | +16469534978 |

## Related

[[wiki/people/del]] · [[wiki/people/menore]] · [[wiki/self/message-corpora/master-message-dump]]
