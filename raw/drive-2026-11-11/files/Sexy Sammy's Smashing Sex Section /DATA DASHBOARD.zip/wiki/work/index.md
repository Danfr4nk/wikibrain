---
domain: work
page_type: summary
status: stable
date_created: 2026-07-11
date_modified: 2026-07-13
sources: []
related: []
---

# work — index

Career and business history, plus the tech projects.

- [[wiki/work/au-zaatar]] — Au Za'atar (East Village, ~2021–2024): the 41-month restaurant job, the Night Class alibi, the STORYTIME post-mortems. Closed.
- [[wiki/work/bfs-foods]] — BFS Foods (Uniontown, 2026): the drawer dispute, the cast, the termination, the never-escalated legal posture. Closed.
- [[wiki/work/fastly-fsly]] — Fastly (FSLY): the edge-CDN tip from Jerad that opened the 2020–2021 market era; the momentum-trading lesson. Closed position.
- [[wiki/work/nemacolin-caddying]] — Nemacolin/Laurel Valley/Pikewood National caddying (Apr 2016–Nov 2019): the looper hierarchy, day-trip call-ups. Closed.

## tech/grok-build

- [[wiki/work/tech/grok-build/overview]] — Grok Build refers to custom agentic / subagent workflows using Grok (xAI) as cognitive prosthetic,…

## tech/imessage-tooling

- [[wiki/work/tech/imessage-tooling/overview]] — Tooling stack for extracting, exporting, and analyzing iMessage/SMS from `~/Library/Messages/chat.db`…

## tech/max-framework

- [[wiki/work/tech/max-framework/overview]] — MAX is the adversarial, output-facing engine. CATO is the forensic exocortex / input-side bootloader for…
