---
domain: work
page_type: event
title: "BFS Foods (2026): Job, Drawer Dispute, Termination"
status: closed
knowledge: mixed
date_created: 2026-07-13
date_modified: 2026-07-19
sources:
  - raw/legal/bfs-dispute/BFS_BOOTLOADER_v2.md
  - raw/legal/bfs-dispute/BFS Anita Quagmire strategy and legal exposure.md
  - "raw/self/dox-md/Drawer shortage dispute with assistant manager.md"
  - "raw/self/dox-md/Cash register shortage explanation.md"
  - "raw/self/dox-md/Little Caesars retaliation timing concerns.md"
  - raw/self/context-core/CONTEXT_CORE_EXPANDED.md
related:
  - wiki/people/brandon-hill
  - wiki/people/anita
  - wiki/people/kim
  - wiki/people/timmy
  - wiki/people/marty-martin
  - wiki/people/maddox
  - wiki/people/tom
  - wiki/self/context-core
  - wiki/mind/synthesis/vertical-authority-skepticism
  - wiki/timeline/periods/2025-collapse
  - wiki/mind/concepts/institutional-out
  - wiki/mind/concepts/dans-law
tags: [addiction-recovery, career, uniontown-era, financial-stress]
connections:
  - page: wiki/mind/concepts/dans-law
    type: evidences
    claim: "The drawer dispute is Dan's Law's cleanest low-stakes application: the missing paper trail read as the demand's feature, and the do-not-validate-by-paying conclusion followed from the stripped signal."
  - page: wiki/mind/concepts/institutional-out
    type: parallels
    claim: "The BFS posture and the pre-installed out share one game-theoretic instinct — engage the institution only through mechanisms it cannot verify or contest — run from opposite sides of the ledger."
  - page: wiki/mind/synthesis/vertical-authority-skepticism
    type: evidences
    claim: "The drawer dispute is the micro-scale exhibit of the vertical-skepticism architecture: an unverified claim from above, backed by social pressure rather than records, met with procedural analysis and refusal."
  - page: wiki/people/tom
    type: caused-by
    claim: "The entire incident cascade traces upstream to Tom's mid-May 2026 supply failure — the withdrawal it caused is what impaired the shift the drawer variance was then pinned to."
  - page: wiki/mind/concepts/dans-law
    type: instantiates
    claim: "The three-hypotheses-held-open method (Brandon's error / soft skim / invented number) with the no-paper-trail fact isolated as the real signal is Dan's Law run at gas-station scale."
  - page: wiki/mind/synthesis/supply-network
    type: caused-by
    claim: "The job's end is the supply network's fragility propagating into employment: the three-burns-in-four-days sourcing cascade left Dan working the pinned shift in withdrawal — single-node supply failure converted directly into job loss."
  - page: wiki/people/anita
    type: co-occurs
    claim: "Anita is the GM who originated the $50 claim and controls the levers (deposit, schedule, discipline); the dispute is the setting where her backward-narrative pattern is documented."
---

# BFS Foods (2026)

Dan worked as a gas-station cashier at BFS Foods — a Bruceton Farm
Service convenience store paired with a company-owned Little Caesars in
the same building — in Uniontown for roughly a month, from late April
2026 until his hours were cut to nothing following a disputed **$50
drawer shortage** in mid-May. The day after a Sunday shift whose CSR
closing report showed "nothing over or under," assistant manager
[[wiki/people/brandon-hill|Brandon Hill]] pulled him aside: "your drawer
was $50 short last night — I paid it out of my own pocket, you owe me…
that's money that would go to food for my daughter." Dan refused to pay
the off-books demand or sign the write-up; his scheduled hours dropped
from 36 to 7 the same day, and the job effectively ended. The dispute
never became a formal legal action — the documented posture was refusal,
evidence preservation, and a planned exit via a Little Caesars transfer
arranged through [[wiki/people/kim]]. Context-core records it flatly:
"BFS termination (cash-variance dispute); Little Caesars transfer via Kim
as the exit."

What makes the episode worth a full page is not the $50. It is that Dan
worked the whole problem, in real time and in opiate withdrawal, as a
forensic reconstruction — and that reconstruction turned an alleged
personal debt into a documented map of a store where the reconciliation
document is decorative, a manager confabulates causes she never traced,
and the actual money loss came from a POS fraud vector Dan diagnosed from
first principles.

## The upstream cause: the supply failure

The incident does not start at the register; it starts with
[[wiki/people/tom]]. Across four days in mid-May 2026 Dan was burned by
three independent suppliers while trying to stay ahead of his Suboxone
supply: Tom promised delivery "after court" in Pittsburgh and then
string-along-failed across Friday, Saturday, and Sunday ("after court,"
"after a nap," "after weed whacking"); a second contact took payment
Sunday night and never delivered; and Dan, cornered, made a desperate
play at his own workplace (below). By the incident shift he had gone
roughly 72+ hours into withdrawal — the impaired state the drawer
variance was then pinned to. Tom's failure is the load-bearing first
domino: had he simply said "I can't" on Friday morning, Dan would have
had time and options to source elsewhere before the impairment cascade
began. The friendship's own collapse is documented on
[[wiki/people/tom]]; here it is the root node of the work crisis.

## The workplace Suboxone attempt

Cornered on the incident shift, Dan approached one of the store's daily
"obvious junkie" customers — a man he describes as visibly strung out,
"hunchbacking and doing the zombie shuffle" — about sourcing Suboxone.
He ran an explicit expected-value calculation before doing it: a ~$35
stake against a perceived 30–40% return probability, positive EV given
how high the utility of a strip was in his state, which he later framed
as "playing a really shitty lottery." Several factors pushed him over
the line — the man came in *every day* (raising the social cost of a
future stiff), was unusually fluent on the specifics (asked whether Dan
wanted "strips or tex," produced believable quantity and chemistry
answers — more articulate on this topic than on anything else Dan had
seen from him), and Dan had already been warming the relationship
(letting him use the store phone against policy, giving him extra cash
for a hotel room, "thinking that would buy some good will").

The tradecraft was real and it is the part he is proud of. He kept any
handoff off-camera, quick, planned in advance — "some real NYC shit that
one gets when they've scored drugs in Washington Square Park at 1am."
More than evasion, he ran **narrative pre-construction**: right before
the ask, he staged a missing-newspaper bit — visibly reacting as if a
paper were gone, then walking out the back with the trash "with purpose"
at the same time the customer left the front — building, in the recorded
behavior itself, a benign explanation for the only correlation a
reviewer could later see (two people exiting contemporaneously through
different doors). He declined the man's offer to leave a backpack as
collateral, specifically because holding physical evidence of a
transaction that never legally happened would be the actual liability.
No product ever materialized — the customer took the ~$35 and never
came back — making him the third burn in four days. Crucially, the man's
own off-baseline behavior (he had earlier come in trying to sell bottles
of vape juice laid out on the counter) meant that when footage was
reviewed, the "sketched-out weirdo" framing was supported by the tape
itself, not just by Dan's account.

## The shift and the claim

The incident shift was a Sunday in mid-May 2026 (the surrounding events
are firmly message-dated: Tom's "need to sell a sub, 20 bucks" on May 9,
Dan's "first paycheck Saturday" and a dreaded sighting of
[[wiki/people/nick-mattie|Nick Mattie]] on May 13, the Pittsburgh court
promise on May 15; the strategy briefing was prepared May 20). Brandon
was the technical closer — he counted his own drawer to $100 just before
Dan took over at 3 PM, worked returned at 10:30 PM to lock up, and
printed the CSR closing report, which he and Dan looked at together. It
read even. Dan's contemporaneous joke, witnessed by Brandon: "they're
laundering money lol." The next morning
[[wiki/people/anita|Anita]] "discovered" the $50 shortage; Brandon
covered it and came to collect from Dan personally.

The core contradiction framed everything after: the contemporaneous CSR
close was clean and jointly witnessed, so the shortage could not have
originated during Dan's sole-operator window. It appeared only the next
day, verbally, with no paper trail on either side — and under any
functioning cash-controls regime a real shortage produces documentation.
Its absence was read as the *feature* of the demand, not an oversight:
off-books payment leaves no recourse in either direction, which is
exactly why an off-books extraction would be structured that way.

## The procedure is the exploit

Dan reconstructed the store's cash procedure and found it structurally
one-sided. The opener inherits a drawer counted "to $100" by the
previous closer with **no independent verification** — and Dan had been
instructed never to use "no-sale" to open the drawer, which is the only
way he could have counted his own starting float. So every shift begins
from an unverified baseline, and the system's only rule is: *last
documented count = the person on the hook.* Any shortage present at open,
created after close, or simply invented is attributable to the last
closer by default.

The tell that the reconciliation itself is decorative: across ~4 weeks
and multiple closers, the CSR printed **$0.00 over/under every single
night**. Real drawers don't reconcile to exactly zero for a month — the
noise floor of human counting alone guarantees variance. A perfect run
of zeros means the report isn't measuring real cash flow (tautological
reconciliation, threshold suppression, or force-balancing). This cuts
against Dan as evidence — "my CSR was clean" is just the document's
default state — but it cuts *harder* against Anita: the same system that
produces "$0.00 every night" is the one now invoked to claim "$50 short."
Whatever produced that number came from some other, unwitnessed process
run by the person demanding payment.

## What actually happened: the gas-lady fraud vector

The real money loss traced to a single transaction Dan handled that
shift, and diagnosing it produced the cluster's sharpest technical
finding. A customer bought Newports and $15 of gas on a card that read
"approved," then returned twice complaining the pump "wasn't working."
Dan reprinted the receipt, confirmed the charge had been approved, and —
with the customer escalating ("MY KIDS ARE IN THE CAR AND THEY'RE HOT") —
chose the least-bad of three options: he used the pump "preset" to
re-apply her $15 so she could get the gas she'd paid for. The actual
problem turned out to be mundane (she hadn't selected a fuel grade), but
by then the transaction had been silently voided in processing.

Working it through, Dan independently identified what he correctly
described as a fraud vector: **prepay drive-off via no-dispense void.**
Because the whole ticket (fuel + Newports) was bundled into one
authorization tied to fuel dispense, lifting the pump handle and
replacing it without pumping reports $0 dispensed, releases the entire
auth, and the charge never settles — the customer keeps the cigarettes
*and* the gas money, for free, with the cashier given no signal any of it
happened. His own summary of the implication: "anyone can just buy a
bunch of shit with their gas and then take the pump off the handle,
replace it and get refunded for their entire order… drive away and get
free whatever." The variance from this event was real but small:
~$15 of fuel plus ~$12.50 of cigarettes walking out on a refunded card.

## The $50 that wasn't quite $50

Two mechanisms plausibly inflate ~$25 of real loss into the claimed $50.
First, at close Dan had a stuck $15 "preset" entry blaring a pump-4 alarm
every five minutes for eight hours (he left it deliberately so a manager
would resolve it at the POS rather than risk voiding it himself); Brandon
cleared it by hitting "total cash" and opening/closing the drawer without
putting cash in — a **phantom tender** that creates a $15 cash-side
expectation with no backing money. Second, Dan's own speech-impediment
theory: Brandon (whom a customer once walked in and asked whether "the
slow one" still worked there) pronounces "fifteen" and "fifty" nearly
identically; Dan wonders whether Brandon reported "a fifteen dollar
thing," Anita heard "fifty," and the number simply propagated. The most
charitable reconstruction — gas $15 + Newports ~$12.50 refunded +
Brandon's $15 phantom ≈ $45, rounded to $50 — is the first version of the
figure that makes internal sense.

Against that reconstruction, Anita's stated cause — "it was the gas,
foodstamps, and lottery" — collapses. **Foodstamps (EBT) cannot make a
cash drawer short at all**: it's a card transaction settled
electronically, no cash moves through the drawer. Lottery and gas are at
least plausible categories but she offered zero transaction-level
evidence for either. Both lottery and EBT are, in fact, the store's
*specifically cataloged* categories with their own receipt trails — the
easy ones to trace to a transaction number — so naming them without a
single pointer is the fingerprint of confabulation, not diagnosis. She
had a number and back-filled categories under it, then reverted to "I
don't know what happened yet."

## The cast

- **[[wiki/people/anita|Anita]] (GM)** — the locus of agency. Originated
  the $50 claim, controls deposits, schedules, and discipline. Her
  backward-narrative pattern is established independently by the Timmy
  precedent (below). The institutional "we are 50 short" became the
  personal "you owe me" once it passed through Brandon — the laundering
  move that converts a store shortage into a private debt.
- **[[wiki/people/brandon-hill|Brandon Hill]] (AM)** — the instrument,
  not the architect. Functionally limited, paid ~$0.50/hr more than Dan
  for 24/7 on-call headache, genuinely believed he'd covered the drawer
  and wanted the money back for his daughter, and refused digital payment
  ("I'm old okay") out of apparent tech-illiteracy rather than laundering
  design. Assessed as salvageable, not malicious.
- **[[wiki/people/kim|Kim]] (Little Caesars manager)** — shared-building
  counterpart on the company-owned pizza side, previously targeted by
  Anita herself, skeptical of her patterns; the planned exit path.
- **[[wiki/people/marty-martin|Marty Martin]]** — the ~6-month coworker
  whose "make the store whole to keep your job" framing named the
  off-books culture; treated as an intelligence asset. His logic —
  eat the loss so corporate never hears — is survival wisdom "from inside
  the cage," and it collapses the moment Dan's hours are cut to nothing:
  "what am I paying to prevent, then?"
- **[[wiki/people/maddox|Maddox]]** — witnessed the May 21 sidewalk
  conversation and volunteered the full Timmy blame-pivot: "You can't do
  that to him if you don't even know what went wrong."

## The Timmy precedent — the pattern template

Two weeks before the drawer dispute, the store held an emergency meeting:
[[wiki/people/timmy|Timmy]], an 18–19-year-old Little Caesars employee,
was banned and "if he's in here you need to call the cops." The real
sequence: Timmy had been playing the store's three slot machines *while
on the clock* at Little Caesars, blocking the regular gamblers (~10 daily
players who feed the machines); the regulars complained; Anita took it to
Kim; Kim pulled the camera footage — which incidentally caught **Anita
selling Timmy a vape while underage**, a licensing liability that nearly
got her fired. She survived, then reportedly kept selling him vapes
anyway. When Dan later declined to sell Timmy nicotine (citing the one
explicit instruction he'd been given, even though Timmy's ID scanned as
valid — a contradiction he flagged honestly to Timmy), Timmy returned
with his mother, who questioned Dan, then warmed to him on realizing he
wasn't messing with her son. The payload: a Little Caesars employee tipped
Dan that Anita had told Timmy that **Kim** reported him — and when Kim
denied it, that **"Daniel"** had. Dan had zero involvement. The Timmy arc
is the template the drawer dispute then instantiates: construct a
narrative backward, run it past someone, see if it sticks.

## Legal posture and strategy (never escalated)

The strategy analysis concluded the labor claim was **inchoate**: under
the Pennsylvania Wage Payment and Collection Law (43 P.S. § 260.3)
employers cannot deduct shortages without written authorization, but no
deduction or completed kickback existed until Dan actually paid — so not
paying was both the defense and the whole game. The retaliation theory
was judged real but narrow: refusing an off-books cash demand is
wage-related protected activity in PA and the same-day 36→7 hours cut is
the textbook retaliation shape, but the protection attaches only to that
act and does not generalize forward — the Little Caesars application Dan
submitted is exit insurance, not legal leverage, and if anything dilutes
the retaliation narrative by supplying an alternative-causation story.
Anita's real exposure — the on-camera vape sale to a minor — was
explicitly *not* to be weaponized, since deploying it would flip Dan's
posture toward extortion and invite symmetric review of his own daily
in-store customer handoffs.

The active levers: preserve the schedule screenshots and the recorded
(legally clean, public-sidewalk) Brandon conversation; demand any
deduction form in writing before signing; pursue partial unemployment
(refusing an illegal demand is not willful misconduct); escalate above
Anita only if at all. The one tactic Dan gravitated to on his own is
worth naming because it recurs across his whole profile: a **"dead man's
switch"** built as a *ritual of veridiction* — a set of deposition-cadence
written questions ("what is the company's procedure for documenting a
shortage and assigning responsibility?"; "did you authorize Brandon to
ask me to pay him $50 personally?") designed so that truth, lie, and
silence are each separately costly, and whose real power is theatrical:
like a polygraph, it works by making the subject believe machinery exists
behind it. His own gloss — "nothing freaks out guilty people like a really
convincing prop or the appearance of a secret weapon" — is the
"when weak, appear strong" principle stated plainly.

Two self-inflicted documentation wounds are logged in the same record and
are characteristic: Dan apologized to Anita in writing for an unverified
shortage, and thanked Brandon in writing for "going out of pocket
immediately for me" — each a written endorsement of the very propositions
he was contesting, driven by the pull toward social-tension resolution
over accuracy. He reframed the thank-you as strategic (performing
gratitude to keep the protection arrangement alive), which is defensible,
but the words still sit there screenshot-able.

## Assessment

The episode is the cleanest small-scale instance of the pattern on
[[wiki/mind/synthesis/vertical-authority-skepticism]]: an unverified
vertical claim backed by social pressure rather than records, met with
procedural analysis and refusal rather than compliance. It is also a
miniature rehearsal of [[wiki/mind/concepts/dans-law|Dan's Law]]'s
deconfounding move — three live hypotheses (Brandon's error, a soft skim,
an invented number) held open simultaneously, with the irreducible fact
(no paper trail existed on either side) isolated as the actual signal.
And it is a case study in the same trait that runs the whole corpus:
under acute stress, in withdrawal, on the worst shift, Dan's response to
being wronged is not to fight or fold but to *reconstruct the machine* —
mapping the POS fraud vector, the decorative reconciliation, and the
mishearing chain with more rigor than the people running the store ever
applied to it.

**Gaps:** exact termination date narrowed to "sometime in May [2026]" per
Dan (2026-07-14), not more precisely dated; final payroll disposition is
still not in the corpus; whether the Little Caesars transfer actually
materialized after June 2026 is undocumented; the true cause of the $50
variance was reconstructed but never confirmed by Anita against an actual
report; whether the store's POS bundles the whole ticket (making the
drive-off vector fully open) or splits fuel from non-fuel tender was never
verified. The roughly month-long tenure is too short for
[[wiki/mind/concepts/institutional-out|the institutional-out protocol]]
(documented over a year-plus at [[wiki/work/au-zaatar]]) to have matured —
no equivalent alibi structure is evident, consistent with that concept
page's own gap note.
