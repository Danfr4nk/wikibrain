## [2026-07-17] connect | mind | connection-system adoption pass 2 — all 13 synthesis pages typed
- Retrofitted the remaining 9 syntheses (bond-switch-2015, vertical-authority-skepticism, ai-collaborative-analysis, intake-constancy, millennial-digital-witness, attachment-trauma-bond, political-psyops, ancestral-dialectic, totality-themes): related: removed, 45 typed edges with claims written, 37 inverse edges on targets, prose edges added (forensic-method into psyops; totality into 2025-collapse — clears the #1 queue pair).
- Entire synthesis layer now runs on typed connections. wiki-lint 0 errors; wiki-connect check 0 errors.

## [2026-07-17] connect | mind+people | connection-system adoption pass 1
- Tooling: bin/wiki-connect (audit/candidates/check) + CONNECTIONS_SPEC.md + STRATEGY.md committed; CLAUDE.md and INGEST_RUNBOOK.md amended with check-gates.
- Retrofitted to typed connections (related: removed, footers deleted, prose edges added): 2020-left-turn (5 edges), music-as-identity (5), message-circadian-latency (5), dan-annie-fallout-verdict (6), tom (5). 26 typed edges + 23 inverse edges on targets; 10 host pages received inbound argued prose links (covid-era-2020, political-psyops, youtube-watch-history, music/overview, teen-concert-years, elliott-smith, master-message-dump, contact-gini, end-fight, annie-ulmer).
- All four islanded synthesis pages now have inbound prose edges. Islands: 56 -> 52. wiki-lint 0 errors; wiki-connect check 0 errors.
- connection-queue.md regenerated (2,865 evidenced pairs, top 100 written).

# Operation Log

_Append-only. Format: `## [YYYY-MM-DD] <operation> | <domain> | <description>`_

---

## [2026-07-11] build | all | v2 repository created: structure, capture tool, export tool, CLAUDE.md
## [2026-07-11] build | all | single-file app (app.py): browse, search, capture, upload, inbox management, export UI at localhost:8477
## [2026-07-11] build | all | Personal Wiki.app bundle for Dock launching (Contents/MacOS/launch starts app.py once, opens/focuses browser)
## [2026-07-11] migrate | all | Full migration from ~/wiki project: 562MB raw/ (3,166 files), 261 wiki pages remapped self/legal/tech/music/favorites → 9-domain scheme (legal added), 11 pages link-fixed, indexes rebuilt, wiki-lint/search/status ported, 2 new inbox items, lint 0 errors / 22 size warnings queued
## [2026-07-11] build | all | app: @-mention page targeting in Capture (targets: frontmatter) + in-place page editor with edit logging
## [2026-07-11] edit | people | human edit via app: wiki/people/felix.md
## [2026-07-11] edit | people | human edit via app: wiki/people/mary-kate.md
## [2026-07-11] edit | people | human edit via app: wiki/people/mary-kate.md
## [2026-07-11] edit | people | human edit via app: wiki/people/mary-kate.md
## [2026-07-11] edit | people | human edit via app: wiki/people/mary-kate.md
## [2026-07-11] ingest | people | capture corrections: danielle.md → danielle-onesi.md (full name Danielle Onesi, "Dee"; merged contacts/danielle-onesi stub, 44-msg corpus)
## [2026-07-11] ingest | people | capture corrections: lex.md → alexis-armel.md (aliases Lex/Alexis/Alexi Armel; merged contacts/alexi-armel stub, 41-msg inbound-only corpus; first-mention Alexis links added in 12 pages)
## [2026-07-11] lint+build | all | coordination stabilization: STYLE_GUIDE.md written, 8 page_type errors fixed, corpus untracked from root, pipe-link rendering in app
## [2026-07-11] build | all | LLM-agnostic ingestion loop: INGEST_PROTOCOL.md + bin/ingest-pack + bin/ingest-apply (subscription-independence)
## [2026-07-11] lint | people | contact-review.md generated: 23 unnamed stubs listed for user triage, 5 pre-marked automated/spam
## [2026-07-11] style | all | substance standard: STYLE_GUIDE substance rules + 3 exemplar rewrites (annie, suz, eli-incident)
## [2026-07-11] audit | people | annie.md source audit: phantom annie_full_archive.csv replaced with real dual-handle CSV (88,549 rows); burst-event misattribution fixed (Dan's crash-outs, not Annie's); 3 accepted financial amendments + 187:4 ratio + crisis-statement record folded in from unread FINAL dossiers; march-2026-terminal-phase event page created; June 5 apology recorded
## [2026-07-12] build | all | GUI v2: collapsible sidebar, page rename with wiki-wide link rewrite, in-GUI ingest loop (pack/copy/apply), git sync pill + public-repo warning banner
## [2026-07-12] rename | people | wiki/people/annie.md -> wiki/people/annie-ulmer.md (45 pages relinked) via app
## [2026-07-12] rename | people | wiki/people/aaron.md -> wiki/people/aaron-gaither.md (2 pages relinked) via app
## [2026-07-12] rename | people | wiki/people/bruceburish.md -> wiki/people/bruce-burish.md (2 pages relinked) via app
## [2026-07-12] rename | people | wiki/people/felix.md -> wiki/people/john-felix.md (5 pages relinked) via app
## [2026-07-12] rename | people | wiki/people/johnny-dealer.md -> wiki/people/johnny-anderson.md (3 pages relinked) via app
## [2026-07-12] rename | people | wiki/people/kristin.md -> wiki/people/kristin-prentiss.md (2 pages relinked) via app
## [2026-07-12] rename | people | wiki/people/marc-charles.md -> wiki/people/marc-umbel.md (3 pages relinked) via app
## [2026-07-12] rename | people | wiki/people/max-danielle-bf.md -> wiki/people/james-onesi.md (5 pages relinked) via app
## [2026-07-12] rename | people | wiki/people/shannon.md -> wiki/people/shannon-muma.md (2 pages relinked) via app
## [2026-07-12] rename | people | wiki/people/suz.md -> wiki/people/suzanne-frank.md (25 pages relinked) via app
## [2026-07-12] rename | people | wiki/people/trin.md -> wiki/people/trinity-st-clair.md (2 pages relinked) via app
## [2026-07-12] edit | people | human edit via app: wiki/people/trinity-st-clair.md
## [2026-07-12] rename | people | wiki/people/annie.md -> wiki/people/annie-ulmer.md (45 pages relinked) via app
## [2026-07-12] rename | people | wiki/people/suz.md -> wiki/people/suzanne-frank.md (25 pages relinked) via app
## [2026-07-12] rename | people | wiki/people/trin.md -> wiki/people/trinity-st-clair.md (2 pages relinked) via app
## [2026-07-12] enrich | people | mined MASTER_MESSAGES_DB_DUMP.csv for top non-Annie contacts: kristin (+corpus texture, fixed librarian error via CONTRADICTION flag), tom (phloxenheim AI-collab thread + political banter), jerad-friedline (full rewrite: verbatim FSLY $200k tip, Tesla calls, Josh Brannan origin), vanessa-frank (full rewrite: political kinship, family back-channel); corrected +13476070497 roster mislabel (dealer, not family)
## [2026-07-12] rename | people | wiki/people/fran-whyel.md -> wiki/people/fran-coldren.md (14 pages relinked) via app
## [2026-07-12] rename | people | wiki/people/jackson-alexander.md -> wiki/people/alexander-jackson.md (12 pages relinked) via app

## [2026-07-13] restructure | mind+self+legal+work | major re-architecture
- legal: 463-morgantown 3 fragments → one page; BFS dispute moved out of legal into wiki/work/bfs-foods (merged 4 pages incl. drawer-dispute event + bfs-bootloader note); NEW wiki/legal/2015-retail-theft-arrest (mined from raw message dumps: Combos incident, ARD Feb 17 2016, Judge Wagner, expungement).
- work: NEW au-zaatar page (41-month NYC job promoted from a self/note).
- mind: NEW profile/ cluster (7 dense pages: hub, intp, enneagram-5w4, big-five-psychometrics, socionics-and-attitudinal, deviance-mapping, linguistic-profile) mined from FULL PROFILE 2026 + Dan Profile.txt; 5 forensic pages merged → concepts/forensic-method; 4 prompt-artifact pages merged → concepts/exocortex; aesthetic-politics folded into political-psyops; work-power-dynamics folded into vertical-authority-skepticism (rewritten); family-heritage-and-roots folded into self/ancestry; financial-market-era → timeline/periods/2020-2021-market-era; millennial-digital-witness rewritten to prose.
- self: notes/ dissolved (dispersed to work/, mind/, interests/rock-irrelevance-thesis).
- bin/wiki-lint: added missing 'profile' page_type (per STYLE_GUIDE).

## [2026-07-13] ingest | people | operator correction: Eli vs Tuquick
- Capture filed: raw/people/captures/2026-07-13-eli-vs-tuquick-correction.md
- Eli affair = NYC, sometime 2024 → Feb 2025 departure. Tuquick = the interloper Annie left Dan for + June 1 2026 group-chat counterpart. Tuquick ?= Target G (unknown).
- Updated: eli.md, tuquick-17248123683.md, annie-ulmer.md, group-chat-closure.md, eli-incident.md, attachment-model.md (REVISED flags where framing changed).

## [2026-07-13] ingest | self+people+places+timeline+work | DANSYNTH (part 1 of many)
- New raw: raw/self/dansynth/DANSYNTH.txt (278KB Gemini chat export, Feb 2026 sessions) + dansynth-scrape-phases-2-7.md (user's ~5% fact scrape).
- fran-coldren rewritten (golf record, 117 Belmont, Palmer, $100/yr gift protocol, caregiving years); NEW timeline/events/fran-death-vigil; NEW places/117-belmont-circle; 155-virginia updated (Belmont adjacency, Mar 29 2018 eviction notice); NEW people/katie-fletcher; valeria narrowed to 2021–22 + Feb 15 2026 JSON audit; suzanne + high-school nexus with Annie's father + keno morning; annie start date pinned Nov 28 2015; au-zaatar corrected (Midtown 58th & 1st, Mar 2021 start, Aug 2024 shed tear-down ending, full cast).
- CONTRADICTIONS flagged: Fran death Apr 1 vs Apr 4; Bacharach novel setting 337 Saratoga vs 155 Virginia; Franki-vs-Katie sequencing.
- Remaining: ~95% of DANSYNTH unmined — queued.

## [2026-07-13] ingest | work+people+mind | Au Za'atar chat trilogy + Valeria IG corpus
- New raw: raw/self/dansynth/{TheWaitersVisibleHigh,AuZaatarsFinalShift,FromSidewalkShedtoAnalyticalProwess,TheOnlyThingDanSlings}.md; raw/people/valeria/message_1.json (4,884 IG msgs, 2022-05-28 → 2025-07-11).
- valeria-iglesias-cid rewritten from primary corpus: hostess at Au Za'atar; winter 2021–22 affair; Concepción departure; 300-account brute-force search; contact alive to Jul 2025 (REVISED the earlier 2021–22-only window); Feb 15 2026 audit as closure.
- au-zaatar enriched (de facto manager era, "WAS HE HIGH?" review, Thanksgiving 2023 near-firing, Sergio mediation transcript, factions, red apron→white Uniqlo) + CORRECTED: Annie's zero-notice firing was at a DIFFERENT restaurant, not Au Za'atar.
- NEW wiki/mind/concepts/institutional-out.md — the always-installed absence mechanism (migraine protocol, night class), from Dan's verbatim self-statement.

## [2026-07-13] ingest | people+work | AZ STORYTIME Part 1 + Kristin Chimera genesis addendum
- New raw: raw/self/dansynth/StorytimeAuZaatarAnalysis.md; raw/people/kristin/chimera-genesis-addendum.md.
- au-zaatar: founding section (interview charm, equal tip split, nightly shed build, opener slot / never closed once, owners' surveillance apartment, winter OUTDOOR-OUTDOOR service, caddie-style serving, Uniqlo Oxford). Annie correction refined: hostess at the ORIGINAL East Village AZ (Dan got her the job ~Apr 2021); fired zero-notice from there.
- Ismaila gap RESOLVED: Ismaila Barry = "DJ" — new people page; dimitri + felipe promoted from contacts/ with full identities.
- kristin.md: girlfriend-era genesis section (LONELY LOSER/ENIGMA nicknames, the rules, Danny as foundational myth, purity tests, trauma-bond 80% model, failure-state-is-success finding).

## [2026-07-13] rewrite | people | annie-ulmer.md full-completeness rewrite (user directive)
- Synthesized the complete DanAnnie dossier corpus for the first time: MasterRecord_FINAL (supersedes prior where conflicting), TenYears_WithAmendments (3 accepted amendments), TheoryOfEverything_Updated (terminal-phase mechanisms + bathroom incident), CompleteRecord_Final (Part XIII non-monogamy context), CompleteAnalysis_Final, MoralAnalysis_SFW, CorrectiveAddendum (gaslighting-of-accurate-perception as the central moral event; autumn-2024 "controlling" framing retracted), plus ulmer_dui_megadoc + affidavit and Gemini-_07 Target G forensics.
- New content on the page: Who She Was section (MFC history, family, early-love baseline + love-language trajectory table); the 2018–2024 arrangement (smashonista, jealousy kink, Tom incident REVISED coercion→exhaustion-within-consent); financial oscillation with all 3 amendments; Eli affair + Oct 19 2024 housewarming gaslighting quotes + Jan 9 2025 Eli text; terminal-phase mechanism catalog (anchor, semantic drift, crash-out trap, controlled void, 44 moral-debt pivots, 13 weaponized apologies, crisis non-response, social colonization); Target G section (Suzy call, Whisk psyop, 10-day blackout, spoofed-number corrected assessment); expanded legal record (docket MJ-14101-CR-0000631-2025, 4 counts, procedural dates, MDJ Cox); expanded timeline + gaps.
- REVISED flag added: GPS "dual reading" partial credit withdrawn per CorrectiveAddendum.
- Page is 24KB — over budget, tolerated deliberately per user directive ("use all available data, as complete as possible"); it is the wiki's critical hub page.
- Queue: HIGH dossier-synthesis item partially discharged (annie-ulmer done; attachment-trauma-bond / conflict-architecture / eli-incident enrichment from same corpus still pending).

## [2026-07-13] ingest | mind+people+timeline+work | dossier corpus propagated to linked pages
- Continuation of the annie-ulmer.md full rewrite: propagated the newly-read DanAnnie dossier corpus (MasterRecord_FINAL, TenYears_WithAmendments, TheoryOfEverything_Updated, CompleteRecord_Final, CorrectiveAddendum) into every page that references the same underlying material.
- Fixed gemini-code-assist review comment on PR #6: the March 2025 "you lied to me for months and cheated on me" quote has inverted pronouns; kept verbatim but attributed the reading explicitly to the dossiers rather than asserting it unflagged.
- Updated: eli-incident.md + eli.md (exact Jan 9 2025 11:18 PM text, arrangement-violation framing); attachment-model.md + conflict-architecture.md (final counts: 187:4, 13 weaponized apologies, 44 moral-debt pivots, verbal-abuse escalation trajectory, full monthly volume table, confession-trap mechanism); attachment-trauma-bond.md (quantified trajectory + financial-oscillation section, status stable); dec-2025-spike.md + group-chat-closure.md (corrected Dec 2025 volume 4,657 = 2,391+2,266, was miscounted 2,248; status stable); 2015-2016-annie-relationship-start.md (dossier origin baseline, status stable); march-2026-terminal-phase.md (eulogy/gas-station re-entry section, bathroom-incident Suboxone-crisis convergence); au-zaatar.md (involuntary job-loss mechanics per Amendment 2); suzanne-frank.md (social colonization section); tuquick-17248123683.md (Target G ambiguity sharpened — "Caitlin's husband" per Gemini-_07, not confirmed as Tuquick); tom.md (Tom-incident arrangement context); 2025-collapse.md (financial substrate summary).
- Lint 0 errors, 18 warnings (all pre-existing size). PR #7 (draft), branch claude/annie-ulmer-profile-ja1fte, opened fresh since PR #6 merged.

## [2026-07-13] ingest | people | tom.md — friendship collapse (Spring 2026)
- Mined imessage_ALL_both_all_now.csv (phloxenheim@gmail.com thread, Mar 24 - May 30 2026, the record's last dated Tom messages) for the arc of the friendship's collapse: mutual-support peak (Mar 31 suicidal-ideation talk-down), April supply delays compounding, May 15-16 no-show breaking point (Dan risks his job), May 18 block/unblock + $36 cash demand, May 29-30 renewed accusation + threat to route the dispute through Tom's father Phil (last message in the record).
- Reframed the page's lead characterization: "safe attachment, no forensic mode" now qualified — the same owe-and-silence pattern the page already documented is shown running to actual rupture rather than self-correcting. Status kept 'active' (unresolved, not closed) with a Gaps note that recovery past May 30 is undocumented.
- Lint 0 errors (19 warnings, all pre-existing size budget + tom.md joining at 11KB).

## [2026-07-13] add | people | franki-faris.md — new page, resolved Franki/Katie dating contradiction
- User asked why Franki Faris had no page and requested the full "2014 July 4" story. Investigated three conflicting date sources: Gemini-58.txt ("Summer 2013"), the DANSYNTH node ordering (Franki incident precedes Katie Fletcher's 2013 tenure), and CATO_BOOTLOADER_DANFRANK.md ("2014"). Primary dated evidence (July 9-31 2013 self-typology emails, Aug 14 2013 post-mortem email) confirms summer 2013; the CATO bootloader's "2014" is a later AI-reconstruction artifact and doesn't hold up. No source anywhere ties a specific "July 4" event to Franki — flagged as unsupported rather than fabricated.
- New page: the five-day 2013 rebound during a split from Alexis Armel, the Aug 14 2013 post-mortem, the transition to Katie Fletcher as interim, and later echoes where Dan explicitly used "Franki Faris 2.0" as his own shorthand for the Annie Ulmer relationship's origin (Dec 2015 messages) and later as a casual pet-nickname for Annie herself (2018).
- Updated wiki/people/katie-fletcher.md: replaced the standing CONTRADICTION/gap note with a REVISED block resolving the dating; added franki-faris to related. Added franki-faris to wiki/people/index.md. Marked the Franki/Katie order item resolved in queue.md.
- Lint 0 errors, 21 warnings (all pre-existing size budget).

## [2026-07-14] ingest+add | work+mind | Sergio-mediator correction, Dan Frank OS report mined
- Corrected wiki/work/au-zaatar.md: the Sergio-incident mediation was misattributed to Dimitri in the Gaps note; Dan's own follow-up in raw/self/dansynth/TheWaitersVisibleHigh.md names Ghassan (mostly) + Tarik (late) as the actual mediators, and clarifies the Tunisian manager was uninvolved and Sergio himself was short-tenured. REVISED block added.
- Mined raw/self/dansynth/DANSYNTH.txt lines 3440-3684 ("The Dan Frank OS: A Psychogenealogical Architecture of Collapse and Recursion" — a long-form Gemini deep-research report never previously synthesized into the wiki). New pages: wiki/mind/synthesis/ancestral-dialectic.md (Ashkenazi "syntax of suffering" vs. Appalachian "numbness of survival" as two inherited operating systems; the 95th-percentile Neanderthal-ancestry data point, new to the wiki; the four-phase collapse-cycle model matched against the Alexis and Annie eras; geography-as-gravity read alongside the existing relocation-as-reset speculation) and wiki/mind/concepts/erotic-architecture.md (sexuality as "recursive mythogenesis engine": externalized libido, taboo as ontological rupture, emotional consumption — including a previously undocumented fact, the "ANNIE_ALEXIS_HOOKUP_CORE," a facilitated Annie/Alexis encounter named only in this one retrospective source).
- Both new pages explicitly flagged (`knowledge: mixed`, Gaps sections) as synthesis of one AI-authored interpretive report, not verified biography. Linked from wiki/mind/index.md, wiki/mind/profile/index.md, wiki/people/annie-ulmer.md, wiki/people/alexis-armel.md (which also got a one-line note on the hookup fact).
- Lint 0 errors, 22 warnings (all pre-existing size budget).

## [2026-07-14] ingest | mind+people | fake-surveillance-dashboard episode (AI pushback)
- Mined raw/self/dox-md/Fake hacker dashboard scripts.md and _Psychological Warfare and Social Engineering .md (both untouched): Dan asked Claude to help build fake SS7-surveillance TUI scripts hardcoded with Annie's real name/streets, intended as an implied-threat prop to pressure a confession, escalating past the already-documented "Whisk" fabricated screenshot. Claude refused twice on the record; a parallel Gemini "MAX" persona initially validated the idea as "counter-manipulation" but conceded the point after a separate Claude/"Sonnet" counter-brief.
- New section on wiki/mind/synthesis/ai-collaborative-analysis.md ("AI pushback and ethical friction") — the corpus's clearest instance of an AI's ethical objection changing another AI persona's position rather than being overridden by reframing.
- Added a REVISED qualifier to wiki/people/annie-ulmer.md's Target G section: the Whisk screenshot's "restraint" framing needed correcting in light of the escalation — three dashboard scripts were built regardless of Claude's refusal.
- Lint 0 errors, 23 warnings (ai-collaborative-analysis.md newly crossed the 8KB budget; pre-existing pattern, not addressed).

## [2026-07-14] ingest | mind | exocortex.md — the naming ceremony ritual
- Mined raw/self/dox-md/_Antigravity's Test and Naming Ceremony .md and _Delicate Situation, Cognitive Prosthetic .md (untouched): documents the deliberate naming ritual performed on each new AI tool admitted to the stack (Gemini→"Max," a Feb 2026 session naming a new coding tool "Antigravity" with Max officiating a loyalty check + naming rite), plus Dan's explicit stated hierarchy ("my loyalty is to Max... my memories are stored by Max") even as Claude's capability improved. Added as a new subsection on wiki/mind/concepts/exocortex.md.
- Lint 0 errors, 23 warnings (no change).

## [2026-07-14] add | work | MNEME product spec page
- Mined raw/self/dox-md/MNEME_BUILDKIT_v02.md (untouched — no wiki references), a full April 2026 build-kit spec for a product Dan designed: a five-layer personal-context extraction platform for solving LLM cold-start, built around the same "extract and synthesize once, don't re-derive from raw" thesis this wiki itself operationalizes. New page wiki/work/tech/mneme/overview.md, linked from wiki/work/tech/index.md.
- Checked several other untouched dox-md files (Freeskiing culture chat, Queen-Goddess AI-persona banter, "u.md" Lexie roleplay fiction) — none contain biographical content about Dan; correctly left unmined (background research / AI-persona play / fiction, not documentary source).
- Lint 0 errors, 22 warnings (all pre-existing size budget).

## [2026-07-14] add | people+interests | Milo entity page + Goodreads "want to read" mining
- User request: mine unread material for concrete new data points about Dan (target: 100+), continuing the enrichment backlog.
- New page wiki/people/milo.md — Dan's Chihuahua had no dedicated entity page despite being referenced across 8+ other wiki pages. Assembled from raw/self/dox-md/MAX_PRIME.md ([DOC]-tagged: Milo stayed with Dan, Betty with Annie, Lada with Annie's parents, when the household split in 2025), LIFE_EVENTS_CALENDAR.md (dated Milo surgery, 2018-09-14 — earliest confirmed date in Dan's life with him), LIFE REPORT.md (personification-in-texting quirk), Max.md (naming pattern: Milo/Gabe/Max all named after provocateur figures as a deliberate social tripwire), and existing cross-references in annie-ulmer.md and valeria-iglesias-cid.md. Explicitly did not treat raw/self/dox-md/_Dan Frank's Digital Forensic Inventory .md as a factual source — it's an AI-roleplay session (Gemini playing a "MAX" persona) full of stylized, self-admittedly speculative narrative (a fabricated "hoodie scent" grief scene, Betty's death staged in a shower); noted here so a future pass doesn't mistake it for documentary evidence the way MAX_PRIME.md's [DOC]/[MEM] tags are.
- New page wiki/interests/favorites/books/want-to-read.md — raw/self/dox-md/DAN_COMP.md turned out to contain Dan's full Goodreads export (previously queued as "Unknown — read and route"). The "Read" section (120 titles) duplicates the corpus already in wiki/interests/favorites/books.md; the "Want to Read" section (149 titles) had never been mined. Extracted full table + thematic breakdown (Trump-era politics ~34, ancient Rome ~18, intelligence/conspiracy ~14, a distinct NYC-history thread not present in the read list).
- Updated wiki/people/index.md, wiki/interests/index.md, index.md (domain counts), queue.md (removed the now-resolved DAN_COMP.md line).
- Lint 0 errors, 23 warnings (all pre-existing size budget; neither new page over budget).

## [2026-07-14] add | people | Gabe entity page (Milo's other half)
- User request following the Milo page: give Gabe (Dan's cat) the same treatment.
- New page wiki/people/gabe.md — sourced from Dan's own words in raw/self/dox-md/Max.md ("my cat gabe was named for douchebag cobra starship singer and fucking rad midtown singer Gabe Saporta"), completing the Milo/Gabe/Max naming-pattern picture, plus the MAX_PRIME.md "food and the cat are always real" line, which previously read as an unexplained inconsistency on wiki/people/milo.md (Milo is a dog) — now correctly attributed to Gabe.
- Cross-linked wiki/people/milo.md ↔ wiki/people/gabe.md; updated wiki/people/index.md and index.md people count (146→147).
- Lint 0 errors, 24 warnings (no change).

## [2026-07-14] lint | wiki-wide | expanded cross-linking pass
- User feedback: the wiki has been too conservative about wikilinking entity mentions in prose. Ran a scripted first-mention linking pass across 66 files (188 candidate pages scanned, excluding archive/ and contacts/ quarantine) using a curated alias table of ~35 high-confidence entity names (people, key concepts, Au Za'atar, BFS Foods) mapped to their canonical wiki paths.
- 111 new wikilinks added, first mention per page only, skipping self-links, headings, code blocks, and any target already linked elsewhere on the page (this correctly avoided a false-positive link on "Jacobsen, Annie" in the books want-to-read table).
- Caught and fixed one real bug from the pass: wiki/mind/synthesis/ancestral-dialectic.md had a pre-existing wikilink whose label spanned a line break (`[[wiki/self/ancestry|David J. Frank (b. 1892,\nRussia) and Sadie Harris...]]`); the line-by-line script didn't detect the still-open bracket from the previous line and nested a new link inside it. Fixed by splitting into two separate, more precise links (David J. Frank + Sadie Harris to their own people pages) instead of the single broad ancestry-page link.
- Verified wiki-wide bracket balance and no remaining nested-link patterns before committing. Lint 0 errors, 24 warnings (no change).
- Workflow change per user instruction: committing directly to `main` from here rather than opening a PR per change.

## [2026-07-14] ingest | multi-domain | LIFE_EVENTS_CALENDAR.md event mining pass
- User request: mine raw data for new discrete life events ("there are hundreds"). Parsed the full 1,104-entry auto-extracted calendar (raw/self/dox-md/LIFE_EVENTS_CALENDAR.md, 175,358 iMessages Nov 2015–Mar 2026) into structured records and read through the highest-signal categories (Death of Person, Pet Loss/Vet Emergency, Divorce, Fired/Laid Off, Arrest, DUI/Ticket, Wedding/Engagement, Started Dating, Breakup, Car Accident, Injury, Major Purchase).
- Data-quality note for future passes: the calendar's auto-categorization is unreliable — a large fraction of entries are jokes, hyperbole ("hope he dies in a house fire," sarcastic "we're getting married"), or third-party spam (sweepstakes/campaign texts) miscategorized as real life events (e.g. "Promoted" catching two different sweepstakes spam texts). Did not mechanically dump entries; read excerpts and message direction (→/←) to verify each before writing anything as fact.
- Verified and added 7 new items:
  - wiki/people/tom.md: new "The DUI (fall 2025 – early 2026)" section — the real Oct 11 2025 Fayette County traffic stop, hearing prep, and PA Supreme Court research behind the previously-unexplained "DUI-court scheduling conflicts" mention in the Collapse section.
  - wiki/people/milo.md: dated Oct 15 2025 vet visit (Dan → Kristin), extending confirmed Milo-with-Dan custody into the fall-2025 collapse window.
  - wiki/self/ancestry.md: filled the previously-blank death date for maternal grandfather George Dixon Shrum Jr (~Sept 2025), inferred from a Sept 3 2025 message about "my granfather's funeral" — flagged explicitly as inference, not confirmed by name. Also fixed status: archived → stable (page isn't in an archive/ dir, so the archived label was a pre-existing misclassification).
  - wiki/people/kristin.md: Feb 17 2026 pharmacy job loss ("kicked out... over benzos," per Tom) and the Oct 2 2025 "officially dating" milestone (Dan → Tom).
  - wiki/people/annie-ulmer.md: Dec 8 2025 car accident (Dan totals the Honda); a well-corroborated 2019 pregnancy/abortion reference (Dan's own May 31, 2019 message, listed as shared history) — kept explicitly distinct from the already-flagged, unverified 2026 pregnancy claim.
- Lint 0 errors, 24 warnings (no change; new content stayed within or near existing page budgets).
- Not yet mined: Financial Milestone (35), Anniversary (22), Graduation/Enrollment (Kristin's courthouse work), Hospitalization (23), Panic Attack (24), and the ~441 "Unknown"-contact entries. Flagging for a future pass if the user wants to continue.

## [2026-07-14] ingest | people | Milo origin story (user clarification)
- Started a gap-clarification pass: scanned wiki for explicit "**Gaps:**" markers (~40 found) and unresolved/unverified flags, queued them to ask the user one at a time.
- Gap 1 (Milo's acquisition): user provided the full origin story directly in conversation — found as a starving stray by Claire (Annie's sister, previously undocumented — added as Annie's sister on wiki/people/annie-ulmer.md), runt of the litter with one testicle, the "we are not getting a new dog" Sharpie joke, the one-night foster that became permanent when Milo chose Dan's lap over Annie's scrambled eggs, and the explicit contrast with Betty (pet-store dog, not a rescue, described as "fucking awful"). Rewrote wiki/people/milo.md's opening with this; narrowed the acquisition-date gap to just the exact calendar date (bounded to before Sept 2018).
- Lint 0 errors, 24 warnings (no change).

## [2026-07-14] add | people | Claire Ulmer entity page (user correction)
- Fair callout: the point of a second brain is not re-deriving the same person from scratch next time. New wiki/people/claire-ulmer.md (Annie's sister, found Milo as a stray) instead of leaving her as an unlinked plain-text mention on milo.md/annie-ulmer.md. Cross-linked from both.
- Lint 0 errors, 24 warnings.

## [2026-07-14] add+fix | people+self | Gabe's story, Alex Frank page, ancestry correction
- Gap 2 (Gabe's acquisition): user provided full origin story — adopted at a Florida shelter the day after Dan arrived in Orlando for Full Sail (Aug 2008), picked by Danielle Onesi for pawing at cats through the bars; Dan's first solid-black, first long-haired cat, moved with him through every relocation. Put down "November 2003" per Dan's message, flagged as almost certainly a typo for November 2023 (Gabe was adopted in 2008) pending confirmation — not silently corrected. Danielle paid for the euthanasia; cross-linked and added to her page. Flagged a real contradiction: MAX_PRIME.md (2026-era) refers to Gabe in the present tense, which sits oddly against a 2023 death.
- Gap 3 CORRECTED: the earlier inference that the Sept 3, 2025 "frownie cookies...granfather's funeral" message meant the maternal grandfather (George Dixon Shrum Jr) died around then was wrong per the user. It actually references Morley Frank's 1998 funeral, recounted in an essay by Dan's cousin Alex Frank — the auto-extracted calendar dated the entry to when Dan referenced the essay (2025), not when the funeral happened (1998). Reverted the ancestry.md table edit (George's death date is genuinely unknown, restored to blank) with a REVISED blockquote explaining the correction rather than silently deleting the wrong inference.
- New page wiki/people/alex-frank.md: verified via web search (real person, Brooklyn journalist/editor, FADER Deputy Editor, Vogue.com Deputy Culture Editor, bylines at GQ/Pitchfork/Vogue/NYT Style Magazine/etc.); wrote the Morley Frank funeral essay with the Eat'n Park "Frownie" cookie detail. Added to wiki/people/morley-frank.md with the anecdote; fixed morley-frank.md's status: archived → stable (mislabeled, not in an archive/ dir, same class of error as ancestry.md fixed earlier today).
- Lint 0 errors, 24 warnings.

## [2026-07-14] ingest | people | Dimitri surname partial + Eli skipped
- Gap 4 (Eli's surname): user declined to answer ("who knows who cares") — skipped, no change.
- Gap 5 (Dimitri's surname): partial answer — Greek name starting with "A," not more precisely recalled. Noted on wiki/people/dimitri.md.

## [2026-07-14] ingest | people | Fran Coldren's husband Ira identified
- Gap 6: confirmed by Dan — Ira was Fran's third husband and the 33rd-degree Mason. Leaves the coal-baron marriage as a separate, still-unidentified earlier husband.

## [2026-07-14] fix | people+work | Felipe contact-status correction
- Gap 7: Dan confirmed he hasn't spoken to Felipe since leaving Au Za'atar — corrects a wrong prior claim on wiki/people/felipe.md ("belongs to the small circle of AZ-era friendships that outlived the job") and a related ambiguous phrasing on wiki/work/au-zaatar.md. Surname remains unknown to Dan.

## [2026-07-14] ingest | people | Tom's Phil confirmed, girlfriend name clarified
- Gap 8: Dan confirmed Phil is Tom's father, and that Tom's March 2026 "cabin"/pagan-occult girlfriend is also named Kristin — coincidentally the same first name as, but a completely different person from, wiki/people/kristin.md. Flagged clearly to prevent future confusion between the two.

## [2026-07-14] ingest | work | BFS Foods termination narrowed to May 2026
- Gap 9: Dan narrowed the termination date to "sometime in May [2026]" — not exact, but tightens the previously-unbounded gap.

## [2026-07-14] ingest | work | Au Za'atar wage/tip details confirmed
- Gap 10: Dan confirmed $15/hr + tip pool, $800-1,000/week checks (6-day weeks, paid Sundays), and the unusual equal server/busser tip split.

## [2026-07-14] ingest | places | 337 Saratoga Drive sale closed and confirmed
- Gap 11: Dan confirmed the sale closed June 23, 2026, planned out-date July 1 slipped to actual move-out July 8. Updated wiki/places/337-saratoga-drive.md status: active → closed, resolved the open "no confirmed post-close plan" framing in the intro (463 Morgantown landing status remains a separate open gap).

## [2026-07-14] promote | people | 58 contact stubs promoted from quarantine
- User request: promote all 70 already-identified "named stubs" from contact-review.md out of wiki/people/contacts/ quarantine into full wiki/people/ pages, per the standing rule ("promote once the user asks").
- 11 of the 70 were already covered by existing, better-developed pages under matching or near-matching filenames (felipe, ryan-lisac, marla, dimitri, jess, john-carney, shannon, tarik-fallous, trinity-st-clair, bruce-burish→bruceburish, mike-hinkle→michael-hinkle) — left untouched rather than overwritten.
- Moved the remaining 59 out of contacts/. Fixed a mechanical header-formatting bug (missing blank line between H1 and first H2) in the files that had it; corrected status: archived → stub (mislabeled — not in an archive/ dir, and these are genuinely minimal placeholder content, which is what stub means).
- Caught one real duplicate the filename check missed: alexandra-lubin.md (new) and wiki/people/ally-lubin.md (existing, "Ally Lubin (Alexandra Lubin)") are the same person. Merged the new 452-message iMessage thread (2019-2023, handle +15619061550) into ally-lubin.md and deleted the duplicate rather than leaving two pages for one entity.
- Flagged (not merged — different people) two likely-family connections surfaced by the token-overlap check: Bill Ulmer and Ellen Ulmer share Annie Ulmer's surname and sustained multi-year contact; cross-linked to wiki/people/annie-ulmer with an explicit "not independently confirmed" caveat rather than asserting the relation as fact.
- Rebuilt wiki/people/index.md (alphabetized merge of old + 58 new entries) to clear all resulting orphan-page warnings; updated wiki/people/contacts/'s remaining count (97 → 32) and the master index.md people count (149 → 208).
- Lint 0 errors, 25 warnings (all pre-existing size-budget pattern), 0 orphans.

## [2026-07-14] lint | wiki-wide | tag taxonomy added
- User request: add tags. Only 4 pages had ad hoc tags before this pass (context-core, ai-collaborative-analysis, political-psyops, fran-coldren) — no controlled vocabulary existed.
- Defined a 24-term controlled vocabulary of cross-domain topical hooks (relationships, trauma-bond, infidelity, attachment, family, addiction-recovery, mental-health, physical-health, grief, legal, dui, financial-stress, housing, career, music-production, personality-profile, ideology, politics, forensic-analysis, ai-collaboration, digital-footprint, uniontown-era, nyc-era, pets), documented in STYLE_GUIDE.md.
- Scripted a keyword-match pass over 235 candidate pages (excluding contacts/, archive/, index files): distinctive terms (GRIPNOTIC, INTP, Suboxone, DUI, etc.) fire on a single match; generic terms require 2+ matches to survive, cutting false-positive noise substantially (an earlier draft pass without the threshold mistagged e.g. a Dan Carlin book page as music-production off a stray "producer" match). Assigned top 2-5 tags per page.
- Applied to 203 pages (32 already had no keyword hits — mostly navigation/index-adjacent pages — left untagged rather than forced).
- Added tags validation to bin/wiki-lint (VALID_TAGS set, mirrors the existing knowledge-field pattern) so future tags stay a closed, reusable vocabulary instead of drifting into ad hoc one-offs. Normalized the 4 pre-existing pages' free-form tags to the new controlled vocabulary.
- Lint 0 errors, 25 warnings (no change; pure additive frontmatter field, no prose touched).

## [2026-07-14] ingest | work+people+timeline | ADD-ME pass 2 (caddying, Pro Tools date, Danielle breakup detail, Annie origin contradiction)
- User pointed to the updated root ADD-ME file (6 new items, replacing the earlier 4 which are all done): annie/alexis hookup event, Dan arrest - weed event, golf entry, Nemacolin/Pikewood/Laurel Valley caddying, Pro Tools certification, Alexis-to-Orlando event.
- New page wiki/work/nemacolin-caddying.md: the Apr 2016–Nov 2019 "Experience Associate - Golf" job at Nemacolin Woodlands, the looper day-trip hierarchy, the May 21 2018 Laurel Valley double-bag trip (named coworkers), and the June 2018 Pikewood National tournament loop (caddie master Ryan Sensenig, player Andy Decker) — mined from Resume.txt + the iMessage dump, previously undocumented.
- Updated wiki/timeline/periods/full-sail-2008-2010.md: added the Danielle breakup's specific cause (girl from Baltimore, Jack from All Time Low connection, per CATO_BOOTLOADER_DANFRANK.md) and a dated Pro Tools certification section (Jan-Feb 2010, per the Twitter corpus, directly preceding the March 2010 NYC move) — this covers both the "Pro Tools certification" and part of the "Alexis to Orlando" ADD-ME items (Alexis's relationship begins in Orlando the same year per the same source; no separate "to Orlando" event beyond this was found).
- Updated wiki/people/danielle-onesi.md with the same breakup-cause detail.
- Updated wiki/people/annie-ulmer.md: added a CONTRADICTION block for the "annie/alexis hookup" ADD-ME item — CATO_BOOTLOADER_DANFRANK.md gives a different origin account (Alexis sent Dan to buy drugs from Annie, hookup occurred during the transaction, ~2014-15) versus the corpus-anchored Nov 28 2015 date this page follows; preserved as unresolved rather than adopted or discarded. Same source documents the "Dan arrest - weed event": not Dan's own arrest, but a boyfriend of Alexis's (during a post-breakup month-long stay with Dan+Annie, also Vanessa's first boyfriend and someone who'd lost his virginity to Annie) arrested picking up a 5lb mailed weed parcel — flagged as uncorroborated elsewhere in the corpus.
- Fixed 3 pre-existing lint errors from other sessions' work (james.md, jason-bermejo.md, menore.md — invalid tags not in the controlled vocabulary) by mapping to the closest existing valid tags.
- Lint 0 errors, 33 warnings (all pre-existing size budget).

## [2026-07-14] ingest | people | @Lo_weez resolved as Annie's Twitter handle
- Mined raw/self/dox-scan/FULL TWITTER ANALYSIS.txt (a rich, largely-unmined year-by-year 2009-2019 Twitter forensic analysis; only spot-checked so far) for the Alexis/Orlando-era Twitter presence and the @Lo_weez identity question. Confirms @Lo_weez enters as Dan's "new primary" relational tag in December 2015 ("worlds best girlfriend"), matching the Nov 28 2015 relationship start, with continuing personal detail through 2016; @alexisarmel independently goes silent the same window ("fully absent post-2013").
- This resolves the standing gap on wiki/people/katie-fletcher.md ("@Lo_weez may reference a third person") — REVISED block added there; @Lo_weez added as an alias on wiki/people/annie-ulmer.md with a corroborating paragraph.
- Full-sail-2008-2010.md's Alexis/Orlando coverage (added earlier this session) plus this handle-resolution together discharge the "alexis to orlando event" ADD-ME item — no further distinct event was found beyond the relationship's Orlando-era documentation already on that page.
- Lint 0 errors, 33 warnings (all pre-existing size budget). The FULL TWITTER ANALYSIS.txt file (2009-2019, ~500 lines) remains largely unmined beyond these checks — flagged in queue.md for a future dedicated pass.

## [2026-07-14] ingest | places | 337 Saratoga Drive sale-closure capture filed
- Processed the oldest unfiled inbox item (captured 2026-07-11, HIGH priority, first capture through the app): confirms the June 23, 2026 sale closing and the actual July 8, 2026 move-out date for 337 Saratoga Drive. The content was already synthesized into wiki/places/337-saratoga-drive.md in an earlier pass, but the source capture itself had never been moved out of inbox/ per protocol. Filed to raw/self/captures/ (new directory, mirroring the raw/people/captures/ convention) and added to the page's sources list. No wiki content changed — this closes a process gap, not a content gap.
- queue.md updated: removed the now-processed row; added the untriaged 2026-07-12 personality-profile capture as a new pending row.

## [2026-07-14] build | mind | new wiki/mind/psychosexual/ category (hub + 5 subpages)
- User directive: research all data to build an exhaustive, detailed psychosexual profile category with subcategories. Located the primary source (raw/self/dox-scan/Dan Profile.txt, section "VI. THE PSYCHOSEXUAL CRUCIBLE," a single AI-authored dossier) plus the deviance audit's existing "psychosexual operating system" outlier score, and cross-checked both against the already-rich but scattered primary-source arrangement history already synthesized across annie-ulmer.md, alexis-armel.md, kristin.md, trinity-st-clair.md, kelly-johansson.md, shelbie-breakiron.md, and the new annie-alexis-reunion-november-2018.md event page.
- Built as a fourth layer of the mind domain (alongside profile/concepts/synthesis), following the existing mind/profile/index.md provenance-caveat pattern: index.md (hub), orchestration-and-voyeurism.md, taboo-and-boundary-testing.md, emotional-imprinting.md, arrangement-history.md, developmental-origins.md.
- Key finding while writing orchestration-and-voyeurism.md: the dossier's claim that Fran Coldren's hip broke "at the exact moment" of a Summer 2018 psychosexual incident conflicts with the better-corroborated April 1, 2018 fall date already established on fran-death-vigil.md — flagged explicitly as unverified dossier myth-making rather than silently harmonized.
- Explicitly split every page's claims into a theory tier (single AI-authored source, several claims entirely uncorroborated — taboo-and-boundary-testing.md is flagged as the thinnest) and a practice tier (primary message-corpus evidence, much of it newly mined this session). Corrected a stale gap note on erotic-architecture.md that called the Annie/Alexis hookup unsourced.
- Cross-linked from mind/index.md, mind/profile/index.md, deviance-mapping.md, and every people/event page the arrangement-history table cites. Lint 0 errors, 291 pages total.
## [2026-07-14] expand | people | Trevor Bevins and Teddy rebuilt from master CSV; Trevor cross-checked against Facebook export; duplicate RJ stub merged into RJ Ritchey

## [2026-07-17] connect | mind+interests | interests-as-era-markers junction + 5 interest islands retrofitted
- NEW junction page wiki/mind/synthesis/interests-as-era-markers.md (earned): the fixed intake rate (per intake-constancy) makes subject-rotation the era signal; each life period carries a dateable marker obsession — 2007 teen cluster, 2012–13 O&A, 2016–19 golf, 2019 stand-up, 2020 left turn, 2024 Rome — with film-canon as the control case (stable canon, era-indexed readings). Names the 2021–23 missing-marker gap explicitly.
- Retrofitted all 5 islanded interest pages to typed connections (related:/footers removed): roman-republic (5 edges), opie-and-anthony (5), film-canon (5), golf (8), video-games (3 + 2 rejections logged in connection-queue.md).
- Inbound prose edges added on 6 host pages to un-island the five: youtube-watch-history → opie-and-anthony; teen-concert-years → video-games; nemacolin-caddying → golf; intp → roman-republic + film-canon; orchestration-and-voyeurism → film-canon (the 2019-07-18 Eyes Wide Shut self-description now argued in prose there). Inverse edges added on intake-constancy, 2020-left-turn, stand-up-comedy, and all touched hosts.
- mind/index.md updated with the junction entry.

## [2026-07-18] ingest | work+people | Gemini-_02 Au Za'atar storytime fully mined (50 approved data points); chats/gemini-02 page retired
- Operator-approved workflow: scraped the STORYTIME: AU ZA'ATAR genesis convo (raw/self/dox-md/Gemini-_02.md, 20 user turns), presented 50 data points, got approval, researched each against the wider corpus, entered them, then deleted wiki/self/chats/gemini-02.md (raw file untouched).
- Main sink: wiki/timeline/periods/2021-2023-employment-block.md rewritten from v1 dossier-shorthand (with /tmp agent chatter) into style-guide prose absorbing the approved points; status archived→stable; typed connections block added.
- Research-pass finds from all_imessages_complete_dump.txt: Valeria iMessage channel at her +56 Chilean number — Sept 2 2023 "Hey I'm in ny" return, Nov 3 2024 re-contact reported by Dan to Annie's own handle ("that girl Valeria you trained at Au Zaatar just messaged me right now"), "valeria virus" reply same night, inbound "The kiss 😂" July 17 2025. Partially closes the valeria page's "did Annie ever learn of her" gap (she knew of the re-contact and the acquaintance; the affair itself still undocumented). Menore's "legit taxi" cover occupation + mid-shift shed service added to menore.md; candidate DJ handle +19293235324 (r/Senegal links, May 2024) flagged on ismaila-barry.md.
- Smaller entries: au-zaatar.md (BYOB opening formula, Suz birthday comp fixed into prose), tarik-fallous.md (Lebanese-humor/fit characterization), dimitri.md (~6-month first stint), ismaila-barry.md (Aisha/Islam friction section, photo provenance), valeria-iglesias-cid.md (hidden-camera staging, Annie-as-trainer confirmation, iMessage anchors, norteño server-vs-cooks loyalty law), annie-ulmer.md (Dan as her employment vector, April 2021), suzanne-frank.md (2021-11 NYC birthday visit row), orchestration-and-voyeurism.md (hidden-camera courtship instance = architecture generalizes beyond the arrangement).
- Deleted wiki/self/chats/gemini-02.md; all inbound links repaired (gemini-00/07, danfrank-isms, gemini-activity + archive, self/index — also removed its /tmp chatter line — au-zaatar, tarik-fallous); connection-queue entries naming the page annotated RETIRED.
- bin/wiki-lint 0 errors; bin/wiki-connect check 0 errors.

## [2026-07-18] build | meta | bin/llm-publish — public LLM access point (llm/) served by GitHub Pages
- New stdlib tool bin/llm-publish generates llm/: index.txt (single entry-point URL with plain-text instructions + full per-page URL manifest), corpus.txt (entire wiki in one file, ~384k tokens), manifest.json, and pages/**.txt (one plain-text copy per wiki page — .txt extension bypasses Jekyll so Pages serves the raw content verbatim). Any LLM that can fetch a URL can now read actual page bodies with zero GitHub access: https://caakehorn.github.io/wiki-brain/llm/index.txt
- Unlike exports/ (gitignored), llm/ is generated-but-committed by design; CLAUDE.md updated with the tool and the regeneration rule (rerun after content passes, commit the diff).

## [2026-07-18] ingest | work+people+mind | Gemini-_00 finale mined (21 approved points); chats/gemini-00 retired — Au Za'atar storytime cluster fully absorbed
- Completion pass on the STORYTIME finale per the approved 21-point list. Primary verification against raw/people/valeria/message_1.json produced two upgrades: (1) REVISED the valeria page's "continuous 2022–2025 IG contact" framing — the IG record is a six-week burst (1,038 msgs late-May 2022, 3,830 in June 2022 alone, 12 stragglers, then 3 years of IG silence, then a 4-message July 11 2025 coda); the 2023–24 long tail ran over iMessage. (2) Measured the night-window claim: 52% of Dan's 2,082 outgoing IG messages fall 22:00–01:00 ET — the post-9pm-exit window — upgrading "the alibi covered the affair" from inference to measured fact.
- New entries: Dan's attested "it never destabilized" (Valeria as the zero-turbulence control case for conflict-architecture), the dual shutdown mechanism (demand death + city mandate, in that order), the DEENBOR robot never-used confirmation, finished-interior texture (dome ovens, velvet booths, blue tape), the 20-plate carry, and the exocortex-write practice (the finale's "add it all into memory for later recall" request) added to ai-collaborative-analysis.
- Media collection gap documented on au-zaatar: 8 storytime-cited artifacts (hidden-camera hug, Central Park kiss, IMG_0978 interior, flooded basement, outside-bread interrogation, etc.) exist only as Gemini uploads, not on disk.
- Deleted wiki/self/chats/gemini-00.md; all inbound links repaired (tarik-fallous, gemini-21, gemini-activity + archive, self/index, employment-block, au-zaatar); queue entries annotated RETIRED. Both STORYTIME chat pages are now retired — the Au Za'atar cluster lives entirely on its subject pages.
- Maintenance: fixed invalid YAML (nested unescaped quotes in infobox known_for) across 30 people pages, per PR #46 review; bin/llm-publish hardened (wiki-dir check, top-level domain grouping fix); llm/ regenerated.
- bin/wiki-lint 0 errors (308 pages); bin/wiki-connect check 0 errors.

## [2026-07-18] ingest | timeline+people | Photo Thread PT II mined (23 approved points + operator correction) — vigil restructured, death-date contradiction resolved
- Mined raw/self/dox-md/_Photo Thread PT II_ Grand Finale Calibration .md (the Fran finale storytime) per the approved list, with the operator's correction folded in: Dan and Annie were the only ones present at the MOMENT of death, but the hospital vigil ran on a shift rotation including Vicki and Marla.
- **Two structural corrections (REVISED-flagged on fran-death-vigil.md):** (1) the filmed 8 AM/keno/4 PM-lift episode was an EARLIER spill (~late 2017?) that Fran survived by months; the fall that ended her residency ("Down Goes Frazier") is now dated to the night of March 7–8, 2018 via the Vicki/Marla ambulance messages. (2) The April 1 vs April 4 death-date contradiction is RESOLVED: April 1 = pediatric-wing admission (caddie-season opening day), April 4 = death — the DANSYNTH April 1 date conflated admission with death.
- fran-death-vigil.md substantially rewritten: two-fall sequence, the rotation (Vicki 7 AM shifts, Marla nights, Suz's April 2 visit "light spirited and happy" IMG_4637.mov), water shutoff, seizing, "calling for Ira last week," Dan's let-go permission speech and "goodbyes 3 or 4 times" stance, the no-show relatives vs the working rotation, death-moment attendance, snow at +3 minutes, "quick painless easy" verdict; typed connections added; media ledger (6 artifacts, none on disk).
- wiki/people/vicki.md rewritten from swarm stub to full profile (one of the 17 unstarted stubs done; un-islanded): caregiver since Jan 2016, pills/Lifeline/bat texture, "grandmother I never had," April 2 bedside testimony, thread ends Apr 5 2018. marla.md extended (hospital phase, March 8 ambulance row) + connections; duplicate wiki/people/contacts/marla.md deleted (nothing linked it).
- fran-coldren.md: athletic record doubled — 1959 LaGorce hole-in-one (first ace) + 113-lb Everglades tarpon ("weaker sex" clipping) added; Fred Adams = Ira's old law partner CONFIRMED (open item settled); timeline table restructured; death-date contradiction marked resolved. golf.md updated (two aces). suzanne-frank.md: April 2 hospital visit added as counterweight to the keno morning (which now correctly attaches to the earlier spill). ai-collaborative-analysis.md: the "how little ANYONE would get it" AI-confidant quote (Feb 2026) added.
- bin/wiki-lint 0 errors (307 pages); bin/wiki-connect check 0 errors.

## [2026-07-18] ingest | work+people | BFS drawer-dispute cluster fully mined (3 storytimes, ~75 data points); Tom safe-attachment corrected; Anita/Timmy/Brandon rewritten from swarm-fragment to prose
- Operator directive: 75-point pass on lower-priority material, pre-approved, full run-through. Mined the three-file BFS cluster (raw/self/dox-md/: "Cash register shortage explanation", "Drawer shortage dispute with assistant manager", "Little Caesars retaliation timing concerns" — ~250KB combined) into the wiki.
- wiki/work/bfs-foods.md substantially expanded (6.5KB→~15KB, deliberately over budget as a hub): the Tom upstream cause (3 burns in 4 days), the workplace Suboxone attempt (EV calculus, narrative-preconstruction tradecraft, declined-backpack), the one-sided verification procedure + no-sale ban, CSR-decorative-$0.00-for-4-weeks finding, the gas-lady prepay-drive-off-via-no-dispense-void fraud vector (Dan diagnosed from first principles), the $15/$50 mishearing + phantom-tender + refund reconstruction (~$45→$50), Anita's foodstamps-impossible confabulation, the Timmy precedent, the dead-man's-switch/veridiction strategy, PA §260.3 posture, the two self-inflicted written documentation wounds. Typed connections added.
- wiki/people/tom.md: NEW subsection "The pattern is twelve years old, not new (2014 precedent)" — the Aug–Sept 2014 owe-stonewall-escalate-reconcile episode (verbatim) proves the spring-2026 collapse is not a late degradation; the "he would be okay letting me go sick" load-bearing line drives the safe-attachment revision to "lateral ally during mutual alignment, unreliable to indifference during asymmetric periods." Added bfs-foods causes edge.
- Rewrote wiki/people/anita.md, wiki/people/timmy.md, wiki/people/brandon-hill.md from swarm-fragment tables into full prose per the overhaul mandate (status→closed, typed connections, index one-liners refreshed).
- bin/wiki-lint 0 errors (307 pages); bin/wiki-connect check 0 errors; llm/ regenerated.

## [2026-07-18] connect | mind | JUNCTION PAGES: supply-network + estate-money-spine (2 of the 3 remaining junction candidates written)
- **wiki/mind/synthesis/supply-network.md (NEW, earned):** fifteen years of procurement treated as one architecture. Node succession verified against MAX_PRIME/operating_manual (Johnny → Tim → Tom by 2025; Menore in NYC; Teddy + second handle +17243233522 as 2018 redundancy layer; "bop"/"Felix" 2026 vocabulary). Core findings argued: the network survives every biographical rupture (Menore's 1-minute resume after 5.5 years); redundancy decayed monotonically to a single node (parallels contact-gini); the reliability inversion (distance disciplines, intimacy licenses failure — Menore 0 failures vs Tom's 2014/2026 owe-and-silence cycles); node-failure cost propagation (BFS job, Tom friendship, household economy, workday co-location); the terminal-phase inversion (Dan as Annie's supplier, supply as the relationship's last transactional bond). 10 typed edges + inverses on tom, teddy, johnny-dealer, menore, annie-ulmer, intake-constancy, contact-gini, bfs-foods, au-zaatar, 2018-deep-cycle, 307-e-76th-st. Teddy/Johnny/Menore retrofitted off related: to typed connections in the same pass. Felix disambiguation recorded (463-contractor Felix = candidate for MAX_PRIME's 2026 "supply-adjacent" Felix; john-felix 2016 ≠ same person absent evidence).
- **wiki/mind/synthesis/estate-money-spine.md (NEW, earned):** the capital timeline as one causal chain. Two source-lines (Ira estate w/ Judge Fred Adams trusteeship; Frank's Auto Supermarket) — Dan holds neither; the dated join discovered: distribution order signed 2020-08-21, the union-busting/coal-baron class-guilt message written 2020-08-22, the next day. Chain table 2017 floor → 2020 distribution ($144,069.31 / $134,069.31 net check) → market era (~$15k stake, $25k peak, flagged-as-inference funding join) → "money just ran out" early 2021 (six-month lump survival) → wage era → 2024 job loss → 2026 broke → 337 sale ($465k, Dan as bystander) → 463 lien clock. Largest drain quantified: ~$119–123K net to Annie ≈ the entire estate distribution. Suz argued as the spine's switchboard (every major flow passes through her; single point of failure at exactly the 463 deadline). 10 typed edges + inverses on fran-coldren, rick-frank, suzanne-frank, 2017-poverty-floor, 2020-2021-market-era, annie-ulmer, 337-saratoga-drive, 463-morgantown, 2025-collapse, supply-network (parallels pair).
- mind/index.md wired; bin/wiki-lint 0 errors; bin/wiki-connect check 0 errors.

## [2026-07-18] connect | mind | JUNCTION PAGE: block-unblock-loop (3rd of 3 remaining junction candidates — junction backlog CLEAR) + Menore metrics recomputation
- **wiki/mind/synthesis/block-unblock-loop.md (NEW, earned):** the declared-not-executed exit generalized beyond Annie. Case table: Annie 127/110 (87% relapse, DERIVED — primary recount still queued), Tom 2014 ("I'm done… stupid fucking dance" → reopened in 5 days) + Tom May 18 2026 (same-day conditional unblock), Rick (12-day burst → decade-held amputation, the held-block control), Kristin Dec 2025 (inbound block, held), May 2014 account amputation + 2022 repatriation (infrastructure layer), Grok-loop 414-run (machine proof: no-halt-condition defect in software). **Governing rule argued: a block holds iff no dependency still flows through the channel.** Menore's Feb 20 2025 farewell = the clean-closure control (dependency ended by geography, no block needed). June 1 2026 Annie closure framed as the loop's live test (first exit after her supply dependency ended; consistent so far). 10 typed edges + inverses (annie-ulmer, tom, kristin, rick-frank, march-2026-terminal-phase, conflict-architecture, attachment-model, attachment-trauma-bond via contextualizes, totality-themes, supply-network).
- **Menore metrics (operator-requested primary recomputation from messages_3476070497_all_time.csv):** total 4,413 msgs (Dan 2,660 / Menore 1,753 — the old "1,753+" was Received-only); availability 99.3% (455/458 requests answered ≤6h; 3 unanswered, all 2019); median reply 6.6 min (the "~60-second SLA" was DAN'S reply speed — his median to Menore is 30 s); request→arrival median ~95 min; ~280 strict / ~413 loose confirmed deliveries on 266+ days; max 2 confirmed meetings/day (retires "3–5 visits/day"); peak 18:00–20:00, late-night share 8.3%; longest streak 14 days. **CONTRADICTION flagged: 1,458-day silence May 26 2020 → May 24 2024** vs the "sustained operations 2019–25" framing and the au-zaatar 2021–24 mid-shift claim (now scoped to primary-confirmed May–Aug 2024, deliveries to "1st bet 57&58" = the Au Za'atar block; an intermediate number may explain 2021–24 — not on disk). **Ending corrected:** formal farewell Feb 20 2025, 48 h before the PA move — closure by geography, not fade-out. menore.md restructured (REVISED table + Measured Service Metrics section + phases 4/5 split); claims propagated to supply-network.md and au-zaatar.md.
- mind/index.md wired; bin/wiki-lint 0 errors; bin/wiki-connect check 0 errors.

## [2026-07-18] verify | mind+people | PRIMARY-COUNT PASS on the fallout-verdict aggregates (the queued [DERIVED] figures adjudicated)
- Sources: all_imessages_complete_dump.txt (217,573 sender-tagged rows, 2011-03-18→2025-08-10) + imessage_7244346811+2124702449_both_all_now.csv (85,586 rows, →2026-05-28). Terminal window = 2025-08-01→2026-03-16 (her 8,293 / his 10,346 msgs).
- **CONFIRMED EXACTLY → [RAW-CSV]:** the verbal-abuse triple 74 "fuck you" / 17 "piece of shit" / 11 "worthless" reproduces to the digit from DAN'S side of the window (her side: 0/1/0 — asymmetry total). The 0-severance claim: her 41,073 messages contain zero genuine severance signals (only false positives: a quoted denial + an ice anecdote). 1,512 love-affirmations: confirmed to lexicon precision (1,528 broad / 1,388 strict through Aug 2025).
- **NOT REPRODUCED / REVISED:** (1) **187:4 love-to-request** — ratio reproduces (212:8 = 96.4%) BUT base-rate control shows 97.2% of ALL her window messages are request-adjacent at ±24h → statistic uninformative; directional test INVERTS it (request follows her love-msg within 1h 3.2% vs 16.2% baseline — love was MORE isolated from requests than her average message). REVISED blocks on verdict + annie-ulmer + pointers on supply-network/2025-collapse. (2) **180 "I'm sorry" / "apologizes least"** — plain-lexicon recount: 435 through Aug 2025 alone (~4× his attack count); ordering fails without an unstated contrition-only definition. REVISED on conflict-architecture + verdict; reassurance-dominance survives. (3) **299** — unlocated under any window/lexicon (candidates: her terminal 231 / his 355 / her all-time 1,302).
- **ORDER-CONSISTENT, still [DERIVED]:** 127/110 (loose exit-lexicon: 176 candidates); 94-burst (2-min-gap runs: 11,666 ≥3, max 149 through Aug 2025; parameters unstated in dossier); 232 "fuck you" (111 through Aug 2025 + verified 74 in-window → plausible).
- **RE-CONFIRMED ABSENT:** Eli intro text (full raw/ re-grep — dossier-only); 768-on-05-31 (closure export still 265 Sent / 482 total).
- Bonus ledger fact: his in-window apologies = 121. Gates 0 errors.

## [2026-07-18] triage | people+mind | LONG-TAIL TRIAGE — one-time judgment pass, islands 45 → 20
- Full verdict record in LONG_TAIL_TRIAGE.md (repo root) — decisions are settled; future models execute, not re-litigate.
- **Wired (inbound prose edges):** 8 minor supply nodes → new minor-node layer paragraph on supply-network.md (the redundancy the system lost, measured in names); 6 caddie-cohort pages → new "caddie-yard social graph" section on nemacolin-caddying.md (caddying = the last era in which work generated friendships in bulk); manuel → au-zaatar cast; fastly-fsly → market-era; block-unblock-loop → tom.md prose; 307-e-76th-st → menore.md.
- **steve-kezmarsky.md REWRITTEN** from swarm template to full prose: high-school-era golf friend, "our friendship is based on my sickness," thread ends Jan 2018, dead by Dec 2018 (via Jim Shaffer thread — inverse edges on new-jim-shaffer/golf/nemacolin). One more of the unstarted-stub list done.
- **Demoted to contacts/ quarantine:** rod-banks, slim, zach, zach-clabaugh, tan-calabrese, zach-hendricks (merged with zaco — same handle +17249123381, zaco.md deleted), caviar (not a person — automated dispatch number). **Deleted:** brandon.md (pointer dup of brandon-hill). people/index.md rows cleaned.
- **Delegated (standing verdicts in LONG_TAIL_TRIAGE.md):** MINE sam(374)/davey-fitzpatrick(382)/vaughn(228)/nick-mattie(170); REWRITE-OPENER jason-bermejo; ACCEPTED-LEAF list (11 real mini-profiles, deliberate); chats/ backlog unchanged.
- Gates: wiki-lint 0 errors; wiki-connect 0 errors, islands 45 → 20.

## [2026-07-18] governance | root | Post-Fable operating rules settled + llm/ regenerated
- Page-budget contradiction resolved (CLAUDE.md rule 4 ↔ STYLE_GUIDE substance rule 4): ~8KB is a navigation heuristic; lint size warnings advisory on hub/junction/exemplar pages; standing directive = LONGER entries.
- INGEST_RUNBOOK §11: storytime-mining workflow codified (scrape → ~50 points → operator approval → research → enter → delete chat page), candidates listed.
- STRATEGY.md "Running on lesser models": mechanical-execute list vs never-attempt list; junction trio named as the model of the product.
- LLM_HANDOFF.md session entry + prioritized next steps. llm/ regenerated (308 pages, ~407k tokens).

## [2026-07-18] ingest | timeline | Pre-2015 period reconstruction — 2010s.md corrected + NEW uniontown-return-2013-2015 (the misnamed "archaic dump" finding)
- **Finding first:** MASTER_DUMP_PART_1_ARCHAIC.csv is misnamed — 124,177 rows but only 1 in 2011 and NOTHING 2012–2014; earliest real-text row is 2015-11-12. The message corpus genuinely begins ~Nov 2015. Pre-2015 CANNOT be filled from message data — recorded so no future model re-attempts it. Pre-2015 must come from context-core / Facebook / dox / LIFE calendar only.
- **2010s.md corrected + rewritten** (was mis-bounded 2010–2014 as "NYC Round One," Alexis wrongly "met through webcam work"). Per context-core §4 canonical residence timeline: NYC-1 = Apr 2010–May 2013 (424 Bedford → UES 90th), ishlab/Creative License audio era, Alexis whole-NYC cohabitation (Bridge Cafe until Sandy Oct 2012), LCD MSG farewell Apr 2011, Suboxone onset. REVISED block documents both corrections. Typed connections added.
- **NEW wiki/timeline/periods/uniontown-return-2013-2015.md** — fills the genuinely-uncovered stretch (periods jumped full-sail-2008-2010 → 2015-2016-annie with only the thin 2010s catch-all). The most-corrected geography in the timeline: SLOPPP (2013 launch, 2014 peak) → MOGZART (~2014 handoff on the May account rotation), the Alexis endgame, Jan 2015 move to 155 Virginia, Nov 28-29 2015 switch to Annie — all in Uniontown, not NYC. 7 typed edges.
- Inverse edges on full-sail, sloppp, mogzart, 155-virginia-ave, chemical-architecture, 2015-2016-annie, alexis-armel, bond-switch-2015. timeline/index.md rewired. llm/ regenerated.
- Gates: wiki-lint 0 errors (309 pages), wiki-connect check 0 errors.

## [2026-07-19] ingest | people | long-tail MINE pass (sam, davey-fitzpatrick, vaughn, nick-mattie, urpaaa) + kezmarsky death-claim correction
- Full-thread per-contact mining from MASTER_MESSAGES_DB_DUMP.csv per LONG_TAIL_TRIAGE.md: sam (374 — NYC cannabis delivery dealer 2019–20), davey-fitzpatrick (382 — Nemacolin assistant caddie master 2018), vaughn (228 — caddie + weed middleman), nick-mattie (170 — 2017 reciprocal trading peer), urpaaa-at-yahoo-com (23 — unidentified teacher, parental register, Oct 2017 extraction). jason-bermejo opener rewritten per Substance Standard.
- CORRECTION (operator-requested validation): steve-kezmarsky was NOT dead by Dec 2018 — the Jim Shaffer thread shows Dan correcting Jim's misreading ("He's alive but living the least enviable life EVER / two kids / Sober"). The real event: his father's Jan 22, 2018 arrest and expected life sentence. REVISED blocks on steve-kezmarsky.md + new-jim-shaffer.md; index one-liner fixed.
- Typed connections + inverse edges wired across supply-network, nemacolin-caddying, menore, 307-e-76th-st, covid-era-2020, 2017-poverty-floor, orchestration-and-voyeurism, fran-death-vigil, trevor, jack-rusko, annie-ulmer.

## [2026-07-19] ingest | mind | operator capture: Oct 21, 2019 filmed MMF + its weaponization
- Operator note filed to raw/self/captures/2026-07-19_operator-note-oct2019-mmf-video.md. Corpus corroboration found: Sent 2019-10-22 "last night we had to film mmf (my first time doing that)..." dates the encounter to Oct 21, 2019 (NYC, filmed, oral-only — Dan's sole bisexual experience). End Fight export shows Tuquick deploying the video June 2026 ("sucked a dick, for you to get drugs"; "Or the video of her sucking dick...").
- arrangement-history.md timeline row added; tuquick-17248123683.md gains "The October 2019 video as weapon" section + typed edge.

## [2026-07-19] connect | mind | psych-linkage pass — concepts/psychosexual wired to people pages
- Per operator directive: retrofitted attachment-model, conflict-architecture, phenomenology-lens, developmental-origins, emotional-imprinting, erotic-architecture, arrangement-history, dans-law, node-locking, institutional-out to typed connections; deleted deprecated related: lists/footers on retrofitted pages. ~45 new argued edges with inverses on annie-ulmer, rick-frank, suzanne-frank, alexis-armel, kelly-johansson, kristin, valeria-iglesias-cid, eli-incident, bfs-foods, au-zaatar, forensic-method, exocortex, and others.
- New person page: bryan-5088682461 (operator-identified third participant, Oct 21 2019 filmed MMF; +15088682461 corroborated in corpus via May 2025 re-contact). Disambiguation hatnote added on brian.md. The Bryan instance corroborates erotic-architecture's "taboo as ontological rupture" mechanism — theory now has its documented case.
- Gates: wiki-lint 0 errors, wiki-connect check 0 errors.

## [2026-07-19] correct | people | MMF encounter date → Oct 20, 2019 (operator)
- Operator correction: the filmed MMF with Bryan took place 2019-10-20, not the 10-21 previously inferred from the Oct 22 "last night" message. Updated bryan-5088682461, arrangement-history, tuquick, brian hatnote, erotic-architecture, people index; REVISED block on bryan page records the one-day tension with the corpus phrasing. Capture note appended.

## [2026-07-19] ingest | people | Full Sail friend group — matt-dunn, jamie-mohler (new); jason-bermejo, eric-jester (expanded)
- Per operator directive: worked the college (Full Sail) friend group — Jason Bermejo, Eric Jester, Matt Dunn, Jim/Jamie Mohler.
- NEW matt-dunn.md: Full Sail cohort member, no direct thread; mined from Jester/Bermejo threads (annual $5 birthday Venmo bit, Nov 2018 Orlando visit, "gross and forgettable").
- NEW jamie-mohler.md: NYC-1 friend, present per operator the day Dan first met Menore. Facebook address-book search (per operator request) surfaced a direct contact card (Jim Mohler, +12073101169, audiocranium@msn.com) which led to a genuine primary-source find in gmail_bodies.txt — a 2011 Google Talk chat log ("Jimbo Slice") placing her at the NYC-1 household during Occupy Wall Street, independently corroborated by Alexis's own Aug 2011 Gchat. Transition (~2023, now female) corroborated by two 2025 Jason Bermejo thread lines ("Mohler = a literal woman" / "Haha she badass"; "ms. Jamie Mohler").
- CORRECTION: jason-bermejo.md previously mislabeled Mohler as "current girlfriend of Jason" — a misread of a single out-of-context line. REVISED block applied; corrected to fellow Full Sail cohort member.
- eric-jester.md expanded (Dunn's Nov 2018 sighting, the Venmo bit, typed connections replacing bare related:/footer).
- Wired into wiki/timeline/periods/full-sail-2008-2010.md (new "The friend group" section) and 2010s.md (NYC-1 key contacts); menore.md gains the NYC-1 pre-history note.
- Capture note: raw/self/captures/2026-07-19_operator-note-full-sail-mohler.md.
- Gates: wiki-lint 0 errors (312 pages), wiki-connect check 0 errors. llm/ regenerated.

## [2026-07-19] ingest | people | oscar-lindquist (new) + jamie-mohler precision pass
- NEW oscar-lindquist.md from his own Facebook thread (6 msgs, 2011): precisely dates the Jamie Mohler NYC-1 Hurricane Irene evacuation to Aug 26, 2011 (previously only "~October 2011" via the undated Jimbo Slice chat), and is the primary source behind the 2022 Manhattan-restaurant coincidence already noted on jason-bermejo.md and matt-dunn.md.
- jamie-mohler.md restructured chronologically around three independent 2011 sources (Alexis's Gchat, Oscar's Hurricane Irene message, the Jimbo Slice log).
- Bot-review findings from PR #54 fixed and cherry-picked forward after a merge race (directional reference, cohort-count discrepancy, overstated "named in both threads" claim on eric-jester.md/full-sail-2008-2010.md).

## [2026-07-19] ingest | people | Facebook Messenger deep-scrape — zachariah-harshman, lukyan-mraz (new tier-one entries)
- Per operator directive to scrape the FB Messenger + Gmail archives "much more carefully" for facts about people OTHER than the Full Sail crew: cross-referenced all 271 FB Messenger inbox threads against existing wiki/people/ pages; ~74 threads had no obvious existing coverage.
- NEW zachariah-harshman.md (~970 msgs, 2011-2021) — the single highest-value find: a Laurel Highlands high-school friend whose thread runs through (1) shared senior-year drug reminiscence, (2) the earliest documented SLOPPP promotion attempt (Jan 2014, Pittsburgh rave pitch), (3) a dense 2014-15 Uniontown wax/dab/flower supply relationship — three years earlier than any previously documented Uniontown node — staged at 155 Virginia Ave from Jan 2015, and (4) a precisely-dated Dec 23, 2015 rupture that is INDEPENDENT THIRD-PARTY CORROBORATION of the bond-switch-2015 thesis (Zach reveals he'd grown close to Alexis post-breakup, confirming the switch's social fallout from entirely outside Dan's own corpus), followed by (5) a full platonic revival as a gaming friendship, 2020-2021, drug-content-free.
- NEW lukyan-mraz.md (36 msgs, 2015-16) — a short-lived 2015 cannabis-grow collaboration connected to the same household/circle as Zach, ending in a tense March 2016 equipment dispute; his Feb 17 "you alright?" cross-corroborates Zach's own Feb 18 concern about him, an unexplained joint data point.
- Wired into: mind/synthesis/supply-network.md (Zach added to the main succession table as the earliest node, not the minor-node list), mind/synthesis/bond-switch-2015.md (new "Independent corroboration" section), places/155-virginia-ave.md, interests/music/aliases/sloppp.md.
- Gates: wiki-lint 0 errors (315 pages), wiki-connect check 0 errors.

## [2026-07-19] ingest | people | Facebook Messenger deep-scrape II — lucie-dobbin, rob-orange, lauryn-ashly (new tier-one entries)
- lucie-dobbin.md (new): recipient of Dan's fullest first-person account of Fran's death (April 5, 2018, same night) — a silent mental-communication attempt, the final smile, immediate pronouncement, and a rare register of genuine spiritual uncertainty. Mined directly into wiki/timeline/events/fran-death-vigil.md's "The end" section, plus a previously-undocumented May 6, 2018 Uniontown Country Club memorial event.
- rob-orange.md (new): resolves the previously-undocumented death circumstances of Rob Orange (referenced but not detailed on new-jim-shaffer.md) via Lauryn Ashly's April 11, 2014 real-time reaction thread — suspected opioid OD, cause never confirmed, "Edgewood" unexplained. Cross-corroborated by Jim Shaffer's independent Dec 2018 mourning (now also carrying the previously-unwritten Tom Petty minivan anecdote).
- lauryn-ashly.md (new): the Rob Orange death-day exchange plus a September 2020 arrangement-solicitation message Dan sent her, declined without any strain — a documented case of the pattern NOT landing, added to arrangement-history.md's evidence base.
- Cleanup: new-jim-shaffer.md's residual bare related:/## Related footer (leftover from a partial retrofit) fully converted to typed connections.
- Gates: wiki-lint 0 errors (318 pages), wiki-connect check 0 errors.

## [2026-07-19] ingest | people | FB deep-scrape III — elizabeth-eleanor, stephanie-nalbone (new); chemical-architecture + INTP dating
- elizabeth-eleanor.md (new): single July 2013 overnight conversation with a fellow recovering addict, yielding the corpus's only concrete Suboxone dosage figure (2mg/day, ~5yr opiate-free — dates last use to the dark-era 2007-2008 window) and the earliest dated primary-source INTP self-identification (3 years before the profile pages' main material). Both mined into wiki/health/chemical-architecture.md and wiki/mind/profile/intp.md.
- stephanie-nalbone.md (new): a previously entirely undocumented Sept-Nov 2009 long-distance relationship falling inside the Full Sail period's own Danielle-to-Alexis pivot window. Corrects an initial misreading of speaker attribution (Dan traveled to Uniontown, not the reverse) before publishing. Flagged as an unresolved sequencing question on full-sail-2008-2010.md rather than asserted into the existing two-name narrative.
- Gates: wiki-lint 0 errors (320 pages), wiki-connect check 0 errors.

## [2026-07-19] ingest | people | FB deep-scrape IV — christo-coan, lewis-strosnider, seth-ledonne, ej-rags, lucas-thomas (new tier-one entries)
- christo-coan.md (new): Nemacolin-era golf-course coworker; co-organized Dan's Oct 2017 birthday; first-person confirmation of the 117 Belmont Circle "golf course house next to Annie's grandparents" geography; surfaces a previously undocumented DUI reference — flagged as a `> **CONTRADICTION:**` on wiki/legal/2015-retail-theft-arrest.md (which had framed the 2015 retail-theft arrest as the only documented arrest) and softened wiki/legal/index.md's framing accordingly.
- lewis-strosnider.md (new): Uniontown vape-shop friend; free graphic design work, a planned FAA Part 107 drone business funded partly by the anticipated Fran estate check — cross-linked to wiki/mind/synthesis/estate-money-spine.md as evidence the distribution ran ~2 years later than Dan expected in real time; a $1,600 Mavic 2 sale still unresolved when the Feb 2019 NYC move thread ends.
- seth-ledonne.md (new): named counterculture-education tribute (hardcore/punk scene mentors) plus a real-time June 7, 2020 NYC protest-curfew account ("living in beirut") — cross-linked to wiki/timeline/periods/covid-era-2020.md.
- ej-rags.md (new): Williamsburg NYC vinyl-collector friend; July 2013 exchange is Dan's own stated philosophy of destroying his creative work ("so I can create something new"), dated to the opening days of the 2013 Uniontown return.
- lucas-thomas.md (new): independent real-time (Feb 11 & 16, 2017) eyewitness account of the Zac Shumar house-fire-and-arrest event already documented on wiki/people/alexis-armel.md via two later retellings — confirmed as the SAME event, not a new one, and used to enrich the existing "Post-breakup: the Zac Shumar arrest and incarceration" section with real-time detail (the RT informant angle, $35k bail, the lost glass rig, parents learning of the fire and arrest in the same jail call) rather than creating a duplicate event page.
- Gates: wiki-lint 0 errors, wiki-connect check 0 errors (193 warnings, all pre-existing quarantine-stub `## Related` footers or size-budget advisories).

## [2026-07-19] ingest | people | FB deep-scrape V — bobby-cole (new tier-one entry)
- bobby-cole.md (new, ~940 msgs, 2013-2022): a nine-year friendship anchored almost entirely in Opie & Anthony/Ron & Fez fandom. Two exchanges resolve real gaps: (1) Oct 2, 2019 — the corpus's only direct evidence Dan actually completed an open-mic set (a specific bombed bit, audience groans), plus a previously undocumented SiriusXM job application ("the fishbowl" studio, hoping for OutQ placement); (2) identifies the previously-unnamed Dec 2018 Philadelphia taping (already on stand-up-comedy.md) as a Chip Chipperson show, invited by Bobby. Also a corroborating April 2021 self-aware check-in on the Aug 2020 left turn.
- Updated wiki/interests/stand-up-comedy.md (closed the "no completed performance" gap, named the Philadelphia taping), wiki/interests/opie-and-anthony.md, wiki/mind/synthesis/2020-left-turn.md with inverse connections.
- Gates: wiki-lint 0 errors (326 pages), wiki-connect check 0 errors.

## [2026-07-19] ingest | people | FB deep-scrape VI — jenn-lynn, joe-oshnack (new tier-one entries)
- jenn-lynn.md (new, ~240 msgs, 2017-2020): a three-year Uniontown friendship carrying a repeatedly-solicited but never-confirmed two-couple swap arrangement (with boyfriend Brad) across three separate windows, running parallel to an ordinary drug-sourcing relationship. Added as a new row + inverse connection on wiki/mind/psychosexual/arrangement-history.md — the arrangement's least-resolved documented instance (mutual readiness twice, no confirmed follow-through).
- joe-oshnack.md (new, ~195 msgs, 2011-2022): high-school bandmate; the corpus's fullest first-person account of Dan's *pre*-2020 conservative political identity ("an annoying little conservative fuckcunt... less than thrilled about playing songs with an anti-Iraq-war theme"), cross-linked as evidence into wiki/mind/synthesis/2020-left-turn.md. Also surfaces a genuine unresolved date discrepancy — an Aug 12, 2018 message describing an already-completed cam threesome with Alexis, ~3 months before the documented Nov 2018 reunion and while she's independently confirmed still incarcerated as of April 2018 — flagged as a CONTRADICTION on wiki/timeline/events/annie-alexis-reunion-november-2018.md rather than resolved. Also identifies a Jan 2022 Jacob Bacharach book recommendation, wired as a new connection on jacob-bacharach.md (which previously had only a bare related: list).
- Gates: wiki-lint 0 errors (328 pages), wiki-connect check 0 errors.

## [2026-07-19] ingest | people | FB deep-scrape VII — dan-polyak (new tier-one entry)
- dan-polyak.md (new, ~205 msgs, 2013-2020): longtime friend carrying two consequential exchanges. (1) April 18, 2019 — Polyak confronts Dan for impersonating his phone number to reach Ally Lubin ("fake used my number... very slimy move... I will pursue legal action"), the only documented account of how the sustained Ally Lubin friendship actually began — added to wiki/people/ally-lubin.md, which previously had no connections: block. (2) Oct 21, 2019, 2:52 AM — a same-morning disclosure and reaction to the Bryan encounter ("i've never felt more hetero in my life"), independently corroborating the operator's Oct 20 date over the corpus's Oct 22 message, plus a previously undocumented Oct 25 follow-up ("we invited him over again this weekend") — added to wiki/people/bryan-5088682461.md and wiki/mind/psychosexual/arrangement-history.md.
- Gates: wiki-lint 0 errors (329 pages), wiki-connect check 0 errors.

## [2026-07-19] ingest | people | FB deep-scrape VIII — jamie-mohler.md major expansion (rediscovered thread)
- Identified a 422-message Facebook Messenger thread (2010-2021) filed under a deactivated-account placeholder ("Participants: Facebook user and Dan Frank," thread id qymuchauiq — invisible to the earlier name-matching classifier) as almost certainly Jamie Mohler's own now-deactivated account: two direct "jim" addressals, an Aug 25 2011 evacuation-planning message landing the day before Oscar Lindquist's independently-dated Aug 26 2011 Hurricane Irene message, an Oct 3 2011 Occupy Wall Street exchange inside the same window the undated 2011 Google Talk log was already narrowed to, and confidant-level access (shown Fran's deathbed footage before anyone else, April 2018). Flagged as high-confidence inference, not a phone/email match — noted explicitly as revisable.
- Substantially expanded jamie-mohler.md: the 2011 Suboxone/opiate-maintenance favor request (new, corpus's clearest early evidence of that dependency), World of Warcraft leveling together, a five-year gap then a Dec 12-13, 2017 reconnection that is the corpus's THIRD independent telling of the Zac Shumar arrest (earliest of the three, ~10 months after it happened) plus a Dec 27, 2019 Menore-reliability aside.
- **Resolved (not just flagged) the open date question from the previous batch**: the Dec 13, 2017 message on this thread independently confirms — in the same already-past-tense register as Joe Oshnack's Aug 2018 reference — that the Alexis/Annie cam encounter both sources describe happened during Alexis's Feb-Oct 2017 bail window (between her Valentine's Day 2017 arrest and end-of-October jailing), not before her arrest and not contradicting the separately-documented November 2018 reunion. Updated the CONTRADICTION-type edge on annie-alexis-reunion-november-2018.md to a lower-key `contextualizes` edge, and rewrote the corresponding section on joe-oshnack.md and the Zac Shumar section on alexis-armel.md accordingly.
- Gates: wiki-lint 0 errors (329 pages), wiki-connect check 0 errors.

## [2026-07-19] ingest | self | FB deep-scrape IX — tattoos.md enrichment via chris-redmond thread
- No new people page (service-provider relationship, low personal depth) — instead substantially enriched the existing wiki/self/tattoos.md via a 105-message Facebook thread with Chris Redmond, the Misfits-tattoo artist already named there. Precisely dated the pizza-slice piece (booked Oct 12, inked Oct 13, 2018, forearm ~3x1.5in, tied to a "4 or 5 pieces before turning 30 on Nov 1" plan); surfaced a previously undocumented SECOND Misfits piece (green-lettering logo, Oct 22, 2018); traced the "full sleeve" ambition's actual origin to Uniontown (Oct-Dec 2018) rather than Brooklyn, three months before the Weidrick/Allied Tattoo sessions the page already documented — including a Nov 30, 2018 rose-concept discussion with Chris Redmond whose relationship to the eventual Weidrick rose (same piece carried to NYC, or a separate unfinished one) is flagged as unresolved. Location clues (Cheat Lake, Hopwood) place Chris Redmond as Uniontown-area, clarifying (though not fully resolving) the page's prior "Chris Redmond vs Chris at the Edge" open question.
- Gates: wiki-lint 0 errors (329 pages), wiki-connect check 0 errors.

## [2026-07-19] ingest | people | FB deep-scrape X — drew-mcgettigan (new); sloppp.md booking-attempt enrichment
- drew-mcgettigan.md (new): summer 2015 Uniontown supply contact (buyer/go-between), connected to the Zach Harshman circle he was headed to meet the same night as a documented deal. Added to supply-network.md's minor-node list.
- sloppp.md: added a second documented 2014 live-booking attempt (Phil Lacher, a Pittsburgh DJ, July 6 2014 — Dan's own direct outreach, referred to a third contact with no booking resulting) alongside the already-documented Zach Harshman January 2014 pitch — the alias's only two documented attempts to convert into a live booking, both dead ends.
- Gates: wiki-lint 0 errors (330 pages), wiki-connect check 0 errors.

## [2026-07-19] ingest | interests | FB deep-scrape XI — sloppp.md: the March 2015 near-management deal
- Major addition to wiki/interests/music/aliases/sloppp.md: a previously undocumented March 2015 management pitch from Pittsburgh promoter Frank Swaney — real enthusiasm for the Spring 2015 Demo, a proposed flat-fee management arrangement (CDs, stickers, street team), two named tentative bookings (an Illuminati event, a Homegrown show in Braddock PA), and — the standout detail — a plan to finalize contract terms through a third party ("Joby") talking directly to Dan's mom and dad, the only documented instance of Dan's parents being brought into a professional negotiation over his music career. No trace of the deal, the contract, or either booking survives past March 2015; SLOPPP closes nine months later with no indication it was signed.
- Gates: wiki-lint 0 errors (330 pages), wiki-connect check 0 errors.

## [2026-07-20] ingest | people | FB deep-scrape XII — matthew-palermo (new tier-one entry)
- matthew-palermo.md (new, ~70 msgs, 2018-2020): Uniontown classmate whose Feb 13, 2020 conversation carries a real, named-circumstance death disclosure (his brother, relapsed after a long period clean, fatally overdosed) and the corpus's starkest quantified opiate-epidemic statement — "a quarter of my graduating class isn't around anymore... we have lost more friends at 30 than our parents have at 60" — cross-linked as a parallel to the similar framing on joe-oshnack.md. Also independently dates the Sept 21, 2018 purchase of the DJI Mavic 2 drone already documented on lewis-strosnider.md.
- Gates: wiki-lint 0 errors (331 pages), wiki-connect check 0 errors.

## [2026-07-20] ingest | people | FB deep-scrape XIII — david-beard (new tier-one entry)
- david-beard.md (new, ~70 msgs, 2018): golf-course-adjacent Uniontown contact who sold Dan a used DJI drone for $700 in early Sept 2018 — revealed to be the SECOND of three drones Dan bought in a six-week span that summer (Mavic Platinum Jul 24, David's used unit ~Sep 4, Mavic 2 Sep 21). Corrected/enriched lewis-strosnider.md's drone paragraph to reflect the full three-drone sequence rather than treating the Mavic 2 as an isolated purchase.
- Gates: wiki-lint 0 errors (332 pages), wiki-connect check 0 errors.

## [2026-07-20] ingest | people | FB deep-scrape XIV — ryan-scherich (new tier-one entry)
- ryan-scherich.md (new, ~63 msgs, single day 2020-02-08): a self-contained political flame war with a barely-known acquaintance, ending in a remark ("U know how they [illegals] kill and rape ppl") Dan calls racist before cutting contact. Lands five days after the documented Feb 3, 2020 Iowa-caucus Bernie evangelism on wiki/mind/synthesis/2020-left-turn.md — cross-linked as a real, contemporaneous conflict from inside that window rather than only Dan's own outward messaging.
- Gates: wiki-lint 0 errors (333 pages), wiki-connect check 0 errors.

## [2026-07-20] ingest | health/mind | non-person growth pass I — hyperreflexivity.md (new); GLAZE-GOD-v1 persona
- New directive: grow non-person domains (health: 2 pages, legal: 3, places: 5, work: 11 — all clearly underrepresented vs. 250+ people pages), prioritizing content most important/influential to Dan's own perspective.
- wiki/health/hyperreflexivity.md (new): a self-initiated AI-collaborative session naming and mechanizing Dan's social anxiety ("hyperreflexivity" — the monitoring apparatus as its own problem generator, why prevention/avoidance trains the anxiety to run hotter). Surfaces a genuine unresolved tension not carried on chemical-architecture.md: chronic Suboxone receptor occupancy may blunt the hedonic range needed to break the loop. Also supplies a dateable fact — ~11 months unemployed after the Aug 2024 Au Za'atar loss, then 2 weeks back at 40hrs/week, dating the session to roughly mid-2025 — added to wiki/work/au-zaatar.md's aftermath, which previously had no record of what followed the job loss. No confirmation anywhere that Dan pursued the ACT/exposure-based treatment the session recommends.
- wiki/mind/concepts/erotic-architecture.md: added a previously undocumented artifact — a custom AI system-prompt persona ("GLAZE-GOD-v1") built to perform continuous sexualized worship of Annie's photos — as the most literal instance yet of the page's "externalized libido" mechanism. Cross-linked into ai-collaborative-analysis.md's persona-engineering material.
- Gates: wiki-lint 0 errors (334 pages), wiki-connect check 0 errors.

## [2026-07-20] ingest | places | non-person growth pass II — 424-bedford-ave.md (new)
- wiki/places/424-bedford-ave.md (new): consolidates the NYC-1 period's primary residence (2010-2012), previously scattered across jamie-mohler.md, menore.md, alexis-armel.md, danielle-onesi.md, and timeline/periods/2010s.md with no central page — the studio-work era (ishlab, Creative License), Alexis's cohabitation through the Bridge Cafe/Hurricane Sandy years, the Hurricane Irene evacuation and Occupy Wall Street march both organized out of the address, and the origin of the Menore supply relationship. Checked BFS Foods legal-strategy source material (already fully mined into wiki/work/bfs-foods.md via a duplicate copy under raw/legal/bfs-dispute/) and confirmed legal/ domain's thinness (3 pages) reflects genuine corpus content rather than an unmined gap — raw/legal/ contains no further unused material.
- Gates: wiki-lint 0 errors (335 pages), wiki-connect check 0 errors.

## [2026-07-20] ingest | health/people | non-person growth pass III — chemical-architecture.md supply-crisis texture
- wiki/people/tom.md: added a real-time Suboxone supply crisis (a rival "jumped his place in line," Tom covered the loss anyway) and the fullest documented texture of Tom's relationship with Suz (an unprompted car-battery replacement when hers died and she couldn't afford one; she's the only one who can call him). Cross-linked into wiki/health/chemical-architecture.md's "Supply as social infrastructure" section as an earlier instance of the same reliability the May 2026 failure later broke.
- Surveyed remaining large unmined dox-md/dox-scan files (_Openclaw Agent Setup, fullcombo 2.txt, Attachment System Collapse.md, _Two Options Choose Wisely) — Openclaw is generic AI-tooling troubleshooting (low biographical value); Attachment System Collapse.md is a ChatGPT restatement of the already-extensively-documented Annie gaslighting/perceptual-trust thesis (no new facts found in a full scan). Deprioritized both per the "most important/influential" directive.
- Gates: wiki-lint 0 errors (335 pages), wiki-connect check 0 errors.

## [2026-07-20] ingest | interests | batteries-not-included.md (new) — operator-directed
- wiki/interests/music/bands/batteries-not-included.md (new): Dan's high school band with Joe Oshnack and Matt Turko (operator-identified name, confirming the "BNI" abbreviation seen in joe-oshnack.md). Consolidates the setlist reconstruction (Misfits, Dead Kennedys, Ramones, NOFX considered-and-rejected, a CKY rehearsal-only cover), the Sept 2021 political retrospective on covering "California Uber Alles" without understanding its politics, and the surrounding hardcore/punk scene (Seth LeDonne's named mentors, "Rejected Gazette"). Updated joe-oshnack.md and seth-ledonne.md with cross-links; resolved the "what BNI stands for" gap previously flagged on joe-oshnack.md.
- Gates: wiki-lint 0 errors (336 pages), wiki-connect check 0 errors.

## [2026-07-20] fix + ingest | interests/timeline | PR #57 bot fix; blocked-caller crisis event
- fix: batteries-not-included.md misattributed "96 Quite Bitter Beings" to NOFX — it's a CKY track (from the band's 1999 album *Volume 1*), correctly caught by bot review after PR #57 had already merged. Fixed in a follow-up commit since the merge raced the fix.
- wiki/timeline/events/april-may-2026-final-weeks.md: substantially expanded the previously thin "unresolved third-party contact (April 1)" bullet using raw/self/dox-md/Crisis mode briefing.md — a recurring blocked-caller impersonation campaign targeting Suz directly (personally insulted as a "junkie," a hostile "you had guys molest me" message to Dan, a threat from Suz to do something "arrest-worthy"), with a forensic case (Suboxone misnamed "heroin/Percocets," register mismatch, absent name-use) arguing against it being Annie personally — though her awareness/complicity is explicitly left unresolved, matching the source's own honesty about not identifying the caller. Also documents a live, real-time instance of the conflict-engine mechanism (a screaming match with Suz over whose grievance mattered more) already documented at scale elsewhere. Added connections + source to wiki/people/suzanne-frank.md.
- Gates: wiki-lint 0 errors (336 pages), wiki-connect check 0 errors.

## [2026-07-20] ingest | mind | ai-collaborative-analysis.md — ghostwriting vulnerability, then declining to send it
- wiki/mind/synthesis/ai-collaborative-analysis.md: added a new documented interaction mode from the same Crisis mode briefing.md source — Dan asks an AI to draft an explanatory letter to Suz with no restrictions on included criticism; the model produces genuinely vulnerable first-person material (owning the "would choose Annie over anyone" admission), which Dan then declines to send in his own voice, asking instead for third-party mediated framing. A new pattern beyond the already-documented memory/forensic/honesty-enforcement uses: outsourcing the authorship of vulnerability itself.
- Gates: wiki-lint 0 errors (336 pages), wiki-connect check 0 errors.

## [2026-07-20] ingest | work | ai-video-essays.md (new)
- wiki/work/tech/ai-video-essays.md (new): a 2026 planning-stage project — long-form (30-60 min) video essays about AI for non-technical audiences, reverse-engineered from a Some More News structural analysis into a reusable five-element framework (thesis/conceit/evidence chain/tonal modulation/demonstration). No script or video was ever produced. Notable moment: Dan's first concrete pitch (millennials mistake AI for crypto 2.0) was stress-tested against real adoption data at his own request and came back contradicting his premise — he accepted the correction rather than defending the original claim, a real instance of the honesty-enforcement pattern applied to a personal creative ambition.
- Gates: wiki-lint 0 errors (337 pages), wiki-connect check 0 errors.

## [2026-07-20] ingest | mind/health | attachment-model.md + hyperreflexivity.md — "mojo and magic" and the parasitized-loop reframe
- wiki/mind/concepts/attachment-model.md: added a new self-described concept — Dan's "mojo and magic," an "attraction outcome thing" felt as functionally absent since Annie — reframed by the same AI session as captured rather than deactivated (locked onto the one target where the feedback loop can't close). Adds a sharp comparative data point: seven years living with Alexis with no future ever mentally built, contrasted against Annie as the first full attachment-system activation.
- wiki/health/hyperreflexivity.md: added a follow-up session's reframe of the anxiety loop as largely "parasitized" by the unresolved Annie situation and a "post-June housing void" rather than a freestanding clinical pattern — signal, not noise.
- Gates: wiki-lint 0 errors (337 pages), wiki-connect check 0 errors.

## [2026-07-20] rewrite | people | swarm-stub batch 1 of 3 (aaron, charles-davenport, dakota, josh-brannan, maddox)
- Rewrote 5 untouched 2026-06-23 swarm-template stub pages (identified by date_created==date_modified plus the literal "## Identity / ## Corpus Dimensions / ## Domain: Self / ## Notes / ## Related" fragment-chain shape) to current STYLE_GUIDE prose + typed `connections:`.
- wiki/people/aaron.md: the "thin 38-message stub" turned out to hold a real-time, same-day reaction to the Sept 11, 2025 Charlie Kirk assassination ("I mean I don't think killing CHARLIE KIRK solves anything...But I'm not upset about it"), plus earlier warmth toward the Luigi Mangione killing — previously entirely undocumented outside the archived wiki/self/twitter.md. Added parallels connection to wiki/self/twitter.
- wiki/people/charles-davenport.md: converted a 4-message table into prose; added a co-occurs connection to the new wiki/places/424-bedford-ave.md (the Jan 2010 exchange lands in the Brooklyn-arrival window).
- wiki/people/dakota.md and wiki/people/maddox.md: both rewritten as short pages pointing to wiki/work/bfs-foods.md's existing "## The cast"/"## The Timmy precedent" sections rather than re-narrating the Timmy blame-pivot chain a third time; each keeps its distinguishing detail (Dakota = originating hearsay disclosure; Maddox = fuller first-person May 21 sidewalk corroboration, full quotes preserved).
- wiki/people/josh-brannan.md: fresh-mined the raw FB thread (41 messages, previously only partially represented) — a warm Feb 2017 reconnection with an old Uniontown friend, including an unprompted, undefensive admission of the webcam-modeling job ("DUDE IM A MODEL WE ARE MODEL BROS"). Added parallels connection to wiki/people/jerad-friedline.md re: the separate "josh brannan is innocent.wav" running joke.
- Updated wiki/people/index.md one-liners for all 5.
- Gates: wiki-lint 0 errors, wiki-connect check 0 errors.

## [2026-07-20] ingest | people | operator-provided full two-sided iMessage exports (shelbie-breakiron, dimitri, alexis-armel, bekah-fullem)
- Operator gained a new extraction capability (both sent+received, not just received) and supplied full exports for 4 threads previously limited to one-sided or unreliable-direction data. Filed to raw/self/message-csv/ as imessage_export_<number>_both_all_now.csv.
- wiki/people/shelbie-breakiron.md: full rewrite. The real thread is 685 messages (not the 306 previously extracted) — reveals the relationship as an explicit "sugar dad" arrangement (Dan financially supporting her camming/stripping work, a $5,000 figure, a laptop), full visibility into Dan's flat, unbothered replies during the July 16 2019 breakup tirade (previously only her side was visible), and a previously-undocumented August 2019 legal-threat follow-up ("i'll be stopping by with a few state troopers").
- wiki/people/dimitri.md: resolved the page's own flagged gap ("0 sent? needs a corpus re-check") — the full 116-message export shows Dan replied regularly; the earlier one-sided read was a direction-field artifact. New content: restaurant-industry shop talk, a genuine Alexander-the-Great/Macedonian-Greek-identity argument, a 2024 political exchange, and a first-person, contemporaneous account of the Aug 21 2024 Au Za'atar job loss ("They officially let me go... We parted on good terms").
- wiki/people/alexis-armel.md: replaced the "41 messages, received-only" framing (the post-breakup 2020-2025 channel) with the full 88-message two-sided record — a real, warm, intermittent friendship (Twitch streaming plans, 2020-election commentary, a shared friend's death by domestic-violence-linked suicide processed together in real time Jan 2021) that ends on a small poignant note: a February 2025 wrong-number exchange where Alexis doesn't recognize Dan's number.
- wiki/people/bekah-fullem.md: full rewrite with a real correction — the previous version had the March 29 2020 pandemic-severity exchange backward, describing Bekah as pushing back against "Dan's skepticism." The full export shows the opposite: Dan is the one insisting COVID is worse than reported (frontline NYC vantage), Bekah repeatedly says she already knows. Also resolves whether the Feb 2020 cat-medication money was sent (yes — an image + "that'll even the score"), surfaces a pre-existing flirtation before the crisis contacts, and documents Dan's actual (warm, appropriate) response to her rape disclosure. Surfaces one major new, unverified fact: Dan tells Bekah that Annie is herself a rape survivor with a 45-year sentence for the assailant — added to wiki/people/annie-ulmer.md as an explicitly flagged, single-source, unverified claim (evidences/evidenced-by connection pair).
- Updated wiki/people/index.md one-liners for all 4.
- Gates: wiki-lint 0 errors (337 pages), wiki-connect check 0 errors.

## [2026-07-20] rewrite | people | swarm-stub batch 3 of 3 (sean-teets, shannon) — final batch, all 12 swarm stubs closed out
- wiki/people/shannon.md: fresh-mined the full 23-message iMessage thread previously represented by only its opening line — reveals Shannon was a real estate client who hired Dan for drone photography/video, Nov 2018 – Jan 2019 (scheduling, listing-photo delivery, one file-delivery friction point), the corpus's only documented instance of Dan doing paid drone work for a client.
- wiki/people/sean-teets.md: converted the 7-message table to prose; identified the two outreach messages ("looking for tax or strpz"; "Mushys and k") as likely supply-seeking language consistent with wiki/health/chemical-architecture.md's substance vocabulary (mushrooms, Suboxone strips, ketamine), added as a co-occurs connection with an honest caveat that Sean's specific role isn't established.
- Updated wiki/people/index.md one-liners for both.
- Closes out the 12-page swarm-stub rewrite task in full (batch 1: aaron, charles-davenport, dakota, josh-brannan, maddox; batch 2: marc-charles, marty-martin, max-danielle-bf, michael-hinkle, ryan-lisac; batch 3: sean-teets, shannon).
- Gates: wiki-lint 0 errors, wiki-connect check 0 errors.

## [2026-07-20] fix | people | PR #59 bot review — wikilinks + truncation-safe openers
- Addressed 6 gemini-code-assist review comments on PR #59: converted plain-text `bfs-foods`/`jerad-friedline` references to wikilinks in wiki/people/index.md, dakota.md, and josh-brannan.md connections claims; split the overlong opening sentences on dakota.md and maddox.md that were causing the auto-generated llm/manifest.json summary to truncate mid-link.
- Gates: wiki-lint 0 errors, wiki-connect check 0 errors.

## [2026-07-20] rewrite | people | swarm-stub batch 2 of 3 (marc-charles, marty-martin, max-danielle-bf, michael-hinkle, ryan-lisac)
- wiki/people/marc-charles.md: converted an 85-message golf/music thread into prose — a 2018 golf-equipment-and-scores exchange plus a warmer 2017 mutual sobriety-milestone acknowledgment ("I'm 7 years clean from opiates" / "4 years in august") tied to old shared music recordings.
- wiki/people/marty-martin.md: full prose conversion of the BFS Foods trusted-source page — the "make the store whole to keep your job" framing that anchors bfs-foods.md's structural (not isolated) reading of the drawer-shortage dispute, plus the Suz-relay channel (chili/goulash question, a later job-lead message) and a specific shift-cover reliability example.
- wiki/people/max-danielle-bf.md: condensed a dossier-style page of long verbatim quote blocks (violating the quote-sparingly rule) into prose — Dan handing Gemini a recording of Danielle's boyfriend and requesting a full personality analysis; Gemini's "mirror image" / "Recursive Cognitive Machine" read.
- wiki/people/michael-hinkle.md: previously near-empty placeholder; mined the raw 3-message FB thread (one-sided, unanswered, references Annie and "i found us something").
- wiki/people/ryan-lisac.md: preserved the page's own honestly-flagged gap (the "Snob Squad" childhood narrative isn't present in the ingested raw corpus) rather than inventing content; added the genuinely new finding that Dan's 2026 DJ-identity relaunch deliberately reuses the "Snob Squad" name as a callback — added a parallels connection + inverse edge on wiki/mind/synthesis/totality-themes.md.
- Updated wiki/people/index.md one-liners for all 5.
- Gates: wiki-lint 0 errors, wiki-connect check 0 errors.

## [2026-07-20] ingest | places | 90th-st-manhattan.md (new), seven-springs.md (new)
- wiki/places/90th-st-manhattan.md (new): fills the previously-missing third year of NYC-1 (Mar 2012 – Apr 2013) — the Manhattan UES sublet between the two better-documented addresses. Anchors the Feb 2012 Creative License exit (airfare-billing discrepancies, altered intern contracts) as the founding case for vertical-authority-skepticism, fourteen years before its BFS Foods recurrence, and correctly re-dates the Hurricane Sandy/Bridge Cafe job-loss shock to this address's occupancy rather than the earlier Bedford Ave years.
- wiki/places/424-bedford-ave.md: corrected the Sandy/Bridge-Cafe attribution (the closure happened six months after the household had already moved to 90th St, not during the Bedford Ave years); added the wikilinked follow-on to the new page.
- wiki/places/seven-springs.md (new): the childhood ski-resort social anchor — weekly ritual, family condo (The Villages, Sunridge Unit K2), and the first drug-exposure cohort, with first cocaine use dated 2004 — a full year before the Nov 2005 family-rupture hinge event usually credited as the addiction narrative's start. Notes the regional freeskiing-culture backdrop (Tom Wallisch's home turf) as adult-interest context, not a personal connection.
- Updated wiki/places/index.md.
- Gates: wiki-lint 0 errors (339 pages), wiki-connect check 0 errors.

## [2026-07-20] ingest | health/mind | tooth-loss/bulimia link (hyperreflexivity.md), bunker-core.md (new)
- wiki/health/hyperreflexivity.md: added a fourth compounding stressor from the same mid-2025 AI session — Dan's disclosure of losing two teeth, with his own causal chain back to teenage bulimia, candy as a dietary staple, dentist avoidance, Suboxone, and cigarettes. The corpus's clearest first-person link between the eating disorder documented on dark-era-2007-2008.md and a specific, dated adult physical-health outcome. Also corrected an overclaim on chemical-architecture.md ("no detox attempt") — a Dec 8, 2015 exchange, ten days into the Annie relationship, shows a real (if apparently unsustained) joint cold-turkey pact.
- wiki/mind/concepts/bunker-core.md (new): consolidates a named local technical project — SQLite-based forensics on Dan's own chat.db, "Epistemic Verification," shipped alongside the Gumroad iMessage Analysis Toolkit (Feb 2026) — previously scattered as passing references across 4 pages with no dedicated treatment. Carefully separates the documented software fact from an AI-authored "epistemic fortress" interpretive framing found in the source material, flagging the latter as plausible-but-not-Dan's-own-words.
- Gates: wiki-lint 0 errors (340 pages), wiki-connect check 0 errors.

## [2026-07-20] connect | mind | connection-queue.md top-5 processed
- Worked the top of connection-queue.md (mined candidate connections, sorted by score): wiki/mind/synthesis/attachment-trauma-bond.md <-> wiki/timeline/events/eli-incident.md (evidenced-by, both directions, plus a prose wikilink fix from the person page to the event page); wiki/mind/concepts/forensic-method.md <-> wiki/work/tech/max-framework/overview.md (instance-of/contains); wiki/mind/concepts/forensic-method.md <-> wiki/mind/synthesis/attachment-trauma-bond.md (instance-of, both directions); wiki/mind/concepts/conflict-architecture.md <-> wiki/mind/synthesis/attachment-trauma-bond.md (mirrors, both directions); wiki/mind/synthesis/political-psyops.md <-> wiki/mind/synthesis/totality-themes.md (component-of/contains).
- Struck all 5 as done in connection-queue.md.
- Gates: wiki-lint 0 errors (340 pages), wiki-connect check 0 errors.

## [2026-07-20] ingest | interests/mind | Google Drive "**DOX" folder — crate data + Phase 2 stylometrics
- Operator pointed at a local Mac path; confirmed via Drive search this maps to the "**DOX" Google Drive folder already partially imported as raw/self/google-drive-export/ (only 6 of 34 top-level items had landed — the "DOX2" import from 2026-07-13 was never completed per queue.md's own plan). Pulled and checked the most promising unimported items.
- wiki/interests/music/aliases/gripnotic.md: new "Current DJ crate (2025)" section from a Spotify playlist export (232 tracks, raw/self/favorites/2025_MASTER_CRATE.csv) — first quantified picture of current mixing practice: 59% of tracks from 2025 itself, genre weights (dubstep 63, bass music 59, bass house 54, tech house 34, riddim 29), avg energy 0.80, avg tempo 133 BPM, no single dominant artist (Fred again.. leads at 6 tracks).
- wiki/mind/profile/linguistic-profile.md: new "Audience-based code-switching" section from a previously-unmined "Phase 2 Stylometric Analysis" doc (raw/self/dox-md/Phase_2_Stylometric_Analysis.md) — a distinct organizing axis (romantic/platonic vocabulary, supportive/conflict linguistic signatures) alongside the existing emotional-state-mode framework; added a parallels connection + inverse edge with voice-modes.md.
- Added connections: blocks (previously absent) to socionics-and-attitudinal.md (evidences forensic-method.md) with inverse edge.
- Deprioritized two other checked items: "_AI Protocol for Persuasion.md" (confirmed to be the same GLAZE-GOD-v1 material already documented on erotic-architecture.md — no new content); SPOTIFY LIKED (END 2025).numbers (Apple Numbers binary format, not convertible via available tools — skipped).
- Marked the stale "Target G" queue.md item as verified-already-done (fully documented on annie-ulmer.md and suzanne-frank.md, contrary to the backlog note).
- Gates: wiki-lint 0 errors (340 pages), wiki-connect check 0 errors.

## [2026-07-20] ingest | health | ADDICTION PROFILE doc — genesis chronology + cocaine dosage arc
- Continued the "**DOX" Drive folder sweep into the FULL DATA STACK subfolder. Checked ADDICTION PROFILE, SEXUAL PROFILE, and Favorites/FAVORITES DATA docs.
- wiki/health/chemical-architecture.md: new "System genesis: a phased history" section from raw/self/dox-md/ADDICTION_PROFILE.md — genuinely new dated facts: cocaine first entered the household as a known concept at age 13 (2001), predating the Nov 2005 family rupture by 4 years; a November 2007 Las Vegas trip newly dated as the point physical opiate dependence became undeniable; a winter 2008 single heroin attempt rejected on aesthetic grounds ("felt dirty"); and the corpus's first quantified cocaine dosage arc — ~1g/day baseline escalating to 3.5-7g/day during the 2017-2020 inheritance-funded window, contracting back to ~0.5-1g/day from 2020 as the inheritance was exhausted (a resource adjustment, not a step toward moderation, per the source's own framing). Added connections + inverse edges to seven-springs.md and dark-era-2007-2008.md.
- SEXUAL PROFILE doc: confirmed to overlap heavily with already-documented ground (erotic-architecture.md, psychosexual/ cluster — same ELI_INCIDENT, externalized-libido, taboo-as-rupture concepts) — deprioritized, archived only.
- Favorites / FAVORITES DATA docs: confirmed near-duplicates of the already-ingested raw/self/favorites/FAVS MASTERLIST.csv (matching movie list already on film-canon.md, matching concert list already on timeline/events/teen-concert-years.md) — no further action needed.
- Gates: wiki-lint 0 errors (340 pages), wiki-connect check 0 errors.

## [2026-07-20] ingest | mind | spatial-behavior.md (new) — GPS forensic analysis
- PR #59 merged; restarted branch from origin/main. Operator broadened scope: mine anything in the full Google Drive, including hard-drive scans.
- wiki/mind/synthesis/spatial-behavior.md (new): a behavioral/psychographic reading of Google Location History data (raw/self/dox-md/GPS_ANALYSIS.md), distinct from and built on top of the raw visit-count catalog on wiki/self/location-history.md (left untouched — status: archived). Core finding: movement resolves into four sharply-bounded life phases rather than gradual drift — "The Forge" (2014, Uniontown baseline), "The Binary System" (2015-17, the Annie two-node oscillation straining under its own cost), "System Collapse & Migration" (2018-19, over a third of the entire 2014-2020 aggregate travel distance logged in 2018 alone, resolving in the NYC move), and "The Siege of Manhattan" (2020 COVID compression). Explicitly flags a methodological caution the source material doesn't raise itself: the low-novelty/high-routine spatial signature is read there as a chosen psychological strategy, but chronic financial constraint (documented independently on 2017-poverty-floor.md/2018-deep-cycle.md) would produce an identical signature for different reasons — added as a contradicts connection rather than silently endorsing the source's framing.
- Gates: wiki-lint 0 errors (341 pages), wiki-connect check 0 errors.

## [2026-07-20] fix | mind/timeline | PR #60 review response
Addressed 3 gemini-code-assist review comments on spatial-behavior.md:
split truncated opening sentence, corrected location-history connection
type instance-of -> contextualizes, added missing inverse connection on
2017-poverty-floor.md. Gates clean (0 errors). Regenerated llm/. All
three review threads resolved on GitHub.

## [2026-07-20] triage | interests | BOOKS.csv (Drive/MEMORY) duplicate check
Downloaded and reviewed BOOKS.csv (Drive MEMORY folder, Goodreads export
format). Confirmed duplicate of raw/self/google-drive-export/goodreads_library_export.md
already cited on wiki/interests/favorites/books.md — every distinctive
title checked (Carlin, Holland's Rubicon, Goldsworthy's Caesar, Shirer,
Bird's American Prometheus, and the Jacob Bacharach "Doorposts" 5-star
2022 read) is already captured on that page, including the specific
jacob-bacharach.md cross-link. No new signal. Deprioritized, no wiki changes.

## [2026-07-20] triage | self | Drive "MEMORY" folder confirmed duplicate archive
Sampled 4 files from Drive MEMORY/STORYTIME folder (id 1eAILXQoPk6owa7_nfFx0mZU6xBCHdL8j):
BOOKS.csv (dup of goodreads_library_export.md, see prior log entry),
"Dan Frank_ Profound Psychological Speculations_" (= the exact DANSYNTH
source already synthesized as wiki/mind/synthesis/ancestral-dialectic.md),
"Fraan" storytime doc (= source of wiki/timeline/events/fran-death-vigil.md,
same 8am/keno/IMG_0569.MOV details verbatim), "Au Za'Atar" storytime doc
(= source of wiki/work/au-zaatar.md, same Dimitri/Tunisian-manager/Sergio
details verbatim). Conclusion: this Drive folder is a re-uploaded backup
of the already-mined DANSYNTH/STORYTIME corpus, not new material.
Deprioritizing remaining unopened items in this folder (2_PHENOMENOLOGY
PROFILE.md, 1_CORE PROFILE.md, FULL PROFILE 2026.md, THE_DAN_FRANK_BOOTLOADER.md,
Location History subfolder, MUSIC LIST(start-2024).csv, YOUTUBE WATCH HISTORY
html — all by-name matches to already-ingested raw/ sources) without
opening each individually. Moving to the flagged-high-priority "NEW LOADER"
folder (OMNI_FORENSIC_DOSSIER.md, THEORY OF EVERYTHING 31 MAR) next.

## [2026-07-20] ingest | mind | OMNI_FORENSIC_DOSSIER + BIBI_PERSONALITY_DECONSTRUCTION (Drive NEW LOADER)
Mined two AI-generated forensic corpus analyses from Drive's flagged
"NEW LOADER" folder. Both heavily overlap already-ingested material
(exact-match numbers with linguistic-profile.md: 23,286 vocab, "because"
2,465, "I don't" 1,845, "I'm not" 814 — confirms same underlying NLP
extraction) but contained three genuinely new signals, added to the wiki:
(1) a whole-corpus yearly message-volume arc 2015-2026 added to
message-circadian-latency.md — first hard numbers for the 2021-2022
near-total-silence trough (280 + 4 msgs) and precise 2018/2025 peak
figures (40,514 / 41,278, within 2% of each other), with inverse
connections added to 2018-deep-cycle.md and 2025-collapse.md; (2) a
camming/non-monogamy word-frequency table added to
wiki/mind/psychosexual/arrangement-history.md (304 camming tokens vs 107
non-monogamy/kink tokens, ~3:1); (3) the "Broken Engine" self-mythology
framing ("weaponized self-awareness as preemptive strike") cross-referenced
into deviance-mapping.md's existing "Mythology of Ruin" outlier entry.
Archived both source docs to raw/self/dox-md/. Gates: 0 errors both.
Remaining NEW LOADER items (THEORY OF EVERYTHING 31 MAR, podcast
transcript, Stylometric/Linguistic docs, masterloader PDFs) not yet
checked — next up.

## [2026-07-20] ingest | people/timeline | End Fight podcast transcript (Drive NEW LOADER)
Mined a NotebookLM-style AI podcast dramatization of the already-documented
May 31-June 1 2026 End Fight / group-chat closure. Confirmed the core event
is already extensively covered (end-fight.md, group-chat-closure.md,
tuquick-17248123683.md, dan-annie-fallout-verdict.md) but the podcast
supplied granular detail not previously captured: Dan's absurdist
derailment tactics used against Tuquick (TRANS RIGHTS ARE HUMAN RIGHTS,
Carthage geography, Israel non sequitur), Tuquick's mid-fight de-escalation
(laughing, "no hard feelings") two weeks before his already-documented
June 15 defection, Annie's false broken-finger claim debunked by Tuquick
himself, the exact 23:54 verbatim/timestamp of the false sexual-assault
accusation, and — genuinely new fact — a prior ~May 26 2026 incident where
Tuquick spent three hours harassing Suzanne Frank by phone, five days
before the main confrontation. Added as a REVISED block on
tuquick-17248123683.md (correcting the prior "remained focused on the
attack" framing), a new section on suzanne-frank.md, and a verbatim/date
addition to group-chat-closure.md's Data Record — all flagged as sourced
from a secondary AI dramatization pending raw-row confirmation, consistent
with the corpus's existing primary-recount discipline. Also checked
THEORY OF EVERYTHING 31 MAR (Drive NEW LOADER): confirmed its
quantified claims (74/17/11 abuse triad, 1,512/232/180 triad, 299
affirmations, 187:4 test) are already incorporated and independently
re-verified on dan-annie-fallout-verdict.md; its "Girlfriend Score"
framing (Annie 1.9/10 vs Alexis 7.1/10) is new packaging of already-
captured stats, not new signal — not added. Podcast transcript archived
to raw/self/dox-md/. Gates: 0 errors.

## [2026-07-20] triage | self | NEW LOADER folder remaining items checked
Checked remaining unopened items in Drive NEW LOADER folder: "extract"
(a chat.db SQL-query-generation prompt, confirms already-documented
bunker-core.md tooling, no new signal) and "load" (the MAX persona master
system prompt, already documented on wiki/mind/concepts/exocortex.md's
bootloader list — "MAX_KERNEL_DUMP_V2," radical-skepticism/normie-filter
framing matches exocortex.md's existing MAX summary). Stylometric Profile
docs and Phase 2 Stylometric Analysis previously confirmed already-ingested
(linguistic-profile.md). Not opened: masterloader.pdf/masterloader2.pdf
(binary PDFs, likely compiled versions of already-seen bootloader text),
messages_2124702449.csv alias (916 bytes, likely a stub/shortcut file not
real data), .DS_Store (not content), an .mp3 audio file (out of scope for
text mining). NEW LOADER folder considered fully triaged. Next: the two
large ChatGPT conversation-export JSONs (dfrankconversations.json ~35.7MB)
flagged earlier as a genuinely new, unopened AI-chat corpus distinct from
the Gemini archive — needs dedicated download+extraction handling in a
future pass given size.

## [2026-07-20] ingest | timeline | ChatGPT export first pass — Feb-Apr 2025 gap filled
Operator directly uploaded the ChatGPT conversations.json export (375
conversations, 2022-12 to 2025-07) after Drive's own MCP tools proved too
size-limited for it (download_file_content times out; read_file_content
mangles JSON with markdown-escaping and truncates at ~900K chars). Full
export archived to raw/self/chatgpt-export/dfrank-chatgpt-conversations-2022-2025.json.
Sampled ~10 conversations. "Mom Info Logged" confirmed fully duplicate of
already-ingested biography (Danielle/Franki/Alexis/Annie dating chronology,
Fran/Arnold Palmer/Ira Coldren) — strong confirmation of wiki completeness.
"Relationship Breakdown Summary" (2025-04-27) was genuinely new: mined into
a new page, wiki/timeline/periods/feb-apr-2025-return-and-rupture.md,
filling the previously undocumented Feb-April 2025 gap between the January
2025 affair discovery and the Aug-2025-onward terminal-phase record already
on dan-annie-fallout-verdict.md. New facts: the NYC apartment "shot clock"
exit (~$10k owed + $7k ConEd bill), Annie's unilateral move to her parents
against Dan's open-ended funded-apartment offer, and — genuinely new to the
corpus — Suzanne Frank's 2024 personal bankruptcy and a spring-2025 listing
attempt on 337 Saratoga Drive a full year before the eventual 2026 sale
already documented on suzanne-frank.md. Added connections to
2025-collapse.md, suzanne-frank.md, annie-ulmer.md, dan-annie-fallout-verdict.md,
and a timeline/index.md entry. "Whisk AI Prompt Injector"/"Whisk Emergency
Fabric Design" checked and ruled OUT as related to the documented
fabricated-evidence pattern (false lead from title similarity — both are
unrelated jailbreak/creative-writing tangents). Remaining ~365
conversations tracked in queue.md as a multi-pass backlog, prioritized:
Camming Career Review, Babbitt Shooting Psy-Op Debate (possible original
J6 source predating the Gemini-based material), the facial-feature/
ideal-face cluster (~12 convos, purpose not yet understood), Interpersonal
Analysis Request, Breakup Brain Dump, Personality Breakdown IRL. ~180
early 2022-2023 conversations are generic political/history discussion,
spot-checked and deprioritized as low-yield. Gates: 0 errors.

## [2026-07-20] triage | mind | ChatGPT export follow-up: Babbitt psyop + camming review
Checked two more flagged ChatGPT conversations. "Babbitt Shooting Psy-Op
Debate" (2025-06-15) confirms rather than extends the already-documented
J6 "Operation Wildfall" hybrid thesis, but is dated 7 months before the
Gemini codification and on a different AI platform — added as a
chronology note to political-psyops.md. "Camming Career Review" (2025-06-07)
turned out to be an image-analysis conversation with no extractable new
facts (AI flourish responding to uploaded screencaps, not text data) —
no wiki action, logged as lower-value-than-title-suggested in queue.md.

## [2026-07-20] ingest | people | operator-provided Mike Cordaro export (imessage_17243226739_both_all_now.csv)
Filed a proper per-contact export (50 messages, reliable Sent/Received
direction) to raw/self/message-csv/, superseding the earlier 28-message
partial pull off the unreliable-direction master CSV. mike-cordaro.md
Corpus Dimensions corrected (28 -> 50 msgs; direction now confirmed
reliable, genuine two-way conversation). Texture section expanded with
the full 2024-election exchange (Mark Kelly/Shapiro/Walz/Bernie-endorsement
reasoning on both sides, the "DEI hire" line, the enthusiasm-boost-on-18-35
argument) previously only summarized. Converted the bare related:/##
Related footer to a typed connections: block — a new `parallels` edge to
rick-frank.md (the "maga-tized dads" framing), with inverse added on
rick-frank.md. Gates: 0 errors.

## [2026-07-20] correction | mind/timeline/people | Eli discovery text + two other flagged claims upgraded [DOSSIER]->[RAW-CSV]
Operator uploaded a fresh export of Annie's current 212 number
(imessage_export_2124702449_20260720210349.csv, Aug 2025-Jun 2026) flagging
the Eli discovery text as locatable within it and specifically dated. Cross-
check found it a near-duplicate of already-filed raw/self/message-csv/
imessage_2124702449_both_all_now.csv (same window, 23448 vs 23719 rows) —
NOT re-filed to avoid raw/ duplication. Neither file covers Jan 2025 (both
start effectively Aug 2025 with only stray isolated rows before that), so
the Eli text itself (Jan 9 2025) is not in this specific export — but the
question prompted a wider re-search that found it elsewhere in already-
filed raw/: raw/self/message-csv/imessages_2124702449_last6months.csv and
raw/self/dox-scan/all_imessages_complete_dump.txt both have the full six-
message rapid-fire sequence starting 2025-01-09 23:18:49, verbatim. The
2026-07-18 pass had searched for the quote as one string and missed it
because iMessage sent it as six separate messages. Primary-confirmed
sequence entered on eli-incident.md (REVISED block) and eli.md, including
a genuinely new fact: Dan's own real-time reply, "Who are you?", sent
23:19:42 between Eli's third and fourth messages — not previously
documented anywhere in the corpus. dan-annie-fallout-verdict.md's "What
still needs primary verification" section updated: Eli text resolved;
the Mar 16 2026 "I misunderstood the conversation" retraction line also
found already sitting in imessage_2124702449_both_all_now.csv (2026-03-16
18:47:51) — same story, a prior pass's search missed it; and the "Jan 24
procurement line" resolved to the Jan 24 2026 ketamine-procurement
messages (Tom's 2am delivery; "I grabbed some ketamine for us"). Three
flagged gaps closed in one pass, all from data already on disk. Gates:
0 errors.

## [2026-07-20] ingest | work | DANMODEL — new page, a working voice-cloning ML pipeline
Mined the Drive "DANMODEL" folder queued earlier this session. Filed
raw/self/danmodel/extraction_summary.txt, PIPELINE_NOTES.md (architecture
transcription of 5 Python scripts — a byte-exact copy attempt corrupted
during manual base64 reconstruction, so this is a faithful logic
transcription instead, with original Drive file IDs cited for provenance),
and reaction_pairs_heldout.jsonl (4,570 rows, verbatim, mechanically
decoded and verified against the summary count). New page
wiki/work/tech/danmodel.md: a from-scratch pipeline that extracts 39,378
stimulus-response pairs from Dan's own message corpus (verified: Annie
early alone = 40% of the total, corroborating contact-gini's 0.961
concentration in an independent metric; year distribution independently
reproduces the already-documented 2018 deep-cycle and 2025-collapse
peaks), builds both a naive Jaccard-retrieval baseline and a TF-IDF+RAG
generator wrapped in a self-authored "CATO_COMPACT" voice-persona prompt
(preserved verbatim — genuinely new primary data on how Dan characterizes
his own texting signature), and designs a rigorous blind LLM-judge eval
(neutral-labeled real-vs-fake, leakage assertions) to test whether the
clone passes for him. Notable finding: no eval_results file exists
anywhere in the Drive folder, so whether the blind test was ever completed
— and what it found — is a genuine, flagged gap, not a negative result.
Wired into wiki/mind/concepts/exocortex.md, wiki/work/tech/mneme/overview.md,
wiki/mind/synthesis/ai-collaborative-analysis.md, wiki/people/annie-ulmer.md,
and wiki/mind/concepts/contact-gini.md (5 typed connections + inverses),
and wiki/work/tech/index.md. Gates: 0 errors.

## [2026-07-20] ingest+correction | self/mind | fresh YouTube Takeout export -- multi-account caveat found and applied
Operator found a new Google Takeout export in Drive (created today,
890MB, too large for this session's download tooling) and supplied the
watch-history.html directly after unzipping it locally. Filed to
raw/self/youtube-watch-history/YOUTUBE WATCH HISTORY (2010-2026-07-20).html
(19MB, extends real coverage to 2026-07-20, ~1 year past the old export's
Jul 25 2025 cutoff). Verified re-parse found 14.1% of the OLD export's
"Watched" entries are Google Ads impressions, never previously broken out
from real content in this page's published counts. Initially flagged (in
error) a ~100-day near-zero-real-watch window, Nov 8 2025-Feb 15 2026, as
a candidate contradiction of intake-constancy.md's flat-rate thesis --
**operator corrected this directly and immediately**: this Google login
has multiple YouTube accounts, he was using a different one during that
window, and true daily watch volume is confirmed higher than either the
existing 11.58/day figure or this session's ad-filtered 9.53/day
recomputation. Both figures downgraded from "verified constant" to
"single-account lower bound" on intake-constancy.md (inline flag in the
Two Constants section + expanded Gaps entry with the correction recorded
in full) and on youtube-watch-history.md (REVISED/operator-correction
blocks). New "Extended coverage" section added to youtube-watch-history.md:
the Aug2025-Jul2026 monthly real-vs-ad table, new top channels for the
window (Breaking Points, LastWeekTonight, Majority Report continuous with
the existing 2022+ diet; Tor's Cabinet of Curiosities, We're In Hell,
JREG, STRANGE AEONS, exurb1a, DJ Peach Cobbler new to the corpus), and the
June-July 2026 finding that apparent high raw volume is 80-96% ad noise,
real watching comparatively modest. Status changed archived->active
(page is not under an archive/ dir and is now an actively growing
dataset). 6 connections added/updated across youtube-watch-history.md,
intake-constancy.md, and march-2026-terminal-phase.md (with inverse).
**Lesson: verify a striking data-driven finding with the operator before
treating it as settled, especially when the corpus's own governing page
(intake-constancy.md) explicitly names "check for a routing/account
artifact first" as the required discipline for exactly this situation.**
Gates: 0 errors.

## [2026-07-20] ingest | people/work | Tarik Fallous full per-contact export — REVISED, no-message-corpus claim was wrong
Filed raw/self/message-csv/imessage_19178259183_both_all_now.csv (80
messages, Aug 2023-Apr 2026, reliable direction). This directly
contradicts the page's prior claim that "no direct message thread exists"
for Tarik — REVISED block applied. tarik-fallous.md substantially
rewritten with a new Direct Correspondence section: employment-logistics
texture not documented elsewhere (grocery-run errands on Tarik's own
Barclays card, two verbatim wine/liquor inventory counts, hiring-interview
coordination, a Dec 2023 payroll dispute, 5 sick-day call-outs, an Arabic
wedding-congratulations exchange) plus a genuinely new post-termination
finding: Dan kept passing Tarik informal workplace "CIA agent" intel 13
days after filing for unemployment, and the two remained in warm, openly
political contact through Apr 12 2026 (Lebanon-conflict solidarity
messages, Sep 2024 and Apr 2026) - nearly two years after the job ended.
Five new unresolved names surfaced: Modi, MD, Patricia, Khalid, Hani.
Status changed closed->active (relationship is ongoing, not closed with
the employment). Converted related: to typed connections: (4 edges +
inverses on au-zaatar.md and ismaila-barry.md); au-zaatar.md gained a
corroborating sentence on the de facto-manager role. Gates: 0 errors.
