repo: caakehorn/leviathan
branch: main

## Last sync

date: 2026-08-14T20:05:38Z

### Updated in this project

- New mobile-first entry: splash (particle wordmark) → seal → radial dial hub with five sections.
- Two-wing Singularity / Temple fork retired; sections are now Wiki, Corpus, Visualizers, The Line, Fact/Story.
- Visualizers consolidated into one mobile index grouped corpus / wiki / Annie.
- Copied `js/void-engine.js`, `css/slime.css` for the particle field and palette.

## Screen map

| project screen | built from |
| --- | --- |
| Leviathan Mobile.dc.html — splash | void.html (PHASE 00/hero), js/void-engine.js (`particle-type`) |
| Leviathan Mobile.dc.html — seal | index.html, README.md (the gate: js/gate.js) |
| Leviathan Mobile.dc.html — dial hub | index.html (doors), singularity.html (doors), temple.html (chapels) |
| Leviathan Mobile.dc.html — section briefs | wiki.html, transcript.html, tree.html, factstory.html copy |
| Leviathan Mobile.dc.html — visualizers index | void.html #corpus/#wiki, brain.html, ask.html, ledger.html, money.html, procurement.html, clock.html, oracle.html, voice.html |
| palette / atmosphere | css/slime.css, void.html inline `:root` tokens |
