/* SNOB SQUAD — easter eggs, part 1: gate, global input, hero */
document.addEventListener('DOMContentLoaded', function () {
  const $ = s => document.querySelector(s);
  const $$ = s => [...document.querySelectorAll(s)];
  const P = () => SS.play;

  /* ---------- ENTRY GATE ---------- */
  const gate = $('#gate');
  if (gate) gate.addEventListener('click', () => {
    SS.audio.unlock();
    P().riser(1.1);
    gate.classList.add('opening');
    setTimeout(() => { P().drop(); SS.shake(500); SS.goo.splat(innerWidth / 2, innerHeight / 2, true); }, 1050);
    setTimeout(() => { gate.remove(); document.body.classList.add('entered'); }, 1600);
    SS.hit('enter', 'YOU\'RE IN. NO REFUNDS.');
  }, { once: true });

  /* ---------- CLICK ANYWHERE = SPLAT ---------- */
  let lastSplat = 0;
  document.addEventListener('pointerdown', e => {
    if (e.target.closest('button, a, input, .skey, .pad, .disc, #knob')) return;
    const now = Date.now();
    if (now - lastSplat < 120) return;
    lastSplat = now;
    SS.goo.splat(e.clientX, e.clientY, false);
    P().splat(false);
    SS.hit('splat', 'FIRST SPLAT. IT WON\'T BE YOUR LAST.');
  });

  /* ---------- LONG PRESS = GOO GROWS ---------- */
  let pressT = null, pressing = false;
  document.addEventListener('pointerdown', e => {
    if (e.target.closest('button, a, input, .skey, .pad, .disc, #knob, .ltr')) return;
    pressT = setTimeout(() => {
      pressing = true;
      SS.goo.startGrow(e.clientX, e.clientY);
      SS.hit('long-press', 'HOLD IT RIGHT THERE. GOO DEPLOYED.');
    }, 600);
  });
  document.addEventListener('pointerup', () => {
    clearTimeout(pressT);
    if (pressing) { SS.goo.endGrow(); pressing = false; }
  });

  /* ---------- DOUBLE CLICK BG = RIPPLE ---------- */
  document.addEventListener('dblclick', e => {
    if (e.target.closest('button, a, input')) return;
    const r = document.createElement('div');
    r.className = 'ripple';
    r.style.left = e.clientX + 'px'; r.style.top = e.clientY + 'px';
    document.body.appendChild(r);
    setTimeout(() => r.remove(), 900);
    P().sub(45, 0.6);
    SS.hit('ripple', 'DOUBLE TAP. BASS RIPPLE DETECTED.');
  });

  /* ---------- KEY SEQUENCES ---------- */
  let buf = '';
  const KONAMI = 'arrowuparrowuparrowdownarrowdownarrowleftarrowrightarrowleftarrowrightba';
  document.addEventListener('keydown', e => {
    if (/INPUT|TEXTAREA/.test(document.activeElement.tagName)) return;
    buf = (buf + e.key.toLowerCase()).slice(-40);
    if (buf.endsWith(KONAMI)) {
      document.body.classList.add('party');
      P().drop(); P().siren(2.5); P().airhorn();
      for (let i = 0; i < 12; i++) setTimeout(() => SS.goo.splat(SS.rand(0, innerWidth), SS.rand(0, innerHeight), true), i * 120);
      setTimeout(() => document.body.classList.remove('party'), 4000);
      SS.hit('konami', 'KONAMI CODE. 30 EXTRA LIVES OF BASS.');
    }
    if (buf.endsWith('bass')) {
      SS.shake(700); P().drop();
      SS.hit('type-bass', 'YOU TYPED BASS. THE FLOOR IS GONE.');
    }
    if (buf.endsWith('slime')) {
      const f = $('#flood');
      if (f) { f.classList.add('on'); P().splat(true); setTimeout(() => f.classList.remove('on'), 2600); }
      SS.hit('type-slime', 'SLIME FLOOD. YOU ASKED FOR THIS.');
    }
    if (buf.endsWith('wub')) {
      document.body.classList.add('wobbling');
      P().wub(48, 1.2, 0.5);
      setTimeout(() => document.body.classList.remove('wobbling'), 1500);
      SS.hit('type-wub', 'WUB WUB WUB. THE PAGE AGREES.');
    }
  });

  /* ---------- MOUSE SHAKE ---------- */
  let lastX = 0, flips = [], lastDir = 0;
  document.addEventListener('pointermove', e => {
    const dir = Math.sign(e.clientX - lastX);
    if (dir !== 0 && dir !== lastDir && lastDir !== 0) {
      flips.push(Date.now());
      flips = flips.filter(t => Date.now() - t < 900);
      if (flips.length > 9) {
        flips = [];
        P().whoosh();
        SS.toast('EASY THERE. SAVE IT FOR THE RAIL.');
        SS.hit('mouse-shake', 'MOUSE SHAKE. CONFISCATING YOUR ESPRESSO.');
      }
    }
    if (dir !== 0) lastDir = dir;
    lastX = e.clientX;
  }, { passive: true });

  /* ---------- EDGE LEAN ---------- */
  const wrap = $('#page');
  document.addEventListener('pointermove', e => {
    if (!wrap) return;
    const m = 14;
    let rot = 0;
    if (e.clientX < m) rot = -0.7; else if (e.clientX > innerWidth - m) rot = 0.7;
    if (rot !== 0) {
      wrap.style.transform = 'perspective(1200px) rotateY(' + rot + 'deg)';
      SS.hit('edge-lean', 'THE PAGE LEANS WITH YOU. IT\'S CLINGY.');
    } else if (wrap.style.transform) {
      wrap.style.transform = '';
    }
  }, { passive: true });

  /* ---------- SHIFT + SCROLL = PITCH BEND ---------- */
  let bendT = 0;
  addEventListener('wheel', e => {
    if (!e.shiftKey) return;
    const now = Date.now();
    if (now - bendT < 150) return;
    bendT = now;
    P().bendUp();
    document.documentElement.style.setProperty('--hue', (parseFloat(document.documentElement.style.getPropertyValue('--hue') || 0) + 12) + 'deg');
    SS.hit('shift-scroll', 'SHIFT+SCROLL. PITCH BENDER.');
  }, { passive: true });

  /* ---------- SCROLL: progress, velocity, puddle ---------- */
  const prog = $('#prog-fill');
  let lastScroll = scrollY, lastScrollT = Date.now(), bottomHit = false, fastHit = false;
  addEventListener('scroll', () => {
    const max = document.documentElement.scrollHeight - innerHeight;
    const pct = max > 0 ? scrollY / max : 0;
    if (prog) prog.style.height = (pct * 100) + '%';
    const now = Date.now(), dt = now - lastScrollT;
    const v = Math.abs(scrollY - lastScroll) / Math.max(1, dt);
    if (v > 3.2 && !fastHit) {
      fastHit = true;
      const h = $('#hero-title'); if (h) { h.classList.add('wobbling'); setTimeout(() => h.classList.remove('wobbling'), 900); }
      P().whoosh();
      SS.hit('scroll-fast', 'SPEED SCROLLING. WHERE\'S THE FIRE?');
    }
    if (pct > 0.985 && !bottomHit) {
      bottomHit = true;
      SS.goo.growPuddle(); SS.goo.growPuddle();
      P().splat(true);
      SS.hit('bottom-puddle', 'ROCK BOTTOM. THE PUDDLE WELCOMES YOU.');
    }
    lastScroll = scrollY; lastScrollT = now;
  }, { passive: true });
  const progBar = $('#prog');
  if (progBar) progBar.addEventListener('click', e => {
    const max = document.documentElement.scrollHeight - innerHeight;
    scrollTo({ top: (e.clientY / innerHeight) * max, behavior: 'smooth' });
    P().blip(700, 0.2);
    SS.hit('progress-click', 'SLIME BAR SCRUBBING. EFFICIENT DEGENERATE.');
  });

  /* ---------- TEXT SELECTION ---------- */
  document.addEventListener('selectionchange', () => {
    const s = document.getSelection();
    if (s && s.toString().length > 6) SS.hit('text-select', 'HIGHLIGHTING TEXT? NERD. WE LOVE IT.');
  });

  /* ---------- HERO: logo click / hold-charge ---------- */
  const logo = $('#hero-logo');
  if (logo) {
    let chargeT = null, charging = false;
    logo.addEventListener('pointerdown', e => {
      e.preventDefault();
      chargeT = setTimeout(() => {
        charging = true;
        logo.classList.add('charging');
        P().riser(1.6);
      }, 350);
    });
    const release = () => {
      clearTimeout(chargeT);
      if (charging) {
        charging = false;
        logo.classList.remove('charging');
        logo.classList.add('boom');
        P().drop(); SS.shake(600);
        const r = logo.getBoundingClientRect();
        SS.goo.splat(r.left + r.width / 2, r.top + r.height / 2, true);
        setTimeout(() => logo.classList.remove('boom'), 700);
        SS.hit('logo-charge', 'CHARGED THE LOGO. IT EXPLODED. WORTH IT.');
      } else {
        logo.classList.add('wob');
        P().splat(false);
        setTimeout(() => logo.classList.remove('wob'), 600);
        SS.hit('logo-click', 'POKED THE LOGO. IT WOBBLED SEDUCTIVELY.');
      }
    };
    logo.addEventListener('pointerup', release);
    logo.addEventListener('pointerleave', () => { clearTimeout(chargeT); if (charging) { charging = false; logo.classList.remove('charging'); } });
  }

  /* ---------- DRAGGABLE HERO LETTERS ---------- */
  $$('.ltr').forEach(el => {
    let ox = 0, oy = 0, vx = 0, vy = 0, drag = null, raf = null;
    const apply = () => { el.style.transform = 'translate(' + ox + 'px,' + oy + 'px)'; };
    el.addEventListener('pointerdown', e => {
      e.preventDefault();
      drag = { x: e.clientX, y: e.clientY };
      el.setPointerCapture(e.pointerId);
      cancelAnimationFrame(raf);
      el.classList.add('held');
    });
    el.addEventListener('pointermove', e => {
      if (!drag) return;
      vx = e.clientX - drag.x; vy = e.clientY - drag.y;
      ox += vx; oy += vy;
      drag = { x: e.clientX, y: e.clientY };
      apply();
    });
    const drop = () => {
      if (!drag) return;
      drag = null;
      el.classList.remove('held');
      SS.hit('drag-letter', 'LETTER YEETED. SPRING-LOADED SLIME.');
      P().blip(SS.rand(300, 900), 0.2);
      (function springLoop() {
        vx += -0.06 * ox; vy += -0.06 * oy;
        vx *= 0.86; vy *= 0.86;
        ox += vx; oy += vy;
        apply();
        if (Math.abs(ox) > 0.5 || Math.abs(oy) > 0.5 || Math.abs(vx) > 0.5 || Math.abs(vy) > 0.5) raf = requestAnimationFrame(springLoop);
        else { ox = oy = 0; el.style.transform = ''; }
      })();
    };
    el.addEventListener('pointerup', drop);
    el.addEventListener('pointercancel', drop);
  });

  /* ---------- HYPNO O ---------- */
  const hyp = $('.hypno');
  if (hyp) hyp.addEventListener('click', e => {
    e.stopPropagation();
    document.body.classList.add('hypno-mode');
    P().siren(2.2);
    setTimeout(() => document.body.classList.remove('hypno-mode'), 3000);
    SS.hit('hypno-o', 'YOU STARED INTO THE O. THE O STARED BACK.');
  });

  /* ---------- TRIPLE-CLICK TITLE = MELT ---------- */
  const title = $('#hero-title');
  if (title) {
    let clicks = [];
    title.addEventListener('click', () => {
      const now = Date.now();
      clicks.push(now);
      clicks = clicks.filter(t => now - t < 700);
      if (clicks.length >= 3) {
        clicks = [];
        title.classList.add('melting');
        P().splat(true);
        setTimeout(() => title.classList.remove('melting'), 2400);
        SS.hit('title-melt', 'TRIPLE CLICK. THE NAME MELTED. IT\'LL BE FINE.');
      }
    });
  }

  /* ---------- MARQUEE GRAB ---------- */
  $$('.marquee').forEach(mq => {
    mq.addEventListener('pointerenter', () => {
      mq.classList.add('fast');
      SS.hit('marquee-hover', 'TOUCHED THE TICKER. IT GOT EXCITED.');
    });
    mq.addEventListener('pointerleave', () => mq.classList.remove('fast'));
  });

  /* ---------- HUD CLICK ---------- */
  const hud = $('#hud');
  if (hud) hud.addEventListener('click', () => {
    P().cowbell();
    SS.toast(SS.foundSet.size < SS.TOTAL ? 'KEEP DIGGING. THE PAGE IS FILTHY WITH SECRETS.' : 'YOU FOUND EVERYTHING. TOUCH GRASS.');
    SS.hit('hud-click', 'YOU CLICKED THE COUNTER. META. VERY META.');
  });
});
