/* SNOB SQUAD — THE LAB: DJ deck, bass synth, drum pads, knobs */
document.addEventListener('DOMContentLoaded', function () {
  const $ = s => document.querySelector(s);
  const P = () => SS.play;

  /* ---------- DECKS ---------- */
  const deck = { a: false, b: false, angA: 0, angB: 0, xf: 0.5 };
  let step = 0, loopT = null;
  const PAT_KICK = [1,0,0,0, 1,0,0,0, 1,0,0,0, 1,0,0,1];
  const PAT_HAT  = [0,0,1,0, 0,0,1,0, 0,0,1,0, 0,0,1,1];
  const PAT_BASS = [55,0,0,55, 0,65.4,0,0, 49,0,49,0, 55,0,73.4,0];

  function xfGain(side) { // equal-power-ish
    return side === 'a' ? Math.cos(deck.xf * Math.PI / 2) : Math.sin(deck.xf * Math.PI / 2);
  }
  function tick() {
    const s16 = step % 16;
    if (deck.a) {
      const ga = xfGain('a');
      if (PAT_KICK[s16]) P().kick(0.8 * ga);
      if (PAT_HAT[s16]) P().hat(0.2 * ga);
      if (s16 === 4 || s16 === 12) P().snare(0.35 * ga);
    }
    if (deck.b) {
      const gb = xfGain('b');
      const n = PAT_BASS[s16];
      if (n) P().wub(n, 0.22, 0.4 * gb);
    }
    step++;
    loopT = setTimeout(tick, 60000 / SS.audio.bpm / 4);
  }
  function ensureLoop() {
    if (loopT === null && (deck.a || deck.b)) tick();
    if (!deck.a && !deck.b && loopT !== null) { clearTimeout(loopT); loopT = null; }
  }

  function wireDeck(side) {
    const btn = $('#play' + side.toUpperCase());
    const disc = $('#deck' + side.toUpperCase() + '-disc');
    if (!btn || !disc) return;
    btn.addEventListener('click', () => {
      if (!SS.audio.unlocked) return;
      deck[side] = !deck[side];
      btn.textContent = deck[side] ? 'STOP' : 'PLAY';
      btn.classList.toggle('on', deck[side]);
      ensureLoop();
      SS.hit('deck-play-' + side, side === 'a' ? 'DECK A: BEATS ENGAGED' : 'DECK B: WUBS ENGAGED');
    });
    // scratch
    let grab = null;
    disc.addEventListener('pointerdown', e => {
      grab = { x: e.clientX, y: e.clientY };
      disc.setPointerCapture(e.pointerId);
      disc.classList.add('grabbed');
    });
    disc.addEventListener('pointermove', e => {
      if (!grab) return;
      const dx = e.clientX - grab.x + (e.clientY - grab.y);
      if (Math.abs(dx) > 4) {
        deck['ang' + side.toUpperCase()] += dx * 0.6;
        P().scratch(dx);
        grab = { x: e.clientX, y: e.clientY };
        SS.hit('deck-scratch', 'WIKI WIKI. YOU SCRATCHED THE RECORD.');
      }
    });
    const end = () => { grab = null; disc.classList.remove('grabbed'); };
    disc.addEventListener('pointerup', end);
    disc.addEventListener('pointercancel', end);
  }
  wireDeck('a'); wireDeck('b');

  // disc spin
  (function spin() {
    if (deck.a) deck.angA += 2.4;
    if (deck.b) deck.angB += 2.4;
    const da = $('#deckA-disc'), db = $('#deckB-disc');
    if (da) da.style.transform = 'rotate(' + deck.angA + 'deg)';
    if (db) db.style.transform = 'rotate(' + deck.angB + 'deg)';
    requestAnimationFrame(spin);
  })();

  // crossfader
  const xf = $('#xfader');
  if (xf) xf.addEventListener('input', () => {
    deck.xf = xf.value / 100;
    SS.hit('crossfader', 'CROSSFADER. SMOOTH OPERATOR.');
  });

  /* ---------- WOBBLE KNOB ---------- */
  const knob = $('#knob'), knobVal = $('#knob-val');
  if (knob) {
    let kGrab = null;
    const setKnob = r => {
      SS.audio.wobbleRate = r;
      knob.style.transform = 'rotate(' + ((r - 1) / 15 * 270 - 135) + 'deg)';
      if (knobVal) knobVal.textContent = r.toFixed(1) + ' Hz';
    };
    setKnob(5);
    knob.addEventListener('pointerdown', e => { kGrab = { y: e.clientY, r: SS.audio.wobbleRate }; knob.setPointerCapture(e.pointerId); });
    knob.addEventListener('pointermove', e => {
      if (!kGrab) return;
      const r = Math.min(16, Math.max(1, kGrab.r + (kGrab.y - e.clientY) * 0.08));
      setKnob(r);
    });
    knob.addEventListener('pointerup', () => {
      if (kGrab) { P().wub(55, 0.7, 0.45); SS.hit('wobble-knob', 'WOBBLE RATE ADJUSTED. FILTH LEVELS RISING.'); }
      kGrab = null;
    });
  }

  /* ---------- TAP TEMPO + BPM ---------- */
  const taps = [];
  const bpmEl = $('#bpm');
  const setBpm = b => { SS.audio.bpm = Math.round(b); if (bpmEl) bpmEl.textContent = Math.round(b) + ' BPM'; };
  const tap = $('#tap');
  if (tap) tap.addEventListener('click', () => {
    const now = Date.now();
    taps.push(now);
    while (taps.length > 6) taps.shift();
    P().hat(0.3);
    if (taps.length >= 3) {
      const iv = (taps[taps.length - 1] - taps[0]) / (taps.length - 1);
      if (iv > 200 && iv < 2000) { setBpm(60000 / iv); SS.hit('tap-tempo', 'TAP TEMPO. YOUR INTERNAL CLOCK IS FILTHY.'); }
    }
  });
  if (bpmEl) bpmEl.addEventListener('click', () => {
    setBpm(SS.rand(140, 180));
    P().blip(1200, 0.2);
    SS.hit('bpm-random', 'BPM ROULETTE. GAMBLING WITH TEMPO.');
  });

  /* ---------- SYNTH KEYBOARD ---------- */
  const NOTES = [
    ['C', 32.7], ['C#', 34.65], ['D', 36.71], ['D#', 38.89], ['E', 41.2], ['F', 43.65],
    ['F#', 46.25], ['G', 49], ['G#', 51.91], ['A', 55], ['A#', 58.27], ['B', 61.74], ['C', 65.41]
  ];
  const KEYMAP = { z: 0, s: 1, x: 2, d: 3, c: 4, v: 5, g: 6, b: 7, h: 8, n: 9, j: 10, m: 11, ',': 12 };
  const synthEl = $('#synth');
  let notesPlayed = 0;
  function playNote(i, el) {
    P().note(NOTES[i][1] * 2, 0.5);
    if (el) { el.classList.add('down'); setTimeout(() => el.classList.remove('down'), 180); }
    SS.hit('synth-key', 'YOU TOUCHED THE BASS. IT LIKED IT.');
    if (++notesPlayed === 8) SS.hit('synth-riff', 'EIGHT NOTES DEEP. THAT\'S BASICALLY A SET.');
  }
  if (synthEl) {
    NOTES.forEach(([name, f], i) => {
      const k = document.createElement('button');
      k.className = 'skey' + (name.includes('#') ? ' black' : '');
      k.innerHTML = '<span>' + name + '</span>';
      k.addEventListener('pointerdown', () => playNote(i, k));
      synthEl.appendChild(k);
    });
  }

  /* ---------- DRUM PADS ---------- */
  const PADS = [
    ['KICK', () => P().kick()], ['SNARE', () => P().snare()], ['HAT', () => P().hat(0.35)],
    ['COWBELL', () => { P().cowbell(); SS.hit('cowbell', 'MORE COWBELL. OBVIOUSLY.'); }],
    ['808', () => P().sub(42)], ['LAZER', () => P().bendUp()],
    ['AIRHORN', () => { P().airhorn(); SS.hit('airhorn', 'AIRHORN. THE PEOPLE\'S INSTRUMENT.'); }],
    ['SIREN', () => P().siren()]
  ];
  const padsEl = $('#pads');
  if (padsEl) {
    PADS.forEach(([name, fn], i) => {
      const b = document.createElement('button');
      b.className = 'pad';
      b.innerHTML = name + '<em>' + (i + 1) + '</em>';
      b.addEventListener('pointerdown', () => {
        fn(); b.classList.add('hitfx'); setTimeout(() => b.classList.remove('hitfx'), 150);
        SS.hit('drum-pad', 'FINGER DRUMMING. FILTHY TECHNIQUE.');
      });
      padsEl.appendChild(b);
    });
  }

  // keyboard: pads 1-8, synth zsxdcvgbhnjm, D = siren
  document.addEventListener('keydown', e => {
    if (e.repeat || e.metaKey || e.ctrlKey || /INPUT|TEXTAREA/.test(document.activeElement.tagName)) return;
    const k = e.key.toLowerCase();
    if (k >= '1' && k <= '8') {
      const i = +k - 1;
      PADS[i][1]();
      const pad = padsEl && padsEl.children[i];
      if (pad) { pad.classList.add('hitfx'); setTimeout(() => pad.classList.remove('hitfx'), 150); }
      SS.hit('drum-pad', 'FINGER DRUMMING. FILTHY TECHNIQUE.');
    } else if (k in KEYMAP && k !== 'd' && k !== 's') {
      const i = KEYMAP[k];
      playNote(i, synthEl && synthEl.children[i]);
    } else if (k === 's' || k === 'd') {
      // s/d are synth keys too (they're in KEYMAP) — play them
      playNote(KEYMAP[k], synthEl && synthEl.children[KEYMAP[k]]);
    }
  });

  /* ---------- SPEAKERS ---------- */
  let blowClicks = [], blownCount = 0;
  document.querySelectorAll('.speaker').forEach(sp => {
    const cone = sp.querySelector('.cone');
    sp.addEventListener('click', () => {
      P().sub(40, 0.9);
      SS.hit('speaker-pulse', 'SPEAKER TEST. NEIGHBORS NOTIFIED.');
      const now = Date.now();
      blowClicks.push(now);
      blowClicks = blowClicks.filter(t => now - t < 1600);
      if (blowClicks.length >= 5 && !sp.classList.contains('blown')) {
        sp.classList.add('blown');
        P().fuzz();
        SS.shake(500);
        SS.hit('speaker-blown', 'YOU BLEW THE SPEAKER. YOU MANIAC.');
        setTimeout(() => sp.classList.remove('blown'), 4000);
        blowClicks = [];
      }
    });
    // audio-reactive cone pump
    (function pump() {
      if (cone && !sp.classList.contains('blown')) cone.style.transform = 'scale(' + (1 + SS.level * 0.35) + ')';
      requestAnimationFrame(pump);
    })();
  });
});
