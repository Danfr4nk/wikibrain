/* SNOB SQUAD — core: secret tracker + toasts + helpers */
window.SS = {
  TOTAL: 53,
  foundSet: new Set(JSON.parse(localStorage.getItem('ss_found') || '[]')),
  level: 0, // audio level 0..1, updated by goo.js

  hit(id, label) {
    if (this.foundSet.has(id)) return false;
    this.foundSet.add(id);
    localStorage.setItem('ss_found', JSON.stringify([...this.foundSet]));
    this.updateHud();
    this.toast('SECRET ' + this.foundSet.size + '/' + this.TOTAL + ' — ' + label);
    if (SS.play) SS.play.pop();
    if (this.foundSet.size >= this.TOTAL) {
      setTimeout(() => this.toast('ALL 50 FOUND. YOU NEED HELP. WE RESPECT THAT.'), 1400);
    }
    return true;
  },

  updateHud() {
    const el = document.getElementById('hud-count');
    if (el) el.textContent = this.foundSet.size + '/' + this.TOTAL;
  },

  toast(msg) {
    const box = document.getElementById('toasts');
    if (!box) return;
    const t = document.createElement('div');
    t.className = 'toast';
    t.textContent = msg;
    box.appendChild(t);
    requestAnimationFrame(() => t.classList.add('in'));
    setTimeout(() => { t.classList.remove('in'); setTimeout(() => t.remove(), 400); }, 3200);
  },

  rand(a, b) { return a + Math.random() * (b - a); },
  pick(arr) { return arr[Math.floor(Math.random() * arr.length)]; },

  shake(ms) {
    document.body.classList.add('shaking');
    clearTimeout(this._shakeT);
    this._shakeT = setTimeout(() => document.body.classList.remove('shaking'), ms || 400);
  }
};
document.addEventListener('DOMContentLoaded', () => SS.updateHud());
