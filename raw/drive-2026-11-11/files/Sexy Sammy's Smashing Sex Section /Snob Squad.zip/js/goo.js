/* SNOB SQUAD — goo canvas: cursor trail, splats, drips, puddle, audio glow */
(function () {
  const cv = document.createElement('canvas');
  cv.id = 'goo';
  document.addEventListener('DOMContentLoaded', () => document.body.appendChild(cv));
  const ctx = cv.getContext('2d');
  let W = 0, H = 0;
  function resize() { W = cv.width = innerWidth; H = cv.height = innerHeight; }
  addEventListener('resize', resize); resize();

  const COLORS = ['#86e62e', '#e93fd6', '#35d6e8'];
  const trail = [], splats = [], drips = [];
  let puddle = 0, puddleTarget = 0, grow = null, lastInput = Date.now(), idleHit = false;

  const G = SS.goo = {};
  G.splat = function (x, y, big) {
    const c = SS.pick(COLORS);
    const blobs = [];
    const n = big ? 9 : 5;
    for (let i = 0; i < n; i++) {
      blobs.push({ dx: SS.rand(-1, 1) * (big ? 34 : 16), dy: SS.rand(-0.6, 0.6) * (big ? 26 : 12), r: SS.rand(4, big ? 26 : 13) });
    }
    splats.push({ x, y, c, blobs, life: 1 });
    const dn = big ? 4 : 2;
    for (let i = 0; i < dn; i++) drips.push({ x: x + SS.rand(-18, 18), y, vy: SS.rand(0.4, 1.4), r: SS.rand(2.5, 5), c, life: 1 });
    if (splats.length > 60) splats.shift();
  };
  G.dripFromTop = function () {
    drips.push({ x: SS.rand(0, W), y: -10, vy: SS.rand(0.8, 2.2), r: SS.rand(3, 7), c: SS.pick(COLORS), life: 1 });
  };
  G.growPuddle = function () { puddleTarget = Math.min(1, puddleTarget + 0.25); };
  G.startGrow = function (x, y) { grow = { x, y, r: 6 }; };
  G.endGrow = function () {
    if (grow) { G.splat(grow.x, grow.y, grow.r > 40); if (SS.play) SS.play.splat(grow.r > 40); }
    grow = null;
  };

  addEventListener('pointermove', e => {
    lastInput = Date.now(); idleHit = idleHit;
    trail.push({ x: e.clientX, y: e.clientY, r: SS.rand(5, 11), life: 1, c: COLORS[0] });
    if (trail.length > 40) trail.shift();
  }, { passive: true });
  addEventListener('pointerdown', () => { lastInput = Date.now(); }, { passive: true });
  addEventListener('keydown', () => { lastInput = Date.now(); });
  addEventListener('scroll', () => { lastInput = Date.now(); }, { passive: true });

  // idle → the site starts melting
  setInterval(() => {
    if (Date.now() - lastInput > 20000) {
      G.dripFromTop();
      if (!idleHit) { idleHit = true; SS.hit('idle-drip', 'YOU LEFT IT ALONE. IT STARTED MELTING.'); }
    }
  }, 500);

  function blob(x, y, r, c, a) {
    ctx.globalAlpha = a;
    ctx.fillStyle = c;
    ctx.beginPath();
    ctx.arc(x, y, Math.max(0.1, r), 0, 7);
    ctx.fill();
  }

  let freq = null;
  function loop() {
    ctx.clearRect(0, 0, W, H);

    // audio level
    const an = SS.audio && SS.audio.analyser;
    if (an) {
      if (!freq) freq = new Uint8Array(an.frequencyBinCount);
      an.getByteFrequencyData(freq);
      let s = 0; for (let i = 0; i < 24; i++) s += freq[i];
      SS.level = SS.level * 0.7 + (s / 24 / 255) * 0.3;
    }

    // audio-reactive edge glow
    if (SS.level > 0.05) {
      const g = ctx.createRadialGradient(W / 2, H / 2, Math.min(W, H) * 0.35, W / 2, H / 2, Math.max(W, H) * 0.75);
      g.addColorStop(0, 'rgba(134,230,46,0)');
      g.addColorStop(1, 'rgba(134,230,46,' + (SS.level * 0.5).toFixed(3) + ')');
      ctx.globalAlpha = 1; ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    }

    // trail
    for (let i = trail.length - 1; i >= 0; i--) {
      const t = trail[i];
      t.life -= 0.04; t.r *= 0.97;
      if (t.life <= 0) { trail.splice(i, 1); continue; }
      blob(t.x, t.y, t.r, '#86e62e', t.life * 0.55);
    }

    // splats
    for (let i = splats.length - 1; i >= 0; i--) {
      const s = splats[i];
      s.life -= 0.0025;
      if (s.life <= 0) { splats.splice(i, 1); continue; }
      s.blobs.forEach(b => blob(s.x + b.dx, s.y + b.dy, b.r, s.c, Math.min(0.8, s.life)));
    }

    // drips
    for (let i = drips.length - 1; i >= 0; i--) {
      const d = drips[i];
      d.vy += 0.05; d.y += d.vy; d.life -= 0.002;
      blob(d.x, d.y, d.r, d.c, Math.min(0.85, d.life));
      blob(d.x, d.y - d.r * 2.4, d.r * 0.6, d.c, Math.min(0.6, d.life));
      if (d.y > H - 6 || d.life <= 0) {
        if (d.y > H - 12) { blob(d.x, H - 4, d.r * 2.2, d.c, 0.5); }
        drips.splice(i, 1);
      }
    }

    // long-press grow
    if (grow) {
      grow.r += 1.4;
      blob(grow.x, grow.y, grow.r, '#86e62e', 0.75);
    }

    // puddle at page bottom
    puddle += (puddleTarget - puddle) * 0.03;
    if (puddle > 0.01) {
      ctx.globalAlpha = 0.8; ctx.fillStyle = '#86e62e';
      const pw = W * (0.25 + puddle * 0.7), ph = 14 + puddle * 26;
      ctx.beginPath();
      ctx.ellipse(W / 2, H + ph * 0.35, pw / 2, ph, 0, 0, 7);
      ctx.fill();
    }

    ctx.globalAlpha = 1;
    requestAnimationFrame(loop);
  }
  requestAnimationFrame(loop);
})();
