/* SNOB SQUAD — easter eggs, part 2: sections, footer, bubbles, toggles */
document.addEventListener('DOMContentLoaded', function () {
  const $ = s => document.querySelector(s);
  const $$ = s => [...document.querySelectorAll(s)];
  const P = () => SS.play;

  /* ---------- TRACK CARDS ---------- */
  const previewed = new Set();
  $$('.track').forEach(card => {
    // tilt
    card.addEventListener('pointermove', e => {
      const r = card.getBoundingClientRect();
      const rx = ((e.clientY - r.top) / r.height - 0.5) * -8;
      const ry = ((e.clientX - r.left) / r.width - 0.5) * 8;
      card.style.transform = 'perspective(700px) rotateX(' + rx + 'deg) rotateY(' + ry + 'deg)';
    });
    card.addEventListener('pointerleave', () => card.style.transform = '');
    // preview
    const btn = card.querySelector('.preview');
    if (btn) btn.addEventListener('click', () => {
      const riff = JSON.parse(card.dataset.riff || '[55,65.4,49,73.4]');
      riff.forEach((f, i) => setTimeout(() => P().wub(f, 0.3, 0.45), i * 180));
      setTimeout(() => P().sub(riff[0] * 0.75), riff.length * 180);
      card.classList.add('bumping');
      setTimeout(() => card.classList.remove('bumping'), riff.length * 180 + 500);
      SS.hit('track-preview', 'PREVIEW TASTED. FIRST ONE\'S FREE.');
      previewed.add(card.dataset.riff);
      if (previewed.size >= 4) SS.hit('track-all', 'SAMPLED THE WHOLE MENU. CONNOISSEUR.');
    });
  });

  /* ---------- TOUR ROWS ---------- */
  $$('.gig').forEach(row => {
    row.addEventListener('click', () => {
      const open = row.classList.toggle('open');
      P().blip(open ? 800 : 500, 0.2);
      SS.hit('tour-expand', 'DATE EXPANDED. COMMITMENT ISSUES SOLVED.');
    });
  });

  /* ---------- EMAIL CHASE ---------- */
  const email = $('#email-link');
  if (email) {
    let dodges = 0;
    email.addEventListener('pointerenter', () => {
      if (dodges < 3) {
        dodges++;
        email.style.transform = 'translate(' + SS.rand(-120, 120) + 'px,' + SS.rand(-40, 40) + 'px) rotate(' + SS.rand(-8, 8) + 'deg)';
        P().whoosh();
        if (dodges === 3) {
          setTimeout(() => {
            email.style.transform = '';
            email.classList.add('gave-up');
            SS.toast('FINE. TAKE THE EMAIL. YOU EARNED IT.');
          }, 500);
        }
      }
    });
    email.addEventListener('click', () => SS.hit('email-catch', 'CAUGHT THE EMAIL. PERSISTENT LITTLE FREAK.'));
  }

  /* ---------- RUNAWAY BOOK BUTTON ---------- */
  const book = $('#book-btn');
  if (book) {
    let runs = 0;
    book.addEventListener('pointerenter', () => {
      if (runs < 2) {
        runs++;
        book.style.transform = 'translate(' + SS.rand(-150, 150) + 'px,' + SS.rand(-50, 50) + 'px)';
        P().whoosh();
      } else {
        book.style.transform = '';
      }
    });
    book.addEventListener('click', () => {
      P().airhorn();
      SS.hit('book-catch', 'YOU CAUGHT THE BOOKING BUTTON. HIRED.');
      SS.toast('EMAIL US. BRING A BUDGET AND A WAIVER.');
    });
  }

  /* ---------- SOCIALS ---------- */
  const hovered = new Set();
  $$('.soc').forEach(s => {
    s.addEventListener('pointerenter', () => {
      P().blip(SS.rand(500, 1400), 0.18);
      hovered.add(s.dataset.fx);
      SS.hit('social-first', 'SOCIAL STALKING INITIATED.');
      if (hovered.size >= 6) SS.hit('social-all', 'PETTED ALL SIX SOCIALS. THOROUGH.');
    });
  });

  /* ---------- FOOTER: copyright barf ---------- */
  const cp = $('#copy');
  if (cp) cp.addEventListener('click', () => {
    for (let i = 0; i < 22; i++) {
      setTimeout(() => {
        SS.goo.splat(SS.rand(0, innerWidth), SS.rand(0, innerHeight), Math.random() > 0.5);
        if (i % 4 === 0) P().splat(true);
      }, i * 90);
    }
    SS.shake(800);
    SS.hit('copyright-barf', 'CLICKED THE FINE PRINT. PAGE BARFED. FAIR.');
  });

  /* ---------- 18+ BADGE = EMOJI RAIN ---------- */
  const badge = $('#badge18');
  if (badge) badge.addEventListener('click', () => {
    const EMO = ['😈', '💦', '🍑', '🍆', '💊', '🫠', '⚡', '💜'];
    for (let i = 0; i < 26; i++) {
      const e = document.createElement('span');
      e.className = 'rain';
      e.textContent = SS.pick(EMO);
      e.style.left = SS.rand(0, 100) + 'vw';
      e.style.animationDelay = SS.rand(0, 0.8) + 's';
      e.style.fontSize = SS.rand(18, 44) + 'px';
      document.body.appendChild(e);
      setTimeout(() => e.remove(), 3500);
    }
    P().siren(1.2); P().pop();
    SS.hit('badge-18', 'CLICKED 18+. OF COURSE YOU DID.');
  });

  /* ---------- VOLUME KNOB (goes to 11) ---------- */
  const vol = $('#vol-knob');
  if (vol) {
    let level = 5;
    const label = vol.querySelector('b');
    vol.addEventListener('click', () => {
      level = level >= 11 ? 3 : level + 1;
      if (label) label.textContent = level;
      SS.audio.setVol(0.15 + level * 0.062);
      P().kick(0.5 + level * 0.04);
      vol.style.setProperty('--rot', (level / 11 * 270 - 135) + 'deg');
      if (level === 11) {
        SS.shake(600);
        vol.classList.add('eleven');
        P().fuzz();
        SS.hit('vol-11', 'IT GOES TO ELEVEN. OBVIOUSLY.');
      } else vol.classList.remove('eleven');
    });
  }

  /* ---------- THEME TOGGLE ---------- */
  const theme = $('#theme-toggle');
  if (theme) theme.addEventListener('click', () => {
    document.body.classList.toggle('midnight');
    P().splat(false);
    SS.hit('theme-toggle', 'AFTERHOURS MODE. YOUR RETINAS THANK YOU.');
  });

  /* ---------- 3D GLASSES ---------- */
  const glasses = $('#glasses-toggle');
  if (glasses) glasses.addEventListener('click', () => {
    document.body.classList.toggle('threed');
    P().bendUp();
    SS.hit('glasses-3d', '3D MODE. GLASSES NOT INCLUDED.');
  });

  /* ---------- NAV DRIPS ---------- */
  $$('.navdrip').forEach(d => {
    d.style.setProperty('--grow', SS.rand(20, 60) + 's');
    d.addEventListener('click', () => {
      d.classList.add('falling');
      P().splat(false);
      const r = d.getBoundingClientRect();
      setTimeout(() => SS.goo.splat(r.left + 4, innerHeight - 30, false), 700);
      setTimeout(() => d.classList.remove('falling'), 1200);
      SS.hit('nav-drip', 'FLICKED A DRIP OFF THE NAV. SATISFYING.');
    });
  });

  /* ---------- BUBBLES ---------- */
  let pops = 0;
  function spawnBubble() {
    if (document.querySelectorAll('.bubble').length < 4 && document.body.classList.contains('entered')) {
      const b = document.createElement('button');
      b.className = 'bubble';
      b.setAttribute('aria-label', 'bubble');
      b.style.left = SS.rand(4, 92) + 'vw';
      b.style.setProperty('--dur', SS.rand(9, 16) + 's');
      b.style.setProperty('--size', SS.rand(22, 52) + 'px');
      b.addEventListener('pointerdown', () => {
        b.classList.add('popped');
        P().pop();
        setTimeout(() => b.remove(), 250);
        pops++;
        SS.hit('bubble-pop', 'BUBBLE POPPED. DOPAMINE DISPENSED.');
        if (pops >= 10) SS.hit('bubble-10', 'TEN BUBBLES. YOU HAVE A PROBLEM. SAME.');
      });
      document.body.appendChild(b);
      setTimeout(() => b.remove(), 17000);
    }
    setTimeout(spawnBubble, SS.rand(3500, 8000));
  }
  setTimeout(spawnBubble, 4000);

  /* ---------- REWIND ---------- */
  const rw = $('#rewind-btn');
  if (rw) rw.addEventListener('click', () => {
    P().rewindFx();
    document.body.classList.add('rewinding');
    scrollTo({ top: 0, behavior: 'smooth' });
    setTimeout(() => document.body.classList.remove('rewinding'), 1000);
    SS.hit('rewind', 'WHEEL UP. SELECTA.');
  });
});
