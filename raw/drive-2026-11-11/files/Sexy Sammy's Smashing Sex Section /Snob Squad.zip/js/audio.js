/* SNOB SQUAD — WebAudio synth engine. All sounds generated, no files. */
(function () {
  const A = { ctx: null, master: null, analyser: null, unlocked: false, wobbleRate: 5, bpm: 150, vol: 0.5 };
  SS.audio = A;

  A.unlock = function () {
    if (A.unlocked) return;
    const Ctx = window.AudioContext || window.webkitAudioContext;
    if (!Ctx) return;
    const ctx = new Ctx();
    A.ctx = ctx;
    A.master = ctx.createGain(); A.master.gain.value = A.vol;
    const comp = ctx.createDynamicsCompressor();
    comp.threshold.value = -18; comp.ratio.value = 6;
    A.analyser = ctx.createAnalyser(); A.analyser.fftSize = 256;
    A.master.connect(comp); comp.connect(A.analyser); A.analyser.connect(ctx.destination);
    A.unlocked = true;
  };
  A.setVol = function (v) { A.vol = v; if (A.master) A.master.gain.setTargetAtTime(v, A.ctx.currentTime, 0.05); };

  function T() { return A.ctx.currentTime; }
  function env(peak, t0, atk, dec, out) {
    const g = A.ctx.createGain();
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(Math.max(peak, 0.0001), t0 + atk);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + atk + dec);
    g.connect(out || A.master);
    return g;
  }
  function osc(type, f, t0, dur) {
    const o = A.ctx.createOscillator();
    o.type = type; o.frequency.setValueAtTime(f, t0);
    o.start(t0); o.stop(t0 + dur + 0.15);
    return o;
  }
  function noiseSrc(dur) {
    const b = A.ctx.createBuffer(1, Math.ceil(A.ctx.sampleRate * dur), A.ctx.sampleRate);
    const d = b.getChannelData(0);
    for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
    const s = A.ctx.createBufferSource(); s.buffer = b;
    return s;
  }
  function ok() { return A.unlocked; }

  const P = {};
  SS.play = P;

  P.blip = function (f, v) {
    if (!ok()) return; const t = T();
    osc('sine', f || 900, t, 0.1).connect(env((v || 0.25), t, 0.005, 0.09));
  };
  P.pop = function () {
    if (!ok()) return; const t = T();
    const o = osc('sine', 300, t, 0.09);
    o.frequency.exponentialRampToValueAtTime(950, t + 0.08);
    o.connect(env(0.3, t, 0.004, 0.08));
  };
  P.splat = function (big) {
    if (!ok()) return; const t = T();
    const n = noiseSrc(0.3);
    const f = A.ctx.createBiquadFilter(); f.type = 'lowpass';
    f.frequency.setValueAtTime(big ? 1400 : 900, t);
    f.frequency.exponentialRampToValueAtTime(90, t + 0.25);
    n.connect(f); f.connect(env(big ? 0.6 : 0.3, t, 0.005, 0.26));
    n.start(t);
    const o = osc('sine', big ? 260 : 200, t, 0.22);
    o.frequency.exponentialRampToValueAtTime(38, t + 0.2);
    o.connect(env(big ? 0.5 : 0.25, t, 0.004, 0.2));
  };
  P.wub = function (f, dur, v) {
    if (!ok()) return; const t = T(); dur = dur || 0.6; f = f || 55;
    const o = osc('sawtooth', f, t, dur);
    const o2 = osc('square', f / 2, t, dur);
    const filt = A.ctx.createBiquadFilter(); filt.type = 'lowpass'; filt.Q.value = 12;
    filt.frequency.value = 300;
    const lfo = osc('sine', A.wobbleRate, t, dur);
    const lg = A.ctx.createGain(); lg.gain.value = 260;
    lfo.connect(lg); lg.connect(filt.frequency);
    const g = env(v || 0.4, t, 0.01, dur);
    o.connect(filt); o2.connect(filt); filt.connect(g);
  };
  P.sub = function (f, v) {
    if (!ok()) return; const t = T(); f = f || 42;
    const o = osc('sine', f * 2.2, t, 0.55);
    o.frequency.exponentialRampToValueAtTime(f, t + 0.09);
    o.connect(env(v || 0.85, t, 0.005, 0.5));
  };
  P.kick = function (v) {
    if (!ok()) return; const t = T();
    const o = osc('sine', 150, t, 0.3);
    o.frequency.exponentialRampToValueAtTime(45, t + 0.11);
    o.connect(env(v || 0.75, t, 0.002, 0.28));
  };
  P.snare = function (v) {
    if (!ok()) return; const t = T();
    const n = noiseSrc(0.2);
    const f = A.ctx.createBiquadFilter(); f.type = 'highpass'; f.frequency.value = 1400;
    n.connect(f); f.connect(env(v || 0.35, t, 0.002, 0.16)); n.start(t);
    osc('triangle', 210, t, 0.09).connect(env((v || 0.35) * 0.7, t, 0.002, 0.08));
  };
  P.hat = function (v) {
    if (!ok()) return; const t = T();
    const n = noiseSrc(0.06);
    const f = A.ctx.createBiquadFilter(); f.type = 'highpass'; f.frequency.value = 7000;
    n.connect(f); f.connect(env(v || 0.18, t, 0.001, 0.05)); n.start(t);
  };
  P.cowbell = function () {
    if (!ok()) return; const t = T();
    [800, 540].forEach(f => {
      const o = osc('square', f, t, 0.3);
      const bp = A.ctx.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = f;
      o.connect(bp); bp.connect(env(0.3, t, 0.002, 0.28));
    });
  };
  P.airhorn = function () {
    if (!ok()) return; const t = T();
    const hits = [[0, 0.28], [0.34, 0.14], [0.52, 0.14], [0.7, 0.7]];
    hits.forEach(([off, dur]) => {
      [0, 7, -5].forEach(det => {
        const o = osc('sawtooth', 440 + det, t + off, dur);
        o.frequency.setValueAtTime(466, t + off);
        o.frequency.linearRampToValueAtTime(440 + det, t + off + Math.min(0.09, dur));
        o.connect(env(0.16, t + off, 0.01, dur));
      });
    });
  };
  P.siren = function (dur) {
    if (!ok()) return; const t = T(); dur = dur || 1.6;
    const o = osc('sawtooth', 500, t, dur);
    const lfo = osc('sine', 2.2, t, dur);
    const lg = A.ctx.createGain(); lg.gain.value = 320;
    lfo.connect(lg); lg.connect(o.frequency);
    o.connect(env(0.22, t, 0.05, dur));
  };
  P.riser = function (dur) {
    if (!ok()) return; const t = T(); dur = dur || 1.4;
    const n = noiseSrc(dur);
    const f = A.ctx.createBiquadFilter(); f.type = 'bandpass'; f.Q.value = 3;
    f.frequency.setValueAtTime(220, t);
    f.frequency.exponentialRampToValueAtTime(5200, t + dur);
    n.connect(f); f.connect(env(0.4, t, dur * 0.75, dur * 0.25)); n.start(t);
    const o = osc('sawtooth', 110, t, dur);
    o.frequency.exponentialRampToValueAtTime(880, t + dur);
    o.connect(env(0.13, t, dur * 0.8, dur * 0.2));
  };
  P.drop = function () {
    if (!ok()) return;
    P.sub(38, 1); P.kick(0.9); P.splat(true);
    setTimeout(() => P.wub(48, 0.9, 0.5), 60);
  };
  P.scratch = function (vel) {
    if (!ok()) return; const t = T();
    const n = noiseSrc(0.08);
    const f = A.ctx.createBiquadFilter(); f.type = 'bandpass'; f.Q.value = 5;
    f.frequency.value = 700 + Math.min(3200, Math.abs(vel) * 42);
    n.connect(f); f.connect(env(Math.min(0.3, 0.07 + Math.abs(vel) * 0.004), t, 0.004, 0.07));
    n.start(t);
  };
  P.fuzz = function () {
    if (!ok()) return; const t = T();
    const n = noiseSrc(0.8);
    const f = A.ctx.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = 380;
    n.connect(f); f.connect(env(0.55, t, 0.01, 0.75)); n.start(t);
    P.sub(35, 1);
  };
  P.note = function (f, dur) {
    if (!ok()) return; P.wub(f, dur || 0.45, 0.42);
  };
  P.bendUp = function () {
    if (!ok()) return; const t = T();
    const o = osc('square', 200, t, 0.25);
    o.frequency.exponentialRampToValueAtTime(620, t + 0.22);
    o.connect(env(0.12, t, 0.01, 0.22));
  };
  P.whoosh = function () {
    if (!ok()) return; const t = T();
    const n = noiseSrc(0.5);
    const f = A.ctx.createBiquadFilter(); f.type = 'bandpass'; f.Q.value = 1.5;
    f.frequency.setValueAtTime(300, t);
    f.frequency.exponentialRampToValueAtTime(2600, t + 0.4);
    n.connect(f); f.connect(env(0.25, t, 0.12, 0.36)); n.start(t);
  };
  P.rewindFx = function () {
    if (!ok()) return; const t = T();
    const o = osc('sawtooth', 900, t, 0.9);
    o.frequency.exponentialRampToValueAtTime(120, t + 0.85);
    const lfo = osc('square', 12, t, 0.9);
    const lg = A.ctx.createGain(); lg.gain.value = 90;
    lfo.connect(lg); lg.connect(o.frequency);
    o.connect(env(0.18, t, 0.02, 0.85));
  };
})();
