/* ============================================================
   STUB void-engine.js — minimal stand-in so the site can boot.
   Original file was missing from the provided folder.
   Provides the two custom elements referenced by the .dc.html:
     <void-engine>   (intended as full-screen main background effect)
     <particle-type> (hero text effect, used for "@danfrank")
   This stub prevents load errors and white screens. The visual
   fidelity is reduced vs. the real WebGL/particle implementation.
============================================================ */
(function () {
  'use strict';
  if (window.__voidEngineDefined) return;
  window.__voidEngineDefined = true;

  class VoidEngine extends HTMLElement {
    connectedCallback() {
      // Subtle starfield / void background using CSS + a few DOM dots
      // (keeps it zero-dependency and lightweight)
      this.style.position = this.style.position || 'absolute';
      this.style.inset = '0';
      this.style.zIndex = this.style.zIndex || '0';
      this.style.overflow = 'hidden';
      this.style.background = 'radial-gradient(circle at 50% 40%, rgba(20,10,50,0.6) 0%, rgba(2,0,8,0.0) 70%)';

      // Add a handful of slow drifting "stars"
      const count = 48;
      for (let i = 0; i < count; i++) {
        const s = document.createElement('div');
        const size = Math.random() * 2.5 + 0.6;
        s.style.position = 'absolute';
        s.style.left = Math.random() * 100 + '%';
        s.style.top = Math.random() * 100 + '%';
        s.style.width = size + 'px';
        s.style.height = size + 'px';
        s.style.borderRadius = '50%';
        s.style.background = (Math.random() > 0.7) ? '#00f0ff' : '#c5b3ff';
        s.style.opacity = Math.random() * 0.6 + 0.25;
        s.style.pointerEvents = 'none';
        const dur = 18000 + Math.random() * 22000;
        s.animate([
          { transform: 'translateY(0)' },
          { transform: 'translateY(-' + (20 + Math.random()*40) + 'px)' }
        ], { duration: dur, iterations: Infinity, easing: 'linear' });
        this.appendChild(s);
      }
    }
  }

  class ParticleType extends HTMLElement {
    connectedCallback() {
      const text = this.getAttribute('text') || '@danfrank';
      this.style.display = 'flex';
      this.style.alignItems = 'center';
      this.style.justifyContent = 'center';
      this.style.position = 'relative';
      this.style.fontFamily = "'Unbounded', sans-serif";
      this.style.fontWeight = '900';
      this.style.fontSize = 'clamp(42px, 9vw, 92px)';
      this.style.letterSpacing = '0.08em';
      this.style.color = '#ffffff';
      this.style.textShadow = '0 0 18px rgba(0,240,255,0.9), 0 0 48px rgba(123,45,255,0.6)';
      this.style.userSelect = 'none';
      this.innerHTML = `<span>${text}</span>`;

      // Gentle continuous glitch pulse on the text
      const span = this.firstElementChild;
      if (span) {
        span.animate([
          { textShadow: '0 0 18px rgba(0,240,255,0.9), 0 0 48px rgba(123,45,255,0.6)' },
          { textShadow: '3px 0 #ff2d95, -2px 0 #00f0ff, 0 0 32px rgba(255,45,149,0.7)' },
          { textShadow: '0 0 18px rgba(0,240,255,0.9), 0 0 48px rgba(123,45,255,0.6)' }
        ], { duration: 4200, iterations: Infinity });
      }

      // Click/hover interaction hint (since real one was interactive)
      this.title = 'Particle field (stub) — original void-engine.js had live shockwave/vortex';
      this.style.cursor = 'pointer';
      this.addEventListener('click', () => {
        this.style.transition = 'transform 120ms ease';
        this.style.transform = 'scale(0.96)';
        setTimeout(() => { this.style.transform = 'scale(1)'; }, 160);
      });
    }
  }

  customElements.define('void-engine', VoidEngine);
  customElements.define('particle-type', ParticleType);
  console.log('%c[stub] void-engine.js loaded (reduced fidelity placeholders for <void-engine> and <particle-type>)', 'color:#6b5ca8');
})();
