/* cursor-fx — fixed-viewport reactive overlay for the void console.
   - neon comet tail that follows the mouse
   - click sparks
   - scroll-velocity star-streaks
   - right-edge scroll progress beam with glowing head
   Registers <cursor-fx>. Canvas is pointer-events:none; it only listens. */
(() => {
  if (customElements.get('cursor-fx')) return;

  const PALETTE = ['#00f0ff', '#ff2d95', '#7b2dff', '#00ff9d'];

  class CursorFX extends HTMLElement {
    connectedCallback() {
      if (this._init) return;
      this._init = true;
      const m = this.parentElement;
      if (m) { m.style.pointerEvents = 'none'; }
      const sh = this.attachShadow({ mode: 'open' });
      this.style.display = 'block';
      this.style.position = 'absolute';
      this.style.inset = '0';
      this.style.width = '100%';
      this.style.height = '100%';
      this.style.pointerEvents = 'none';
      const c = document.createElement('canvas');
      c.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;display:block;';
      sh.appendChild(c);
      this._c = c;
      this._ctx = c.getContext('2d');

      this._trail = [];      // comet tail points
      this._sparks = [];     // click bursts
      this._streaks = [];    // scroll velocity streaks
      this._mx = -100; this._my = -100;
      this._pmx = -100; this._pmy = -100;
      this._hue = 0;
      this._lastScroll = window.scrollY;
      this._scrollVel = 0;
      this._beamPulse = 0;

      this._onMove = (e) => { this._mx = e.clientX; this._my = e.clientY; };
      this._onDown = (e) => this._burst(e.clientX, e.clientY);
      this._onScroll = () => {
        const y = window.scrollY;
        this._scrollVel = this._scrollVel * 0.5 + (y - this._lastScroll) * 0.5;
        this._lastScroll = y;
        this._beamPulse = 1;
      };
      window.addEventListener('pointermove', this._onMove, { passive: true });
      window.addEventListener('pointerdown', this._onDown, { passive: true });
      window.addEventListener('scroll', this._onScroll, { passive: true });

      this._resize = () => {
        const dpr = Math.min(window.devicePixelRatio || 1, 2);
        this._w = this.clientWidth || window.innerWidth;
        this._h = this.clientHeight || window.innerHeight;
        c.width = this._w * dpr; c.height = this._h * dpr;
        this._ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      };
      this._resize();
      window.addEventListener('resize', this._resize);

      const loop = () => { this._raf = requestAnimationFrame(loop); this._step(); };
      loop();
    }

    disconnectedCallback() {
      cancelAnimationFrame(this._raf);
      window.removeEventListener('pointermove', this._onMove);
      window.removeEventListener('pointerdown', this._onDown);
      window.removeEventListener('scroll', this._onScroll);
      window.removeEventListener('resize', this._resize);
      this._init = false;
    }

    _burst(x, y) {
      for (let i = 0; i < 26; i++) {
        const a = Math.random() * Math.PI * 2;
        const sp = 2 + Math.random() * 7;
        this._sparks.push({
          x, y,
          vx: Math.cos(a) * sp, vy: Math.sin(a) * sp,
          life: 1, decay: 0.02 + Math.random() * 0.03,
          col: PALETTE[(Math.random() * PALETTE.length) | 0],
          sz: 1 + Math.random() * 2.4
        });
      }
    }

    _step() {
      const ctx = this._ctx, w = this._w, h = this._h;
      ctx.clearRect(0, 0, w, h);
      this._hue = (this._hue + 1.4) % 360;

      ctx.globalCompositeOperation = 'lighter';

      /* ---- click sparks ---- */
      for (let i = this._sparks.length - 1; i >= 0; i--) {
        const s = this._sparks[i];
        s.life -= s.decay;
        if (s.life <= 0) { this._sparks.splice(i, 1); continue; }
        s.x += s.vx; s.y += s.vy;
        s.vx *= 0.96; s.vy = s.vy * 0.96 + 0.05;
        ctx.beginPath();
        ctx.strokeStyle = s.col;
        ctx.shadowColor = s.col;
        ctx.shadowBlur = 10 * s.life;
        ctx.globalAlpha = s.life;
        ctx.lineWidth = s.sz * s.life;
        ctx.moveTo(s.x - s.vx * 2.4, s.y - s.vy * 2.4);
        ctx.lineTo(s.x, s.y);
        ctx.stroke();
      }
      ctx.shadowBlur = 0; ctx.globalAlpha = 1;

      /* ---- scroll velocity streaks ---- */
      const v = this._scrollVel;
      this._scrollVel *= 0.9;
      const mag = Math.min(Math.abs(v), 90);
      if (mag > 4) {
        const count = Math.min((mag / 8) | 0, 6);
        for (let i = 0; i < count; i++) {
          this._streaks.push({
            x: Math.random() * w,
            y: Math.random() * h,
            len: 20 + mag * (1.2 + Math.random()),
            dir: v > 0 ? -1 : 1,
            life: 1,
            col: PALETTE[(Math.random() * PALETTE.length) | 0],
            sp: 6 + Math.random() * 10
          });
        }
      }
      for (let i = this._streaks.length - 1; i >= 0; i--) {
        const s = this._streaks[i];
        s.life -= 0.05;
        if (s.life <= 0) { this._streaks.splice(i, 1); continue; }
        s.y += s.dir * s.sp;
        const grad = ctx.createLinearGradient(s.x, s.y, s.x, s.y + s.dir * s.len);
        grad.addColorStop(0, s.col);
        grad.addColorStop(1, 'transparent');
        ctx.strokeStyle = grad;
        ctx.globalAlpha = s.life * 0.55;
        ctx.lineWidth = 1.4;
        ctx.beginPath();
        ctx.moveTo(s.x, s.y);
        ctx.lineTo(s.x, s.y + s.dir * s.len);
        ctx.stroke();
      }
      ctx.globalAlpha = 1;

      /* ---- right-edge scroll progress beam ---- */
      const doc = document.documentElement;
      const max = Math.max(doc.scrollHeight - window.innerHeight, 1);
      const prog = Math.min(window.scrollY / max, 1);
      this._beamPulse *= 0.94;
      const bx = w - 5;
      const headY = 10 + prog * (h - 20);
      // track
      ctx.strokeStyle = 'rgba(123,45,255,0.22)';
      ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(bx, 10); ctx.lineTo(bx, h - 10); ctx.stroke();
      // filled portion
      const bg = ctx.createLinearGradient(0, 10, 0, headY);
      bg.addColorStop(0, 'rgba(0,240,255,0.15)');
      bg.addColorStop(1, '#00f0ff');
      ctx.strokeStyle = bg;
      ctx.lineWidth = 2;
      ctx.shadowColor = '#00f0ff';
      ctx.shadowBlur = 6 + this._beamPulse * 14;
      ctx.beginPath(); ctx.moveTo(bx, 10); ctx.lineTo(bx, headY); ctx.stroke();
      // head node
      ctx.beginPath();
      ctx.fillStyle = '#ff2d95';
      ctx.shadowColor = '#ff2d95';
      ctx.shadowBlur = 12 + this._beamPulse * 26;
      ctx.arc(bx, headY, 3 + this._beamPulse * 3.5, 0, Math.PI * 2);
      ctx.fill();
      ctx.shadowBlur = 0;
      ctx.globalCompositeOperation = 'source-over';
    }
  }

  customElements.define('cursor-fx', CursorFX);
})();
