---
domain: mind
page_type: concept
status: stable
date_created: 2026-06-22
date_modified: 2026-07-11
sources:
  - raw/self/dox-scan/DanAnnie_CorrectiveAddendum.txt
  - raw/self/dox-scan/DanAnnie_MasterRecord_March16.docx
  - raw/self/dox-scan/Dan Profile.txt
  - raw/self/dox-scan/all_imessages_complete_dump.txt
related:
  - wiki/people/annie
  - wiki/timeline/events/eli-incident
  - wiki/timeline/events/group-chat-closure
  - wiki/self/facebook
---

# Attachment Model

The attachment model details the first documented instance of full attachment-system activation in Dan's history, which occurred during his relationship with Annie. His prior relationships with Danielle, Kelly, and [[wiki/people/alexis-armel|Alexis]] did not trigger this level of psychological attachment. Within Dan's cognitive processing architecture, positive verbal expressions function as absolute rules that remain active until an explicit, unambiguous signal of severance is received. If no explicit severance signal is issued, the internal system is unable to generate a counter-rule to close the model, leaving the attachment loop active indefinitely.

This cognitive architecture is heavily influenced by a multi-generational family layer. A paternal authority wound was established by a parental rupture in 2005, when his father Rick entered rehabilitation and his parents separated, leading to subsequent low-intensity contact. A pattern of functional alcoholism also spans several generations of Dan's family. Conversely, his maternal great-grandmother, Fran Whyel, was his self-described largest life influence. This background encoded relational templates characterized by intermittent attachment, vertical suspicion, and an expectation of abandonment. Further details on these family influences are found in [[wiki/people/rick-frank]], [[wiki/people/fran-whyel]], [[wiki/people/suz]], and [[wiki/self/ancestry]].

## Quantitative Corpus Indicators

| Indicator | Count | Source Document |
|---|---|---|
| Love affirmations from Annie to Dan | 299 | MasterRecord Synthesis |
| Explicit severance signals from Annie to Dan | 0 | Full ten-year Annie Corpus |
| Documented relationship events | 266 | LIFE_EVENTS_CALENDAR.md |
| Cheating and affair subcategory events | 84 | LIFE_EVENTS_CALENDAR.md |
| Written denials of a third-party relationship | 2 | MasterRecord Synthesis |
| Sequences pairing an affection expression with a request | 145 | MasterRecord Synthesis |
| Documented "fell asleep" alibis | 24 | MasterRecord Synthesis |
| High-volume communication burst events | 94 | MasterRecord Synthesis |

The complete lack of explicit severance signals across a ten-year corpus, combined with two hundred and ninety-nine love affirmations, meant that no internal data was available to generate a counter-rule. Consequently, the attachment model remained active until it was terminated by an external event.

## Model Narrative

The attachment model describes the catastrophic interaction between Dan's rule-based processing architecture and a relationship that lacked a definitive conclusion. This mechanism is structural rather than pathological. Because the cognitive engine weights positive rhetoric heavily and requires a formal, explicit signal to terminate an active rule, the model stayed active throughout a fifteen-month terminal phase from August 2025 to June 2026. The system did not fail to perceive Annie's behavioral withdrawal; rather, it noted the behavioral withdrawal, found it inconsistent with the active attachment rule, and flagged the contradiction as an anomaly to be resolved rather than closing the model. Every instance where Annie said "I love you" while withdrawing behaviorally generated a data conflict that prevented closure.

This dynamic was further complicated by historical family patterns. The parental rupture of 2005 established a template where a trusted primary figure maintained a concealed alternate reality. Dan's relationship with Annie replicated this template, involving a trusted partner, sustained deception, and Dan choosing to accept verbal denials to preserve relational stability.

The core moral event of the relationship's terminal phase was the systematic erosion of Dan's perception, often described as gaslighting. Convincing a partner that their accurate observations are signs of paranoia or mental illness attacks their core capacity to understand reality. The closure event on June 1, 2026, provided the first explicit, verified data that allowed the cognitive system to generate a counter-rule and close the model.

## Gaslighting Architecture

The communication corpus demonstrates a systematic gaslighting architecture used to maintain relational stasis during active deception:
- **Verbal Anchoring:** Annie maintained explicit verbal commitments, such as calling Dan her "soulmate" or telling him she loved him, while concurrently withdrawing physical presence, shared time, and fidelity.
- **Semantic Drift:** The ten-year norm of mutual location sharing was unilaterally removed by Annie in August 2025, following a night spent at her former partner's residence. This removal was subsequently refed and reframed as Dan making a controlling demand.
- **Cause-and-Effect Inversion:** Annie systematically responded to the distress caused by her withdrawal rather than the withdrawal itself, using phrases such as "I cannot talk to you when you are like this" to avoid addressing the underlying issues.
- **Systematic Attacks on Reality:** While maintaining a relationship with Eli from at least August 2024, Annie repeatedly told Dan that his suspicions were insane, paranoid, or symptoms of mental illness. Dan explicitly documented that he chose to believe these assertions in order to return to a perceived normal life.

The central impact of this architecture was the subversion of Dan's cognitive stability. By targeting his capacity to verify reality, the deception inflicted a distinct category of psychological harm that went beyond simple infidelity.

## Documented Contradictions

> **CONTRADICTION:** Annie issued written denials of third-party involvement in November 2025 and February 2026. These denials were issued while she was actively engaged in a relationship with Eli and conducting a defamation campaign within their shared peer network, creating a direct contradiction between her private assurances and her public actions.

> **REVISED 2026-06-22:** Previous analyses characterized the relationship with Eli as an isolated incident discovered in January 2025. Corrective sources confirm that the relationship was a sustained concealment that began in at least autumn 2024. This timeline has been updated in [[wiki/timeline/events/eli-incident]] and the main entry for Annie.
