---
domain: self
page_type: synthesis
status: archived
date_created: 2026-06-22
date_modified: 2026-06-23
sources: ["raw/self/location/2026-06-22-ingest/Location History (Timeline)-20260622T225253Z-3-001.zip", "raw/self/location/2026-06-22-ingest/Location History (Timeline)/semantic_location.db", "raw/self/location/2026-06-22-ingest/Location History (Timeline)/Records.json", "raw/self/facebook/facebook-ihatedanfrank/", "raw/self/archives/google-data-export-index-20260623.html"]
related:
  - wiki/self/context-core
  - wiki/self/overview
  - wiki/self/facebook
  - wiki/self/facebook
  - wiki/self/facebook
  - wiki/self/facebook/messages
  - wiki/self/youtube-watch-history
  - wiki/self/twitter
  - wiki/self/ancestry
  - wiki/mind/synthesis/family-heritage-and-roots
  - wiki/mind/synthesis/totality-themes
  - wiki/mind/synthesis/millennial-digital-witness
  - wiki/timeline/periods/2017-poverty-floor
  - wiki/timeline/periods/2018-deep-cycle
  - wiki/timeline/periods/2021-2023-employment-block
  - wiki/timeline/periods/dec-2025-spike
  - wiki/timeline/periods/2025-collapse
  - wiki/people/suz
  - wiki/people/rick-frank
  - wiki/people/fran-whyel
  - wiki/people/david-j-frank
  - wiki/interests/favorites/music
---

# Location History (Google Timeline)

## Corpus Dimensions

| Metric                  | Value                          |
|-------------------------|--------------------------------|
| Source                  | Google Takeout Timeline export (2026-06-22) |
| Files                   | 98 monthly JSONs (Semantic Location History 2014-2024 partial) + Records.json (28MB raw points from 2014-04) + semantic_location.db (2.1MB, 6227 visits) + Settings.json + Timeline Edits.json |
| Date range              | 2014-04 – 2024 (partial 2024; Records.json earliest 2014-04-02) |
| Total place visits      | 6,227                         |
| Total activity segments | ~6,700                        |
| Years covered           | 11 (2014-2024)                |
| PA-ish visits (addr/name match Uniontown/PA/Farmington) | 3,815 |
| NYC-ish visits (NY/ New York / 76th / 1st Ave) | 2,301 |

### Visits by Year (from semantic db)

| Year | Place Visits | Notes |
|------|--------------|-------|
| 2014 | 108         | Early data (starts ~Aug; Records Apr) |
| 2015 | 23          | Low |
| 2016 | 531         | Rising |
| 2017 | 1,111       | Peak activity |
| 2018 | 1,716       | Highest (258 in Aug alone) |
| 2019 | 809         | NYC transition |
| 2020 | 121         | Sharp drop (pandemic) |
| 2021 | 257         | Low |
| 2022 | 806         | Resurgence |
| 2023 | 728         | Sustained |
| 2024 | 17          | Very low / incomplete in export |

Peak mobility 2017-2018 (2,827 visits). NYC chapter 2019 onward accounts for majority of non-PA. 2020-21 low mobility aligns employment + pandemic. Resurgence 2022-23 matches YT/Twitter/other. 

## Google Takeout Archive Index
The source `raw/self/archives/google-data-export-index-20260623.html` is the browser-rendered index for the Google Takeout (May 14, 2024, 2:06 AM PDT) for dfrank88@gmail.com. 

**Contents indexed:** 66.1 MB total; **Products in Archive (1):** LOCATION_HISTORY (Timeline export). 99 files (monthly JSONs + Records.json + semantic_location.db + Settings + Timeline Edits). Semantic Location History JSONs from 2014+. Matches exactly the 2026-06-22 raw location ingest (98-99 files, 66.1MB zip).

Not a full multi-product Takeout; no YouTube, Gmail, Drive, Photos etc. in this particular archive (separate YT watch history HTML export exists at `raw/self/youtube-watch-history/YOUTUBE WATCH HISTORY (2010-2025).html` and ingest/).

**Cross-refs:**
- Confirms location-history corpus dimensions (99 files, semantic db 6227 visits).
- [[wiki/self/youtube-watch-history]] (parallel but independent Google data source).
- [[wiki/self/facebook]] (FB location / login cross).
- Noted in self/index + phenom/context as "digital witness" substrate.
- Archive browser reinforces no new phenom concepts; pure data index.

### Granular by Period (cross to wiki periods)

| Period | Years | Visits | Notes / Ties |
|--------|-------|--------|--------------|
| Pre / Origin (FB documented) | ~2010-2013 | N/A (loc starts 2014) | FB profile: Brooklyn Jan 2010; hometown Uniontown; events 2012-2014 (e.g. Jul 2014, Feb 2013). FB security logins start sparse ~2022 in export. |
| 2014-2016 ramp | 2014-16 | 662 | Early PA cluster; FB events align data start. |
| 2017-poverty-floor + 2018-deep-cycle | 2017-18 | 2,827 | Highest volume; local Uniontown/Farmington heavy (e.g. 73 Smith School House Rd 206, 117 Belmont 246). High mobility pre-NYC move. |
| NYC chapter (2019-Feb 2025) | 2019-23 | ~2,593 (2019-23) | 307 E 76th 1,082; Au Za'atar 445; 1063 1st Ave. FB profile "current city New York". Low 2020-21 (85+257). 2022-23 high (806+728). |
| 2021-2023-employment-block | 2021-23 | ~1,791 | Lower than 17-18 peaks; concentrated home/work pins. Resurgence despite block. |
| 2025-collapse / post | 2024- | Low | 2024 17; return to 337 Saratoga noted in core; loc export cutoff post-Feb 2025 PA return + Annie events. |
| Ancestry roots overlay | 1988+ | Generational | See below. |

## Family Geographic Roots (from 23andMe + Ancestry GEDCOM tree)
Multi-generational concentration in Fayette County PA (Uniontown, Brownsville, Hopwood, Champion) + maternal WV origins (Fort Martin) directly grounds the location corpus. Tree residences match core addresses (337 Saratoga Drive family-built 1996; 12 Bryer Ave pre-1996) and repeated Uniontown chapters. 

- Dan born 1988-11-01 Uniontown, Fayette, PA.
- Father Richard Harrison Frank b.1959 Uniontown; multiple RESI Uniontown 1993-2002.
- Paternal great-grandparents: David J. Frank (1892 Russia) + Sadie Harris (1900 Austria) — Jewish immigrants to Brownsville/Hopwood PA. Grandfather Morley Jay Frank (1927 Brownsville – 1998 Hopwood).
- Maternal: Fran Whyel (Jesse Frances Thomas Whyel /Coldren, 1920 Fort Martin WV – 2018 Uniontown); mother Suzanne.
- Core match: 337 Saratoga (family-built), Uniontown addresses dominate loc visits + FB hometown.

See [[wiki/self/ancestry]], [[wiki/mind/synthesis/family-heritage-and-roots]], [[wiki/people/rick-frank]], [[wiki/people/fran-whyel]], [[wiki/people/david-j-frank]].
- Cross to periods: Origin (1988-2008), poverty floor, deep cycle all in this geography. PA cluster 3,815 visits.
- No contradictions; extends the 2014-2024 data with generational context. Ties also to legal (Suz realtor activity on family properties), music (Fran gifted Numark NS7 → sub-bass).

Data is privacy-redacted (many "Unnamed" or generic). High volume of precise home/work pins. 4,306 unnamed visits in db.

## Visits by Year

| Year | Place Visits | Notes |
|------|--------------|-------|
| 2014 | 108         | Early data |
| 2015 | 23          | Low |
| 2016 | 531         | Rising |
| 2017 | 1,111       | Peak activity |
| 2018 | 1,716       | Highest |
| 2019 | 809         | NYC transition |
| 2020 | 121         | Sharp drop (pandemic) |
| 2021 | 257         | Low |
| 2022 | 806         | Resurgence |
| 2023 | 728         | Sustained |
| 2024 | 17          | Very low / incomplete in export |

## Top Locations (by visits; db aggregates + address variants collapsed where obvious)

| Location                                      | Visits | Context |
|-----------------------------------------------|--------|---------|
| 307 E 76th St, New York, NY 10021, USA        | 1,082  | NYC apartment (2019-2025 chapter) |
| 155 Virginia Avenue, Uniontown, PA            | 849    | Uniontown residence |
| Au Za'atar (and Midtown East)                 | 445    | Frequent restaurant (NYC) |
| 337 Saratoga Drive, Uniontown, PA             | ~415 (297+118+...) | Family home (multiple periods; built 1996) |
| 117 Belmont Circle, Uniontown, PA             | 246    | Local address |
| 73 Smith School House Road, Farmington, PA    | 206    | Recurring (near roots) |
| 1063 1st Ave., New York, NY                   | 201    | NYC location (Au Za'atar addr) |
| 147 Virginia Ave, Uniontown, PA               | 128    | Local |
| McDonald's                                    | 130    | Chain visits |
| CVS                                           | 126    | Chain |

Strong home-centric pattern: the top named non-generic locations are current/former residences and one favorite eatery. Chain locations (fast food, pharmacy) are background noise.

### Top PA / Uniontown / Fayette Addresses (sample from 3,815 PA)
- 155 Virginia Avenue, Uniontown: 849 + variants
- 337 Saratoga Drive / Dr, Uniontown: ~415 total
- 117 Belmont Circle / Cir, Uniontown: 246+
- 73 Smith School House Road, Farmington: 206
- 147 Virginia Ave, Uniontown: 128+
- Uniontown Country Club: 82 (ties FB golf/caddie mentions)
- Lady Luck Casino Nemacolin, Wharton Twp PA: 28

### Top NYC Addresses (sample from 2,301 NYC)
- 307 E 76th St: 1,082
- 1063 1st Ave (Au Za'atar): 249 + 201
- 1396 2nd Ave: 121
- 188 E 86th St: samples
- 215/301/349/370 E 76th area small (salon, club)

### Chain / Generic (background; 4,306 unnamed overall)
McDonald's 130, CVS 126, Walgreens 24, Walmart 23, Sheetz 22, KeyBank 66, Sunoco 30, PLS Check Cashing 28, Vapor Hut 34, Shepherds Rock #13 50.

## Relation to Self Model

- **Confirms canonical residence timeline** in [[wiki/self/context-core]] §4:
  - NYC 307 E 76th (high 1,082 visits) aligns with Feb 2019–Feb 2025 period.
  - Uniontown addresses (337 Saratoga + 155 Virginia) dominate other years.
  - 2020 drop and 2021 low match employment block and pandemic effects.
  - 2022–2023 resurgence consistent with data in other corpora. Aligns YT 2022-23 high volume.

- **Employment block 2021-2023** (see [[wiki/timeline/periods/2021-2023-employment-block]]): ~1,791 visits across those years. Lower mobility than 2017-2018 peaks. Fixed note: ~98 JSONs (not 95) in export.

- **Poverty floor / deep cycle 2017-2018** ([[wiki/timeline/periods/2017-poverty-floor]], [[wiki/timeline/periods/2018-deep-cycle]]): Peak 2,827 visits; local PA heavy (Uniontown + Farmington / Wharton Twp). High signal before NYC move.

- **Current / post-closure**: Low 2024 counts may reflect data export cutoff, phone changes, or reduced travel after return to Uniontown Feb 2025 and major life events (Annie closure June 2026). 337 Saratoga remains high-signal home base. Ties [[wiki/timeline/periods/2025-collapse]].

- **Ancestry / FB pre-2014 context**: FB profile (ihatedanfrank, reg. 2007-01-09) lists hometown Uniontown PA, places lived Brooklyn NYC (from Jan 3, 2010), current city New York (at snapshot). FB events include 2012-2014 dates (e.g. Jul 4 2014, Feb 22 2013, May 2012) aligning loc data start 2014. FB security_and_login_information exports mostly 2022+ (67-151 dates, PA mentions), consistent with later periods. No contradiction.

- Complements other behavioral streams:
  - [[wiki/self/youtube-watch-history]] (digital attention; 2022-23 loc resurgence matches YT 5k+ watched + YT Music; portable across homes)
  - [[wiki/self/twitter]] (public expression)
  - [[wiki/self/favorites]] / [[wiki/interests/favorites/music]] (cultural; ODESZA 2014 FB like during loc PA base)
  - iMessage / voice (social)
  - [[wiki/self/facebook]] full: profile bio/education/work (Au Za'atar NYC job ties loc restaurant pin 445), events, security logins, liked pages (196: ODESZA, comedy clubs, politics, electronic labels).

The data shows a life with clear "home bases" (Uniontown family properties + one NYC apartment) and limited long-distance travel outside those nodes. This supports Contact Gini themes (concentrated physical world) and the high Si (archivist) + low Sociability profile. PA roots explain repeated returns and volume concentration.

## Ties to Facebook Events / Security / Profile (2010+)
- Profile: Early digital identity (2007 reg), Brooklyn move 2010, Uniontown hometown, relationship status, work (Nemacolin PA, Au Za'atar NYC). Political views DSA.
- Events: 2012-2014 responses documented; pre-dates full loc but grounds 2014 start of 108 visits.
- Security: account_activity / logins / ip (39 unique) show 2022+ activity (earliest Aug 2022 in parses); "pa" mentions frequent in loc fields. Limited older export data but consistent with FB profile timeline.
- Cross: FB likes ODESZA Oct 2014 + electronic (JAUZ, DIM MAK etc) during loc PA base + early YT radio era. Comedy club likes align entertainment patterns.

## Data Notes & Limitations
- Large "Unnamed" / "Unknown" category (4,306 in db) due to Google's labeling.
- Some addresses appear with slight variations (e.g., 337 Saratoga Drive vs Dr; Virginia Avenue vs Ave).
- Export dated 2026-06-22; 2024 coverage is minimal (possible device change or opt-out). Records.json provides raw lat/long backup from 2014-04.
- Includes both place visits and activity segments (walking, driving, etc.).
- Cross-referenced against [[wiki/self/context-core]] biography, [[wiki/self/facebook]] profile/events, and ancestry GEDCOM for validation. No major incompletes; 98 JSONs confirmed via dir.

## Sources
- Raw export: `raw/self/location/2026-06-22-ingest/`
- Primary: monthly Semantic Location History JSONs + semantic_location.db (visits/activities tables) + Records.json (raw points)
- Cross: `raw/self/facebook/facebook-ihatedanfrank/` (profile, events, security_and_login_information, pages_and_profiles/pages_you_ve_liked.html)

See also:
- [[wiki/self/context-core]] (canonical residence timeline)
- [[wiki/timeline/periods/2017-poverty-floor]], [[wiki/timeline/periods/2018-deep-cycle]], [[wiki/timeline/periods/2021-2023-employment-block]]
- [[wiki/self/overview]]
- [[wiki/self/youtube-watch-history]] (cross consumption)
- [[wiki/self/facebook]] (events 2012+, profile 2010 Brooklyn, likes 2014 ODESZA)
- [[wiki/self/ancestry]] (Fayette PA roots grounding)
- [[wiki/mind/synthesis/family-heritage-and-roots]], [[wiki/mind/synthesis/totality-themes]]