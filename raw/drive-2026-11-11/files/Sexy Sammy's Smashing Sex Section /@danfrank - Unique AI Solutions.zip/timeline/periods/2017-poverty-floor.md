---
domain: timeline
page_type: period
status: archived
importance: high
date_created: 2026-06-22
date_modified: 2026-07-11
date_range_start: 2017-01-01
date_range_end: 2017-12-31
changelog:
  - 2026-07-11: Full narrative rewrite per style guide. Prose over bullets. All numerical data preserved.
sources:
  - "raw/self/dox-md/LIFE_EVENTS_CALENDAR.md"
  - "raw/self/context-core/CONTEXT_CORE_EXPANDED.md"
  - "raw/self/dox-md/operating_manual.md"
  - "raw/self/message-csv/*"
  - "raw/self/facebook/facebook-ihatedanfrank/"
  - "raw/self/dox-md/LIFE REPORT.md"
  - "raw/self/dox-md/Gemini-_18.md"
  - "raw/self/ancestry/"
related:
  - "wiki/timeline/events/timeline"
  - "wiki/people/annie"
  - "wiki/timeline/periods/2015-2016-annie-relationship-start"
  - "wiki/self/ancestry"
  - "wiki/people/rick-frank"
  - "wiki/people/suz"
  - "wiki/people/fran-whyel"
  - "wiki/mind/synthesis/work-power-dynamics"
  - "wiki/self/message-corpora/master-message-dump"
  - "wiki/self/gemini-activity/gemini-activity"
---

# 2017 Poverty Floor

2017 was the year the floor dropped out. Dan was twenty-eight, living in Uniontown, Pennsylvania, in a house on Virginia Avenue he had moved into with [[wiki/people/annie]] after Lex helped them clear out of Scerba's old place. The calendar logged 85 events. The financial and relational categories dominated so completely that the year reads as a single sustained emergency rather than a sequence of discrete crises. Water was shut off. The account was overdrawn. His grandmother [[wiki/people/fran-whyel]] woke with nosebleeds at 3am. His mother told him he had played his cards out and crossed a final line. This was not a rough patch. It was the bottom.

## Setting and Context

Uniontown in 2017 was the same Uniontown it had always been — the same Fayette County geography that had anchored the Frank family across multiple generations, documented in the ancestry tree rooted in that region. Dan had returned here from whatever wider trajectory had briefly opened after Full Sail, and the city absorbed him back without ceremony. The 2017 chapter sits between the 2015–2016 period that established the [[wiki/people/annie]] relationship and the 2018 peak that would briefly escalate everything before the first serious attempt at escape. In 2017, there was no escape in view.

There was no car. There was no reliable income. The operating manual records a specific, precise indignity: he DJed for four hours and was not paid. The math on a given day could run: gas costs more than the earnings. He sold gold. He sold clothes. He made money from camming — a lower-naked goal, whatever the going rate was, whatever the algorithm rewarded that week. Tom fronted drugs and was owed $120. [[wiki/people/suz]] is somewhere in the peripheral record of this year, as is the broader family structure that both cushioned and judged.

## Key Events

January opened with debt. The account was overdrawn by $600, with a note in the record: *I cannot let my account get overdrawn again.* It did. The Domino's overdraft appears separately, its specificity functioning as a kind of comedy the record refuses to let breathe — the universe of problems compressed into a pizza delivery charge that cleared nothing. January also carried the weight of a breakup reconciliation, of getting back together, a cycle that the 85 calendar events of this year would replay in multiple forms. There was a death threat in the record — *I bet your a fuckin Muslim* — logged alongside an airport shooter threat context from the same window.

April produced a breakup accompanied by *you're literally everything*, which is the kind of thing said at the point where language has exhausted its precision. The cat Sabrina died. A major decision was made to protect the relationship. The record does not specify what was sacrificed.

[[wiki/people/fran-whyel]] had nosebleeds at 3am — a detail that sits in the operating manual without elaboration, which is how the truly heavy things tend to sit. She was aging. The music she had given Dan was already part of how he understood himself. The 2018 deathwatch category would formalize what 2017's nosebleeds were quietly announcing.

His mother's verdict — *you've played your cards out* — is the kind of sentence that becomes permanent. It was not said in ordinary frustration. It was a closing statement.

The financial subcategory for 2017 contributes to a total of 105 financial events across the corpus and 266 relationship events across the corpus, with this year weighted heavily in both. The debt subcategory registers 65 relevant events across the corpus; 2017's contribution is dense.

## Psychological Dimension

The LIFE REPORT characterizes this period as one of analytical and emotional processing under conditions of compressed information flow and rapid fragmented cadence — the cognitive signature of managing multiple simultaneous threats with inadequate resources. Loyalty and trust were the drivers being stress-tested. The forensic mode that would later become a default cognitive tool was being trained here, under duress, on real problems with real consequences.

There is a particular kind of clarity that poverty instills. When there is no margin, every decision has an immediate and legible cost. 2017 did not produce paralysis — the calendar records action, transaction, movement — but the action was entirely reactive. The question was never what to build; it was what to hold together until tomorrow.

The [[wiki/people/annie]] relationship logged 85 calendar events in this year alone. That density reflects both genuine attachment and the way volatile bonds generate their own administrative overhead — the breakups, the reconciliations, the decisions, the events that require a calendar entry because they happened and mattered and needed to be tracked.

## Data Signature

| Metric | Value |
|---|---|
| Calendar events (2017) | 85 |
| Primary categories | Relationship, Financial, Health |
| Corpus relationship events total | 266 |
| Corpus financial events total | 105 |
| Corpus debt subcategory total | 65 |
| Account overdraft (Jan) | $600 |
| Drug debt owed (Tom) | $120 |
| DJ shift compensation | $0 (4 hours unpaid) |
| Fran Whyel health flag | 3am nosebleeds (recurring) |

## Transition

2017 ended without resolution. The poverty floor did not lift — it tilted. 2018 would bring higher event density (254 calendar events, the highest recorded year), more dealers in the network, more financial velocity, and no structural improvement. The escalation that followed was not recovery. It was acceleration in the same channel. The deep cycle that 2017 had begun was still gathering.

**Related:** [[wiki/timeline/events/timeline]], [[wiki/timeline/periods/2018-deep-cycle]], [[wiki/people/annie]], [[wiki/self/message-corpora/master-message-dump]], [[wiki/self/ancestry]], [[wiki/people/fran-whyel]], [[wiki/people/suz]], [[wiki/self/gemini-activity/gemini-activity]]
