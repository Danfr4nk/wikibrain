---
domain: interests
page_type: entity
status: active
importance: medium
date_created: 2026-06-22
date_modified: 2026-07-11
sources: ["raw/self/favorites/FAVS MASTERLIST.csv"]
related:
  - "wiki/interests/favorites/books"
  - "wiki/interests/favorites/books/topics/war"
  - "wiki/interests/favorites/books/topics/ancient-history"
  - "wiki/self/context-core"
changelog:
  - 2026-07-11: Full rewrite from stub. Added thematic framing, podcast-to-book context, wiki links.
---

# Dan Carlin

American journalist turned podcaster turned author, best known for *Hardcore History* — a podcast series that treats episodes of ancient and military history as epic narratives running four to six hours each. Two of those episodes exist as book-length written versions in the favorites list: *Blueprint for Armageddon* (WWI on the Western Front) and *Wrath of the Khans* (the Mongol conquests).

## In Favorites

2 books (both Hardcore History adaptations).

## Why This Author

Carlin's method is to inhabit the human scale of events that historians typically describe from altitude. *Blueprint for Armageddon* doesn't explain the strategic logic of trench warfare so much as it tries to make you understand what it felt like to be in it — the industrial-scale carnage, the literal industrial processing of human bodies, the absurdity of dying for yards. *Wrath of the Khans* does the same with Mongol conquest: not the geopolitics, but the sheer staggering fact of how much violence one force of organized riders could inflict on how many civilizations in how few decades.

This connects both to [[wiki/interests/favorites/books/topics/war]] and [[wiki/interests/favorites/books/topics/ancient-history]] — not as genres but as domains where the gap between official history and lived experience is vast and interesting. Carlin is explicitly in the business of closing that gap through visceral narrative.

The draw here isn't that Carlin is the most rigorous historian — he'd be the first to say he isn't. The draw is the scope. He thinks about history the way a music producer thinks about dynamic range: the contrast between silence and the loudest moment is where the meaning lives. Both WWI and the Mongol conquests are events so enormous that their full emotional weight barely fits inside conventional historical prose. Carlin just makes sure you feel the weight.

## Format Note

The Hardcore History podcast versions of these episodes predate the books and run considerably longer. The books are essentially transcripts refined for the page. The podcast is likely the more familiar format here — the books are the physical artifact of something first encountered as audio.
