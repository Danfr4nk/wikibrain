---
domain: interests
page_type: entity
status: active
importance: high
date_created: 2026-06-22
date_modified: 2026-07-11
sources: ["raw/self/favorites/FAVS MASTERLIST.csv"]
related:
  - "wiki/interests/favorites/music"
  - "wiki/interests/music/overview"
  - "wiki/self/context-core"
changelog:
  - 2026-07-11: Full rewrite from stub. Added producer-lineage framing, post-2016 complexity, wiki links.
---

# Kanye West

Chicago producer and rapper, born 1977. The most consequential hip-hop producer of the 2000s, whose sample-flipping and chipmunk-soul aesthetic on *The College Dropout* and *Late Registration* restructured what mainstream hip-hop sounded like for a decade — and then kept mutating through electronic maximalism (*808s & Heartbreak*, *Yeezus*), orchestral grandiosity (*My Beautiful Dark Twisted Fantasy*), and gospel minimalism (*Donda*). Now a figure whose public behavior has made any uncomplicated engagement with his catalog impossible and has also made that catalog no less formally significant than it was before.

## In Favorites

11 tracks — second only to JPEGMAFIA in the hip-hop cluster.

## Why This Artist

From a production standpoint, the Kanye catalog is obligatory. If you care about how modern hip-hop is constructed — how drums sit, how samples are pitched, how bass and melody negotiate space — you trace a significant portion of contemporary technique back to what he was doing at Roc-A-Fella in 2002. The sped-up soul samples were not just an aesthetic; they were a proof of concept that hip-hop could be emotionally warm without being soft, that grief and joy could coexist in the same four bars.

For someone who produces music, the 11-track count isn't just taste — it's research. You listen to the production on *Runaway* the way you study a score. *Blood on the Leaves*'s orchestration, the way *Heartless* builds a complete emotional world from a two-note synth line — these are craft references.

The post-2016 complexity is real and doesn't resolve into a clean position. The man who made *Jesus Walks* in 2004 and endorsed Trump in 2018 is the same man, and the easiest interpretations of that — either that he was always like this, or that he's simply broken — are both insufficient. The 11-track count represents engagement that hasn't neatly exited despite that complexity, which is its own data point about how Dan processes the relationship between art and the person who made it.

## The Production Lineage

The relevance here is genealogical as much as aesthetic. A music producer in the 2020s who doesn't understand what Kanye built in the 2000s has a significant gap in their understanding of the field. The 11 tracks in the favorites list are at least partly a professional account of that lineage, filed under listening because the production is where the knowledge lives.
