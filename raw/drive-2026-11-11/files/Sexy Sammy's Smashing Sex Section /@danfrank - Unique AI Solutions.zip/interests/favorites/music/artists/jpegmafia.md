---
domain: interests
page_type: entity
status: active
importance: high
date_created: 2026-06-22
date_modified: 2026-07-11
sources: ["raw/self/favorites/FAVS MASTERLIST.csv"]
related:
  - "wiki/interests/favorites/music"
  - "wiki/interests/music/concepts/sub-bass-signature"
  - "wiki/self/context-core"
changelog:
  - 2026-07-11: Full rewrite from stub. Added producer-lens framing, track count analysis, sub-bass connection, wiki links.
---

# JPEGMAFIA

Born Barrington DeVaughn Hendricks in Brooklyn, raised partly in Jamaica, radicalized by Birmingham, Alabama. Makes experimental hip-hop that is confrontational by design — politically, sonically, structurally. His albums (*Veteran*, *All My Heroes Are Cornballs*, *Darkskin Maniac*) are dense collisions of samples, distorted bass, internet-culture references, and lyrics that treat American white supremacy with the flat contempt of someone who has studied it too long to be surprised by it.

## In Favorites

13 tracks — the single highest count in a 1,477-artist library where the average artist appears once. At 13 tracks against a 1.26-track average, JPEGMAFIA is over ten times the typical presence. That's not genre loyalty; that's a sustained relationship with a specific sensibility.

## Why This Artist

The obvious connection is the production. JPEGMAFIA self-produces everything, and his production methodology has more in common with noise music and sound art than with conventional hip-hop beat construction — he treats the track as a space where every element is fighting for dominance and clarity is optional. The sub-bass presence in his work is structural, not decorative: it underpins tracks that are otherwise deliberately abrasive, functioning as the one stable frequency beneath the chaos.

This maps directly to the [[wiki/interests/music/concepts/sub-bass-signature]] that runs across Dan's own production work — the preference for bass as foundation rather than ornament, bass as the thing that makes it okay for everything else to be violent. Peggy's productions demonstrate what it looks like when that principle is pushed to its logical extreme.

The political content is inseparable from the sonic content. The confrontational delivery, the refusal to soften, the specific anger at American institutions — these aren't lyrics laid over beats. They're the same argument made twice simultaneously. A producer who also writes politics is not making two separate things; he's making one.

## The Count

13 tracks from someone whose albums don't have obvious singles in the radio sense means these aren't the popular ones — they're the ones that earned repeat plays through something more specific. JPEGMAFIA rewards close listening in ways that passive consumption doesn't register. The track count is evidence of that kind of engagement.
