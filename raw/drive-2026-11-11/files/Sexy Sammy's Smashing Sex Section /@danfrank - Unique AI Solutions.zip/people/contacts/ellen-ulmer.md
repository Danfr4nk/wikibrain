---
domain: people
page_type: entity
status: archived
date_created: 2026-06-23
date_modified: 2026-07-11
date_range_start: 2017-04-11
date_range_end: 2025-11-01
sources: ["raw/self/message-csv/MASTER_MESSAGES_DB_DUMP.csv"]
related: ["wiki/self/message-corpora/master-message-dump", "wiki/mind/concepts/contact-gini"]
---

# Ellen Ulmer## Identity
Contact identified via Google Contacts as Ellen Ulmer. Previously unresolved contact from iMessage corpus at handle `+17243662589`. 63 messages exchanged over 2017-04-11 to 2025-11-01. Sample interaction: "Thanks Dan. I appreciate the offer and will keep it in mind as things progress- especially with B. E". Appears in personal message contexts (not obvious spam per filter).

## Corpus Dimensions
| Metric | Value |
|--------|-------|
| Messages | 63 |
| Date range | 2017-04-11 – 2025-11-01 |
| Sent / Received (approx) | 0 / 63 |
| Sample | Thanks Dan. I appreciate the offer and will keep it in mind as things progress- especially with B. E. |

## Domain: Self
Part of the long-tail or mid-tier social graph. Contributes to contact Gini distribution and period behavioral profiles.

## Notes
Stub generated from MASTER_MESSAGES_DB_DUMP.csv analysis. Expand with any additional context from dox, FB, or other threads if identity emerges. Personal vs transactional role not fully resolved from this source alone.

## Related
- [[wiki/self/message-corpora/master-message-dump]]
- [[wiki/mind/concepts/contact-gini]]
