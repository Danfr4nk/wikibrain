---
domain: people
page_type: entity
status: archived
date_created: 2026-06-23
date_modified: 2026-07-11
date_range_start: 2016-02-12
date_range_end: 2016-06-01
sources: ["raw/self/message-csv/MASTER_MESSAGES_DB_DUMP.csv"]
related: ["wiki/self/message-corpora/master-message-dump", "wiki/mind/concepts/contact-gini"]
---

# John Felix## Identity
Contact identified via Google Contacts as John Felix. Previously unresolved contact from iMessage corpus at handle `+17249636738`. 59 messages exchanged over 2016-02-12 to 2016-06-01. Sample interaction: "Come on". Appears in personal message contexts (not obvious spam per filter).

## Corpus Dimensions
| Metric | Value |
|--------|-------|
| Messages | 59 |
| Date range | 2016-02-12 – 2016-06-01 |
| Sent / Received (approx) | 0 / 59 |
| Sample | Come on |

## Domain: Self
Part of the long-tail or mid-tier social graph. Contributes to contact Gini distribution and period behavioral profiles.

## Notes
Stub generated from MASTER_MESSAGES_DB_DUMP.csv analysis. Expand with any additional context from dox, FB, or other threads if identity emerges. Personal vs transactional role not fully resolved from this source alone.

## Related
- [[wiki/self/message-corpora/master-message-dump]]
- [[wiki/mind/concepts/contact-gini]]
