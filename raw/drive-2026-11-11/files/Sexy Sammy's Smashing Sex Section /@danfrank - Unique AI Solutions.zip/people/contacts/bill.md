---
domain: people
page_type: entity
status: archived
date_created: 2026-06-23
date_modified: 2026-07-11
date_range_start: 2018-09-04
date_range_end: 2018-09-20
sources: ["raw/self/message-csv/MASTER_MESSAGES_DB_DUMP.csv"]
related: ["wiki/self/message-corpora/master-message-dump", "wiki/mind/concepts/contact-gini"]
---

# Bill## Identity
Contact identified via Google Contacts as Bill. Previously unresolved contact from iMessage corpus at handle `+17244157026`. 21 messages exchanged over 2018-09-04 to 2018-09-20. Sample interaction: "Yeah I'd like to get 14 of them. That's like 95 bucks. What time u gonna have them I gotta come to t". Appears in personal message contexts (not obvious spam per filter).

## Corpus Dimensions
| Metric | Value |
|--------|-------|
| Messages | 21 |
| Date range | 2018-09-04 – 2018-09-20 |
| Sent / Received (approx) | 0 / 21 |
| Sample | Yeah I'd like to get 14 of them. That's like 95 bucks. What time u gonna have them I gotta come to town anyways. |

## Domain: Self
Part of the long-tail or mid-tier social graph. Contributes to contact Gini distribution and period behavioral profiles.

## Notes
Stub generated from MASTER_MESSAGES_DB_DUMP.csv analysis. Expand with any additional context from dox, FB, or other threads if identity emerges. Personal vs transactional role not fully resolved from this source alone.

## Related
- [[wiki/self/message-corpora/master-message-dump]]
- [[wiki/mind/concepts/contact-gini]]
