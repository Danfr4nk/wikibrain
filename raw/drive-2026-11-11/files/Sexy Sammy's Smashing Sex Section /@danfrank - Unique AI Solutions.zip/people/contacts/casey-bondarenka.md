---
domain: people
page_type: entity
status: archived
date_created: 2026-06-23
date_modified: 2026-07-11
date_range_start: 2015-11-29
date_range_end: 2018-10-24
sources: ["raw/self/message-csv/MASTER_MESSAGES_DB_DUMP.csv"]
related: ["wiki/self/message-corpora/master-message-dump", "wiki/mind/concepts/contact-gini"]
---

# Casey Bondarenka## Identity
Contact identified via Google Contacts as Casey Bondarenka. Previously unresolved contact from iMessage corpus at handle `+17245626199`. 36 messages exchanged over 2015-11-29 to 2018-10-24. Sample interaction: "Yoooo.. I got a pen vape for dabs. How much does a single dab cost so I'm sure it works for me and I". Appears in personal message contexts (not obvious spam per filter).

## Corpus Dimensions
| Metric | Value |
|--------|-------|
| Messages | 36 |
| Date range | 2015-11-29 – 2018-10-24 |
| Sent / Received (approx) | 0 / 36 |
| Sample | Yoooo.. I got a pen vape for dabs. How much does a single dab cost so I'm sure it works for me and I like it |

## Domain: Self
Part of the long-tail or mid-tier social graph. Contributes to contact Gini distribution and period behavioral profiles.

## Notes
Stub generated from MASTER_MESSAGES_DB_DUMP.csv analysis. Expand with any additional context from dox, FB, or other threads if identity emerges. Personal vs transactional role not fully resolved from this source alone.

## Related
- [[wiki/self/message-corpora/master-message-dump]]
- [[wiki/mind/concepts/contact-gini]]
