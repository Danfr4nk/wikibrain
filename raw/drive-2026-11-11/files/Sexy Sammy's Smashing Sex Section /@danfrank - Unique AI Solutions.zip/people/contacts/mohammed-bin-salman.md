---
domain: people
page_type: entity
status: archived
date_created: 2026-06-23
date_modified: 2026-07-11
date_range_start: 2023-09-29
date_range_end: 2024-08-12
sources: ["raw/self/message-csv/MASTER_MESSAGES_DB_DUMP.csv"]
related: ["wiki/self/message-corpora/master-message-dump", "wiki/mind/concepts/contact-gini"]
---

# Mohammed Bin salman## Identity
Contact identified via Google Contacts as Mohammed Bin salman. Previously unresolved contact from iMessage corpus at handle `+13474936671`. 281 messages exchanged over 2023-09-29 to 2024-08-12. Sample interaction: "May I inquire on the reason m’lord". Appears in personal message contexts (not obvious spam per filter).

## Corpus Dimensions
| Metric | Value |
|--------|-------|
| Messages | 281 |
| Date range | 2023-09-29 – 2024-08-12 |
| Sent / Received (approx) | 0 / 281 |
| Sample | May I inquire on the reason m’lord |

## Domain: Self
Part of the long-tail or mid-tier social graph. Contributes to contact Gini distribution and period behavioral profiles.

## Notes
Stub generated from MASTER_MESSAGES_DB_DUMP.csv analysis. Expand with any additional context from dox, FB, or other threads if identity emerges. Personal vs transactional role not fully resolved from this source alone.

## Related
- [[wiki/self/message-corpora/master-message-dump]]
- [[wiki/mind/concepts/contact-gini]]
