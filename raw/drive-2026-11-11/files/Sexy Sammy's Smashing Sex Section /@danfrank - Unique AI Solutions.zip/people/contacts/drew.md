---
domain: people
page_type: entity
status: archived
date_created: 2026-06-23
date_modified: 2026-07-11
date_range_start: 2017-06-20
date_range_end: 2017-07-01
sources: ["raw/self/message-csv/MASTER_MESSAGES_DB_DUMP.csv"]
related: ["wiki/self/message-corpora/master-message-dump", "wiki/mind/concepts/contact-gini"]
---

# Drew## Identity
Contact identified via Google Contacts as Drew. Previously unresolved contact from iMessage corpus at handle `+17244157295`. 45 messages exchanged over 2017-06-20 to 2017-07-01. Sample interaction: "Wambam". Appears in personal message contexts (not obvious spam per filter).

## Corpus Dimensions
| Metric | Value |
|--------|-------|
| Messages | 45 |
| Date range | 2017-06-20 – 2017-07-01 |
| Sent / Received (approx) | 0 / 45 |
| Sample | Wambam |

## Domain: Self
Part of the long-tail or mid-tier social graph. Contributes to contact Gini distribution and period behavioral profiles.

## Notes
Stub generated from MASTER_MESSAGES_DB_DUMP.csv analysis. Expand with any additional context from dox, FB, or other threads if identity emerges. Personal vs transactional role not fully resolved from this source alone.

## Related
- [[wiki/self/message-corpora/master-message-dump]]
- [[wiki/mind/concepts/contact-gini]]
