---
domain: people
page_type: entity
status: archived
date_created: 2026-06-23
date_modified: 2026-07-11
date_range_start: 2017-12-08
date_range_end: 2018-04-05
sources: ["raw/self/message-csv/MASTER_MESSAGES_DB_DUMP.csv"]
related: ["wiki/self/message-corpora/master-message-dump", "wiki/mind/concepts/contact-gini"]
---

# Marla## Identity
Contact identified via Google Contacts as Marla. Previously unresolved contact from iMessage corpus at handle `+17245626515`. 52 messages exchanged over 2017-12-08 to 2018-04-05. Sample interaction: "Hi Dan it’s Marla.  Maybe u can do tonite and I’ll do tomorrow?". Appears in personal message contexts (not obvious spam per filter).

## Corpus Dimensions
| Metric | Value |
|--------|-------|
| Messages | 52 |
| Date range | 2017-12-08 – 2018-04-05 |
| Sent / Received (approx) | 0 / 52 |
| Sample | Hi Dan it’s Marla.  Maybe u can do tonite and I’ll do tomorrow? |

## Domain: Self
Part of the long-tail or mid-tier social graph. Contributes to contact Gini distribution and period behavioral profiles.

## Notes
Stub generated from MASTER_MESSAGES_DB_DUMP.csv analysis. Expand with any additional context from dox, FB, or other threads if identity emerges. Personal vs transactional role not fully resolved from this source alone.

## Related
- [[wiki/self/message-corpora/master-message-dump]]
- [[wiki/mind/concepts/contact-gini]]
