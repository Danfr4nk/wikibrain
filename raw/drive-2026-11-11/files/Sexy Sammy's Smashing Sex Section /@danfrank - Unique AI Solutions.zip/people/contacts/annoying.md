---
domain: people
page_type: entity
status: archived
date_created: 2026-06-23
date_modified: 2026-07-11
date_range_start: 2019-06-02
date_range_end: 2019-07-17
sources: ["raw/self/message-csv/MASTER_MESSAGES_DB_DUMP.csv"]
related: ["wiki/self/message-corpora/master-message-dump", "wiki/mind/concepts/contact-gini"]
---

# annoying## Identity
Contact identified via Google Contacts as annoying. Previously unresolved contact from iMessage corpus at handle `+13057095740`. 87 messages exchanged over 2019-06-02 to 2019-07-17. Sample interaction: "Hey bro". Appears in personal message contexts (not obvious spam per filter).

## Corpus Dimensions
| Metric | Value |
|--------|-------|
| Messages | 87 |
| Date range | 2019-06-02 – 2019-07-17 |
| Sent / Received (approx) | 0 / 87 |
| Sample | Hey bro |

## Domain: Self
Part of the long-tail or mid-tier social graph. Contributes to contact Gini distribution and period behavioral profiles.

## Notes
Stub generated from MASTER_MESSAGES_DB_DUMP.csv analysis. Expand with any additional context from dox, FB, or other threads if identity emerges. Personal vs transactional role not fully resolved from this source alone.

## Related
- [[wiki/self/message-corpora/master-message-dump]]
- [[wiki/mind/concepts/contact-gini]]
