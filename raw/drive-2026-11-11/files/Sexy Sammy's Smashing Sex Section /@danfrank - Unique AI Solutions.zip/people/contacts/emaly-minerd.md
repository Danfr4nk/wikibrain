---
domain: people
page_type: entity
status: archived
date_created: 2026-06-23
date_modified: 2026-07-11
date_range_start: 2018-09-02
date_range_end: 2019-01-27
sources: ["raw/self/message-csv/MASTER_MESSAGES_DB_DUMP.csv", "raw/self/dox-md/LIFE_EVENTS_CALENDAR.md"]
related: ["wiki/self/message-corpora/master-message-dump", "wiki/mind/concepts/contact-gini"]
---

# Emaly Minerd## Identity
Non-named contact from iMessage at +17245525006 (613 msgs, concentrated 2018-09 to 2019-01). Sample: "I had a strange dream with you in it last night". 

Heavily referenced in LIFE_EVENTS_CALENDAR with personal milestones: multiple Addiction/Recovery, Crisis, Breakup ×2, Panic Attack, Wedding, Started Dating, Engagement, Arrest, Lawyer/Legal, Publication/Achievement ×2, Moved (other handle cross), Fire (context). Quotes tied to handle include reflections on refined addictions, emotional engagement, sober regrets, and life events. Suggests a close, emotionally charged relationship with significant life transitions documented around 2018.

## Corpus Dimensions
| Metric | Value |
|--------|-------|
| Messages | 613 |
| Date range | 2018-09-02 – 2019-01-27 |
| Sent / Received (approx) | 0 / 613 |
| Sample | I had a strange dream with you in it last night |

## Domain: Self
Part of the long-tail or mid-tier social graph. Contributes to contact Gini distribution and period behavioral profiles. Strong signal in LIFE calendar for 2018 period (addiction, relationships, legal/crisis events).

## Timeline (LIFE Events tagged to handle)
- Multiple **Addiction/Recovery** (2018-10+): Discussions of sobriety, refined addictions, "Lol so you may regret this when you're sober".
- **Crisis**, **Panic Attack**, **Breakup** (×2+), **Financial Milestone**.
- **Wedding**, **Engagement**, **Started Dating** — significant relational milestones logged.
- **Arrest**, **Lawyer/Legal**, **Publication/Achievement** ×2 — legal and achievement nodes.
- Context quotes: "I'm very proud of how well refined these addictions are. I don't want to live some boring, normal existence." Cross to other handles for "Moved".

## Notes
Stub generated from MASTER_MESSAGES_DB_DUMP.csv analysis + LIFE cross. 2018 concentration aligns with deep-cycle/poverty periods. No clean name emerged; high personal event density suggests close confidant role. Expand if FB/dox names this handle.

## Related
- [[wiki/self/message-corpora/master-message-dump]]
- [[wiki/mind/concepts/contact-gini]]
- raw/self/dox-md/LIFE_EVENTS_CALENDAR.md (detailed event tags)
- Periods 2018-deep-cycle, 2017-poverty-floor
