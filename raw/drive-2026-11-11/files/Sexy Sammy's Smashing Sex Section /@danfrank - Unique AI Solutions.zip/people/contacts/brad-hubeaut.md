---
domain: people
page_type: entity
status: archived
date_created: 2026-06-23
date_modified: 2026-07-11
date_range_start: 2017-10-13
date_range_end: 2018-10-03
sources: ["raw/self/message-csv/MASTER_MESSAGES_DB_DUMP.csv"]
related: ["wiki/self/message-corpora/master-message-dump", "wiki/mind/concepts/contact-gini"]
---

# Brad Hubeaut## Identity
Contact identified via Google Contacts as Brad Hubeaut. Previously unresolved contact from iMessage corpus at handle `+13042162954`. 163 messages exchanged over 2017-10-13 to 2018-10-03. Sample interaction: "11:00 report". Appears in personal message contexts (not obvious spam per filter).

## Corpus Dimensions
| Metric | Value |
|--------|-------|
| Messages | 163 |
| Date range | 2017-10-13 – 2018-10-03 |
| Sent / Received (approx) | 0 / 163 |
| Sample | 11:00 report |

## Domain: Self
Part of the long-tail or mid-tier social graph. Contributes to contact Gini distribution and period behavioral profiles.

## Notes
Stub generated from MASTER_MESSAGES_DB_DUMP.csv analysis. Expand with any additional context from dox, FB, or other threads if identity emerges. Personal vs transactional role not fully resolved from this source alone.

## Related
- [[wiki/self/message-corpora/master-message-dump]]
- [[wiki/mind/concepts/contact-gini]]
