---
domain: people
page_type: entity
status: archived
date_created: 2026-06-23
date_modified: 2026-07-11
date_range_start: 2019-03-17
date_range_end: 2019-08-16
sources: ["raw/self/message-csv/MASTER_MESSAGES_DB_DUMP.csv"]
related: ["wiki/self/message-corpora/master-message-dump", "wiki/mind/concepts/contact-gini"]
---

# Del## Identity
Contact identified via Google Contacts as Del. Previously unresolved contact from iMessage corpus at handle `+19177251279`. 65 messages exchanged over 2019-03-17 to 2019-08-16. Sample interaction: "Sorry for the late reply. We have various StIIIzy strains available. I'm presently downtown but head". Appears in personal message contexts (not obvious spam per filter).

## Corpus Dimensions
| Metric | Value |
|--------|-------|
| Messages | 65 |
| Date range | 2019-03-17 – 2019-08-16 |
| Sent / Received (approx) | 0 / 65 |
| Sample | Sorry for the late reply. We have various StIIIzy strains available. I'm presently downtown but headed to the upper East |

## Domain: Self
Part of the long-tail or mid-tier social graph. Contributes to contact Gini distribution and period behavioral profiles.

## Notes
Stub generated from MASTER_MESSAGES_DB_DUMP.csv analysis. Expand with any additional context from dox, FB, or other threads if identity emerges. Personal vs transactional role not fully resolved from this source alone.

## Related
- [[wiki/self/message-corpora/master-message-dump]]
- [[wiki/mind/concepts/contact-gini]]
