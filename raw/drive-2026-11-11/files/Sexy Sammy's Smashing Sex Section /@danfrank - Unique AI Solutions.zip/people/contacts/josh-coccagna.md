---
domain: people
page_type: entity
status: archived
date_created: 2026-06-23
date_modified: 2026-07-11
date_range_start: 2017-04-12
date_range_end: 2019-02-01
sources: ["raw/self/message-csv/MASTER_MESSAGES_DB_DUMP.csv"]
related: ["wiki/self/message-corpora/master-message-dump", "wiki/mind/concepts/contact-gini"]
---

# Josh Coccagna## Identity
Contact identified via Google Contacts as Josh Coccagna. Previously unresolved contact from iMessage corpus at handle `+14124450765`. 32 messages exchanged over 2017-04-12 to 2019-02-01. Sample interaction: "Don't let your weight get that far to your right side.  Think about keeping it on the inside sole of". Appears in personal message contexts (not obvious spam per filter).

## Corpus Dimensions
| Metric | Value |
|--------|-------|
| Messages | 32 |
| Date range | 2017-04-12 – 2019-02-01 |
| Sent / Received (approx) | 0 / 32 |
| Sample | Don't let your weight get that far to your right side.  Think about keeping it on the inside sole of your foot |

## Domain: Self
Part of the long-tail or mid-tier social graph. Contributes to contact Gini distribution and period behavioral profiles.

## Notes
Stub generated from MASTER_MESSAGES_DB_DUMP.csv analysis. Expand with any additional context from dox, FB, or other threads if identity emerges. Personal vs transactional role not fully resolved from this source alone.

## Related
- [[wiki/self/message-corpora/master-message-dump]]
- [[wiki/mind/concepts/contact-gini]]
