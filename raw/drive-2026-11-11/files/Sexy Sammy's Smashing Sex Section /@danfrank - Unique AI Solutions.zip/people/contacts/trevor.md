---
domain: people
page_type: entity
status: archived
date_created: 2026-06-23
date_modified: 2026-07-11
date_range_start: 2017-10-19
date_range_end: 2020-06-18
sources: ["raw/self/message-csv/MASTER_MESSAGES_DB_DUMP.csv"]
related: ["wiki/self/message-corpora/master-message-dump", "wiki/mind/concepts/contact-gini"]
---

# Trevor## Identity
Contact identified via Google Contacts as Trevor. Previously unresolved contact from iMessage corpus at handle `+12532025869`. 1095 messages exchanged over 2017-10-19 to 2020-06-18. Sample interaction: "I probably won’t be here but thanks for the invite. And that flyer is money!! Haha I’m rolling!!". Appears in personal message contexts (not obvious spam per filter).

## Corpus Dimensions
| Metric | Value |
|--------|-------|
| Messages | 1095 |
| Date range | 2017-10-19 – 2020-06-18 |
| Sent / Received (approx) | 0 / 1095 |
| Sample | I probably won’t be here but thanks for the invite. And that flyer is money!! Haha I’m rolling!! |

## Domain: Self
Part of the long-tail or mid-tier social graph. Contributes to contact Gini distribution and period behavioral profiles.

## Notes
Stub generated from MASTER_MESSAGES_DB_DUMP.csv analysis. Expand with any additional context from dox, FB, or other threads if identity emerges. Personal vs transactional role not fully resolved from this source alone.

## Related
- [[wiki/self/message-corpora/master-message-dump]]
- [[wiki/mind/concepts/contact-gini]]
