---
domain: people
page_type: entity
status: archived
date_created: 2026-06-23
date_modified: 2026-07-11
date_range_start: 2017-01-20
date_range_end: 2026-03-21
sources: ["raw/self/message-csv/MASTER_MESSAGES_DB_DUMP.csv"]
related: ["wiki/self/message-corpora/master-message-dump", "wiki/mind/concepts/contact-gini"]
---

# Jason Bermejo## Identity
Contact identified via Google Contacts as Jason Bermejo. Previously unresolved contact from iMessage corpus at handle `+18172693422`. 451 messages exchanged over 2017-01-20 to 2026-03-21. Sample interaction: "Hahaha! That is fuxking awesome!". Appears in personal message contexts (not obvious spam per filter).

## Corpus Dimensions
| Metric | Value |
|--------|-------|
| Messages | 451 |
| Date range | 2017-01-20 – 2026-03-21 |
| Sent / Received (approx) | 187 / 264 |
| Sample | Hahaha! That is fuxking awesome! |

## Domain: Self
Part of the long-tail or mid-tier social graph. Contributes to contact Gini distribution and period behavioral profiles.

## Notes
Stub generated from MASTER_MESSAGES_DB_DUMP.csv analysis. Expand with any additional context from dox, FB, or other threads if identity emerges. Personal vs transactional role not fully resolved from this source alone.

## Related
- [[wiki/self/message-corpora/master-message-dump]]
- [[wiki/mind/concepts/contact-gini]]
