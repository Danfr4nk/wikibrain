---
domain: people
page_type: entity
status: archived
date_created: 2026-06-23
date_modified: 2026-07-11
date_range_start: 2018-04-14
date_range_end: 2018-06-13
sources: ["raw/self/message-csv/MASTER_MESSAGES_DB_DUMP.csv"]
related: ["wiki/self/message-corpora/master-message-dump", "wiki/mind/concepts/contact-gini"]
---

# Jimmy## Identity
Contact identified via Google Contacts as Jimmy. Previously unresolved contact from iMessage corpus at handle `+17244667401`. 24 messages exchanged over 2018-04-14 to 2018-06-13. Sample interaction: "Cool to stop?". Appears in personal message contexts (not obvious spam per filter).

## Corpus Dimensions
| Metric | Value |
|--------|-------|
| Messages | 24 |
| Date range | 2018-04-14 – 2018-06-13 |
| Sent / Received (approx) | 0 / 24 |
| Sample | Cool to stop? |

## Domain: Self
Part of the long-tail or mid-tier social graph. Contributes to contact Gini distribution and period behavioral profiles.

## Notes
Stub generated from MASTER_MESSAGES_DB_DUMP.csv analysis. Expand with any additional context from dox, FB, or other threads if identity emerges. Personal vs transactional role not fully resolved from this source alone.

## Related
- [[wiki/self/message-corpora/master-message-dump]]
- [[wiki/mind/concepts/contact-gini]]
