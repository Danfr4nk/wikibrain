---
domain: people
page_type: entity
status: archived
date_created: 2026-06-23
date_modified: 2026-07-11
date_range_start: 2018-04-02
date_range_end: 2018-09-15
sources: ["raw/self/message-csv/MASTER_MESSAGES_DB_DUMP.csv"]
related: ["wiki/self/message-corpora/master-message-dump", "wiki/mind/concepts/contact-gini"]
---

# Mike Zollinger## Identity
Contact identified via Google Contacts as Mike Zollinger. Previously unresolved contact from iMessage corpus at handle `+17246208130`. 51 messages exchanged over 2018-04-02 to 2018-09-15. Sample interaction: "How was ur first loop". Appears in personal message contexts (not obvious spam per filter).

## Corpus Dimensions
| Metric | Value |
|--------|-------|
| Messages | 51 |
| Date range | 2018-04-02 – 2018-09-15 |
| Sent / Received (approx) | 0 / 51 |
| Sample | How was ur first loop |

## Domain: Self
Part of the long-tail or mid-tier social graph. Contributes to contact Gini distribution and period behavioral profiles.

## Notes
Stub generated from MASTER_MESSAGES_DB_DUMP.csv analysis. Expand with any additional context from dox, FB, or other threads if identity emerges. Personal vs transactional role not fully resolved from this source alone.

## Related
- [[wiki/self/message-corpora/master-message-dump]]
- [[wiki/mind/concepts/contact-gini]]
