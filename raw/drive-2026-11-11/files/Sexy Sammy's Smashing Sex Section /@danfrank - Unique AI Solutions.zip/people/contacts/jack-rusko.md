---
domain: people
page_type: entity
status: archived
date_created: 2026-06-23
date_modified: 2026-07-11
date_range_start: 2017-10-16
date_range_end: 2018-08-09
sources: ["raw/self/message-csv/MASTER_MESSAGES_DB_DUMP.csv"]
related: ["wiki/self/message-corpora/master-message-dump", "wiki/mind/concepts/contact-gini"]
---

# Jack Rusko## Identity
Contact identified via Google Contacts as Jack Rusko. Previously unresolved contact from iMessage corpus at handle `+17249636436`. 202 messages exchanged over 2017-10-16 to 2018-08-09. Sample interaction: "U get a Tex's". Appears in personal message contexts (not obvious spam per filter).

## Corpus Dimensions
| Metric | Value |
|--------|-------|
| Messages | 202 |
| Date range | 2017-10-16 – 2018-08-09 |
| Sent / Received (approx) | 0 / 202 |
| Sample | U get a Tex's |

## Domain: Self
Part of the long-tail or mid-tier social graph. Contributes to contact Gini distribution and period behavioral profiles.

## Notes
Stub generated from MASTER_MESSAGES_DB_DUMP.csv analysis. Expand with any additional context from dox, FB, or other threads if identity emerges. Personal vs transactional role not fully resolved from this source alone.

## Related
- [[wiki/self/message-corpora/master-message-dump]]
- [[wiki/mind/concepts/contact-gini]]
