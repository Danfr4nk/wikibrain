---
domain: people
page_type: entity
status: archived
date_created: 2026-06-23
date_modified: 2026-07-11
date_range_start: 2023-08-13
date_range_end: 2026-02-25
sources: ["raw/self/message-csv/MASTER_MESSAGES_DB_DUMP.csv"]
related: ["wiki/self/message-corpora/master-message-dump", "wiki/mind/concepts/contact-gini"]
---

# Manuel## Identity
Contact identified via Google Contacts as Manuel. Previously unresolved contact from iMessage corpus at handle `+13472828140`. 45 messages exchanged over 2023-08-13 to 2026-02-25. Sample interaction: "where did you buy the spinach yesterday". Appears in personal message contexts (not obvious spam per filter).

## Corpus Dimensions
| Metric | Value |
|--------|-------|
| Messages | 45 |
| Date range | 2023-08-13 – 2026-02-25 |
| Sent / Received (approx) | 11 / 34 |
| Sample | where did you buy the spinach yesterday |

## Domain: Self
Part of the long-tail or mid-tier social graph. Contributes to contact Gini distribution and period behavioral profiles.

## Notes
Stub generated from MASTER_MESSAGES_DB_DUMP.csv analysis. Expand with any additional context from dox, FB, or other threads if identity emerges. Personal vs transactional role not fully resolved from this source alone.

## Related
- [[wiki/self/message-corpora/master-message-dump]]
- [[wiki/mind/concepts/contact-gini]]
