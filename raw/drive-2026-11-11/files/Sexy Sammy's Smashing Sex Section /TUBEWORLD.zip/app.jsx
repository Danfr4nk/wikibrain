// app.jsx — top-level. Wires query state, glitch overlays, and the Tweaks panel.

(function () {
  const { TAGS, EDGES, pathBetween } = window.LT_DATA;
  const { Graph, TopBar, HUD, DetailPanel, IntersectionFlash } = window;

  // EDITMODE block — host rewrites this on disk when tweaks change.
  const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
    "scanlines": "med",
    "grain": true,
    "huedrift": true,
    "rgbshift": "med",
    "physics": "calm",
    "palette": "magenta",
    "wall": "med"
  }/*EDITMODE-END*/;

  const PHYSICS_PRESETS = {
    tight: { rest: 130, kSpring: 0.020, kRep: 1800, kCenter: 0.0014, damp: 0.84, maxSpeed: 6 },
    calm:  { rest: 180, kSpring: 0.012, kRep: 2400, kCenter: 0.0008, damp: 0.86, maxSpeed: 6 },
    loose: { rest: 240, kSpring: 0.008, kRep: 3600, kCenter: 0.0004, damp: 0.88, maxSpeed: 8 },
  };

  const PALETTES = {
    magenta: ['oklch(0.78 0.30 340)', 'oklch(0.86 0.18 210)', 'oklch(0.92 0.22 130)'],
    acid:    ['oklch(0.90 0.26 130)', 'oklch(0.86 0.22 200)', 'oklch(0.82 0.24 25)'],
    sunset:  ['oklch(0.82 0.20 25)',  'oklch(0.78 0.22 340)', 'oklch(0.88 0.18 80)'],
    cool:    ['oklch(0.84 0.18 250)', 'oklch(0.86 0.18 200)', 'oklch(0.78 0.22 290)'],
  };

  function App() {
    const [t, setTweak] = window.useTweaks(TWEAK_DEFAULTS);
    const [query, setQuery] = React.useState([]);
    const [hovered, setHovered] = React.useState(null);
    const [coord, setCoord] = React.useState('00·00');
    const [glitchTick, setGlitchTick] = React.useState(0);
    const [lastPull, setLastPull] = React.useState(null);
    const [pullPath, setPullPath] = React.useState(null); // ordered tag ids for a thread walk
    const [fps, setFps] = React.useState(60);

    // Live coord display in top bar — quirky vaporwave indicator.
    React.useEffect(() => {
      const id = setInterval(() => {
        const a = Math.floor(performance.now() * 0.013 % 96 + 8);
        const b = Math.floor(performance.now() * 0.007 % 60 + 4);
        setCoord(String(a).padStart(2, '0') + '·' + String(b).padStart(2, '0'));
      }, 240);
      return () => clearInterval(id);
    }, []);

    // FPS counter — light touch, only updates HUD ~once/sec.
    React.useEffect(() => {
      let frames = 0, last = performance.now(), raf;
      const tick = (now) => {
        frames++;
        if (now - last > 1000) {
          setFps(Math.round((frames * 1000) / (now - last)));
          frames = 0; last = now;
        }
        raf = requestAnimationFrame(tick);
      };
      raf = requestAnimationFrame(tick);
      return () => cancelAnimationFrame(raf);
    }, []);

    // Occasional VHS-style glitch roll. Rare.
    React.useEffect(() => {
      if (!t.huedrift) return;
      const tick = () => {
        const next = 5000 + Math.random() * 15000;
        setTimeout(() => { setGlitchTick((n) => n + 1); tick(); }, next);
      };
      const id = setTimeout(tick, 4000);
      return () => clearTimeout(id);
    }, [t.huedrift]);

    // Apply palette as CSS vars on root.
    React.useEffect(() => {
      const p = PALETTES[t.palette] || PALETTES.magenta;
      document.documentElement.style.setProperty('--hot', p[0]);
      document.documentElement.style.setProperty('--cool', p[1]);
      document.documentElement.style.setProperty('--acid', p[2]);
    }, [t.palette]);

    // Apply rgbshift level to text — re-apply on change. (CSS does the heavy
    // lifting; here we just toggle a class.)
    React.useEffect(() => {
      const cls = ['rgb-off', 'rgb-low', 'rgb-med', 'rgb-high'];
      cls.forEach((c) => document.body.classList.remove(c));
      document.body.classList.add({
        off: 'rgb-off', low: 'rgb-low', med: 'rgb-med', high: 'rgb-high',
      }[t.rgbshift] || 'rgb-med');
    }, [t.rgbshift]);

    const onTagClick = (id) => {
      setPullPath(null);
      setQuery((q) => q.length === 1 && q[0] === id ? [] : [id]);
    };
    const onPull = (a, b) => {
      // A pull is a PATH WALK: find how the two tags connect through the
      // co-occurrence graph and surface the videos along that route.
      const path = (pathBetween && pathBetween(a, b)) || [a, b];
      setQuery(path);
      setPullPath(path.length >= 2 ? path : null);
      setLastPull(path);
    };
    const onToggleTag = (id) => {
      setPullPath(null);
      setQuery((q) => q.includes(id) ? q.filter((t) => t !== id) : [...q, id]);
    };
    const onClearTag = (id) => {
      setPullPath(null);
      setQuery((q) => q.filter((t) => t !== id));
    };

    return (
      <div className="app" data-palette={t.palette}>
        <window.BackgroundWall intensity={t.wall} />
        <TopBar query={query} coord={coord} onClear={() => setQuery([])} />

        <Graph
          query={query}
          hovered={hovered}
          onTagClick={onTagClick}
          onPull={onPull}
          onHover={setHovered}
          physics={PHYSICS_PRESETS[t.physics] || PHYSICS_PRESETS.calm} />

        <DetailPanel
          query={query}
          path={pullPath}
          onClose={() => { setPullPath(null); setQuery([]); }}
          onToggleTag={onToggleTag}
          onClearTag={onClearTag} />

        <IntersectionFlash tags={lastPull} />

        {/* Overlays */}
        {t.scanlines !== 'off' && (
          <div className={'scanlines' + (t.scanlines === 'heavy' ? ' heavy' : '')} />
        )}
        <div className="vignette" />
        {t.grain && <div className="grain" />}
        <div key={glitchTick} className="glitch-flash on" />

        <window.TweaksPanel title="tweaks">
          <window.TweakSection label="Vibe">
            <window.TweakRadio label="palette"
              value={t.palette}
              options={['magenta', 'acid', 'sunset', 'cool']}
              onChange={(v) => setTweak('palette', v)} />
            <window.TweakRadio label="rgb shift"
              value={t.rgbshift}
              options={['off', 'low', 'med', 'high']}
              onChange={(v) => setTweak('rgbshift', v)} />
            <window.TweakRadio label="scanlines"
              value={t.scanlines}
              options={['off', 'med', 'heavy']}
              onChange={(v) => setTweak('scanlines', v)} />
            <window.TweakToggle label="film grain"
              value={t.grain} onChange={(v) => setTweak('grain', v)} />
            <window.TweakToggle label="hue drift + flashes"
              value={t.huedrift} onChange={(v) => setTweak('huedrift', v)} />
          </window.TweakSection>
          <window.TweakSection label="Graph">
            <window.TweakRadio label="physics"
              value={t.physics}
              options={['tight', 'calm', 'loose']}
              onChange={(v) => setTweak('physics', v)} />
          </window.TweakSection>
          <window.TweakSection label="Wall">
            <window.TweakRadio label="performers"
              value={t.wall}
              options={['off', 'low', 'med', 'high']}
              onChange={(v) => setTweak('wall', v)} />
          </window.TweakSection>
        </window.TweaksPanel>
      </div>
    );
  }

  const root = ReactDOM.createRoot(document.getElementById('root'));
  root.render(<App />);
})();
