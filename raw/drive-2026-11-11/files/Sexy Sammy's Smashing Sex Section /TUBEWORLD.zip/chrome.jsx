// chrome.jsx — top bar, bottom HUD, detail panel, glitch overlays.

(function () {
  const { TAGS, neighborsOf, videosForTags, scoreVideosForTags, pathBetween, videosAlongPath } = window.LT_DATA;
  const tagById = Object.fromEntries(TAGS.map((t) => [t.id, t]));

  function TopBar({ query, onClear, coord }) {
    return (
      <div className="topbar">
        <div className="wordmark" onClick={onClear} title="reset">
          ladytube<span className="dot">.</span><sub>graph v0.7</sub>
        </div>
        <div className="crumbs">
          <span className="live" />
          <span>live</span>
          <span className="sep">/</span>
          {query.length === 0 ? (
            <span>idle — wander the graph</span>
          ) : (
            <span>
              {query.map((t, i) => (
                <React.Fragment key={t}>
                  {i > 0 && <span className="sep"> × </span>}
                  <b style={{ color: 'var(--acid)', fontWeight: 400 }}>{t}</b>
                </React.Fragment>
              ))}
            </span>
          )}
          <span className="pull-hint">drag a tag → another to intersect</span>
        </div>
        <div className="coord">{coord}</div>
      </div>
    );
  }

  function HUD({ nodeCount, edgeCount, fps }) {
    return (
      <div className="hud">
        <div className="keys">
          <span><kbd>drag</kbd>pan</span>
          <span><kbd>scroll</kbd>zoom</span>
          <span><kbd>click</kbd>focus</span>
          <span><kbd>drag tag</kbd>thread</span>
        </div>
        <div>
          {nodeCount} tags · {edgeCount} edges · {fps} fps
        </div>
      </div>
    );
  }

  function DetailPanel({ query, path, onClose, onToggleTag, onClearTag }) {
    const open = query.length > 0;
    // Hold last-non-empty query for slide-out animation; otherwise the panel
    // would lose its content mid-transition.
    const [hold, setHold] = React.useState({ q: query, p: path });
    React.useEffect(() => {
      if (query.length > 0) setHold({ q: query, p: path });
    }, [query, path]);
    const q = open ? query : hold.q;
    const p = open ? path : hold.p;

    // Thread mode: a pull gesture produced an ordered path walk.
    const threadMode = !!(p && p.length >= 2);
    const hops = threadMode ? videosAlongPath(p) : [];
    const hopVideoCount = threadMode
      ? new Set(hops.flatMap((h) => h.videos.map((v) => v.id))).size : 0;

    // Ranked mode: soft intersection — never empty when any tag has videos.
    const scored = threadMode ? [] : scoreVideosForTags(q);
    const videos = scored.map((e) => e.video);
    const focus = q[0];
    const focusTag = focus ? tagById[focus] : null;
    const neighbors = focus
      ? [...neighborsOf(focus).entries()].sort((a, b) => b[1] - a[1]).slice(0, 14)
      : [];

    return (
      <aside className={'detail' + (open ? ' open' : '')}>
        <div className="detail-head">
          <div className="detail-eyebrow">
            <span>
              {threadMode
                ? `THREAD · ${hops.length} hop${hops.length === 1 ? '' : 's'} · ${hopVideoCount} title${hopVideoCount === 1 ? '' : 's'}`
                : `${q.length === 1 ? 'TAG' : 'INTERSECTION'} · ${videos.length} title${videos.length === 1 ? '' : 's'}`}
            </span>
            <span className="close" onClick={onClose}>✕</span>
          </div>
          <div className={'detail-title' + (threadMode && p.length > 2 ? ' path' : '')}>
            {q.map((t, i) => (
              <React.Fragment key={t}>
                {i > 0 && (
                  <span style={{ color: 'var(--acid)', margin: '0 6px' }}>
                    {threadMode ? '→' : '×'}
                  </span>
                )}
                {t}
              </React.Fragment>
            ))}
          </div>
          {focusTag && (
            <div className="detail-meta">
              <span>cat · <b>{focusTag.cat}</b></span>
              <span>neighbors · <b>{neighbors.length}</b></span>
            </div>
          )}
        </div>

        {q.length === 1 && neighbors.length > 0 && (
          <div className="detail-tags">
            {neighbors.map(([nid, w]) => (
              <span key={nid}
                    className={'tag-chip' + (q.includes(nid) ? ' active' : '')}
                    onClick={() => onToggleTag(nid)}>
                + {nid} <span style={{ opacity: .55, marginLeft: 4 }}>{w}</span>
              </span>
            ))}
          </div>
        )}
        {q.length > 1 && (
          <div className="detail-tags">
            {q.map((t) => (
              <span key={t} className="tag-chip active" onClick={() => onClearTag(t)}>
                − {t}
              </span>
            ))}
          </div>
        )}

        <div className="detail-grid">
          {threadMode ? (
            hops.map((h, hi) => (
              <React.Fragment key={h.from + '→' + h.to}>
                <div className="hop-head">
                  <span className="hop-num">{String(hi + 1).padStart(2, '0')}</span>
                  {h.from} <span className="x">×</span> {h.to}
                  <span className="hop-count">{h.videos.length}</span>
                </div>
                {h.videos.map((v, i) => (
                  <div key={h.from + h.to + v.id} className="vid-card">
                    <window.PixelThumb
                      video={v}
                      badge={String(i + 1).padStart(2, '0')} />
                    <div className="vid-title">{v.t}</div>
                    <div className="vid-sub">
                      {v.tags.slice(0, 3).join(' · ')}
                    </div>
                  </div>
                ))}
              </React.Fragment>
            ))
          ) : videos.length === 0 ? (
            (() => {
              const bridge = q.length >= 2 ? pathBetween(q[0], q[q.length - 1]) : null;
              return (
                <div className="empty-state">
                  <b>no direct crossing</b>
                  {bridge && bridge.length > 2
                    ? <>nearest thread runs through <i style={{ color: 'var(--acid)', fontStyle: 'normal' }}>{bridge[1]}</i></>
                    : "the threads don't cross here yet."}
                </div>
              );
            })()
          ) : scored.map((e, i) => (
            <div key={e.video.id} className="vid-card">
              <window.PixelThumb
                video={e.video}
                badge={String(i + 1).padStart(2, '0')} />
              <div className="vid-title">
                {q.length > 1 && e.exact && <span className="exact-mark">exact</span>}
                {e.video.t}
              </div>
              <div className="vid-sub">
                {e.video.tags.slice(0, 3).join(' · ')}
              </div>
            </div>
          ))}
        </div>
      </aside>
    );
  }

  function IntersectionFlash({ tags }) {
    // Briefly announce a pull-thread intersection event.
    const [show, setShow] = React.useState(false);
    React.useEffect(() => {
      if (!tags) return;
      setShow(true);
      const t = setTimeout(() => setShow(false), 1600);
      return () => clearTimeout(t);
    }, [tags && tags.join('|')]);
    if (!tags || !show) return null;
    const hops = tags.length - 1;
    return (
      <div className="intersection-note">
        thread → {tags.map((t, i) => (
          <React.Fragment key={t}>
            {i > 0 && <span className="x">→</span>}<b>{t}</b>
          </React.Fragment>
        ))}
        {hops > 1 && <span style={{ opacity: .6, marginLeft: 8 }}>{hops} hops</span>}
      </div>
    );
  }

  Object.assign(window, { TopBar, HUD, DetailPanel, IntersectionFlash });
})();
