// pixel-thumb.jsx — procedural pixel thumbnails with scrub-on-hover.
//
// Each video has a deterministic seed (hashed from its id). We generate ~14
// frames of a 32×24 pixel canvas at mount: 2-3 colored "blobs" drift across a
// dark field, with scanline + chromatic-aberration noise baked in. Hovering
// the tile maps mouse-X to the frame index so the user "scrubs" through the
// motion. Nothing depicts real content — the abstraction is the point.

(function () {
  const HOT_PALETTES = [
    // each palette is bg + 2-3 highlight colors (8-bit RGB tuples)
    [[24, 8, 40],   [255, 60, 160], [120, 220, 255], [255, 220, 100]],
    [[10, 16, 48],  [255, 100, 220], [180, 255, 200], [255, 80, 120]],
    [[40, 10, 50],  [255, 180, 60],  [60, 200, 255],  [255, 60, 200]],
    [[8, 6, 32],    [200, 120, 255], [120, 255, 220], [255, 220, 80]],
    [[30, 5, 30],   [255, 80, 80],   [255, 200, 240], [80, 220, 255]],
    [[10, 30, 40],  [255, 110, 200], [120, 255, 180], [255, 240, 120]],
    [[28, 12, 60],  [255, 60, 120],  [60, 240, 220],  [200, 255, 80]],
  ];

  // Deterministic xorshift seeded from a string.
  function strHash(s) {
    let h = 2166136261 >>> 0;
    for (let i = 0; i < s.length; i++) h = Math.imul(h ^ s.charCodeAt(i), 16777619);
    return h >>> 0;
  }
  function makeRng(seed) {
    let s = seed | 0 || 1;
    return () => {
      s ^= s << 13; s ^= s >>> 17; s ^= s << 5;
      return ((s >>> 0) % 100000) / 100000;
    };
  }

  function generateFrames(id, frames, W, H) {
    const seed = strHash(id);
    const rng = makeRng(seed);
    const palette = HOT_PALETTES[seed % HOT_PALETTES.length];
    const [bg, ...lights] = palette;

    // 2-4 drifting blobs.
    const nBlobs = 2 + Math.floor(rng() * 3);
    const blobs = [];
    for (let i = 0; i < nBlobs; i++) {
      blobs.push({
        x: rng() * W,
        y: rng() * H,
        vx: (rng() - 0.5) * 0.6,
        vy: (rng() - 0.5) * 0.4,
        r: 4 + rng() * 6,
        c: lights[i % lights.length],
      });
    }
    // Distortion knobs vary per video.
    const wave = rng() * 0.4;
    const grainStrength = 0.10 + rng() * 0.10;
    const tearProb = rng() * 0.04;            // chance per row of a horizontal tear band
    const aberration = 0.6 + rng() * 1.2;     // pixels of R/B offset

    const out = [];
    for (let f = 0; f < frames; f++) {
      const tn = f / frames;
      // Advance blobs along their drift.
      for (const b of blobs) {
        b.x += b.vx; b.y += b.vy;
        if (b.x < -2) b.x = W + 2; if (b.x > W + 2) b.x = -2;
        if (b.y < -2) b.y = H + 2; if (b.y > H + 2) b.y = -2;
      }
      // Render this frame as raw RGBA, then clone into ImageData.
      const buf = new Uint8ClampedArray(W * H * 4);
      // First pass: base color contributions from blobs.
      for (let y = 0; y < H; y++) {
        // Horizontal tear: shift sample x by a random amount on some rows.
        const tear = rng() < tearProb ? Math.floor((rng() - 0.5) * 6) : 0;
        for (let x = 0; x < W; x++) {
          const sx = x + tear + Math.sin((y + f) * 0.4) * wave;
          let r = bg[0], g = bg[1], bl = bg[2];
          for (const b of blobs) {
            const dx = sx - b.x;
            const dy = y - b.y;
            const d2 = dx * dx + dy * dy;
            const k = Math.exp(-d2 / (b.r * b.r * 1.4));
            r += b.c[0] * k;
            g += b.c[1] * k;
            bl += b.c[2] * k;
          }
          // Scanline darkening every other row.
          const scan = y % 2 === 0 ? 1.0 : 0.78;
          // Grain.
          const n = (rng() - 0.5) * 255 * grainStrength;
          const o = (y * W + x) * 4;
          buf[o]     = Math.min(255, Math.max(0, r * scan + n));
          buf[o + 1] = Math.min(255, Math.max(0, g * scan + n));
          buf[o + 2] = Math.min(255, Math.max(0, bl * scan + n));
          buf[o + 3] = 255;
        }
      }
      // Cheap chromatic aberration: shift R right, B left by `aberration` px.
      const dup = new Uint8ClampedArray(buf);
      const shift = Math.round(aberration);
      for (let y = 0; y < H; y++) {
        for (let x = 0; x < W; x++) {
          const o = (y * W + x) * 4;
          const xr = Math.max(0, Math.min(W - 1, x - shift));
          const xb = Math.max(0, Math.min(W - 1, x + shift));
          dup[o]     = buf[(y * W + xr) * 4];
          dup[o + 2] = buf[(y * W + xb) * 4 + 2];
        }
      }
      // The first frame to mount sets up an ImageData via document; subsequent
      // frames clone its dims to skip the constructor's spec quirk in older
      // browsers. (new ImageData(buf, W, H) works everywhere modern — kept
      // straightforward.)
      out.push(new ImageData(dup, W, H));
    }
    return out;
  }

  // The component itself. Renders the canvas at native pixel res and lets CSS
  // scale it up with image-rendering:pixelated for the chunky look.
  function PixelThumb({ video, frames = 14, w = 36, h = 27, badge }) {
    const frameData = React.useMemo(
      () => generateFrames(video.id, frames, w, h),
      [video.id, frames, w, h]
    );
    const canvasRef = React.useRef(null);
    const [frame, setFrame] = React.useState(0);
    const [hovering, setHovering] = React.useState(false);

    React.useEffect(() => {
      const c = canvasRef.current;
      if (!c) return;
      c.getContext('2d').putImageData(frameData[frame], 0, 0);
    }, [frame, frameData]);

    // Idle gentle drift: when not hovered, slowly cycle frames so the wall of
    // tiles feels alive.
    React.useEffect(() => {
      if (hovering) return;
      let raf, last = performance.now(), f = frame;
      const step = (t) => {
        if (t - last > 280) {
          f = (f + 1) % frames;
          setFrame(f);
          last = t;
        }
        raf = requestAnimationFrame(step);
      };
      raf = requestAnimationFrame(step);
      return () => cancelAnimationFrame(raf);
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [hovering, frames]);

    const onMove = (e) => {
      const r = e.currentTarget.getBoundingClientRect();
      const t = (e.clientX - r.left) / r.width;
      setFrame(Math.min(frames - 1, Math.max(0, Math.floor(t * frames))));
    };

    return (
      <div className="vid-thumb-wrap"
           onMouseEnter={() => setHovering(true)}
           onMouseLeave={() => setHovering(false)}
           onMouseMove={(e) => { if (hovering) onMove(e); }}>
        {badge && <div className="badge">{badge}</div>}
        <div className="vid-thumb">
          <canvas ref={canvasRef} width={w} height={h} />
        </div>
        <div className="scrub-bar">
          <i style={{ width: ((frame + 1) / frames * 100) + '%' }} />
        </div>
      </div>
    );
  }

  window.PixelThumb = PixelThumb;
})();
