// background-wall.jsx — ambient wall of pixelated "performer portrait" tiles
// drifting slowly behind the graph. Each tile is procedurally generated:
// vertical 24×36 pixel canvas, soft elliptical blobs in skin-tone palettes
// suggesting a figure (head + body silhouette) without ever depicting
// anything specific. Rendered heavily blurred and dimmed so it reads as
// ambient texture, not subject matter.

(function () {
  // Skin-tone palettes — bg color, midtone, highlight, hair/shadow.
  const PALETTES = [
    [[18,  6, 28], [220, 170, 150], [255, 220, 200], [60, 30, 30]],   // warm light
    [[30, 14, 46], [180, 130, 110], [240, 200, 180], [40, 20, 20]],   // medium warm
    [[10, 12, 32], [130,  92,  78], [200, 160, 140], [30, 14, 16]],   // tan
    [[15,  8, 28], [ 95,  64,  54], [160, 120, 100], [20, 10, 14]],   // deep
    [[25, 10, 36], [ 70,  50,  46], [130,  96,  84], [10,  6, 10]],   // deeper
    [[14, 18, 42], [210, 160, 180], [255, 220, 230], [80, 30, 50]],   // pinkish wash
    [[36, 14, 30], [150, 105,  90], [220, 170, 150], [50, 20, 24]],   // golden
  ];
  const HAIR_TINTS = [
    [40, 20, 20], [80, 50, 30], [180, 120, 70], [200, 80, 60],
    [40, 40, 40], [60, 30, 80], [180, 60, 140],
  ];

  function strHash(s) {
    let h = 2166136261 >>> 0;
    for (let i = 0; i < s.length; i++) h = Math.imul(h ^ s.charCodeAt(i), 16777619);
    return h >>> 0;
  }
  function makeRng(seed) {
    let s = (seed | 0) || 1;
    return () => { s ^= s << 13; s ^= s >>> 17; s ^= s << 5; return ((s >>> 0) % 100000) / 100000; };
  }

  // Render one "portrait" silhouette to an ImageData. The composition is
  // intentionally vague — a circle near the top (head), an elongated rounded
  // shape below (torso), occasionally a paired second figure offset by a
  // few pixels. Skin tones, hair tint, soft falloff, scanline darkening.
  function generatePortrait(seed, W, H) {
    const rng = makeRng(seed);
    const palette = PALETTES[seed % PALETTES.length];
    const [bg, skin, light, shadow] = palette;
    const hair = HAIR_TINTS[(seed >> 3) % HAIR_TINTS.length];

    // Figure layout — sometimes one, sometimes two intertwined.
    const figs = [];
    const nFigs = rng() < 0.35 ? 2 : 1;
    for (let i = 0; i < nFigs; i++) {
      const xc = W * (0.35 + 0.3 * (i + rng() * 0.4));
      figs.push({
        headX: xc + (rng() - 0.5) * 2,
        headY: H * (0.18 + rng() * 0.08),
        headR: 3.4 + rng() * 0.6,
        bodyX: xc + (rng() - 0.5) * 3,
        bodyY: H * (0.55 + rng() * 0.10),
        bodyW: 5 + rng() * 2,
        bodyH: 9 + rng() * 3,
        lean: (rng() - 0.5) * 0.5,
      });
    }

    const buf = new Uint8ClampedArray(W * H * 4);
    // Vertical bg gradient — slight warm shift.
    for (let y = 0; y < H; y++) {
      const t = y / H;
      const gR = bg[0] * (1 - t * 0.5) + skin[0] * 0.05 * t;
      const gG = bg[1] * (1 - t * 0.5) + skin[1] * 0.05 * t;
      const gB = bg[2] * (1 - t * 0.5) + skin[2] * 0.05 * t;
      for (let x = 0; x < W; x++) {
        const o = (y * W + x) * 4;
        buf[o] = gR; buf[o + 1] = gG; buf[o + 2] = gB; buf[o + 3] = 255;
      }
    }
    // Composite figures with soft falloff.
    for (let y = 0; y < H; y++) {
      for (let x = 0; x < W; x++) {
        let r = 0, g = 0, b = 0, m = 0; // accumulator + total weight
        for (const f of figs) {
          // Head (filled circle, dark hair on top portion).
          const dxh = x - f.headX, dyh = y - f.headY;
          const dh = Math.sqrt(dxh * dxh + dyh * dyh);
          const headK = Math.exp(-Math.pow(dh / f.headR, 4));
          if (headK > 0.01) {
            // Top half = hair, bottom half = skin (face).
            const isHair = dyh < -f.headR * 0.05;
            const c = isHair ? hair : skin;
            r += c[0] * headK; g += c[1] * headK; b += c[2] * headK; m += headK;
          }
          // Body — leaning ellipse.
          const dxb = (x - f.bodyX) - (y - f.bodyY) * f.lean;
          const dyb = y - f.bodyY;
          const bk = Math.exp(-Math.pow(Math.abs(dxb) / f.bodyW, 2.4)
                              - Math.pow(Math.abs(dyb) / f.bodyH, 2.4));
          if (bk > 0.01) {
            // Highlight on one side (light source from upper-right).
            const sideShade = 0.85 + 0.25 * (dxb / f.bodyW);
            r += skin[0] * sideShade * bk;
            g += skin[1] * sideShade * bk;
            b += skin[2] * sideShade * bk;
            m += bk;
          }
        }
        if (m > 0) {
          // Blend onto bg.
          const k = Math.min(1, m);
          const o = (y * W + x) * 4;
          buf[o]     = buf[o]     * (1 - k) + (r / m) * k;
          buf[o + 1] = buf[o + 1] * (1 - k) + (g / m) * k;
          buf[o + 2] = buf[o + 2] * (1 - k) + (b / m) * k;
        }
      }
    }
    // Scanline darkening and grain.
    for (let y = 0; y < H; y++) {
      const dark = y % 2 === 0 ? 1 : 0.82;
      for (let x = 0; x < W; x++) {
        const o = (y * W + x) * 4;
        const n = (rng() - 0.5) * 32;
        buf[o]     = Math.min(255, Math.max(0, buf[o]     * dark + n));
        buf[o + 1] = Math.min(255, Math.max(0, buf[o + 1] * dark + n));
        buf[o + 2] = Math.min(255, Math.max(0, buf[o + 2] * dark + n));
      }
    }
    return new ImageData(buf, W, H);
  }

  // The wall element: a fixed-position element that lays out a grid of small
  // canvases. Slow horizontal drift + every few seconds a tile re-rolls its
  // seed so the wall doesn't feel static. Heavy CSS blur dims it into pure
  // ambient texture.
  function BackgroundWall({ intensity = 'med' }) {
    const ref = React.useRef(null);
    const TILE_W = 28, TILE_H = 42; // canvas pixel dims (scales up via CSS)
    // Columns × rows tuned to comfortably overdraw most viewports.
    const cols = 10, rows = 6;

    React.useEffect(() => {
      const root = ref.current;
      if (!root) return;
      const tiles = [];
      for (let i = 0; i < cols * rows; i++) {
        const c = document.createElement('canvas');
        c.width = TILE_W; c.height = TILE_H;
        c.className = 'wall-tile';
        const seed = Math.floor(Math.random() * 1e9);
        const img = generatePortrait(seed, TILE_W, TILE_H);
        c.getContext('2d').putImageData(img, 0, 0);
        root.appendChild(c);
        tiles.push({ el: c, seed });
      }
      // Periodic re-roll: every ~2.5s pick a tile and swap its seed for a
      // gentle "scrub" feel. Disabled in heavy blur to save CPU.
      const reroll = () => {
        const t = tiles[Math.floor(Math.random() * tiles.length)];
        t.seed = Math.floor(Math.random() * 1e9);
        const img = generatePortrait(t.seed, TILE_W, TILE_H);
        t.el.getContext('2d').putImageData(img, 0, 0);
      };
      const id = setInterval(reroll, 800);
      return () => {
        clearInterval(id);
        tiles.forEach((t) => t.el.remove());
      };
    }, []);

    return <div ref={ref} className={'wall ' + 'wall-' + intensity}
                style={{ '--cols': cols, '--rows': rows }} />;
  }

  window.BackgroundWall = BackgroundWall;
})();
