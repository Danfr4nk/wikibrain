// data.js — ladytube tag/video graph
// Tags are nodes. Videos sit "between" their tags — each video creates edges
// between every pair of its tags. Edge weight = co-occurrence count.

(function () {
  // Categories follow the standard taxonomy that tube sites use to organize
  // content. Each category gets a distinct node glyph/color in the graph.
  const TAG_CATS = {
    format:      ['solo', 'duo', 'threesome', 'foursome', 'group', 'couple', 'gangbang', 'orgy', 'swingers', 'compilation', 'split-screen', 'montage', 'two-couples', 'audition'],
    orientation: ['lesbian', 'gay', 'straight', 'bisexual', 'trans', 'queer', 'pansexual', 'sapphic'],
    body:        ['petite', 'curvy', 'bbw', 'milf', 'mature', 'athletic', 'busty', 'slim', 'dilf', 'gilf', 'muscular', 'chubby', 'tall', 'short', 'thick', 'skinny', 'flexible', 'toned', 'soft', 'dad-bod'],
    look:        ['brunette', 'blonde', 'redhead', 'tattooed', 'pierced', 'glasses', 'shaved', 'hairy', 'freckles', 'dyed-hair', 'long-hair', 'short-hair', 'goth', 'natural', 'pale', 'tan-lines', 'curly-hair', 'buzzcut', 'mullet', 'beard', 'silver-fox', 'girl-next-door', 'alt', 'androgynous'],
    production:  ['amateur', 'professional', 'homemade', 'studio', 'vintage', 'cinematic', 'verified', 'casting', 'behind-the-scenes', 'low-budget', 'arthouse', 'documentary', 'indie', 'big-budget', 'one-take', 'remastered'],
    quality:     ['hd', '4k', '8k', 'vr', 'pov', '60fps', 'vertical', 'slow-motion', 'grainy', 'webcam', 'upscaled', 'lossless'],
    setting:     ['bedroom', 'kitchen', 'shower', 'outdoor', 'office', 'hotel', 'public', 'car', 'beach', 'bathtub', 'pool', 'garden', 'garage', 'rooftop', 'basement', 'cabin', 'forest', 'gym', 'library', 'elevator', 'balcony', 'sauna', 'tent', 'boat', 'staircase', 'laundry-room', 'motel', 'attic', 'jacuzzi', 'campervan', 'barn', 'wine-cellar', 'penthouse', 'fire-escape'],
    kink:        ['bdsm', 'fetish', 'foot', 'roleplay', 'voyeur', 'cosplay', 'dom', 'sub', 'taboo', 'bondage', 'latex', 'leather', 'spanking', 'praise', 'pet-play', 'wax-play', 'blindfold', 'handcuffs', 'exhibitionist', 'femdom', 'worship', 'shibari', 'temperature-play', 'sensory', 'denial', 'aftercare'],
    act:         ['oral', 'anal', 'toys', 'massage', 'edging', 'rimming', 'fingering', 'handjob', 'deepthroat', 'facesitting', 'pegging', 'scissoring', 'titjob', 'grinding', 'tribbing', '69', 'lap-dance', 'striptease', 'mutual', 'cuddling'],
    sound:       ['asmr', 'dirty-talk', 'moaning', 'silent', 'music', 'tape-hiss', 'whispering', 'laughing', 'breathing', 'narration', 'lo-fi', 'vinyl-crackle', 'rain-audio', 'heartbeat', 'field-recording', 'muffled'],
    mood:        ['rough', 'gentle', 'passionate', 'romantic', 'sensual', 'intense', 'playful', 'tender', 'sleepy', 'desperate', 'awkward', 'loving', 'teasing', 'slow', 'urgent', 'dreamy', 'melancholy', 'euphoric', 'feral', 'shy', 'worshipful', 'unhurried', 'reverent', 'giddy'],
    tongue:      ['français', 'japanese', 'portuguese', 'subtitled', 'spanish', 'german', 'italian', 'russian', 'korean', 'dubbed', 'multilingual', 'accents'],
    wardrobe:    ['lingerie', 'stockings', 'heels', 'uniform', 'nude', 'oiled', 'wet-clothes', 'socks-on', 'denim', 'silk', 'corset', 'harness', 'bodysuit', 'bathrobe', 'suit-and-tie', 'nothing-but-jewelry'],
    scenario:    ['teacher', 'nurse', 'boss', 'secretary', 'plumber', 'delivery', 'landlord', 'roommate', 'the-ex', 'neighbor', 'stranger', 'masseuse', 'yoga-instructor', 'personal-trainer', 'photographer', 'tutor'],
    era:         ['70s', '80s', '90s', 'y2k', 'modern', 'retro', 'super-8', 'vhs', 'dvd-rip', 'film-grain', 'betamax', 'polaroid'],
    camera:      ['handheld', 'tripod', 'closeup', 'wide-shot', 'mirror-shot', 'overhead', 'dutch-angle', 'long-take', 'split-diopter', 'night-vision', 'fisheye', 'security-cam'],
    time:        ['morning', 'afternoon', 'midnight', 'golden-hour', '3am', 'sunrise', 'dusk', 'lunchtime', 'all-night', 'sunday'],
    vibe:        ['candlelit', 'neon', 'natural-light', 'black-and-white', 'sepia', 'overexposed', 'soft-focus', 'fluorescent', 'lamplight', 'moonlit', 'strobe', 'projector-glow'],
    relationship:['married', 'dating', 'first-date', 'long-distance', 'reunion', 'anniversary', 'honeymoon', 'friends', 'strangers-to-lovers', 'situationship', 'second-marriage', 'open-relationship'],
    community:   ['trending', 'classic', 'underrated', 'award-winning', 'viral', 'cult-classic', 'staff-pick', 'fan-favorite', 'deep-cut', 'new-upload'],
  };
  const ALL_TAGS = [];
  for (const cat in TAG_CATS) for (const t of TAG_CATS[cat]) ALL_TAGS.push({ id: t, cat });
  const CAT_OF = {};
  for (const t of ALL_TAGS) CAT_OF[t.id] = t.cat;

  // Hand-curated titles — descriptive in the genre's typical voice but kept
  // lowercased ladytube-style. Tags are chosen so clusters emerge (amateur +
  // bedroom + couple co-occur often, vintage + film + tape-hiss, etc.) and a
  // handful of bridging titles cross categories.
  const CURATED = [
    { t: 'real amateur, bedroom 4pm', tags: ['amateur', 'bedroom', 'couple', 'hd', 'gentle', 'duo', 'afternoon'] },
    { t: 'pov: hotel room service', tags: ['pov', 'hotel', 'roleplay', 'duo', 'straight', 'professional'] },
    { t: 'milf teaches yoga', tags: ['milf', 'roleplay', 'amateur', 'duo', 'gentle', 'bedroom', 'yoga-instructor'] },
    { t: 'two strangers, hotel hallway', tags: ['hotel', 'taboo', 'straight', 'duo', 'rough', 'professional', 'stranger'] },
    { t: 'homemade tape, no rehearsal', tags: ['amateur', 'homemade', 'duo', 'vintage', 'tape-hiss', 'couple', 'vhs'] },
    { t: 'lesbian couple morning routine', tags: ['lesbian', 'couple', 'bedroom', 'gentle', 'amateur', 'tender', 'hd', 'morning'] },
    { t: 'french exit, no language', tags: ['français', 'subtitled', 'duo', 'sensual', 'cinematic', 'hotel'] },
    { t: 'shower, after midnight', tags: ['shower', 'duo', 'amateur', 'passionate', 'couple', 'hd', 'midnight'] },
    { t: 'studio shoot — gold light', tags: ['studio', 'professional', 'cinematic', '4k', 'duo', 'sensual', 'golden-hour'] },
    { t: 'tattooed redhead solo', tags: ['solo', 'tattooed', 'redhead', 'toys', 'amateur', 'bedroom'] },
    { t: 'busty blonde, kitchen', tags: ['busty', 'blonde', 'kitchen', 'amateur', 'duo', 'straight'] },
    { t: 'queer foursome rooftop', tags: ['queer', 'foursome', 'rooftop', 'outdoor', 'professional', 'sensual'] },
    { t: 'bdsm: the patient session', tags: ['bdsm', 'dom', 'sub', 'duo', 'studio', 'intense', 'rough', 'aftercare'] },
    { t: 'voyeur tapes, archive 03', tags: ['voyeur', 'vintage', 'tape-hiss', 'amateur', 'duo', 'security-cam'] },
    { t: 'massage: forty minute take', tags: ['massage', 'duo', 'professional', 'gentle', 'tender', 'long-take'] },
    { t: 'pov anal, slow', tags: ['pov', 'anal', 'duo', 'gentle', 'hd', 'bedroom', 'slow'] },
    { t: 'asmr: just breathing', tags: ['asmr', 'silent', 'solo', 'sensual', 'bedroom', 'gentle', 'breathing'] },
    { t: 'two boys, one apartment', tags: ['gay', 'duo', 'amateur', 'bedroom', 'tender', 'hd'] },
    { t: 'dilf neighbor — afternoon', tags: ['dilf', 'mature', 'gay', 'duo', 'amateur', 'kitchen', 'neighbor', 'afternoon'] },
    { t: 'four hands massage', tags: ['massage', 'threesome', 'gentle', 'professional', 'sensual', 'oiled'] },
    { t: 'vintage 70s reel — lost cut', tags: ['vintage', 'cinematic', 'duo', 'tape-hiss', 'straight', '70s', 'film-grain'] },
    { t: 'trans couple, sunday', tags: ['trans', 'couple', 'duo', 'tender', 'bedroom', 'amateur', 'sunday'] },
    { t: 'office party, after hours', tags: ['office', 'group', 'roleplay', 'professional', 'straight', 'rough'] },
    { t: 'foot worship pt.7', tags: ['foot', 'fetish', 'duo', 'studio', 'sub', 'worship'] },
    { t: 'cosplay: very gentle', tags: ['cosplay', 'roleplay', 'duo', 'gentle', 'tender', 'amateur'] },
    { t: 'vr beach house pov', tags: ['vr', 'pov', 'beach', 'outdoor', 'duo', '4k'] },
    { t: 'edging, alone', tags: ['solo', 'edging', 'sensual', 'bedroom', 'amateur', 'denial'] },
    { t: 'three girls, no rules', tags: ['threesome', 'lesbian', 'amateur', 'rough', 'bedroom'] },
    { t: 'rim job, real love', tags: ['rimming', 'duo', 'amateur', 'tender', 'queer', 'loving'] },
    { t: 'public balcony, dawn', tags: ['public', 'balcony', 'voyeur', 'duo', 'amateur', 'sensual', 'sunrise'] },
    { t: 'professional petite scene', tags: ['petite', 'professional', 'studio', '4k', 'duo'] },
    { t: 'curvy brunette, slow zoom', tags: ['curvy', 'brunette', 'sensual', 'studio', 'solo', 'cinematic', 'closeup'] },
    { t: 'bbw goddess, devotional', tags: ['bbw', 'sub', 'duo', 'tender', 'sensual', 'studio', 'worshipful'] },
    { t: 'athletic couple gym shower', tags: ['athletic', 'couple', 'shower', 'gym', 'duo', 'amateur'] },
    { t: 'car backseat, raining', tags: ['car', 'duo', 'amateur', 'rough', 'passionate', 'rain-audio'] },
    { t: 'mature dom, leather chair', tags: ['mature', 'dom', 'bdsm', 'duo', 'studio', 'intense', 'leather'] },
    { t: 'japanese subtitled drama', tags: ['japanese', 'subtitled', 'cinematic', 'professional', 'duo', 'sensual'] },
    { t: 'portuguese asmr whisper', tags: ['portuguese', 'asmr', 'subtitled', 'solo', 'sensual', 'whispering'] },
    { t: 'pierced glasses solo', tags: ['solo', 'pierced', 'glasses', 'toys', 'amateur', 'bedroom'] },
    { t: 'gang bang — slow burn', tags: ['gangbang', 'group', 'rough', 'studio', 'professional', 'intense'] },
    { t: 'oral, very long', tags: ['oral', 'duo', 'gentle', 'amateur', 'bedroom', 'unhurried'] },
    { t: 'toys haul tutorial', tags: ['solo', 'toys', 'amateur', 'playful', 'bedroom', 'webcam'] },
    { t: 'milf and stepson roleplay', tags: ['milf', 'roleplay', 'taboo', 'duo', 'straight', 'amateur'] },
    { t: 'dirty talk: full audio mix', tags: ['dirty-talk', 'duo', 'amateur', 'bedroom', 'passionate', 'hd'] },
    { t: 'wordless film, 28 minutes', tags: ['silent', 'cinematic', 'duo', 'sensual', 'professional', 'arthouse'] },
    { t: 'blonde busty office', tags: ['blonde', 'busty', 'office', 'duo', 'professional', 'straight', 'secretary'] },
    { t: 'hairy bear duo', tags: ['gay', 'hairy', 'duo', 'tender', 'bedroom', 'amateur', 'beard'] },
    { t: 'lesbian threesome — hotel', tags: ['lesbian', 'threesome', 'hotel', 'professional', 'passionate'] },
    { t: 'pov: morning, sleepy', tags: ['pov', 'gentle', 'tender', 'bedroom', 'duo', 'amateur', 'hd', 'morning', 'sleepy'] },
    { t: 'twin bed, one fan', tags: ['amateur', 'duo', 'bedroom', 'homemade', 'gentle'] },
    { t: 'rough — and then not', tags: ['rough', 'duo', 'intense', 'passionate', 'studio', 'aftercare'] },
    { t: 'shaved, polaroid lighting', tags: ['shaved', 'duo', 'amateur', 'vintage', 'bedroom', 'polaroid'] },
    { t: 'voyeur window, 2:14 am', tags: ['voyeur', 'amateur', 'duo', 'taboo', '3am'] },
    { t: 'rooftop kink dinner', tags: ['rooftop', 'bdsm', 'group', 'sensual', 'professional'] },
    { t: 'four hands, no rush', tags: ['threesome', 'gentle', 'sensual', 'amateur', 'duo', 'unhurried'] },
    { t: 'beach house honeymoon', tags: ['beach', 'outdoor', 'couple', 'duo', 'romantic', 'tender', 'honeymoon'] },
    { t: 'fetish: silk gloves only', tags: ['fetish', 'duo', 'sensual', 'studio', 'tender', 'silk'] },
    { t: 'cosplay duo — wholesome', tags: ['cosplay', 'duo', 'playful', 'tender', 'amateur', 'bedroom'] },
    { t: 'pov edge, no release', tags: ['pov', 'edging', 'sub', 'sensual', 'studio', 'denial'] },
    { t: 'studio anal — patient cut', tags: ['anal', 'studio', 'professional', 'duo', '4k', 'sensual'] },
    { t: 'kitchen counter quickie', tags: ['kitchen', 'duo', 'amateur', 'rough', 'couple', 'urgent'] },
    { t: 'romantic candlelit duo', tags: ['romantic', 'tender', 'duo', 'bedroom', 'amateur', 'sensual', 'candlelit'] },
    { t: 'public train fantasy', tags: ['public', 'roleplay', 'taboo', 'duo', 'professional', 'stranger'] },
    { t: 'queer trio, kitchen', tags: ['queer', 'threesome', 'kitchen', 'amateur', 'gentle'] },
    { t: 'french couple, hotel suite', tags: ['français', 'subtitled', 'couple', 'duo', 'hotel', 'sensual'] },
    { t: 'studio cinema 4k — duo', tags: ['studio', 'cinematic', '4k', 'duo', 'sensual', 'professional'] },
    { t: 'two milfs, one weekend', tags: ['milf', 'lesbian', 'duo', 'amateur', 'tender'] },
    { t: 'mature couple, anniversary', tags: ['mature', 'couple', 'duo', 'tender', 'romantic', 'amateur', 'anniversary', 'married'] },
    { t: 'devotional sub, asmr', tags: ['sub', 'asmr', 'sensual', 'tender', 'duo', 'bdsm', 'worshipful'] },
    { t: 'office assistant — pov', tags: ['pov', 'office', 'roleplay', 'duo', 'straight', 'professional', 'secretary'] },
    { t: 'bisexual three, neon room', tags: ['bisexual', 'threesome', 'studio', 'passionate', 'professional', 'neon'] },
    { t: 'amateur hd, no edits', tags: ['amateur', 'hd', 'duo', 'homemade', 'bedroom', 'one-take'] },
    { t: 'vintage 80s adult network', tags: ['vintage', 'tape-hiss', 'studio', 'duo', 'straight', '80s', 'betamax'] },
    { t: 'public lake, golden hour', tags: ['public', 'outdoor', 'beach', 'duo', 'sensual', 'amateur', 'golden-hour'] },
    { t: 'taboo neighbors, hd', tags: ['taboo', 'hd', 'duo', 'roleplay', 'amateur', 'kitchen', 'neighbor'] },
    { t: 'professional foot scene', tags: ['foot', 'fetish', 'studio', 'professional', 'duo'] },
    { t: 'real couple — script test', tags: ['couple', 'amateur', 'duo', 'playful', 'bedroom', 'behind-the-scenes'] },
    { t: 'two boys, balcony, dawn', tags: ['gay', 'duo', 'balcony', 'outdoor', 'tender', 'amateur', 'sunrise'] },
    { t: 'asmr dirty talk loop', tags: ['asmr', 'dirty-talk', 'solo', 'sensual', 'bedroom'] },
    { t: 'redhead milf, kitchen pov', tags: ['redhead', 'milf', 'kitchen', 'pov', 'duo', 'amateur'] },
    { t: 'glasses solo, very long', tags: ['glasses', 'solo', 'toys', 'edging', 'amateur'] },
    { t: 'queer wedding night', tags: ['queer', 'couple', 'duo', 'romantic', 'tender', 'hotel', 'married'] },
    { t: 'gay shower, intense', tags: ['gay', 'shower', 'duo', 'intense', 'passionate', 'amateur'] },
    { t: 'bisexual group, slow', tags: ['bisexual', 'group', 'gentle', 'sensual', 'professional', 'slow'] },
    { t: 'cosplay schoolgirl roleplay', tags: ['cosplay', 'roleplay', 'taboo', 'duo', 'studio'] },
    { t: 'oil massage — couple', tags: ['massage', 'couple', 'duo', 'gentle', 'sensual', 'tender', 'oiled'] },
    { t: 'trans solo — bath', tags: ['trans', 'solo', 'bathtub', 'tender', 'sensual', 'amateur'] },
    { t: 'pov: kissing only', tags: ['pov', 'gentle', 'tender', 'duo', 'amateur', 'romantic'] },
    // ── expansion wave: new settings, wardrobe, scenarios, eras, cameras ──
    { t: 'sauna, no talking', tags: ['sauna', 'duo', 'silent', 'sensual', 'amateur', 'gay', 'muffled'] },
    { t: 'pool boy audition tape', tags: ['pool', 'audition', 'casting', 'roleplay', 'duo', 'straight', 'playful'] },
    { t: 'jacuzzi at the motel', tags: ['jacuzzi', 'motel', 'couple', 'duo', 'amateur', 'passionate', 'midnight'] },
    { t: 'wine cellar, candlelit', tags: ['wine-cellar', 'candlelit', 'duo', 'sensual', 'cinematic', 'slow'] },
    { t: 'penthouse, floor to ceiling', tags: ['penthouse', 'duo', 'professional', '4k', 'wide-shot', 'neon'] },
    { t: 'fire escape, july heat', tags: ['fire-escape', 'public', 'exhibitionist', 'duo', 'amateur', 'urgent'] },
    { t: 'barn light, super 8', tags: ['barn', 'super-8', 'film-grain', 'duo', 'vintage', 'dreamy'] },
    { t: 'campervan, national forest', tags: ['campervan', 'forest', 'couple', 'amateur', 'handheld', 'tender'] },
    { t: 'tent, two sleeping bags', tags: ['tent', 'outdoor', 'couple', 'amateur', 'whispering', 'laughing'] },
    { t: 'library stacks, hushed', tags: ['library', 'public', 'voyeur', 'duo', 'muffled', 'shy', 'urgent'] },
    { t: 'elevator, eleven floors', tags: ['elevator', 'public', 'stranger', 'duo', 'urgent', 'security-cam'] },
    { t: 'basement dungeon tour', tags: ['basement', 'bdsm', 'bondage', 'dom', 'sub', 'studio', 'leather'] },
    { t: 'staircase, one shoe off', tags: ['staircase', 'duo', 'heels', 'urgent', 'amateur', 'passionate'] },
    { t: 'laundry room spin cycle', tags: ['laundry-room', 'duo', 'amateur', 'playful', 'quickie-mood', 'giddy'].filter(x => x !== 'quickie-mood') },
    { t: 'garage, engine still warm', tags: ['garage', 'duo', 'rough', 'amateur', 'denim', 'handheld'] },
    { t: 'garden party, overdressed', tags: ['garden', 'group', 'swingers', 'professional', 'sensual', 'afternoon'] },
    { t: 'cabin weekend, no service', tags: ['cabin', 'couple', 'amateur', 'tender', 'all-night', 'lamplight'] },
    { t: 'attic light through dust', tags: ['attic', 'duo', 'soft-focus', 'sensual', 'amateur', 'natural-light'] },
    { t: 'boat deck, open water', tags: ['boat', 'outdoor', 'couple', 'duo', 'sensual', 'sunrise', 'wide-shot'] },
    { t: 'lingerie try-on, mirror', tags: ['lingerie', 'solo', 'mirror-shot', 'striptease', 'teasing', 'bedroom'] },
    { t: 'stockings and heels only', tags: ['stockings', 'heels', 'solo', 'studio', 'sensual', 'closeup'] },
    { t: 'corset unlacing, real time', tags: ['corset', 'duo', 'slow', 'sensual', 'candlelit', 'long-take'] },
    { t: 'harness, latex, strobe', tags: ['harness', 'latex', 'bdsm', 'femdom', 'studio', 'strobe', 'intense'] },
    { t: 'suit and tie, undone', tags: ['suit-and-tie', 'office', 'boss', 'duo', 'dom', 'intense', 'straight'] },
    { t: 'bathrobe falls open', tags: ['bathrobe', 'hotel', 'duo', 'teasing', 'sensual', 'morning'] },
    { t: 'wet clothes, warm rain', tags: ['wet-clothes', 'outdoor', 'duo', 'passionate', 'rain-audio', 'amateur'] },
    { t: 'socks on, heat off', tags: ['socks-on', 'couple', 'bedroom', 'cuddling', 'tender', 'amateur', 'playful'] },
    { t: 'nothing but jewelry', tags: ['nothing-but-jewelry', 'nude', 'solo', 'studio', 'cinematic', 'sensual'] },
    { t: 'the nurse will see you', tags: ['nurse', 'uniform', 'roleplay', 'duo', 'professional', 'teasing'] },
    { t: 'tutor after class', tags: ['tutor', 'roleplay', 'duo', 'amateur', 'shy', 'taboo'] },
    { t: 'plumber, no callout fee', tags: ['plumber', 'roleplay', 'kitchen', 'duo', 'straight', 'playful'] },
    { t: 'delivery at the door', tags: ['delivery', 'roleplay', 'stranger', 'duo', 'amateur', 'urgent'] },
    { t: 'landlord negotiates rent', tags: ['landlord', 'roleplay', 'taboo', 'duo', 'professional'] },
    { t: 'roommate agreement, revised', tags: ['roommate', 'roleplay', 'duo', 'amateur', 'awkward', 'tender'] },
    { t: 'the ex, one last time', tags: ['the-ex', 'duo', 'passionate', 'melancholy', 'amateur', 'midnight'] },
    { t: 'personal trainer, extra set', tags: ['personal-trainer', 'gym', 'athletic', 'duo', 'roleplay', 'rough'] },
    { t: 'photographer and muse', tags: ['photographer', 'studio', 'duo', 'arthouse', 'sensual', 'black-and-white'] },
    { t: 'masseuse — happy ending?', tags: ['masseuse', 'massage', 'roleplay', 'duo', 'teasing', 'professional'] },
    { t: 'teacher keeps you late', tags: ['teacher', 'roleplay', 'duo', 'dom', 'straight', 'office'] },
    { t: 'y2k webcam archive', tags: ['y2k', 'webcam', 'grainy', 'solo', 'amateur', 'lo-fi'] },
    { t: '90s dvd rip, upscaled', tags: ['90s', 'dvd-rip', 'upscaled', 'studio', 'duo', 'classic'] },
    { t: 'remastered: the pool scene', tags: ['remastered', 'classic', 'pool', '4k', 'professional', 'award-winning'] },
    { t: 'super 8, no sound', tags: ['super-8', 'silent', 'film-grain', 'duo', 'arthouse', 'dreamy'] },
    { t: 'security cam, aisle 5', tags: ['security-cam', 'voyeur', 'public', 'duo', 'grainy', 'exhibitionist'] },
    { t: 'overhead, white sheets', tags: ['overhead', 'duo', 'bedroom', '4k', 'sensual', 'natural-light'] },
    { t: 'fisheye peephole pov', tags: ['fisheye', 'voyeur', 'hotel', 'duo', 'taboo', 'grainy'] },
    { t: 'dutch angle, red room', tags: ['dutch-angle', 'studio', 'cinematic', 'bdsm', 'intense', 'neon'] },
    { t: 'split diopter, both faces', tags: ['split-diopter', 'cinematic', 'arthouse', 'duo', 'passionate', 'big-budget'] },
    { t: 'night vision campsite', tags: ['night-vision', 'tent', 'voyeur', 'couple', 'amateur', 'grainy'] },
    { t: 'tripod, no operator', tags: ['tripod', 'homemade', 'couple', 'duo', 'amateur', 'one-take'] },
    { t: '8k skin documentary', tags: ['8k', 'documentary', 'closeup', 'solo', 'arthouse', 'slow-motion'] },
    { t: 'vertical: for your phone', tags: ['vertical', 'solo', 'amateur', 'teasing', 'bedroom', 'new-upload'] },
    { t: '60fps, every flutter', tags: ['60fps', 'closeup', 'studio', 'duo', 'professional', 'lossless'] },
    { t: 'slow motion, water glass', tags: ['slow-motion', 'cinematic', 'duo', 'sensual', 'big-budget', '4k'] },
    { t: 'first date, last bus missed', tags: ['first-date', 'dating', 'duo', 'awkward', 'tender', 'amateur'] },
    { t: 'long distance, reunited', tags: ['long-distance', 'reunion', 'couple', 'passionate', 'desperate', 'airport-adjacent'].filter(x => x !== 'airport-adjacent') },
    { t: 'strangers to lovers, 3 acts', tags: ['strangers-to-lovers', 'stranger', 'cinematic', 'duo', 'romantic', 'arthouse'] },
    { t: 'situationship, undefined', tags: ['situationship', 'friends', 'duo', 'awkward', 'passionate', 'amateur'] },
    { t: 'open relationship, guest star', tags: ['open-relationship', 'threesome', 'couple', 'amateur', 'playful'] },
    { t: 'second marriage, better this time', tags: ['second-marriage', 'married', 'mature', 'couple', 'tender', 'loving'] },
    { t: 'friends, one blanket', tags: ['friends', 'duo', 'shy', 'tender', 'amateur', 'lamplight', 'cuddling'] },
    { t: 'honeymoon suite, do not disturb', tags: ['honeymoon', 'married', 'hotel', 'couple', 'passionate', 'all-night'] },
    { t: 'pansexual house party', tags: ['pansexual', 'group', 'orgy', 'amateur', 'playful', 'music'] },
    { t: 'sapphic slow dance', tags: ['sapphic', 'lesbian', 'duo', 'romantic', 'music', 'candlelit', 'slow'] },
    { t: 'swingers, first meeting', tags: ['swingers', 'two-couples', 'foursome', 'amateur', 'awkward', 'giddy'] },
    { t: 'orgy, choreographed', tags: ['orgy', 'group', 'big-budget', 'professional', 'cinematic', 'intense'] },
    { t: 'compilation: only the endings', tags: ['compilation', 'montage', 'hd', 'intense', 'fan-favorite'] },
    { t: 'split screen: both bedrooms', tags: ['split-screen', 'long-distance', 'couple', 'webcam', 'tender', 'arthouse'] },
    { t: 'gilf, unbothered', tags: ['gilf', 'mature', 'solo', 'confident-mood', 'sensual', 'amateur'].filter(x => x !== 'confident-mood') },
    { t: 'muscular, gentle anyway', tags: ['muscular', 'tall', 'duo', 'gentle', 'gay', 'tender'] },
    { t: 'dad bod appreciation', tags: ['dad-bod', 'dilf', 'duo', 'loving', 'amateur', 'bedroom'] },
    { t: 'soft and slow, sunday', tags: ['soft', 'chubby', 'couple', 'slow', 'sunday', 'tender', 'morning'] },
    { t: 'flexible: full split', tags: ['flexible', 'athletic', 'toned', 'solo', 'studio', 'impressive-mood'].filter(x => x !== 'impressive-mood') },
    { t: 'tall girl, short boy', tags: ['tall', 'short', 'duo', 'straight', 'playful', 'amateur'] },
    { t: 'thick thighs save lives', tags: ['thick', 'curvy', 'duo', 'worship', 'amateur', 'praise'] },
    { t: 'skinny dipping, actually skinny', tags: ['skinny', 'slim', 'pool', 'nude', 'playful', 'moonlit'] },
    { t: 'goth gf, fluorescent bathroom', tags: ['goth', 'alt', 'dyed-hair', 'duo', 'fluorescent', 'amateur', 'rough'] },
    { t: 'girl next door, literally', tags: ['girl-next-door', 'neighbor', 'natural', 'duo', 'amateur', 'shy'] },
    { t: 'silver fox, wine cellar', tags: ['silver-fox', 'mature', 'wine-cellar', 'duo', 'sensual', 'straight'] },
    { t: 'androgynous, overexposed', tags: ['androgynous', 'queer', 'solo', 'overexposed', 'arthouse', 'black-and-white'] },
    { t: 'buzzcut and mullet, garage band', tags: ['buzzcut', 'mullet', 'alt', 'duo', 'garage', 'rough', 'music'] },
    { t: 'freckles, every one counted', tags: ['freckles', 'pale', 'duo', 'tender', 'closeup', 'praise', 'worshipful'] },
    { t: 'tan lines, august', tags: ['tan-lines', 'beach', 'solo', 'natural-light', 'amateur', 'teasing'] },
    { t: 'long hair everywhere', tags: ['long-hair', 'curly-hair', 'duo', 'passionate', 'bedroom', 'amateur'] },
    { t: 'short hair, don\'t care', tags: ['short-hair', 'lesbian', 'duo', 'playful', 'amateur', 'giddy'] },
    { t: 'shibari, patient hands', tags: ['shibari', 'bondage', 'bdsm', 'duo', 'studio', 'reverent', 'slow'] },
    { t: 'wax play, red candles', tags: ['wax-play', 'temperature-play', 'bdsm', 'duo', 'candlelit', 'intense'] },
    { t: 'blindfold, guess the touch', tags: ['blindfold', 'sensory', 'duo', 'teasing', 'gentle', 'bedroom'] },
    { t: 'handcuffed to the headboard', tags: ['handcuffs', 'bondage', 'duo', 'sub', 'bedroom', 'intense'] },
    { t: 'praise only, full session', tags: ['praise', 'worshipful', 'duo', 'gentle', 'tender', 'asmr', 'loving'] },
    { t: 'pet play, sunday afternoon', tags: ['pet-play', 'roleplay', 'duo', 'playful', 'sub', 'afternoon'] },
    { t: 'femdom, silk and steel', tags: ['femdom', 'dom', 'silk', 'duo', 'intense', 'studio', 'heels'] },
    { t: 'spanking: count out loud', tags: ['spanking', 'bdsm', 'duo', 'dom', 'sub', 'rough'] },
    { t: 'exhibitionist, hotel window', tags: ['exhibitionist', 'voyeur', 'hotel', 'duo', 'urgent', 'public'] },
    { t: 'aftercare, twenty minutes', tags: ['aftercare', 'cuddling', 'tender', 'duo', 'loving', 'quiet-mood'].filter(x => x !== 'quiet-mood') },
    { t: 'temperature play: ice, then not', tags: ['temperature-play', 'sensory', 'duo', 'teasing', 'studio', 'intense'] },
    { t: 'denial diary, day 9', tags: ['denial', 'edging', 'solo', 'desperate', 'webcam', 'amateur'] },
    { t: 'lap dance, private room', tags: ['lap-dance', 'striptease', 'duo', 'teasing', 'music', 'neon'] },
    { t: 'striptease, work clothes', tags: ['striptease', 'solo', 'office', 'teasing', 'music', 'amateur'] },
    { t: 'sixty-nine, symmetrical', tags: ['69', 'mutual', 'duo', 'passionate', 'amateur', 'overhead'] },
    { t: 'fingering, radio on', tags: ['fingering', 'duo', 'car', 'amateur', 'music', 'urgent'] },
    { t: 'handjob, eye contact', tags: ['handjob', 'duo', 'closeup', 'intense', 'amateur', 'pov'] },
    { t: 'deepthroat, professional', tags: ['deepthroat', 'oral', 'duo', 'studio', 'professional', 'intense'] },
    { t: 'facesitting, queen', tags: ['facesitting', 'femdom', 'duo', 'worship', 'studio', 'intense'] },
    { t: 'pegging, his first time', tags: ['pegging', 'anal', 'duo', 'straight', 'gentle', 'amateur', 'shy'] },
    { t: 'scissoring, golden hour', tags: ['scissoring', 'tribbing', 'lesbian', 'duo', 'golden-hour', 'passionate'] },
    { t: 'titjob, oiled', tags: ['titjob', 'busty', 'oiled', 'duo', 'studio', 'sensual'] },
    { t: 'grinding, jeans on', tags: ['grinding', 'denim', 'duo', 'desperate', 'amateur', 'teasing'] },
    { t: 'mutual, mirrored', tags: ['mutual', 'duo', 'mirror-shot', 'sensual', 'amateur', 'bedroom'] },
    { t: 'cuddling that escalates', tags: ['cuddling', 'couple', 'tender', 'slow', 'bedroom', 'amateur', 'sleepy'] },
    { t: 'moaning, unedited', tags: ['moaning', 'duo', 'amateur', 'passionate', 'homemade', 'lossless'] },
    { t: 'laughing through it', tags: ['laughing', 'couple', 'playful', 'giddy', 'amateur', 'bedroom'] },
    { t: 'narrated by her', tags: ['narration', 'dirty-talk', 'duo', 'pov', 'sensual', 'professional'] },
    { t: 'lo-fi to grind to', tags: ['lo-fi', 'music', 'duo', 'dreamy', 'amateur', 'lamplight'] },
    { t: 'vinyl crackle, slow jazz', tags: ['vinyl-crackle', 'music', 'duo', 'romantic', 'candlelit', 'slow', 'vintage'] },
    { t: 'heartbeat mic, chest down', tags: ['heartbeat', 'asmr', 'breathing', 'duo', 'closeup', 'tender'] },
    { t: 'field recording: cabin, rain', tags: ['field-recording', 'rain-audio', 'cabin', 'couple', 'tender', 'lo-fi'] },
    { t: 'muffled through the wall', tags: ['muffled', 'voyeur', 'taboo', 'amateur', 'duo', 'motel'] },
    { t: 'spanish golden age reel', tags: ['spanish', 'subtitled', 'vintage', '70s', 'duo', 'cinematic'] },
    { t: 'german precision, dungeon', tags: ['german', 'bdsm', 'studio', 'dom', 'professional', 'intense'] },
    { t: 'italian arthouse, restored', tags: ['italian', 'arthouse', 'remastered', 'cinematic', 'duo', 'classic'] },
    { t: 'russian white nights', tags: ['russian', 'subtitled', 'duo', 'melancholy', 'cinematic', 'moonlit'] },
    { t: 'korean drama, uncut', tags: ['korean', 'subtitled', 'cinematic', 'duo', 'romantic', 'professional'] },
    { t: 'badly dubbed, beloved', tags: ['dubbed', 'cult-classic', 'vintage', 'duo', 'awkward', 'fan-favorite'] },
    { t: 'multilingual threesome', tags: ['multilingual', 'threesome', 'accents', 'professional', 'playful'] },
    { t: 'accents only, no plot', tags: ['accents', 'dirty-talk', 'duo', 'teasing', 'amateur'] },
    { t: 'staff pick: the bathtub one', tags: ['staff-pick', 'bathtub', 'couple', 'tender', 'cinematic', 'underrated'] },
    { t: 'trending: don\'t ask why', tags: ['trending', 'viral', 'amateur', 'duo', 'awkward', 'playful'] },
    { t: 'deep cut, 43 views', tags: ['deep-cut', 'underrated', 'arthouse', 'solo', 'melancholy', 'lamplight'] },
    { t: 'award winner, 2024', tags: ['award-winning', 'big-budget', 'cinematic', 'duo', 'professional', '8k'] },
    { t: 'cult classic: the mirror scene', tags: ['cult-classic', 'classic', 'mirror-shot', 'duo', 'vintage', '80s'] },
    { t: 'new upload, be nice', tags: ['new-upload', 'amateur', 'solo', 'shy', 'webcam', 'vertical'] },
    { t: 'viral for the wrong reasons', tags: ['viral', 'trending', 'amateur', 'laughing', 'awkward', 'homemade'] },
    { t: 'fan favorite, tenth rewatch', tags: ['fan-favorite', 'classic', 'couple', 'passionate', 'hd'] },
    { t: 'behind the scenes, still hot', tags: ['behind-the-scenes', 'documentary', 'studio', 'group', 'laughing', 'playful'] },
    { t: 'indie darling, one location', tags: ['indie', 'low-budget', 'one-take', 'duo', 'arthouse', 'natural-light'] },
    { t: 'casting couch, subverted', tags: ['casting', 'audition', 'roleplay', 'duo', 'femdom', 'professional'] },
    { t: 'verified couple, 3 years in', tags: ['verified', 'couple', 'amateur', 'loving', 'bedroom', 'hd'] },
    { t: 'feral, then embarrassed', tags: ['feral', 'passionate', 'duo', 'amateur', 'giddy', 'bedroom'] },
    { t: 'reverent, like church', tags: ['reverent', 'worshipful', 'worship', 'duo', 'candlelit', 'slow'] },
    { t: 'euphoric, post-everything', tags: ['euphoric', 'cuddling', 'couple', 'loving', 'amateur', 'morning'] },
    { t: 'melancholy hotel, checkout at 11', tags: ['melancholy', 'hotel', 'the-ex', 'duo', 'cinematic', 'morning'] },
    { t: 'dreamy, soft focus, no plot', tags: ['dreamy', 'soft-focus', 'duo', 'sensual', 'arthouse', 'sepia'] },
    { t: 'desperate, quiet, parents home', tags: ['desperate', 'muffled', 'taboo', 'duo', 'amateur', 'urgent'] },
    { t: 'lunchtime, twelve minutes flat', tags: ['lunchtime', 'office', 'duo', 'urgent', 'professional', 'quickie-cat'].filter(x => x !== 'quickie-cat') },
    { t: 'all night, three acts', tags: ['all-night', 'couple', 'passionate', 'marathon-cat', 'bedroom', 'hd'].filter(x => x !== 'marathon-cat') },
    { t: 'dusk on the balcony', tags: ['dusk', 'balcony', 'duo', 'sensual', 'golden-hour', 'amateur'] },
    { t: '3am, neither can sleep', tags: ['3am', 'couple', 'sleepy', 'tender', 'bedroom', 'lamplight'] },
    { t: 'moonlit pool, no suits', tags: ['moonlit', 'pool', 'nude', 'couple', 'sensual', 'midnight'] },
    { t: 'projector glow, home movies', tags: ['projector-glow', 'vintage', 'super-8', 'couple', 'tender', 'nostalgic-x'].filter(x => x !== 'nostalgic-x') },
    { t: 'sepia, restored from betamax', tags: ['sepia', 'betamax', 'remastered', 'duo', 'vintage', 'grainy'] },
    { t: 'black and white, hands only', tags: ['black-and-white', 'closeup', 'arthouse', 'duo', 'sensual', 'silent'] },
  ].map((v) => ({ t: v.t, tags: [...new Set(v.tags)].filter((t) => CAT_OF[t]) }));

  // ── Deterministic generator: guarantees every tag appears in ≥2 videos so
  // no node gets orphan-filtered, and fills the graph with plausible
  // co-occurrence clusters. Seeded PRNG → stable ids across reloads.
  function mulberry32(seed) {
    return function () {
      seed |= 0; seed = (seed + 0x6D2B79F5) | 0;
      let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  const rnd = mulberry32(20260704);
  const pick = (arr) => arr[Math.floor(rnd() * arr.length)];

  // Which categories plausibly co-occur with each category.
  const COMPAT = {
    format:      ['orientation', 'mood', 'setting', 'production', 'quality', 'act'],
    orientation: ['format', 'body', 'mood', 'setting', 'production'],
    body:        ['look', 'format', 'setting', 'mood', 'production'],
    look:        ['body', 'format', 'setting', 'production', 'act'],
    production:  ['quality', 'era', 'camera', 'setting', 'mood'],
    quality:     ['production', 'camera', 'setting', 'format'],
    setting:     ['time', 'mood', 'format', 'production', 'wardrobe'],
    kink:        ['mood', 'wardrobe', 'setting', 'format', 'sound'],
    act:         ['mood', 'format', 'setting', 'production', 'time'],
    sound:       ['mood', 'production', 'quality', 'setting', 'format'],
    mood:        ['setting', 'time', 'format', 'act', 'sound'],
    tongue:      ['production', 'mood', 'setting', 'era', 'format'],
    wardrobe:    ['kink', 'mood', 'setting', 'look', 'format'],
    scenario:    ['kink', 'setting', 'mood', 'format', 'production'],
    era:         ['production', 'quality', 'sound', 'camera', 'format'],
    camera:      ['production', 'quality', 'setting', 'format', 'mood'],
    time:        ['setting', 'mood', 'format', 'sound', 'vibe'],
    vibe:        ['setting', 'time', 'mood', 'camera', 'production'],
    relationship:['format', 'mood', 'setting', 'time', 'vibe'],
    community:   ['production', 'era', 'quality', 'format', 'mood'],
  };
  const GLUE = ['amateur', 'duo', 'hd', 'bedroom', 'sensual', 'couple', 'tender', 'professional', 'studio'];

  const CLOSERS = [
    'no rush', 'the long cut', 'after hours', 'first upload', "director's cut",
    'one take', 'unlisted', 'reupload', 'the good one', 'extended mix',
    'b-side', 'take two', 'as requested', 'quiet version', 'full length',
    'do not recommend to friends', 'archive copy', 'late entry', 'loop this',
    'sound on', 'for the algorithm', 'as found', 'no context', 'the sequel',
  ];
  const JOINERS = [' × ', ' + ', ' / ', ' meets ', ' but ', ', then '];
  const TEMPLATES = [
    (a, b) => `${a}${pick(JOINERS)}${b}`,
    (a, b) => `${a}, ${b} — ${pick(CLOSERS)}`,
    (a)    => `${a}: ${pick(CLOSERS)}`,
    (a, b) => `${b} ${a}, ${pick(CLOSERS)}`,
    (a)    => `${a} pt.${2 + Math.floor(rnd() * 9)}`,
    (a, b) => `${a} (${b} edit)`,
    (a)    => `${a}, archive ${String(1 + Math.floor(rnd() * 40)).padStart(2, '0')}`,
    (a, b) => `just ${a} and ${b}`,
  ];

  const coverage = new Map();
  ALL_TAGS.forEach((t) => coverage.set(t.id, 0));
  const bump = (v) => v.tags.forEach((t) => coverage.set(t, (coverage.get(t) || 0) + 1));
  CURATED.forEach(bump);

  function leastCovered(tags) {
    let best = null, bestC = Infinity;
    for (const t of tags) {
      const c = coverage.get(t);
      if (c < bestC) { best = t; bestC = c; }
    }
    return best;
  }

  const GENERATED = [];
  let guard = 0;
  while (guard++ < 700) {
    const anchor = leastCovered([...coverage.keys()]);
    if (coverage.get(anchor) >= 2) break; // everything covered twice
    const cats = COMPAT[CAT_OF[anchor]] || ['format', 'mood', 'setting'];
    const tags = new Set([anchor]);
    const n = 4 + Math.floor(rnd() * 3); // 5-7 tags total
    let tries = 0;
    while (tags.size < n && tries++ < 30) {
      let candidate;
      if (rnd() < 0.22) {
        candidate = pick(GLUE);
      } else {
        const cat = pick(cats);
        const pool = TAG_CATS[cat];
        // Half the time reach for the least-covered tag in the pool so
        // coverage converges; otherwise random for texture.
        candidate = rnd() < 0.5 ? leastCovered(pool) : pick(pool);
      }
      if (candidate !== anchor) tags.add(candidate);
    }
    const arr = [...tags];
    const b = arr[1] || pick(GLUE);
    const title = pick(TEMPLATES)(anchor, b);
    const v = { t: title, tags: arr };
    GENERATED.push(v);
    bump(v);
  }

  const VIDEOS = [...CURATED, ...GENERATED].map((v, i) => ({ id: 'v' + i, ...v }));

  // ── Build edges from co-occurrence.
  const edgeMap = new Map();
  const tagVidIndex = new Map();
  for (const v of VIDEOS) {
    for (const t of v.tags) {
      if (!tagVidIndex.has(t)) tagVidIndex.set(t, new Set());
      tagVidIndex.get(t).add(v.id);
    }
    for (let i = 0; i < v.tags.length; i++) {
      for (let j = i + 1; j < v.tags.length; j++) {
        const a = v.tags[i], b = v.tags[j];
        const key = a < b ? a + '|' + b : b + '|' + a;
        edgeMap.set(key, (edgeMap.get(key) || 0) + 1);
      }
    }
  }
  const EDGES = [...edgeMap.entries()].map(([k, w]) => {
    const [a, b] = k.split('|');
    return { a, b, w };
  });

  // Filter out orphaned tags so every node has at least one edge.
  const inUse = new Set();
  EDGES.forEach((e) => { inUse.add(e.a); inUse.add(e.b); });
  VIDEOS.forEach((v) => v.tags.forEach((t) => inUse.add(t)));
  const TAGS = ALL_TAGS.filter((t) => inUse.has(t.id));

  function videosForTag(tagId) {
    const ids = tagVidIndex.get(tagId);
    return ids ? VIDEOS.filter((v) => ids.has(v.id)) : [];
  }
  function videosForTags(tagIds) {
    if (!tagIds || tagIds.length === 0) return [];
    if (tagIds.length === 1) return videosForTag(tagIds[0]);
    return VIDEOS.filter((v) => tagIds.every((t) => v.tags.includes(t)));
  }
  // ── Adjacency map (tag → Map(neighbor → weight)), built once from EDGES.
  const ADJ = new Map();
  for (const e of EDGES) {
    if (!ADJ.has(e.a)) ADJ.set(e.a, new Map());
    if (!ADJ.has(e.b)) ADJ.set(e.b, new Map());
    ADJ.get(e.a).set(e.b, e.w);
    ADJ.get(e.b).set(e.a, e.w);
  }
  function neighborsOf(tagId) {
    return new Map(ADJ.get(tagId) || []);
  }

  // Soft intersection: never-empty relevance ranking.
  // +1.0 per selected tag the video carries directly,
  // +0.35 per selected tag whose graph neighbor the video carries.
  // Returns [{ video, score, overlap, exact }] sorted by score desc,
  // tiebroken by direct-tag overlap count. Drops score-0 videos.
  function scoreVideosForTags(tagIds) {
    if (!tagIds || tagIds.length === 0) return [];
    const out = [];
    for (const v of VIDEOS) {
      const vt = new Set(v.tags);
      let score = 0, overlap = 0;
      for (const t of tagIds) {
        if (vt.has(t)) { score += 1.0; overlap++; continue; }
        const nb = ADJ.get(t);
        if (nb) {
          for (const tag of v.tags) {
            if (nb.has(tag)) { score += 0.35; break; }
          }
        }
      }
      if (score <= 0) continue;
      out.push({ video: v, score, overlap, exact: overlap === tagIds.length });
    }
    out.sort((a, b) => b.score - a.score || b.overlap - a.overlap);
    return out;
  }

  // Shortest weighted path over EDGES (Dijkstra, cost = 1/w so heavier
  // co-occurrence is a cheaper hop). Returns [a, ...bridges, b] or null.
  function pathBetween(aId, bId) {
    if (aId === bId) return [aId];
    if (!ADJ.has(aId) || !ADJ.has(bId)) return null;
    const dist = new Map([[aId, 0]]);
    const prev = new Map();
    const done = new Set();
    // O(V^2) scan is plenty for ~326 nodes on a gesture.
    for (;;) {
      let u = null, best = Infinity;
      for (const [k, d] of dist) {
        if (!done.has(k) && d < best) { best = d; u = k; }
      }
      if (u === null) return null; // disconnected
      if (u === bId) break;
      done.add(u);
      for (const [v, w] of ADJ.get(u)) {
        if (done.has(v)) continue;
        const nd = best + 1 / w;
        if (nd < (dist.has(v) ? dist.get(v) : Infinity)) {
          dist.set(v, nd);
          prev.set(v, u);
        }
      }
    }
    const path = [bId];
    while (path[0] !== aId) path.unshift(prev.get(path[0]));
    return path;
  }

  // For each adjacent pair on a path, the videos carrying both tags of that
  // hop — grouped so the UI can render the thread as a ribbon of hops.
  function videosAlongPath(pathTagIds) {
    if (!pathTagIds || pathTagIds.length < 2) return [];
    const hops = [];
    for (let i = 0; i < pathTagIds.length - 1; i++) {
      const from = pathTagIds[i], to = pathTagIds[i + 1];
      hops.push({ from, to, videos: videosForTags([from, to]) });
    }
    return hops;
  }

  window.LT_DATA = {
    TAGS, VIDEOS, EDGES, TAG_CATS,
    videosForTag, videosForTags, neighborsOf,
    scoreVideosForTags, pathBetween, videosAlongPath,
  };
})();
