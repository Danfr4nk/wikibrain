// graph.jsx — force-directed tag graph with pan/zoom + pull-thread drag.
//
// Renders edges to a canvas and tag labels as absolutely-positioned divs. The
// physics tick runs in rAF and directly mutates label transforms so React
// only renders the label list once. Pull-thread: pointerdown on a tag node
// starts a drag; release on another node creates an intersection query;
// release elsewhere is just a focus click.

(function () {
  const { TAGS, EDGES, TAG_CATS } = window.LT_DATA;

  // Physics constants — exposed via tweaks-panel via the `physics` prop.
  const DEFAULT_PHYSICS = {
    rest: 180, kSpring: 0.012, kRep: 2400,
    kCenter: 0.0008, damp: 0.86, maxSpeed: 6,
  };

  // Pre-categorize tags so initial layout is roughly clustered by category
  // (saves the simulation a few seconds of churn).
  const CAT_ORDER = Object.keys(TAG_CATS);

  function initialNodes() {
    const nodes = TAGS.map((t) => {
      const ci = CAT_ORDER.indexOf(t.cat);
      const angle = (ci / CAT_ORDER.length) * Math.PI * 2;
      // Cluster in 8 lobes around the origin, with intra-cluster jitter.
      const r = 240 + (Math.random() - 0.5) * 80;
      return {
        id: t.id, cat: t.cat,
        x: Math.cos(angle) * r + (Math.random() - 0.5) * 90,
        y: Math.sin(angle) * r + (Math.random() - 0.5) * 90,
        vx: 0, vy: 0,
      };
    });
    return nodes;
  }

  function Graph({
    query, hovered, onTagClick, onPull, onHover,
    physics = DEFAULT_PHYSICS, glitchLevel = 1, density = 1,
  }) {
    const stageRef = React.useRef(null);
    const canvasRef = React.useRef(null);
    const labelsRef = React.useRef(null);
    const nodesRef = React.useRef(initialNodes());
    const labelElsRef = React.useRef({}); // id → DOM element
    const cameraRef = React.useRef({ x: 0, y: 0, zoom: 1 });
    const sizeRef = React.useRef({ w: 1, h: 1 });
    // Interaction state — pointerEvent driven, kept in refs so the rAF loop
    // can react without re-rendering React tree.
    const interactRef = React.useRef({
      mode: 'idle', // 'idle' | 'pan' | 'pull'
      panStart: null, // {mx, my, camX, camY}
      pullFrom: null, // node id
      pullTo:   null, // node id when snapped
      mouseW:   { x: 0, y: 0 }, // current mouse pos in world
      mouseS:   { x: 0, y: 0 }, // current mouse pos in screen
      mouseDown: null, // {id, x, y, t} for click-vs-drag disambiguation
    });
    // Edge index by tag — for fast lookup of which edges to highlight.
    const edgeIndex = React.useMemo(() => {
      const m = new Map();
      EDGES.forEach((e, i) => {
        if (!m.has(e.a)) m.set(e.a, []);
        if (!m.has(e.b)) m.set(e.b, []);
        m.get(e.a).push(i); m.get(e.b).push(i);
      });
      return m;
    }, []);
    // O(1) node lookup — built once (node list never changes after init).
    const nodeMapRef = React.useRef(null);
    const nodeMap = () => nodeMapRef.current
      || (nodeMapRef.current = new Map(nodesRef.current.map((n) => [n.id, n])));
    const tagPos = (id) => nodeMap().get(id);

    // Track which tag is under the mouse during a pull, so we can "snap" the
    // thread end to it.
    const queryRef = React.useRef(query);  queryRef.current = query;
    const hoveredRef = React.useRef(hovered); hoveredRef.current = hovered;

    // ── Resize handling ────────────────────────────────────────────────
    React.useEffect(() => {
      const el = stageRef.current;
      if (!el) return;
      const sync = () => {
        const r = el.getBoundingClientRect();
        sizeRef.current = { w: r.width, h: r.height };
        const c = canvasRef.current;
        const dpr = Math.min(window.devicePixelRatio || 1, 2);
        c.width = r.width * dpr; c.height = r.height * dpr;
        c.style.width = r.width + 'px'; c.style.height = r.height + 'px';
        c.getContext('2d').setTransform(dpr, 0, 0, dpr, 0, 0);
      };
      sync();
      const ro = new ResizeObserver(sync);
      ro.observe(el);
      return () => ro.disconnect();
    }, []);

    // ── Physics + render loop ──────────────────────────────────────────
    React.useEffect(() => {
      let raf;
      const step = () => {
        tickPhysics();
        render();
        raf = requestAnimationFrame(step);
      };
      raf = requestAnimationFrame(step);
      return () => cancelAnimationFrame(raf);
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    function tickPhysics() {
      const nodes = nodesRef.current;
      const N = nodes.length;
      const { kRep, kSpring, rest, kCenter, damp, maxSpeed } = physicsRef.current;
      // Repulsion — every pair.
      for (let i = 0; i < N; i++) {
        const a = nodes[i];
        for (let j = i + 1; j < N; j++) {
          const b = nodes[j];
          const dx = a.x - b.x;
          const dy = a.y - b.y;
          const d2 = Math.max(40, dx * dx + dy * dy);
          const f = kRep / d2;
          const d = Math.sqrt(d2);
          const fx = (dx / d) * f, fy = (dy / d) * f;
          a.vx += fx; a.vy += fy;
          b.vx -= fx; b.vy -= fy;
        }
      }
      // Springs (edges) — O(1) map lookups, no per-frame linear scans.
      const byId = nodeMap();
      for (const e of EDGES) {
        const a = byId.get(e.a);
        const b = byId.get(e.b);
        if (!a || !b) continue;
        const dx = b.x - a.x;
        const dy = b.y - a.y;
        const d = Math.max(1, Math.sqrt(dx * dx + dy * dy));
        // Heavier edges (more shared videos) want a shorter rest length.
        const targetRest = rest / (1 + Math.log(1 + e.w) * 0.6);
        const f = kSpring * (d - targetRest);
        const fx = (dx / d) * f, fy = (dy / d) * f;
        a.vx += fx; a.vy += fy;
        b.vx -= fx; b.vy -= fy;
      }
      // Gentle pull to origin.
      for (const n of nodes) {
        n.vx -= n.x * kCenter;
        n.vy -= n.y * kCenter;
        n.vx *= damp; n.vy *= damp;
        // Clamp to avoid the occasional explosion.
        const v = Math.sqrt(n.vx * n.vx + n.vy * n.vy);
        if (v > maxSpeed) { n.vx *= maxSpeed / v; n.vy *= maxSpeed / v; }
        n.x += n.vx; n.y += n.vy;
      }
    }
    const physicsRef = React.useRef(physics);
    React.useEffect(() => { physicsRef.current = physics; }, [physics]);

    function render() {
      const c = canvasRef.current;
      if (!c) return;
      const ctx = c.getContext('2d');
      const { w, h } = sizeRef.current;
      const cam = cameraRef.current;
      ctx.clearRect(0, 0, w, h);
      // World → screen helper.
      const w2sX = (x) => (x - cam.x) * cam.zoom + w / 2;
      const w2sY = (y) => (y - cam.y) * cam.zoom + h / 2;

      const nodes = nodesRef.current;
      const nodeById = nodeMap();
      const q = queryRef.current || [];
      const hov = hoveredRef.current;
      const focus = q.length === 1 ? q[0] : null;
      const highlight = new Set();
      [focus, hov, ...q].filter(Boolean).forEach((id) => {
        const arr = edgeIndex.get(id);
        if (arr) arr.forEach((i) => highlight.add(i));
      });
      // Pull thread destination, when active.
      const inter = interactRef.current;

      // ── Edges — base layer (faint).
      ctx.lineWidth = 0.8;
      for (let i = 0; i < EDGES.length; i++) {
        if (highlight.has(i)) continue;
        const e = EDGES[i];
        const a = nodeById.get(e.a), b = nodeById.get(e.b);
        if (!a || !b) continue;
        const ax = w2sX(a.x), ay = w2sY(a.y);
        const bx = w2sX(b.x), by = w2sY(b.y);
        const alpha = (q.length || focus) ? 0.05 : 0.14 + Math.min(0.25, e.w * 0.04);
        ctx.strokeStyle = `oklch(0.72 0.18 320 / ${alpha})`;
        ctx.beginPath(); ctx.moveTo(ax, ay); ctx.lineTo(bx, by); ctx.stroke();
      }
      // ── Edges — highlighted layer (glowing magenta/cyan with animated dash).
      const t = performance.now() * 0.001;
      for (const i of highlight) {
        const e = EDGES[i];
        const a = nodeById.get(e.a), b = nodeById.get(e.b);
        if (!a || !b) continue;
        const ax = w2sX(a.x), ay = w2sY(a.y);
        const bx = w2sX(b.x), by = w2sY(b.y);
        // Glow underlay.
        ctx.lineWidth = 4;
        ctx.strokeStyle = `oklch(0.78 0.30 340 / 0.18)`;
        ctx.beginPath(); ctx.moveTo(ax, ay); ctx.lineTo(bx, by); ctx.stroke();
        // Sharp top line.
        ctx.lineWidth = 1.2;
        ctx.strokeStyle = `oklch(0.86 0.22 200 / 0.95)`;
        ctx.setLineDash([8, 6]);
        ctx.lineDashOffset = -((t * 40) % 14);
        ctx.beginPath(); ctx.moveTo(ax, ay); ctx.lineTo(bx, by); ctx.stroke();
        ctx.setLineDash([]);
      }
      // ── Node halos drawn under labels.
      for (const n of nodes) {
        const sx = w2sX(n.x), sy = w2sY(n.y);
        const isQuery = q.includes(n.id);
        const isHov = hov === n.id;
        if (!isQuery && !isHov) continue;
        const radius = isQuery ? 36 : 22;
        const grad = ctx.createRadialGradient(sx, sy, 1, sx, sy, radius);
        grad.addColorStop(0, isQuery ? 'oklch(0.86 0.22 200 / 0.55)'
                                     : 'oklch(0.92 0.22 130 / 0.4)');
        grad.addColorStop(1, 'transparent');
        ctx.fillStyle = grad;
        ctx.beginPath(); ctx.arc(sx, sy, radius, 0, Math.PI * 2); ctx.fill();
      }
      // ── Pull thread.
      if (inter.mode === 'pull' && inter.pullFrom) {
        const from = nodeById.get(inter.pullFrom);
        if (from) {
          const ax = w2sX(from.x), ay = w2sY(from.y);
          let bx, by;
          if (inter.pullTo && nodeById.get(inter.pullTo)) {
            const to = nodeById.get(inter.pullTo);
            bx = w2sX(to.x); by = w2sY(to.y);
          } else {
            bx = inter.mouseS.x; by = inter.mouseS.y;
          }
          // Wavy bezier — control points perpendicular to the chord.
          const mx = (ax + bx) / 2, my = (ay + by) / 2;
          const dx = bx - ax, dy = by - ay;
          const len = Math.max(1, Math.sqrt(dx * dx + dy * dy));
          const perpX = -dy / len, perpY = dx / len;
          const wob = Math.sin(t * 7) * 12;
          const c1x = mx + perpX * (24 + wob), c1y = my + perpY * (24 + wob);
          ctx.lineWidth = 6;
          ctx.strokeStyle = 'oklch(0.92 0.22 130 / 0.18)';
          ctx.beginPath();
          ctx.moveTo(ax, ay); ctx.quadraticCurveTo(c1x, c1y, bx, by);
          ctx.stroke();
          ctx.lineWidth = 1.4;
          ctx.strokeStyle = inter.pullTo
            ? 'oklch(0.92 0.22 130 / 1)'
            : 'oklch(0.92 0.22 130 / 0.85)';
          ctx.setLineDash([4, 4]);
          ctx.lineDashOffset = -((t * 60) % 8);
          ctx.beginPath();
          ctx.moveTo(ax, ay); ctx.quadraticCurveTo(c1x, c1y, bx, by);
          ctx.stroke();
          ctx.setLineDash([]);
          // Dot at end.
          ctx.fillStyle = 'oklch(0.92 0.22 130 / 0.9)';
          ctx.beginPath(); ctx.arc(bx, by, inter.pullTo ? 6 : 3, 0, Math.PI * 2); ctx.fill();
        }
      }

      // ── Update label positions (no React).
      const dim = q.length > 0 || hov;
      for (const n of nodes) {
        const el = labelElsRef.current[n.id];
        if (!el) continue;
        const sx = w2sX(n.x), sy = w2sY(n.y);
        el.style.left = sx + 'px';
        el.style.top = sy + 'px';
        // Visual state attrs.
        const onQuery = q.includes(n.id);
        const isHov = hov === n.id;
        const isSnapTo = inter.pullTo === n.id;
        const isSnapFrom = inter.pullFrom === n.id;
        el.setAttribute('data-focus', onQuery ? '1' : '0');
        el.setAttribute('data-selected', isSnapTo || isSnapFrom ? '1' : '0');
        el.setAttribute('data-hover', isHov ? '1' : '0');
        // Dim if there's an active query AND this node isn't a neighbor of any
        // currently-selected node (and not on the query itself).
        let isDim = false;
        if (dim) {
          const keep = new Set();
          (q.length ? q : [hov]).forEach((id) => {
            if (!id) return;
            keep.add(id);
            const arr = edgeIndex.get(id);
            if (arr) arr.forEach((i) => {
              keep.add(EDGES[i].a); keep.add(EDGES[i].b);
            });
          });
          isDim = !keep.has(n.id);
        }
        el.setAttribute('data-dim', isDim ? '1' : '0');
      }
    }

    // ── Pointer handling ────────────────────────────────────────────────
    const screenToWorld = (sx, sy) => {
      const cam = cameraRef.current;
      const { w, h } = sizeRef.current;
      return { x: (sx - w / 2) / cam.zoom + cam.x, y: (sy - h / 2) / cam.zoom + cam.y };
    };
    // Find nearest tag node within radius `r` (screen px) — used during drag
    // to snap the pull thread.
    const nodeNearScreen = (sx, sy, r = 28, onlyIds = null) => {
      const cam = cameraRef.current;
      const { w, h } = sizeRef.current;
      let best = null, bestD2 = r * r;
      for (const n of nodesRef.current) {
        if (onlyIds && !onlyIds.has(n.id)) continue;
        const x = (n.x - cam.x) * cam.zoom + w / 2;
        const y = (n.y - cam.y) * cam.zoom + h / 2;
        const dx = x - sx, dy = y - sy;
        const d2 = dx * dx + dy * dy;
        if (d2 < bestD2) { bestD2 = d2; best = n; }
      }
      return best;
    };

    const onPointerDown = (e) => {
      // If the target is a tag-node, we *may* be starting a pull. We decide
      // based on whether the pointer moves before release.
      const stage = stageRef.current;
      const r = stage.getBoundingClientRect();
      const sx = e.clientX - r.left, sy = e.clientY - r.top;
      const tagEl = e.target.closest('.tag-node');
      const inter = interactRef.current;
      if (tagEl) {
        inter.mouseDown = { id: tagEl.getAttribute('data-id'), x: sx, y: sy, t: performance.now() };
        inter.mode = 'idle';
      } else {
        inter.mode = 'pan';
        inter.panStart = { mx: sx, my: sy, camX: cameraRef.current.x, camY: cameraRef.current.y };
        stage.classList.add('dragging');
      }
      // Capture pointer to keep getting moves outside the stage.
      stage.setPointerCapture(e.pointerId);
    };
    const onPointerMove = (e) => {
      const stage = stageRef.current;
      const r = stage.getBoundingClientRect();
      const sx = e.clientX - r.left, sy = e.clientY - r.top;
      const inter = interactRef.current;
      inter.mouseS = { x: sx, y: sy };
      inter.mouseW = screenToWorld(sx, sy);

      // Hover detection (when idle).
      if (inter.mode === 'idle' && !inter.mouseDown) {
        const near = nodeNearScreen(sx, sy, 24);
        const id = near ? near.id : null;
        if (id !== hoveredRef.current) onHover(id);
      }

      if (inter.mode === 'pan' && inter.panStart) {
        const { mx, my, camX, camY } = inter.panStart;
        const cam = cameraRef.current;
        cam.x = camX - (sx - mx) / cam.zoom;
        cam.y = camY - (sy - my) / cam.zoom;
      } else if (inter.mouseDown) {
        // Promote to pull mode if dragged far enough.
        const dx = sx - inter.mouseDown.x, dy = sy - inter.mouseDown.y;
        if (dx * dx + dy * dy > 8 * 8) {
          inter.mode = 'pull';
          inter.pullFrom = inter.mouseDown.id;
          inter.mouseDown = null;
          // Cache co-occurring neighbors of the pulled tag so the snap can
          // prefer nodes that share an edge (pulls land somewhere meaningful).
          const adj = new Set();
          const arr = edgeIndex.get(inter.pullFrom);
          if (arr) arr.forEach((i) => { adj.add(EDGES[i].a); adj.add(EDGES[i].b); });
          adj.delete(inter.pullFrom);
          inter.pullAdj = adj;
        }
      }
      if (inter.mode === 'pull') {
        // Prefer snapping to tags that share an edge with pullFrom (wider
        // radius); fall back to any node — non-adjacent pulls route via
        // pathBetween downstream, so they never dead-end.
        const nearAdj = inter.pullAdj && inter.pullAdj.size
          ? nodeNearScreen(sx, sy, 46, inter.pullAdj) : null;
        const near = nearAdj || nodeNearScreen(sx, sy, 30);
        inter.pullTo = (near && near.id !== inter.pullFrom) ? near.id : null;
      }
    };
    const onPointerUp = (e) => {
      const stage = stageRef.current;
      const inter = interactRef.current;
      stage.classList.remove('dragging');
      if (inter.mode === 'pan') {
        inter.mode = 'idle'; inter.panStart = null;
      } else if (inter.mode === 'pull') {
        if (inter.pullTo && inter.pullFrom && inter.pullTo !== inter.pullFrom) {
          onPull(inter.pullFrom, inter.pullTo);
        }
        inter.mode = 'idle'; inter.pullFrom = null; inter.pullTo = null; inter.pullAdj = null;
      } else if (inter.mouseDown) {
        // Click without drag: focus that tag.
        onTagClick(inter.mouseDown.id);
        inter.mouseDown = null; inter.mode = 'idle';
      }
    };
    const onWheel = (e) => {
      e.preventDefault();
      const stage = stageRef.current;
      const r = stage.getBoundingClientRect();
      const sx = e.clientX - r.left, sy = e.clientY - r.top;
      const cam = cameraRef.current;
      const { w, h } = sizeRef.current;
      const wx = (sx - w / 2) / cam.zoom + cam.x;
      const wy = (sy - h / 2) / cam.zoom + cam.y;
      const factor = Math.exp(-e.deltaY * 0.0015);
      cam.zoom = Math.min(2.4, Math.max(0.35, cam.zoom * factor));
      cam.x = wx - (sx - w / 2) / cam.zoom;
      cam.y = wy - (sy - h / 2) / cam.zoom;
    };
    React.useEffect(() => {
      const stage = stageRef.current;
      stage.addEventListener('wheel', onWheel, { passive: false });
      return () => stage.removeEventListener('wheel', onWheel);
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    // Smooth camera move when query/focused changes — center on the centroid
    // of selected tags, with a gentle zoom-in.
    React.useEffect(() => {
      if (!query || query.length === 0) return;
      const positions = query.map(tagPos).filter(Boolean);
      if (positions.length === 0) return;
      const tx = positions.reduce((s, n) => s + n.x, 0) / positions.length;
      const ty = positions.reduce((s, n) => s + n.y, 0) / positions.length;
      const tz = query.length === 1 ? 1.15 : 1.05;
      // Tween over ~450ms.
      const cam = cameraRef.current;
      const start = { x: cam.x, y: cam.y, z: cam.zoom };
      const t0 = performance.now();
      const dur = 500;
      let raf;
      const step = (t) => {
        const k = Math.min(1, (t - t0) / dur);
        const e = 1 - Math.pow(1 - k, 3);
        cam.x = start.x + (tx - start.x) * e;
        cam.y = start.y + (ty - start.y) * e;
        cam.zoom = start.z + (tz - start.z) * e;
        if (k < 1) raf = requestAnimationFrame(step);
      };
      raf = requestAnimationFrame(step);
      return () => cancelAnimationFrame(raf);
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [query && query.join('|')]);

    return (
      <div ref={stageRef} className="graph-stage"
           onPointerDown={onPointerDown}
           onPointerMove={onPointerMove}
           onPointerUp={onPointerUp}
           onPointerCancel={onPointerUp}>
        <canvas ref={canvasRef} className="graph-canvas" />
        <div ref={labelsRef} className="graph-labels">
          {nodesRef.current.map((n) => (
            <div key={n.id}
                 ref={(el) => { if (el) labelElsRef.current[n.id] = el; }}
                 className="tag-node"
                 data-id={n.id}
                 data-cat={n.cat}>
              <span className="glyph" />{n.id}
            </div>
          ))}
        </div>
      </div>
    );
  }

  window.Graph = Graph;
})();
